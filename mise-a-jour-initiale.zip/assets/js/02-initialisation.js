
const navButtons = document.querySelectorAll('.nav-btn');
const views = document.querySelectorAll('.view');
const title = document.getElementById('pageTitle');


navButtons.forEach(btn=>{
  btn.addEventListener('click',async()=>{
    const id = btn.dataset.view;

    if(id==='administrateur' && typeof adminSecurityRequestAccess==='function'){
      const allowed=await adminSecurityRequestAccess();
      if(!allowed) return;
    }

    showView(id,id === 'accueil' ? 'Gestion de Parc' : btn.textContent.trim(),id);
  });
});

const initialParkData = [{"registration":"HJ541TY","type":"Tracteur","parkNumber":""},{"registration":"GH682MG","type":"Tracteur","parkNumber":""},{"registration":"GR901XD","type":"Tracteur","parkNumber":""},{"registration":"HL859JP","type":"Tracteur","parkNumber":""},{"registration":"HD021SF","type":"Tracteur","parkNumber":""},{"registration":"HF378JT","type":"Tracteur","parkNumber":""},{"registration":"GH105HJ","type":"Tracteur","parkNumber":""},{"registration":"GV246SY","type":"Tracteur","parkNumber":""},{"registration":"GG980ZW","type":"Tracteur","parkNumber":""},{"registration":"HE442CG","type":"Tracteur","parkNumber":""},{"registration":"GE841ZY","type":"Tracteur","parkNumber":""},{"registration":"GE842ZY","type":"Tracteur","parkNumber":""},{"registration":"GF130GJ","type":"Tracteur","parkNumber":""},{"registration":"GF209GJ","type":"Tracteur","parkNumber":""},{"registration":"GF264BF","type":"Tracteur","parkNumber":""},{"registration":"GF546HB","type":"Tracteur","parkNumber":""},{"registration":"GF549HB","type":"Tracteur","parkNumber":""},{"registration":"GF843FH","type":"Tracteur","parkNumber":""},{"registration":"GF844FH","type":"Tracteur","parkNumber":""},{"registration":"GF845FH","type":"Tracteur","parkNumber":""},{"registration":"GG341YH","type":"Tracteur","parkNumber":""},{"registration":"GG978ZW","type":"Tracteur","parkNumber":""},{"registration":"GG979ZW","type":"Tracteur","parkNumber":""},{"registration":"GH043HM","type":"Tracteur","parkNumber":""},{"registration":"GH044HM","type":"Tracteur","parkNumber":""},{"registration":"GH082HJ","type":"Tracteur","parkNumber":""},{"registration":"GH681MG","type":"Tracteur","parkNumber":""},{"registration":"GH683MG","type":"Tracteur","parkNumber":""},{"registration":"GH684MG","type":"Tracteur","parkNumber":""},{"registration":"GH922HL","type":"Tracteur","parkNumber":""},{"registration":"GH923HL","type":"Tracteur","parkNumber":""},{"registration":"GN349FX","type":"Tracteur","parkNumber":""},{"registration":"GN463VP","type":"Tracteur","parkNumber":""},{"registration":"GN510PA","type":"Tracteur","parkNumber":""},{"registration":"GP200SB","type":"Tracteur","parkNumber":""},{"registration":"GP298VN","type":"Tracteur","parkNumber":""},{"registration":"GP309VN","type":"Tracteur","parkNumber":""},{"registration":"GQ334HM","type":"Tracteur","parkNumber":""},{"registration":"GR128QR","type":"Tracteur","parkNumber":""},{"registration":"GR259WZ","type":"Tracteur","parkNumber":""},{"registration":"GR277XH","type":"Tracteur","parkNumber":""},{"registration":"GR290GV","type":"Tracteur","parkNumber":""},{"registration":"GR296JZ","type":"Tracteur","parkNumber":""},{"registration":"GR338XH","type":"Tracteur","parkNumber":""},{"registration":"GR472GV","type":"Tracteur","parkNumber":""},{"registration":"GR784QT","type":"Tracteur","parkNumber":""},{"registration":"GR841QT","type":"Tracteur","parkNumber":""},{"registration":"GR935PW","type":"Tracteur","parkNumber":""},{"registration":"GS047GE","type":"Tracteur","parkNumber":""},{"registration":"GS048GE","type":"Tracteur","parkNumber":""},{"registration":"GS304EJ","type":"Tracteur","parkNumber":""},{"registration":"GS718BN","type":"Tracteur","parkNumber":""},{"registration":"GS722DS","type":"Tracteur","parkNumber":""},{"registration":"GS999BM","type":"Tracteur","parkNumber":""},{"registration":"GT666KY","type":"Tracteur","parkNumber":""},{"registration":"GT858KY","type":"Tracteur","parkNumber":""},{"registration":"GT943KY","type":"Tracteur","parkNumber":""},{"registration":"GV259XQ","type":"Tracteur","parkNumber":""},{"registration":"GV261XQ","type":"Tracteur","parkNumber":""},{"registration":"GV262XQ","type":"Tracteur","parkNumber":""},{"registration":"GV263XQ","type":"Tracteur","parkNumber":""},{"registration":"GV290AQ","type":"Tracteur","parkNumber":""},{"registration":"GV291AQ","type":"Tracteur","parkNumber":""},{"registration":"GV292AQ","type":"Tracteur","parkNumber":""},{"registration":"GV294AQ","type":"Tracteur","parkNumber":""},{"registration":"GV913QX","type":"Tracteur","parkNumber":""},{"registration":"GV914QX","type":"Tracteur","parkNumber":""},{"registration":"GV915QX","type":"Tracteur","parkNumber":""},{"registration":"GV974MD","type":"Tracteur","parkNumber":""},{"registration":"GV980HT","type":"Tracteur","parkNumber":""},{"registration":"GV981HT","type":"Tracteur","parkNumber":""},{"registration":"GV983HT","type":"Tracteur","parkNumber":""},{"registration":"GZ767NH","type":"Tracteur","parkNumber":""},{"registration":"GZ932NJ","type":"Tracteur","parkNumber":""},{"registration":"GZ323GG","type":"Tracteur","parkNumber":""},{"registration":"GZ324GG","type":"Tracteur","parkNumber":""},{"registration":"GZ327GG","type":"Tracteur","parkNumber":""},{"registration":"GZ587GB","type":"Tracteur","parkNumber":""},{"registration":"HD843RJ","type":"Tracteur","parkNumber":""},{"registration":"HD835SE","type":"Tracteur","parkNumber":""},{"registration":"HD814RJ","type":"Tracteur","parkNumber":""},{"registration":"HE461CG","type":"Tracteur","parkNumber":""},{"registration":"HE476CG","type":"Tracteur","parkNumber":""},{"registration":"HD863XF","type":"Tracteur","parkNumber":""},{"registration":"HE582AE","type":"Tracteur","parkNumber":""},{"registration":"HE611AE","type":"Tracteur","parkNumber":""},{"registration":"HE634AE","type":"Tracteur","parkNumber":""},{"registration":"HD295WD","type":"Tracteur","parkNumber":""},{"registration":"HD141WD","type":"Tracteur","parkNumber":""},{"registration":"HD909WC","type":"Tracteur","parkNumber":""},{"registration":"HD958SE","type":"Tracteur","parkNumber":""},{"registration":"HF418JT","type":"Tracteur","parkNumber":""},{"registration":"HF425LL","type":"Tracteur","parkNumber":""},{"registration":"HF246JT","type":"Tracteur","parkNumber":""},{"registration":"HF450JT","type":"Tracteur","parkNumber":""},{"registration":"HF538JT","type":"Tracteur","parkNumber":""},{"registration":"HF268JT","type":"Tracteur","parkNumber":""},{"registration":"HF366JT","type":"Tracteur","parkNumber":""},{"registration":"HF390LL","type":"Tracteur","parkNumber":""},{"registration":"HF402LL","type":"Tracteur","parkNumber":""},{"registration":"GG977ZW","type":"Tracteur","parkNumber":""},{"registration":"HF509JT","type":"Tracteur","parkNumber":""},{"registration":"GP098ZD","type":"Tracteur","parkNumber":""},{"registration":"GV248SY","type":"Tracteur","parkNumber":""},{"registration":"GS045GE","type":"Tracteur","parkNumber":""},{"registration":"HH295XC","type":"Tracteur","parkNumber":""},{"registration":"HH234XG","type":"Tracteur","parkNumber":""},{"registration":"GP302VN","type":"Tracteur","parkNumber":""},{"registration":"GN465VP","type":"Tracteur","parkNumber":""},{"registration":"GG208VK","type":"Tracteur","parkNumber":""},{"registration":"HJ538PR","type":"Tracteur","parkNumber":""},{"registration":"HJ717SP","type":"Tracteur","parkNumber":""},{"registration":"HJ023WH","type":"Tracteur","parkNumber":""},{"registration":"HK636FD","type":"Tracteur","parkNumber":""},{"registration":"HK982FK","type":"Tracteur","parkNumber":""},{"registration":"HK922FK","type":"Tracteur","parkNumber":""},{"registration":"HK904JG","type":"Tracteur","parkNumber":""},{"registration":"GJ262RS","type":"Tracteur","parkNumber":""},{"registration":"HK367KT","type":"Tracteur","parkNumber":""},{"registration":"HK660QC","type":"Tracteur","parkNumber":""},{"registration":"HK989QC","type":"Tracteur","parkNumber":""},{"registration":"HK057QD","type":"Tracteur","parkNumber":""},{"registration":"HK682QR","type":"Tracteur","parkNumber":""},{"registration":"HK616QR","type":"Tracteur","parkNumber":""},{"registration":"HK527QR","type":"Tracteur","parkNumber":""},{"registration":"GV293AQ","type":"Tracteur","parkNumber":""},{"registration":"GS117EJ","type":"Tracteur","parkNumber":""},{"registration":"FW266JB","type":"Tracteur","parkNumber":""},{"registration":"GV911QX","type":"Tracteur","parkNumber":""},{"registration":"GZ325NJ","type":"Tracteur","parkNumber":""},{"registration":"GP299VN","type":"Tracteur","parkNumber":""},{"registration":"GC786FX","type":"Tracteur","parkNumber":""},{"registration":"HL361JP","type":"Tracteur","parkNumber":""},{"registration":"HL730JP","type":"Tracteur","parkNumber":""},{"registration":"HL120KG","type":"Tracteur","parkNumber":""},{"registration":"GE843ZY","type":"Tracteur","parkNumber":""},{"registration":"GT763KY","type":"Tracteur","parkNumber":""},{"registration":"GC112JB","type":"Tracteur","parkNumber":""},{"registration":"HK327KT","type":"Tracteur","parkNumber":""},{"registration":"HL038KG","type":"Tracteur","parkNumber":""},{"registration":"GE839ZY","type":"Tracteur","parkNumber":""},{"registration":"GE875ZY","type":"Tracteur","parkNumber":""},{"registration":"GF847FH","type":"Tracteur","parkNumber":""},{"registration":"GW084EQ","type":"Tracteur","parkNumber":""},{"registration":"HE496CG","type":"Tracteur","parkNumber":""},{"registration":"GD135CB","type":"Tracteur","parkNumber":""},{"registration":"FS608VL","type":"Tracteur","parkNumber":""},{"registration":"DA434VE","type":"Semi","parkNumber":"10813"},{"registration":"EV704XC","type":"Semi","parkNumber":"10814"},{"registration":"EK238WZ","type":"Semi","parkNumber":"10652"},{"registration":"EK529WZ","type":"Semi","parkNumber":"10653"},{"registration":"EK544ZJ","type":"Semi","parkNumber":"10654"},{"registration":"EL782BE","type":"Semi","parkNumber":"10659"},{"registration":"ET323JK","type":"Semi","parkNumber":"10670"},{"registration":"ET665HR","type":"Semi","parkNumber":"10671"},{"registration":"ET722GM","type":"Semi","parkNumber":"10672"},{"registration":"ET986HR","type":"Semi","parkNumber":"10673"},{"registration":"EV317LE","type":"Semi","parkNumber":"10674"},{"registration":"EV609SF","type":"Semi","parkNumber":"10675"},{"registration":"EV719RW","type":"Semi","parkNumber":"10676"},{"registration":"EV920ND","type":"Semi","parkNumber":"10677"},{"registration":"EV993VW","type":"Semi","parkNumber":"10678"},{"registration":"EW279WG","type":"Semi","parkNumber":"10679"},{"registration":"EX016PM","type":"Semi","parkNumber":"10680"},{"registration":"FB024HM","type":"Semi","parkNumber":"10687"},{"registration":"FC123XW","type":"Semi","parkNumber":"10688"},{"registration":"FC271JP","type":"Semi","parkNumber":"10689"},{"registration":"FD158GZ","type":"Semi","parkNumber":"10692"},{"registration":"FD386SW","type":"Semi","parkNumber":"10694"},{"registration":"FD560ZA","type":"Semi","parkNumber":"10695"},{"registration":"FD666GY","type":"Semi","parkNumber":"10696"},{"registration":"FE415YZ","type":"Semi","parkNumber":"10697"},{"registration":"FE439RH","type":"Semi","parkNumber":"10698"},{"registration":"FE466WB","type":"Semi","parkNumber":"10699"},{"registration":"FE790ME","type":"Semi","parkNumber":"10700"},{"registration":"FE809DR","type":"Semi","parkNumber":"10701"},{"registration":"FG344CP","type":"Semi","parkNumber":"10702"},{"registration":"FG604RZ","type":"Semi","parkNumber":"10703"},{"registration":"FG833RZ","type":"Semi","parkNumber":"10705"},{"registration":"FJ092RG","type":"Semi","parkNumber":"10706"},{"registration":"FJ305RG","type":"Semi","parkNumber":"10707"},{"registration":"FJ996RF","type":"Semi","parkNumber":"10708"},{"registration":"FM017YT","type":"Semi","parkNumber":"10709"},{"registration":"FN318AE","type":"Semi","parkNumber":"10710"},{"registration":"FN391HF","type":"Semi","parkNumber":"10711"},{"registration":"FP005MT","type":"Semi","parkNumber":"10712"},{"registration":"FP020MJ","type":"Semi","parkNumber":"10713"},{"registration":"FP056MJ","type":"Semi","parkNumber":"10714"},{"registration":"FP279RM","type":"Semi","parkNumber":"10715"},{"registration":"FP299LZ","type":"Semi","parkNumber":"10716"},{"registration":"FP352HB","type":"Semi","parkNumber":"10717"},{"registration":"FP362RM","type":"Semi","parkNumber":"10718"},{"registration":"FP428QV","type":"Semi","parkNumber":"10719"},{"registration":"FP486LT","type":"Semi","parkNumber":"10720"},{"registration":"FP749PL","type":"Semi","parkNumber":"10721"},{"registration":"FP846HB","type":"Semi","parkNumber":"10722"},{"registration":"FS002MM","type":"Semi","parkNumber":"10723"},{"registration":"FS047LH","type":"Semi","parkNumber":"10724"},{"registration":"FS195ML","type":"Semi","parkNumber":"10725"},{"registration":"FS333ML","type":"Semi","parkNumber":"10726"},{"registration":"FS454ML","type":"Semi","parkNumber":"10727"},{"registration":"FS939LG","type":"Semi","parkNumber":"10728"},{"registration":"FX027RZ","type":"Semi","parkNumber":"10729"},{"registration":"FX235DZ","type":"Semi","parkNumber":"10730"},{"registration":"FX568JR","type":"Semi","parkNumber":"10731"},{"registration":"FX700MM","type":"Semi","parkNumber":"10732"},{"registration":"FX889NM","type":"Semi","parkNumber":"10733"},{"registration":"FX943DY","type":"Semi","parkNumber":"10734"},{"registration":"FX992VM","type":"Semi","parkNumber":"10735"},{"registration":"FY344SC","type":"Semi","parkNumber":"10736"},{"registration":"FY406EX","type":"Semi","parkNumber":"10737"},{"registration":"FY434KV","type":"Semi","parkNumber":"10738"},{"registration":"FY630MR","type":"Semi","parkNumber":"10739"},{"registration":"FY654RJ","type":"Semi","parkNumber":"10740"},{"registration":"FY710LP","type":"Semi","parkNumber":"10741"},{"registration":"FZ465WB","type":"Semi","parkNumber":"10742"},{"registration":"GA173YW","type":"Semi","parkNumber":"10743"},{"registration":"GA667ZN","type":"Semi","parkNumber":"10744"},{"registration":"GB312JX","type":"Semi","parkNumber":"10745"},{"registration":"GE007XT","type":"Semi","parkNumber":"10746"},{"registration":"GE607NA","type":"Semi","parkNumber":"10747"},{"registration":"GE947EM","type":"Semi","parkNumber":"10748"},{"registration":"GF547AS","type":"Semi","parkNumber":"10749"},{"registration":"GF765CC","type":"Semi","parkNumber":"10750"},{"registration":"GF775KA","type":"Semi","parkNumber":"10751"},{"registration":"GF813TL","type":"Semi","parkNumber":"10752"},{"registration":"GF874VT","type":"Semi","parkNumber":"10753"},{"registration":"GF941CC","type":"Semi","parkNumber":"10754"},{"registration":"GG081TV","type":"Semi","parkNumber":"10755"},{"registration":"GG181DT","type":"Semi","parkNumber":"10756"},{"registration":"GG326DT","type":"Semi","parkNumber":"10757"},{"registration":"GG489CS","type":"Semi","parkNumber":"10758"},{"registration":"GG550TE","type":"Semi","parkNumber":"10759"},{"registration":"GG986YT","type":"Semi","parkNumber":"10760"},{"registration":"GJ551HK","type":"Semi","parkNumber":"10761"},{"registration":"GJ610HD","type":"Semi","parkNumber":"10762"},{"registration":"GJ792FL","type":"Semi","parkNumber":"10763"},{"registration":"GJ795KQ","type":"Semi","parkNumber":"10764"},{"registration":"GJ812NQ","type":"Semi","parkNumber":"10765"},{"registration":"GM675YK","type":"Semi","parkNumber":"10766"},{"registration":"GM818YK","type":"Semi","parkNumber":"10767"},{"registration":"GM931YK","type":"Semi","parkNumber":"10768"},{"registration":"GN284SP","type":"Semi","parkNumber":"10769"},{"registration":"GN306SB","type":"Semi","parkNumber":"10770"},{"registration":"GN739CR","type":"Semi","parkNumber":"10771"},{"registration":"GN834TH","type":"Semi","parkNumber":"10772"},{"registration":"GP242AG","type":"Semi","parkNumber":"10773"},{"registration":"GP243EN","type":"Semi","parkNumber":"10774"},{"registration":"GP283RQ","type":"Semi","parkNumber":"10775"},{"registration":"GP397TZ","type":"Semi","parkNumber":"10776"},{"registration":"GP986RF","type":"Semi","parkNumber":"10777"},{"registration":"GR153QX","type":"Semi","parkNumber":"10778"},{"registration":"GR177DK","type":"Semi","parkNumber":"10779"},{"registration":"GR311QX","type":"Semi","parkNumber":"10780"},{"registration":"GR448KS","type":"Semi","parkNumber":"10781"},{"registration":"GR694KT","type":"Semi","parkNumber":"10782"},{"registration":"GR952DJ","type":"Semi","parkNumber":"10783"},{"registration":"GW573HJ","type":"Semi","parkNumber":"10784"},{"registration":"GW576ZD","type":"Semi","parkNumber":"10785"},{"registration":"GW635LF","type":"Semi","parkNumber":"10786"},{"registration":"GW731NW","type":"Semi","parkNumber":"10788"},{"registration":"GW765XB","type":"Semi","parkNumber":"10789"},{"registration":"GX247ML","type":"Semi","parkNumber":"10791"},{"registration":"EK012VG","type":"Semi","parkNumber":"10650"},{"registration":"EK216TW","type":"Semi","parkNumber":"10651"},{"registration":"EK624LY","type":"Semi","parkNumber":"10655"},{"registration":"EL020TH","type":"Semi","parkNumber":"10657"},{"registration":"EM100DW","type":"Semi","parkNumber":"10661"},{"registration":"EM391MZ","type":"Semi","parkNumber":"10662"},{"registration":"EM487KF","type":"Semi","parkNumber":"10663"},{"registration":"EM769XQ","type":"Semi","parkNumber":"10664"},{"registration":"EP333RR","type":"Semi","parkNumber":"10665"},{"registration":"EP965QB","type":"Semi","parkNumber":"10666"},{"registration":"EQ113HY","type":"Semi","parkNumber":"10667"},{"registration":"EQ370FK","type":"Semi","parkNumber":"10668"},{"registration":"EZ217DB","type":"Semi","parkNumber":"10682"},{"registration":"EZ585DB","type":"Semi","parkNumber":"10683"},{"registration":"FA558LQ","type":"Semi","parkNumber":"10684"},{"registration":"FA604LR","type":"Semi","parkNumber":"10685"},{"registration":"FA792LQ","type":"Semi","parkNumber":"10686"},{"registration":"FD009KR","type":"Semi","parkNumber":"10690"},{"registration":"FD019GD","type":"Semi","parkNumber":"10691"},{"registration":"FD238GD","type":"Semi","parkNumber":"10693"},{"registration":"EJ207GD","type":"Semi","parkNumber":"10798"},{"registration":"EJ464GD","type":"Semi","parkNumber":"10799"},{"registration":"EJ767ES","type":"Semi","parkNumber":"10800"},{"registration":"EL935NX","type":"Semi","parkNumber":"10660"},{"registration":"EX656KK","type":"Semi","parkNumber":"10681"},{"registration":"GW677XE","type":"Semi","parkNumber":"10787"},{"registration":"GX330CQ","type":"Semi","parkNumber":"10792"},{"registration":"GX807XJ","type":"Semi","parkNumber":"10794"},{"registration":"GX608ZX","type":"Semi","parkNumber":"10793"},{"registration":"GY841AK","type":"Semi","parkNumber":"10796"},{"registration":"GY165AL","type":"Semi","parkNumber":"10795"},{"registration":"HA530BB","type":"Semi","parkNumber":"10806"},{"registration":"GZ714YX","type":"Semi","parkNumber":"10807"},{"registration":"GZ636VC","type":"Semi","parkNumber":"10808"},{"registration":"GZ967PD","type":"Semi","parkNumber":"10809"},{"registration":"GZ028QT","type":"Semi","parkNumber":"10810"},{"registration":"GZ444HE","type":"Semi","parkNumber":"10811"},{"registration":"GZ538FZ","type":"Semi","parkNumber":"10812"}];

const initialDrivers = [{"name":"ABBE Eric","tractor":"GH-682-MG","semi":"DA-434-VE","number":"","phone":"06 80 47 00 34","personal":"07 65 25 33 63"},{"name":"ABDULAH Jeremy","tractor":"HK-057-QD","semi":"GF-874-VT","number":"10753","phone":"06 62 24 10 61","personal":"07 86 28 41 65"},{"name":"AFONSO Pierre","tractor":"HF-509-JT","semi":"EV-920-ND","number":"10677","phone":"06 61 65 26 78","personal":"06 13 19 33 84"},{"name":"AGASSE Frédéric","tractor":"GV-290-AQ","semi":"FY-654-RJ","number":"10740","phone":"06 61 65 26 54","personal":"07 85 02 49 38"},{"name":"ALBRAN Johan","tractor":"HD-863-XF","semi":"FX-027-RZ","number":"10729","phone":"06 61 65 26 33","personal":"06 72 09 50 85"},{"name":"ANGIBAUD Romuald","tractor":"GV-248-SY","semi":"FX-235-DZ","number":"10730","phone":"06 63 37 17 22","personal":"06 72 74 24 31"},{"name":"ARNAUD SOUMAIN Jerome","tractor":"HE-611-AE","semi":"FS-454-ML","number":"10727","phone":"06 13 45 32 13","personal":"06 72 76 52 64"},{"name":"ASSATI Teddy","tractor":"HL-120-KG","semi":"FX-700-MM","number":"10732","phone":"06 61 65 25 53","personal":"06 70 17 85 75"},{"name":"AUBRY Jean-Baptiste","tractor":"GP-298-VN","semi":"GA-173-YW","number":"10743","phone":"06 61 65 25 97","personal":"07 43 56 04 69"},{"name":"AURIOU Geoffrey","tractor":"GV-261-XQ","semi":"GY-165-AL","number":"10795","phone":"06 99 98 93 20","personal":"06 62 99 18 03"},{"name":"AZOUA Abdelazize","tractor":"HL-178-KG","semi":"ET-323-JK","number":"10670","phone":"06 62 23 45 27","personal":"06 49 61 75 11"},{"name":"BAIKRICH Romain","tractor":"GV-981-HT","semi":"FC-123-XW","number":"10688","phone":"06 61 65 25 50","personal":"06 02 25 21 79"},{"name":"BALAZS Victoria","tractor":"GZ-327-GG","semi":"EV-993-VW","number":"10678","phone":"06 12 66 94 03","personal":"06 95 53 57 45"},{"name":"BALLION Eric","tractor":"GV-911-QX","semi":"GG-986-YT","number":"10760","phone":"06 30 29 95 25","personal":"06 58 80 21 17"},{"name":"BARDET Christophe","tractor":"GZ-323-GG","semi":"GZ-967-PD","number":"10809","phone":"06 12 66 94 10","personal":"06 99 26 68 63"},{"name":"BARRY Ousmane","tractor":"GG-208-VK","semi":"EL-782-BE","number":"10659","phone":"06 62 23 19 20","personal":"06 21 41 26 82"},{"name":"BART Grégory","tractor":"GR-935-PW","semi":"FP-056-MJ","number":"10714","phone":"06 61 65 25 98","personal":"06 38 61 98 51"},{"name":"BENOIST Olivier","tractor":"GH-082-HJ","semi":"FN-318-AE","number":"10710","phone":"06 98 73 55 75","personal":"07 63 23 07 77"},{"name":"BERTHE Gwenael","tractor":"GE-842-ZY","semi":"FD-386-SW","number":"10694","phone":"06 61 65 25 31","personal":"06 32 11 63 15"},{"name":"BIMONT Christophe","tractor":"HK-682-QR","semi":"FY-630-MR","number":"10739","phone":"06 62 69 87 62","personal":"06 80 75 19 60"},{"name":"BLONDIN Pierrick","tractor":"GR-277-XH","semi":"GG-489-CS","number":"10758","phone":"06 62 70 04 62","personal":"06 59 22 64 43"},{"name":"BOTTINO Mickael","tractor":"HL-859-JP","semi":"GR-153-QX","number":"10778","phone":"06 61 65 26 97","personal":"06 37 91 44 81"},{"name":"BOUFFARTIGUES Guy","tractor":"GC-112-JB","semi":"GM-675-YK","number":"10766","phone":"06 63 37 17 26","personal":"07 68 78 23 73 / 09 84 16 00 13"},{"name":"BOULA / GROLET","tractor":"GE-839-ZY","semi":"FA-792-LQ","number":"10686","phone":"","personal":"B 06 56 67 71 45 / G 06 79 41 51 53"},{"name":"BOWE Geoffrey","tractor":"HD-835-SE","semi":"FD-666-GY","number":"10696","phone":"06 61 65 25 93","personal":"06 51 73 07 41"},{"name":"BREVET Arnaud","tractor":"GZ-587-GB","semi":"GZ-538-FZ","number":"10812","phone":"06 12 66 53 02","personal":"06 48 39 93 44"},{"name":"BROSSARD Axel","tractor":"GR-901-XD","semi":"FJ-996-RF","number":"10708","phone":"06 61 65 26 96","personal":"07 83 18 30 57"},{"name":"CAPITAINE Olivier","tractor":"GF-843-FH","semi":"FM-017-YT","number":"10709","phone":"06 85 41 29 09","personal":"06 84 96 47 20"},{"name":"CARDOSO Mickaël","tractor":"GF-845-FH","semi":"ET-665-HR","number":"10671","phone":"06 61 65 25 46","personal":"06 51 07 38 00"},{"name":"CARLIER Antoine","tractor":"HD-021-SF","semi":"FS-333-ML","number":"10726","phone":"06 61 65 25 38","personal":"07 87 39 39 67"},{"name":"CHAMORRO / PEREIRA","tractor":"GE-875-ZY","semi":"FA-558-LQ","number":"10684","phone":"06 85 41 29 05","personal":"C 06 83 98 14 47 / P 06 50 84 61 04"},{"name":"CHARLES Ludji","tractor":"GG-977-ZW","semi":"GX-807-XJ","number":"10794","phone":"06 34 48 46 60","personal":"07 82 57 78 76"},{"name":"CHARPENTIER Hervé","tractor":"HF-538-JT","semi":"GE-607-NA","number":"10747","phone":"06 61 65 25 55","personal":"06 83 71 62 57"},{"name":"CHARRON Mario","tractor":"GR-259-WZ","semi":"GP-397-TZ","number":"10776","phone":"06 72 59 65 59","personal":"06 58 50 09 85"},{"name":"CHAVET Jérémy","tractor":"HF-390-LL","semi":"HA-530-BB","number":"10806","phone":"06 61 65 26 55","personal":"06 64 36 98 07"},{"name":"CHERVET Clement","tractor":"HK-904-JG","semi":"FS-939-LG","number":"10728","phone":"06 63 12 61 62","personal":"06 40 07 77 89"},{"name":"CHTIOUI Salim","tractor":"GS-117-EJ","semi":"FG-833-RZ","number":"10705","phone":"06 98 73 55 79","personal":"06 15 78 04 53"},{"name":"COIUTTO Grégory","tractor":"HF-366-JT","semi":"EJ-767-ES","number":"10800","phone":"06 07 83 76 96","personal":"06 95 29 86 76"},{"name":"COLAERT Jonathan","tractor":"GT-763-KY","semi":"GF-813-TL","number":"10752","phone":"06 61 65 25 99","personal":"06 24 95 90 33"},{"name":"COUTURE Damien","tractor":"GG-979-ZW","semi":"FY-344-SC","number":"10736","phone":"06 85 41 30 48","personal":"06 37 07 49 32"},{"name":"CUISINIER Kelly","tractor":"GT-858-KY","semi":"GX-330-CQ","number":"10792","phone":"06 61 65 25 32","personal":"06 59 88 13 90"},{"name":"DARCQUE Eric","tractor":"GR-841-QT","semi":"EV-317-LE","number":"10674","phone":"06 82 89 27 45","personal":"06 85 33 43 89"},{"name":"DAURAT Agathe","tractor":"GV-263-XQ","semi":"GG-081-TV","number":"10755","phone":"06 62 23 01 12","personal":"06 77 50 46 20"},{"name":"DE OLIVEIRA Joao","tractor":"GF-844-FH","semi":"GN-306-SB","number":"10770","phone":"06 85 41 29 92","personal":"07 82 21 86 51"},{"name":"de VRIENDT Thierry","tractor":"HL-730-JP","semi":"FJ-092-RG","number":"10706","phone":"06 63 37 17 23","personal":"07 81 42 13 71"},{"name":"DEBOST Raphael","tractor":"HK-922-FK","semi":"GJ-610-HD","number":"10762","phone":"06 61 65 25 96","personal":"06 13 58 26 90 / 03 89 24 93 31"},{"name":"DEGRAS André","tractor":"GQ-334-HM","semi":"FE-809-DR","number":"10701","phone":"06 22 38 75 07","personal":"06 46 17 33 86"},{"name":"DERNONCOURT Bruno","tractor":"HE-461-CG","semi":"GW-677-XE","number":"10787","phone":"06 79 47 32 90","personal":"06 98 47 63 07"},{"name":"DESSEIGNE Cédric","tractor":"HF-246-JT","semi":"FD-019-GD","number":"10691","phone":"06 61 65 26 30","personal":"06 62 40 45 20 / 04 37 26 90 76"},{"name":"DHONT Erick","tractor":"GF-264-BF","semi":"GR-311-QX","number":"10780","phone":"06 61 65 25 39","personal":"06 84 62 70 87 / 09 83 26 99 81"},{"name":"DIDIER Philippe","tractor":"GS-048-GE","semi":"GP-283-RQ","number":"10775","phone":"06 61 65 26 27","personal":"06 79 60 63 00"},{"name":"DOMINGO Bonaventure","tractor":"GR-290-GV","semi":"FB-024-HM","number":"10687","phone":"07 61 62 09 69","personal":"06 10 92 17 51"},{"name":"DOMINICONE Geoffrey","tractor":"GR-128-QR","semi":"GW-765-XB","number":"10789","phone":"06 85 41 30 46","personal":"06 73 80 82 21"},{"name":"DUROZELLE Christophe","tractor":"HD-814-RJ","semi":"EZ-217-DB","number":"10682","phone":"06 61 65 26 59","personal":"06 37 38 92 96"},{"name":"EMERAUX Allan","tractor":"HE-496-CG","semi":"GZ-714-YX","number":"10807","phone":"06 98 73 55 57","personal":"06 66 54 12 09"},{"name":"FELIX Pierre","tractor":"GH-923-HL","semi":"GF-547-AS","number":"10749","phone":"06 85 41 30 76","personal":"07 81 44 22 68"},{"name":"FERRAND Charlotte","tractor":"GN-465-VP","semi":"FE-439-RH","number":"10698","phone":"06 61 65 26 61","personal":"06 60 91 81 61"},{"name":"FORTAS Marine","tractor":"GS-045-GE","semi":"FG-767-DM","number":"10704","phone":"06 63 37 17 25","personal":"07 63 55 50 97"},{"name":"FOURNET Dominique","tractor":"GH-922-HL","semi":"GM-931-YK","number":"10768","phone":"06 61 65 26 22","personal":"06 15 60 22 14"},{"name":"FRENGUIAN Patrick","tractor":"GC-786-FX","semi":"FP-428-QV","number":"10719","phone":"06 85 41 30 03","personal":"06 75 44 30 27"},{"name":"GARCIA Pedro","tractor":"HD-909-WC","semi":"FS-047-LH","number":"10724","phone":"06 98 73 55 63","personal":"06 16 15 16 12"},{"name":"GENOUDET Christophe","tractor":"GZ-932-NJ","semi":"GJ-795-KQ","number":"10764","phone":"06 98 73 55 87","personal":"06 01 35 07 90"},{"name":"GERME Ludovic","tractor":"GF-209-GJ","semi":"GF-775-KA","number":"10751","phone":"06 07 83 76 90","personal":"06 88 97 19 42"},{"name":"GIABBANI / EL BOUHOU","tractor":"GF-546-HB","semi":"EJ-464-GD","number":"10799","phone":"","personal":"E 06 61 34 63 36 / G 07 66 03 08 20"},{"name":"GOUTRY Alexandre","tractor":"GE-843-ZY","semi":"ET-722-GM","number":"10672","phone":"06 61 65 26 92","personal":"06 58 13 95 00"},{"name":"GRONDIN Olivier","tractor":"GS-047-GE","semi":"GW-731-NW","number":"10788","phone":"06 61 65 25 61","personal":"06 18 57 91 08"},{"name":"GUICHARD Cyril","tractor":"GP-299-VN","semi":"GA-667-ZN","number":"10744","phone":"07 64 17 30 09","personal":"06 14 52 50 50"},{"name":"GUYON / BENGUEDDA","tractor":"GH-044-HM","semi":"EJ-207-GD","number":"10798","phone":"06 85 41 30 81","personal":"G 06 58 82 92 54 / B 06 61 23 14 69"},{"name":"GYOKERES Michel","tractor":"GG-978-ZW","semi":"FP-362-RM","number":"10718","phone":"06 86 68 79 23","personal":"06 02 62 82 15"},{"name":"HENNER Marc","tractor":"GV-291-AQ","semi":"GG-550-TE","number":"10759","phone":"06 62 22 76 03","personal":"06 46 29 30 51"},{"name":"JACQUES Sébastien","tractor":"GS-304-EJ","semi":"GX-247-ML","number":"10791","phone":"06 98 73 55 36","personal":"06 62 61 90 81"},{"name":"JAMBON Eddy","tractor":"GR-472-GV","semi":"EK-529-WZ","number":"10653","phone":"06 61 65 26 89","personal":"07 52 18 91 59"},{"name":"JOUIN Evan","tractor":"GH-683-MG","semi":"GX-608-ZX","number":"10793","phone":"06 61 65 26 93","personal":"06 46 26 49 89"},{"name":"KIZILKILIC Cegiz","tractor":"GG-980-ZW","semi":"FY-406-EX","number":"10737","phone":"06 61 65 26 20","personal":"06 34 64 81 76"},{"name":"KOBYLESKI / POUILLY","tractor":"GD-135-CB","semi":"","number":"","phone":"","personal":"K 06 61 42 72 56 / P 06 24 54 60 89"},{"name":"KULA Erdogan","tractor":"HF-378-JT","semi":"FY-434-KV","number":"10738","phone":"06 61 65 25 64","personal":"06 31 74 09 35"},{"name":"LACROIX Damien","tractor":"GH-105-HJ","semi":"EQ-113-HY","number":"10667","phone":"06 61 65 26 95","personal":"06 69 12 20 12"},{"name":"LARTAUD Romain","tractor":"HF-450-JT","semi":"FX-992-VM","number":"10735","phone":"06 98 73 55 28","personal":"06 33 45 29 30"},{"name":"LAVOINE Roman","tractor":"GF-130-GJ","semi":"GP-243-EN","number":"10774","phone":"06 61 65 26 77","personal":"06 01 27 58 18"},{"name":"LE CAILLEC Eric","tractor":"GV-915-QX","semi":"GF-765-CC","number":"10750","phone":"06 61 65 26 21","personal":"06 29 53 76 37"},{"name":"LE COINT Daniel","tractor":"HK-616-QR","semi":"FN-391-HF","number":"10711","phone":"06 61 65 27 13","personal":"06 80 88 03 77"},{"name":"LECLAIR Marcel","tractor":"HE-442-CG","semi":"GE-007-XT","number":"10746","phone":"06 62 22 30 33","personal":"06 33 42 51 51"},{"name":"LECLERC Florian","tractor":"HD-843-RJ","semi":"FS-195-ML","number":"10725","phone":"06 63 37 17 24","personal":"06 63 00 60 09 / 03 89 26 41 20"},{"name":"LEFRANCOIS Denis","tractor":"GZ-324-GG","semi":"GZ-444-HE","number":"10811","phone":"06 34 48 03 44","personal":"06 26 73 33 60"},{"name":"LOUVET David","tractor":"GS-722-DS","semi":"FX-943-DY","number":"10734","phone":"06 61 65 26 86","personal":"06 83 86 70 83"},{"name":"LUGAND Jean-Philippe","tractor":"GV-913-QX","semi":"GX-215-XJ","number":"10790","phone":"06 61 65 25 47","personal":"07 62 05 38 68"},{"name":"LUTROT Benjamin","tractor":"GW-084-EQ","semi":"GR-448-KS","number":"10781","phone":"06 62 23 28 06","personal":"06 34 16 27 33"},{"name":"Man","tractor":"DL-734-DJ","semi":"","number":"","phone":"","personal":""},{"name":"MARGERIE Tom","tractor":"GV-294-AQ","semi":"EK-238-WZ","number":"10652","phone":"06 61 65 26 46","personal":"07 67 59 34 50"},{"name":"MARMAGNE Benjamin","tractor":"GR-784-QT","semi":"EQ-370-FK","number":"10668","phone":"06 38 12 74 15","personal":"06 21 21 03 39"},{"name":"MARTEL Jean Philippe","tractor":"GP-309-VN","semi":"EW-279-WG","number":"10679","phone":"06 98 73 55 61","personal":"06 64 36 47 08 / 04 72 57 43 72"},{"name":"MATOS Tonio","tractor":"HE-476-CG","semi":"ET-986-HR","number":"10673","phone":"06 61 65 26 98","personal":"06 86 76 21 13"},{"name":"MAZILLE John","tractor":"GV-262-XQ","semi":"EM-487-KF","number":"10663","phone":"06 98 73 55 76","personal":"06 15 35 10 01"},{"name":"MAZZALLON Christian","tractor":"GV-974-MD","semi":"GE-947-EM","number":"10748","phone":"06 61 65 27 00","personal":"06 25 05 56 33"},{"name":"MEENS Alexandre","tractor":"GS-999-BM","semi":"FE-466-WB","number":"10699","phone":"06 61 65 26 99","personal":"07 62 64 06 72"},{"name":"MHUN Stephane","tractor":"GV-914-QX","semi":"GY-841-AK","number":"10796","phone":"06 61 65 26 94","personal":"06 41 19 42 74"},{"name":"MICHEL Michael","tractor":"HE-582-AE","semi":"GR-694-KT","number":"10782","phone":"06 61 65 25 48","personal":"06 46 16 53 22"},{"name":"MONTEIRO Jose","tractor":"GN-349-FX","semi":"FP-352-HB","number":"10717","phone":"06 73 15 93 61","personal":"06 29 71 68 14"},{"name":"MONTOIS Jason","tractor":"HJ-023-WH","semi":"FX-568-JR","number":"10731","phone":"06 79 47 32 83","personal":"06 74 19 18 28"},{"name":"MOREL Gérald","tractor":"HH-295-XG","semi":"","number":"","phone":"","personal":"06 58 30 02 72"},{"name":"MORNET Jordan","tractor":"GV-293-AQ","semi":"FS-002-MM","number":"10723","phone":"06 62 22 46 14","personal":"07 69 01 13 48"},{"name":"MOURET Thierry","tractor":"GT-666-KY","semi":"GJ-792-FL","number":"10763","phone":"07 64 17 30 11","personal":"06 22 54 14 18"},{"name":"MOUTAKI Ossama","tractor":"HF-402-LL","semi":"FD-009-KR","number":"10690","phone":"06 61 65 25 49","personal":"06 19 60 18 03"},{"name":"NEVEU Antoine","tractor":"GH-043-HM","semi":"FD-238-GD","number":"10693","phone":"06 61 65 26 84","personal":"06 27 13 39 47"},{"name":"OBE Dorian","tractor":"GV-292-AQ","semi":"FP-749-PL","number":"10721","phone":"06 61 65 26 57","personal":"06 37 78 35 21"},{"name":"OLIVIER Joseph","tractor":"GT-943-KY","semi":"EM-100-DW","number":"10661","phone":"06 61 65 26 41","personal":"06 61 29 24 53"},{"name":"OTT Damien","tractor":"HD-958-SE","semi":"FD-158-GZ","number":"10692","phone":"06 61 65 26 08","personal":"06 35 90 10 45"},{"name":"PATURET Steeve","tractor":"GV-259-XQ","semi":"GP-242-AG","number":"10773","phone":"06 62 70 45 62","personal":"06 61 21 07 69"},{"name":"PAUL Franck","tractor":"FS-608-VL","semi":"EK-012-VG","number":"10650","phone":"","personal":"06 63 41 77 34"},{"name":"PAUL Vincent","tractor":"GF-847-FH","semi":"FE-790-ME","number":"10700","phone":"06 09 81 16 87","personal":"06 35 95 72 56"},{"name":"PERARD Jean Francois","tractor":"GJ-262-RS","semi":"GG-181-DT","number":"10756","phone":"06 61 65 25 91","personal":"07 83 56 07 83"},{"name":"PERNIN Lucas","tractor":"HL-038-KG","semi":"GJ-551-HK","number":"10761","phone":"06 61 65 26 40","personal":"06 11 61 07 10"},{"name":"PHILIPPE P. Athéa","tractor":"HL-361-JP","semi":"GB-312-JX","number":"10745","phone":"06 74 08 42 23","personal":"07 60 21 34 04"},{"name":"PIERREMONT Anthony","tractor":"HD-863-XF","semi":"GN-739-CR","number":"10771","phone":"06 61 65 25 41","personal":"07 70 99 29 63"},{"name":"PLATEAU François","tractor":"GZ-325-NJ","semi":"GF-941-CC","number":"10754","phone":"06 61 65 26 32","personal":"06 50 00 36 55"},{"name":"POURRAT Valentin","tractor":"HK-367-KT","semi":"GG-326-DT","number":"10757","phone":"07 64 17 30 13","personal":"07 45 25 11 08"},{"name":"REIS Baptiste","tractor":"HE-634-AE","semi":"FZ-465-WB","number":"10742","phone":"07 61 68 82 07","personal":"06 73 20 53 66"},{"name":"REIS PINHO Manuel","tractor":"HD-295-WD","semi":"FP-846-HB","number":"10722","phone":"06 61 65 25 90","personal":"06 85 19 26 83"},{"name":"RIBOTTE Dominique","tractor":"GV-246-SY","semi":"FG-604-RZ","number":"10703","phone":"06 61 65 27 02","personal":"06 50 91 48 83"},{"name":"RICHEZ Benoit","tractor":"HK-989-QC","semi":"FD-560-ZA","number":"10695","phone":"06 64 64 43 95","personal":"06 76 59 31 58"},{"name":"RICHEZ Eric","tractor":"HK-982-FK","semi":"FX-889-NM","number":"10733","phone":"06 61 65 25 42","personal":"06 62 62 35 83"},{"name":"RONZEL Grégory","tractor":"HH-234-XG","semi":"","number":"","phone":"","personal":"06 30 86 90 90"},{"name":"ROUAG Maurice","tractor":"GZ-767-NH","semi":"GZ-636-VC","number":"10808","phone":"06 63 12 45 62","personal":"06 64 00 11 56 / 04 74 80 67 13"},{"name":"RUHLAND Martin","tractor":"HK-327-KT","semi":"EK-624-LY","number":"10655","phone":"","personal":"07 49 85 08 62"},{"name":"SAINT LOUIS Thierry","tractor":"GP-200-SB","semi":"GP-986-RF","number":"10777","phone":"06 61 65 25 34","personal":"06 47 83 60 62"},{"name":"SAINT MAXIN Gaylor","tractor":"GP-098-ZD","semi":"FP-279-RM","number":"10715","phone":"06 61 65 27 09","personal":"06 21 50 35 12"},{"name":"SAMAIN Jérôme","tractor":"GG-341-YH","semi":"EK-544-ZJ","number":"10654","phone":"06 34 48 95 63","personal":"06 31 50 71 20"},{"name":"SANZ Pierre","tractor":"HK-660-QC","semi":"FG-344-CP","number":"10702","phone":"06 62 23 94 83","personal":"06 95 91 34 71"},{"name":"SAUGER Willy","tractor":"HF-425-LL","semi":"FP-299-LZ","number":"10716","phone":"06 85 41 29 97","personal":"06 87 25 00 04 / 04 27 49 34 93"},{"name":"SAUZET Jean-David","tractor":"HJ-541-TY","semi":"FP-005-MT","number":"10712","phone":"","personal":"06 48 62 68 45"},{"name":"SENSE Francky","tractor":"GS-718-BN","semi":"GZ-028-QT","number":"10810","phone":"06 61 65 26 79","personal":"06 84 36 95 85 / 03 21 01 15 11"},{"name":"SICLER Mickael","tractor":"HF-418-JT","semi":"GW-573-HJ","number":"10784","phone":"06 79 47 32 82","personal":"06 22 30 32 93"},{"name":"SIMONS Allan","tractor":"GH-681-MG","semi":"GR-177-DK","number":"10779","phone":"06 61 65 26 42","personal":"06 42 72 54 33"},{"name":"SOLD Jean Louis","tractor":"HJ-717-SP","semi":"GJ-812-NQ","number":"10765","phone":"06 61 65 26 29","personal":"06 20 54 39 92 / 03 88 94 72 97"},{"name":"SOUBEYRAND Juan","tractor":"HF-268-JT","semi":"GN-834-TH","number":"10772","phone":"07 64 17 30 15","personal":"06 08 85 66 93 / 04 77 33 69 45"},{"name":"STUDER Marc","tractor":"GV-983-HT","semi":"FY-710-LP","number":"10741","phone":"06 61 65 26 90","personal":"06 68 42 72 14"},{"name":"TAILLARD Samuel","tractor":"GV-980-HT","semi":"GM-818-YK","number":"10767","phone":"06 61 65 26 88","personal":"06 72 90 52 89"},{"name":"TINE Thomas","tractor":"GH-684-MG","semi":"FJ-305-RG","number":"10707","phone":"06 61 65 26 74","personal":"07 55 75 99 16"},{"name":"TIXIER Ludovic","tractor":"GN-463-VP","semi":"EX-016-PM","number":"10680","phone":"06 62 22 09 97","personal":"06 17 19 09 86"},{"name":"TORTIELLO Damien","tractor":"GR-296-JZ","semi":"EV-609-SF","number":"10675","phone":"06 62 22 60 92","personal":"06 58 03 85 47"},{"name":"TSCHIRRET Lionel","tractor":"GN-510-PA","semi":"GN-284-SP","number":"10769","phone":"06 61 65 26 70","personal":"06 49 42 26 16 / 03 88 80 47 16"},{"name":"VANECHOP Rodolphe","tractor":"GR-338-XH","semi":"GW-635-LF","number":"10786","phone":"06 34 48 95 41","personal":"06 68 67 02 41"},{"name":"VERCOUTRE Eddy","tractor":"HD-141-WD","semi":"EL-020-TH","number":"10657","phone":"06 61 65 26 04","personal":"06 23 72 52 12"},{"name":"VIGNERON Arnaud","tractor":"HK-636-FD","semi":"GR-952-DJ","number":"10783","phone":"06 61 65 26 47","personal":"06 59 28 97 02"},{"name":"VIRFOLLET Eric","tractor":"GF-549-HB","semi":"GW-576-ZD","number":"10785","phone":"06 61 65 26 85","personal":"06 16 63 05 91 / 02 43 45 61 48"},{"name":"VIVIN Margot","tractor":"HK-527-QR","semi":"FP-486-LT","number":"10720","phone":"06 61 65 25 56","personal":"07 72 03 38 91"},{"name":"VOSKERITCHAN Stéphane","tractor":"GE-841-ZY","semi":"EM-391-MZ","number":"10662","phone":"06 98 73 56 76","personal":"06 60 55 42 70"},{"name":"YE Etienne","tractor":"HJ-538-PR","semi":"","number":"","phone":"06 85 41 29 69","personal":"06 76 67 61 33"},{"name":"ZAK Vladimir","tractor":"GP-302-VN","semi":"EV-719-RW","number":"10676","phone":"06 61 65 26 18","personal":"06 59 45 31 31"}];

const PARK_STORAGE_KEY = 'hessers-parc-data-v3';
const AFFECT_STORAGE_KEY = 'hessers-affectations-data-v3';

// Préparé pour une future base partagée.
// Pour l'instant le dashboard reste autonome et utilise le stockage local du navigateur.
const DATA_BACKEND = {
  mode: 'local',
  apiBaseUrl: ''
};
let parkData = initialParkData.map(item=>({...item}));

try{
  const storedParkData = JSON.parse(localStorage.getItem(PARK_STORAGE_KEY));
  if(Array.isArray(storedParkData) && storedParkData.every(item=>
    item && typeof item.registration === 'string' && ['Tracteur','Semi'].includes(item.type)
  )){
    parkData = storedParkData;
  }
}catch(error){
  console.warn('Les données locales du parc sont indisponibles.',error);
}

let affectations = initialDrivers.map(item=>({...item}));

try{
  const storedAffectations = JSON.parse(localStorage.getItem(AFFECT_STORAGE_KEY));
  if(Array.isArray(storedAffectations) && storedAffectations.every(item=>item && typeof item.name === 'string')){
    affectations = storedAffectations;
  }
}catch(error){
  console.warn('Les données locales des affectations sont indisponibles.',error);
}

const parkTable = document.getElementById('parkTable');
const parkSearch = document.getElementById('parkSearch');
const parkTypeFilter = document.getElementById('parkTypeFilter');
const parkResultCount = document.getElementById('parkResultCount');
const rowActionsMenu = document.getElementById('rowActionsMenu');
const editVehicleOption = document.getElementById('editVehicleOption');
const deleteVehicleOption = document.getElementById('deleteVehicleOption');
const editVehicleModal = document.getElementById('editVehicleModal');
const editVehicleForm = document.getElementById('editVehicleForm');
const editVehicleRegistration = document.getElementById('editVehicleRegistration');
const editVehicleType = document.getElementById('editVehicleType');
const editVehicleParkNumber = document.getElementById('editVehicleParkNumber');
const editParkNumberField = document.getElementById('editParkNumberField');
const editVehicleError = document.getElementById('editVehicleError');
const addVehicleModal = document.getElementById('addVehicleModal');
const addVehicleForm = document.getElementById('addVehicleForm');
const newVehicleRegistration = document.getElementById('newVehicleRegistration');
const newVehicleType = document.getElementById('newVehicleType');
const newVehicleParkNumber = document.getElementById('newVehicleParkNumber');
const parkNumberField = document.getElementById('parkNumberField');
const addVehicleError = document.getElementById('addVehicleError');
const deleteVehicleModal = document.getElementById('deleteVehicleModal');
const deleteVehicleRegistration = document.getElementById('deleteVehicleRegistration');

let activeParkRegistration = null;
let activeActionButton = null;
let pendingDeleteRegistration = null;
let editingOriginalRegistration = null;

const parkTypeOrder = {Tracteur:0,Semi:1};
const normalizeParkText = value=>String(value).toLocaleLowerCase('fr').replace(/[^a-z0-9]/g,'');
const normalizeRegistration = value=>String(value).toUpperCase().replace(/[^A-Z0-9]/g,'');
const formatRegistration = value=>{
  const registration = normalizeRegistration(value);
  const parts = registration.match(/^([A-Z]{2})(\d{3})([A-Z]{0,2})$/);
  return parts ? [parts[1],parts[2],parts[3]].filter(Boolean).join('-') : registration;
};


parkSearch.addEventListener('input',renderParkTable);
parkTypeFilter.addEventListener('change',renderParkTable);

parkTable.addEventListener('click',event=>{
  const actionButton = event.target.closest('.row-menu');
  if(actionButton){
    event.stopPropagation();
    openRowActionsMenu(actionButton,actionButton.dataset.registration);
    return;
  }

  const row = event.target.closest('tr[data-registration]');
  if(!row) return;
  closeRowActionsMenu();
  parkTable.querySelectorAll('tr').forEach(item=>item.classList.remove('selected'));
  row.classList.add('selected');
});

editVehicleOption.addEventListener('click',()=>{
  if(!activeParkRegistration) return;
  const registration = activeParkRegistration;
  closeRowActionsMenu();
  openEditVehicleModal(registration);
});

deleteVehicleOption.addEventListener('click',()=>{
  if(!activeParkRegistration) return;
  const registration = activeParkRegistration;
  closeRowActionsMenu();
  openDeleteVehicleModal(registration);
});


editVehicleType.addEventListener('change',updateEditParkNumberField);

editVehicleRegistration.addEventListener('input',()=>{
  let value = editVehicleRegistration.value.toUpperCase().replace(/[^A-Z0-9-]/g,'').replace(/-{2,}/g,'-');
  const registration = normalizeRegistration(value);
  if(!value.includes('-') && registration.length >= 5) value = formatRegistration(registration);
  editVehicleRegistration.value = value;
});

editVehicleRegistration.addEventListener('blur',()=>{
  const registration = normalizeRegistration(editVehicleRegistration.value);
  if(registration.length >= 5) editVehicleRegistration.value = formatRegistration(registration);
});

editVehicleParkNumber.addEventListener('input',()=>{
  editVehicleParkNumber.value = editVehicleParkNumber.value.replace(/\D/g,'');
});

editVehicleForm.addEventListener('submit',event=>{
  event.preventDefault();
  if(!editingOriginalRegistration) return;

  const registration = normalizeRegistration(editVehicleRegistration.value);
  const type = editVehicleType.value;
  const parkNumber = type === 'Semi' ? editVehicleParkNumber.value.trim() : '';

  if(registration.length < 2){
    editVehicleError.textContent = 'Saisissez une immatriculation valide.';
    return;
  }

  if(parkData.some(item=>
    normalizeRegistration(item.registration) === registration &&
    normalizeRegistration(item.registration) !== editingOriginalRegistration
  )){
    editVehicleError.textContent = 'Cette immatriculation existe déjà dans le parc.';
    return;
  }

  if(type === 'Semi' && !parkNumber){
    editVehicleError.textContent = 'Le numéro de parc est obligatoire pour une semi-remorque.';
    return;
  }

  if(parkNumber && parkData.some(item=>
    String(item.parkNumber) === parkNumber &&
    normalizeRegistration(item.registration) !== editingOriginalRegistration
  )){
    editVehicleError.textContent = 'Ce numéro de parc est déjà utilisé.';
    return;
  }

  const item = parkData.find(vehicle=>normalizeRegistration(vehicle.registration) === editingOriginalRegistration);
  if(!item) return;

  const oldRegistration = item.registration;
  item.registration = registration;
  item.type = type;
  item.parkNumber = parkNumber;

  propagateVehicleChange(oldRegistration,registration,type,parkNumber);
  saveParkData();
  saveAffectations();

  closeEditVehicleModal();
  renderParkTable();
  renderAffectations();
});

document.getElementById('closeEditVehicle').addEventListener('click',closeEditVehicleModal);
document.getElementById('cancelEditVehicle').addEventListener('click',closeEditVehicleModal);
editVehicleModal.addEventListener('click',event=>{
  if(event.target === editVehicleModal) closeEditVehicleModal();
});

document.getElementById('confirmDeleteVehicle').addEventListener('click',()=>{
  if(!pendingDeleteRegistration) return;
  const index = parkData.findIndex(item=>item.registration === pendingDeleteRegistration);
  if(index !== -1){
    const removed=parkData.splice(index,1)[0];
    if(!saveParkData()){parkData.splice(index,0,removed);return;}
    window.dashboardOfferUndo?.('Véhicule supprimé',()=>{
      if(parkData.some(row=>normalizeRegistration(row.registration)===normalizeRegistration(removed.registration)))return false;
      parkData.splice(Math.min(index,parkData.length),0,removed);
      if(!saveParkData()){parkData.splice(parkData.indexOf(removed),1);return false;}
      renderParkTable();renderAffectations();return true;
    });
    renderParkTable();
    renderAffectations();
  }
  closeDeleteVehicleModal();
});

document.getElementById('openAffectations').addEventListener('click',()=>{
  closeRowActionsMenu();
  showView('affectations','Affectations','parc');
});
document.getElementById('backToPark').addEventListener('click',()=>{
  showView('parc','Parc','parc');
});
document.getElementById('addParkVehicle').addEventListener('click',openAddVehicleModal);
document.getElementById('closeAddVehicle').addEventListener('click',closeAddVehicleModal);
document.getElementById('cancelAddVehicle').addEventListener('click',closeAddVehicleModal);
document.getElementById('closeDeleteVehicle').addEventListener('click',closeDeleteVehicleModal);
document.getElementById('cancelDeleteVehicle').addEventListener('click',closeDeleteVehicleModal);
newVehicleType.addEventListener('change',updateParkNumberField);

newVehicleRegistration.addEventListener('input',()=>{
  let value = newVehicleRegistration.value.toUpperCase().replace(/[^A-Z0-9-]/g,'').replace(/-{2,}/g,'-');
  const registration = normalizeRegistration(value);
  if(!value.includes('-') && registration.length >= 5) value = formatRegistration(registration);
  newVehicleRegistration.value = value;
});

newVehicleRegistration.addEventListener('blur',()=>{
  const registration = normalizeRegistration(newVehicleRegistration.value);
  if(registration.length >= 5) newVehicleRegistration.value = formatRegistration(registration);
});

newVehicleParkNumber.addEventListener('input',()=>{
  newVehicleParkNumber.value = newVehicleParkNumber.value.replace(/\D/g,'');
});

addVehicleForm.addEventListener('submit',event=>{
  event.preventDefault();
  const registration = normalizeRegistration(newVehicleRegistration.value);
  const type = newVehicleType.value;
  const parkNumber = type === 'Semi' ? newVehicleParkNumber.value.trim() : '';

  if(registration.length < 2){
    addVehicleError.textContent = 'Saisissez une immatriculation valide.';
    newVehicleRegistration.focus();
    return;
  }
  if(parkData.some(item=>normalizeRegistration(item.registration) === registration)){
    addVehicleError.textContent = 'Cette immatriculation existe déjà dans le parc.';
    newVehicleRegistration.focus();
    return;
  }
  if(type === 'Semi' && !parkNumber){
    addVehicleError.textContent = 'Le numéro de parc est obligatoire pour une semi-remorque.';
    newVehicleParkNumber.focus();
    return;
  }
  if(parkNumber && parkData.some(item=>String(item.parkNumber) === parkNumber)){
    addVehicleError.textContent = 'Ce numéro de parc est déjà utilisé.';
    newVehicleParkNumber.focus();
    return;
  }

  parkData.push({registration,type,parkNumber});
  saveParkData();
  parkSearch.value = '';
  parkTypeFilter.value = '';
  closeAddVehicleModal();
  renderParkTable();
});

document.addEventListener('click',event=>{
  if(!rowActionsMenu.hidden && !rowActionsMenu.contains(event.target) && !event.target.closest('.row-menu')) closeRowActionsMenu();
});

window.addEventListener('resize',closeRowActionsMenu);
window.addEventListener('scroll',closeRowActionsMenu,true);
navButtons.forEach(button=>button.addEventListener('click',closeRowActionsMenu));

addVehicleModal.addEventListener('click',event=>{
  if(event.target === addVehicleModal) closeAddVehicleModal();
});
deleteVehicleModal.addEventListener('click',event=>{
  if(event.target === deleteVehicleModal) closeDeleteVehicleModal();
});

document.addEventListener('keydown',event=>{
  if(event.key !== 'Escape') return;
  if(!deleteAssignmentModal.hidden) closeDeleteAssignmentModal();
  else if(!editAssignmentModal.hidden) closeEditAssignmentModal();
  else if(!addAssignmentModal.hidden) closeAddAssignmentModal();
  else if(!deleteVehicleModal.hidden) closeDeleteVehicleModal();
  else if(!editVehicleModal.hidden) closeEditVehicleModal();
  else if(!addVehicleModal.hidden) closeAddVehicleModal();
  else{
    closeAffectationActionsMenu();
    closeRowActionsMenu();
  }
});


document.getElementById('exportParkCsv').addEventListener('click',()=>{
  const rows = [...parkData]
    .sort((a,b)=>
      (parkTypeOrder[a.type] ?? 99) - (parkTypeOrder[b.type] ?? 99) ||
      normalizeRegistration(a.registration).localeCompare(normalizeRegistration(b.registration),'fr',{numeric:true})
    )
    .map(item=>[formatRegistration(item.registration),item.type,item.parkNumber || '']);
  downloadCsv('Parc_vehicules.csv',['Immatriculation','Type','N° de parc'],rows);
});

document.getElementById('exportAssignmentsCsv').addEventListener('click',()=>{
  const rows = [...affectations]
    .sort((a,b)=>a.name.localeCompare(b.name,'fr',{sensitivity:'base'}))
    .map(item=>[
      item.name,
      item.tractor ? formatRegistration(item.tractor) : '',
      item.semi ? formatRegistration(item.semi) : '',
      item.number || '',
      item.phone || '',
      item.personal || ''
    ]);
  downloadCsv('Affectations.csv',['Chauffeur','Tracteur','Semi','N°','Téléphone pro','N° personnel'],rows);
});


const affTable = document.getElementById('affTable');
const affSearch = document.getElementById('affSearch');
const affCount = document.getElementById('affCount');
const affTotal = document.getElementById('affTotal');
const affAssigned = document.getElementById('affAssigned');
const affUnassigned = document.getElementById('affUnassigned');
const affIssues = document.getElementById('affIssues');
const affName = document.getElementById('affName');
const affTractor = document.getElementById('affTractor');
const affSemi = document.getElementById('affSemi');
const affNumber = document.getElementById('affNumber');
const affPhone = document.getElementById('affPhone');
const affPersonal = document.getElementById('affPersonal');
const affNotice = document.getElementById('affNotice');
const saveAssignment = document.getElementById('saveAssignment');
const selectedDriverName = document.getElementById('selectedDriverName');
const addAssignmentButton = document.getElementById('addAssignment');
const addAssignmentModal = document.getElementById('addAssignmentModal');
const addAssignmentForm = document.getElementById('addAssignmentForm');
const newAssignmentName = document.getElementById('newAssignmentName');
const newAssignmentTractor = document.getElementById('newAssignmentTractor');
const newAssignmentSemi = document.getElementById('newAssignmentSemi');
const newAssignmentNumber = document.getElementById('newAssignmentNumber');
const newAssignmentPhone = document.getElementById('newAssignmentPhone');
const newAssignmentPersonal = document.getElementById('newAssignmentPersonal');
const addAssignmentError = document.getElementById('addAssignmentError');
const affectationActionsMenu = document.getElementById('affectationActionsMenu');
const editAffectationOption = document.getElementById('editAffectationOption');
const deleteAffectationOption = document.getElementById('deleteAffectationOption');
const editAssignmentModal = document.getElementById('editAssignmentModal');
const deleteAssignmentModal = document.getElementById('deleteAssignmentModal');
const deleteAssignmentName = document.getElementById('deleteAssignmentName');

let selectedAffectationIndex = -1;
let activeAffectationIndex = -1;
let activeAffectationActionButton = null;
let pendingDeleteAffectationIndex = -1;


affSearch.addEventListener('input',renderAffectations);

affName.addEventListener('change',()=>{
  selectedDriverName.textContent=affName.value || 'Aucun chauffeur sélectionné';
  affNotice.textContent='';
});

affTable.addEventListener('click',event=>{
  const actionButton = event.target.closest('.affectation-row-menu');
  if(actionButton){
    event.stopPropagation();
    openAffectationActionsMenu(actionButton,Number(actionButton.dataset.index));
    return;
  }

  if(event.target.closest('tr[data-index]')){
    closeAffectationActionsMenu();
  }
});

affSemi.addEventListener('change',()=>{
  const normalized = normalizeRegistration(affSemi.value);
  if(!normalized){
    affNumber.value = '';
    return;
  }
  const semi = parkData.find(item=>item.type === 'Semi' && normalizeRegistration(item.registration) === normalized);
  if(semi && semi.parkNumber) affNumber.value = semi.parkNumber;
});


addAssignmentButton.addEventListener('click',openAddAssignmentModal);
document.getElementById('closeAddAssignment').addEventListener('click',closeAddAssignmentModal);
document.getElementById('cancelAddAssignment').addEventListener('click',closeAddAssignmentModal);

newAssignmentSemi.addEventListener('change',()=>{
  const normalized = normalizeRegistration(newAssignmentSemi.value);
  if(!normalized){
    newAssignmentNumber.value = '';
    return;
  }
  const semi = parkData.find(item=>item.type === 'Semi' && normalizeRegistration(item.registration) === normalized);
  newAssignmentNumber.value = semi && semi.parkNumber ? semi.parkNumber : '';
});

newAssignmentNumber.addEventListener('input',()=>{
  newAssignmentNumber.value = newAssignmentNumber.value.replace(/\D/g,'');
});

addAssignmentForm.addEventListener('submit',event=>{
  event.preventDefault();
  const name = newAssignmentName.value.trim().replace(/\s+/g,' ');
  const normalizedName = normalizeAffText(name);

  if(!name){
    addAssignmentError.textContent = 'Sélectionnez un chauffeur.';
    newAssignmentName.focus();
    return;
  }
  if(!driverAllowsMultipleAssignments(name) && affectations.some(item=>normalizeAffText(item.name) === normalizedName)){
    addAssignmentError.textContent = 'Ce chauffeur possède déjà une affectation. Seuls les chauffeurs Régionaux peuvent avoir plusieurs affectations.';
    newAssignmentName.focus();
    return;
  }

  const newItem = {
    name,
    tractor: newAssignmentTractor.value ? formatRegistration(newAssignmentTractor.value) : '',
    semi: newAssignmentSemi.value ? formatRegistration(newAssignmentSemi.value) : '',
    number: newAssignmentNumber.value.trim(),
    phone: newAssignmentPhone.value.trim(),
    personal: newAssignmentPersonal.value.trim()
  };

  const assignmentError=dashboardValidateAssignment(newItem,-1);
  if(assignmentError){
    addAssignmentError.textContent=assignmentError;
    return;
  }

  affectations.push(newItem);
  affectations.sort((a,b)=>a.name.localeCompare(b.name,'fr',{sensitivity:'base'}));
  selectedAffectationIndex = -1;
  saveAffectations();

  affSearch.value = '';
  closeAddAssignmentModal();
  renderAffectations();
});

addAssignmentModal.addEventListener('click',event=>{
  if(event.target === addAssignmentModal) closeAddAssignmentModal();
});

editAffectationOption.addEventListener('click',()=>{
  if(activeAffectationIndex < 0) return;
  const index = activeAffectationIndex;
  closeAffectationActionsMenu();
  openEditAssignmentModal(index);
});

deleteAffectationOption.addEventListener('click',()=>{
  if(activeAffectationIndex < 0) return;
  const index = activeAffectationIndex;
  closeAffectationActionsMenu();
  openDeleteAssignmentModal(index);
});

document.getElementById('confirmDeleteAssignment').addEventListener('click',()=>{
  if(pendingDeleteAffectationIndex < 0 || !affectations[pendingDeleteAffectationIndex]) return;

  const deletedIndex = pendingDeleteAffectationIndex;
  const removed=affectations.splice(deletedIndex,1)[0];
  const saved = saveAffectations();
  if(!saved){affectations.splice(deletedIndex,0,removed);return;}
  window.dashboardOfferUndo?.('Affectation supprimée',()=>{
    if(affectations.some(row=>
      (removed.tractor&&normalizeRegistration(row.tractor)===normalizeRegistration(removed.tractor)) ||
      (removed.semi&&normalizeRegistration(row.semi)===normalizeRegistration(removed.semi)) ||
      (!driverAllowsMultipleAssignments(removed.name)&&normalizeAffText(row.name)===normalizeAffText(removed.name))
    ))return false;
    affectations.splice(Math.min(deletedIndex,affectations.length),0,removed);
    if(!saveAffectations()){affectations.splice(affectations.indexOf(removed),1);return false;}
    renderAffectations();renderParkTable();return true;
  });

  if(selectedAffectationIndex === deletedIndex){
    clearSelectedAffectation();
  }else if(selectedAffectationIndex > deletedIndex){
    selectedAffectationIndex -= 1;
  }

  selectedAffectationIndex = -1;
  closeDeleteAssignmentModal();
  renderAffectations();
});

document.getElementById('closeEditAssignment').addEventListener('click',closeEditAssignmentModal);
document.getElementById('cancelEditAssignment').addEventListener('click',closeEditAssignmentModal);
editAssignmentModal.addEventListener('click',event=>{
  if(event.target === editAssignmentModal) closeEditAssignmentModal();
});

document.getElementById('closeDeleteAssignment').addEventListener('click',closeDeleteAssignmentModal);
document.getElementById('cancelDeleteAssignment').addEventListener('click',closeDeleteAssignmentModal);
deleteAssignmentModal.addEventListener('click',event=>{
  if(event.target === deleteAssignmentModal) closeDeleteAssignmentModal();
});

document.addEventListener('click',event=>{
  if(!affectationActionsMenu.hidden &&
     !affectationActionsMenu.contains(event.target) &&
     !event.target.closest('.affectation-row-menu')){
    closeAffectationActionsMenu();
  }
});

window.addEventListener('resize',closeAffectationActionsMenu);
window.addEventListener('scroll',closeAffectationActionsMenu,true);
navButtons.forEach(button=>button.addEventListener('click',closeAffectationActionsMenu));

saveAssignment.addEventListener('click',()=>{
  const item = affectations[selectedAffectationIndex];
  if(!item) return;

  const selectedName=String(affName.value||'').trim();
  if(!selectedName){
    affNotice.style.color='#ff7373';
    affNotice.textContent='Sélectionnez un chauffeur.';
    affName.focus();
    return;
  }

  const duplicateDriver=!driverAllowsMultipleAssignments(selectedName) && affectations.some((other,index)=>
    index!==selectedAffectationIndex && normalizeAffText(other.name)===normalizeAffText(selectedName)
  );
  if(duplicateDriver){
    affNotice.style.color='#ff7373';
    affNotice.textContent='Ce chauffeur possède déjà une affectation. Seuls les chauffeurs Régionaux peuvent avoir plusieurs affectations.';
    affName.focus();
    return;
  }

  const candidate={
    ...item,
    name:selectedName,
    tractor:affTractor.value ? formatRegistration(affTractor.value) : '',
    semi:affSemi.value ? formatRegistration(affSemi.value) : '',
    number:affNumber.value.trim(),
    phone:affPhone.value.trim(),
    personal:affPersonal.value.trim()
  };

  const assignmentError=dashboardValidateAssignment(candidate,selectedAffectationIndex);
  if(assignmentError){
    alert(assignmentError);
    return;
  }

  Object.assign(item,candidate);
  affectations.sort((a,b)=>a.name.localeCompare(b.name,'fr',{sensitivity:'base'}));

  saveAffectations();
  closeEditAssignmentModal();
  renderAffectations();
});


renderParkTable();
populateVehicleSelects();
populateNewAssignmentSelects();
renderAffectations();
setAffectationFieldsDisabled(true);


/* ===== PAGE CHAUFFEUR ===== */
const DRIVER_STORAGE_KEY = 'hessers-driver-profiles-v1';


let driverProfiles = [];
try{
  const storedDrivers = JSON.parse(localStorage.getItem(DRIVER_STORAGE_KEY));
  if(Array.isArray(storedDrivers)){
    driverProfiles = storedDrivers;
  }
}catch(error){
  console.warn('Impossible de lire les fiches chauffeurs.',error);
}
if(!driverProfiles.length){
  driverProfiles = seedDriversFromAffectations();
}

// Mise à niveau des fiches déjà enregistrées :
// - ajout de la ville de naissance
// - récupération du téléphone depuis Affectations lorsqu'il est vide
const affectationPhoneByName = new Map(
  affectations.map(item=>[
    normalizeAffText(item.name),
    String(item.phone || '').trim()
  ])
);
let driverProfilesMigrated = false;
const DRIVER_STATUSES={titulaire:'Titulaire',regional:'Régional',jockey:'Jockey',inactive:'Inactif'};


driverProfiles.forEach(driver=>{
  const normalizedStatus=normalizeDriverStatus(driver.status);
  if(driver.status!==normalizedStatus){
    driver.status=normalizedStatus;
    driverProfilesMigrated=true;
  }
  if(typeof driver.birthCity !== 'string'){
    driver.birthCity = '';
    driverProfilesMigrated = true;
  }
  if(typeof driver.birthPostalCode !== 'string'){
    driver.birthPostalCode = '';
    driverProfilesMigrated = true;
  }
  if(!String(driver.phone || '').trim()){
    const key = normalizeAffText(`${driver.lastName} ${driver.firstName}`);
    const phone = affectationPhoneByName.get(key);
    if(phone){
      driver.phone = phone;
      driverProfilesMigrated = true;
    }
  }
  delete driver.fimoExpiry;
  delete driver.medicalExpiry;
  delete driver.adrExpiry;
});
if(driverProfilesMigrated){
  try{
    localStorage.setItem(DRIVER_STORAGE_KEY,JSON.stringify(driverProfiles));
  }catch(error){}
}


const driverList = document.getElementById('driverList');


const driverSearch = document.getElementById('driverSearch');
const driverStatusFilter = document.getElementById('driverStatusFilter');
const driverListCount = document.getElementById('driverListCount');
const driverEmptyState = document.getElementById('driverEmptyState');
const driverDetailContent = document.getElementById('driverDetailContent');
const driverDetailName = document.getElementById('driverDetailName');
const driverBigAvatar = document.getElementById('driverBigAvatar');
const driverLastName = document.getElementById('driverLastName');
const driverFirstName = document.getElementById('driverFirstName');
const driverStatus = document.getElementById('driverStatus');
const driverBirthDate = document.getElementById('driverBirthDate');
const driverBirthCity = document.getElementById('driverBirthCity');
const driverBirthPostalCode = document.getElementById('driverBirthPostalCode');
const driverPhone = document.getElementById('driverPhone');
const driverAddress = document.getElementById('driverAddress');
const driverPostalCode = document.getElementById('driverPostalCode');
const driverCity = document.getElementById('driverCity');
const driverLicenseNumber = document.getElementById('driverLicenseNumber');
const driverLicenseIssueDate = document.getElementById('driverLicenseIssueDate');
const driverLicenseExpiry = document.getElementById('driverLicenseExpiry');
const driverSaveNotice = document.getElementById('driverSaveNotice');
const saveDriverButton = document.getElementById('saveDriver');
const editDriverButton = document.getElementById('editDriver');
const cancelDriverEditButton = document.getElementById('cancelDriverEdit');

const driverActionsMenu = document.getElementById('driverActionsMenu');
const deleteDriverOption = document.getElementById('deleteDriverOption');
const addDriverModal = document.getElementById('addDriverModal');
const addDriverForm = document.getElementById('addDriverForm');
const newDriverLastName = document.getElementById('newDriverLastName');
const newDriverFirstName = document.getElementById('newDriverFirstName');
const newDriverStatus = document.getElementById('newDriverStatus');
const newDriverBirthDate = document.getElementById('newDriverBirthDate');
const newDriverBirthCity = document.getElementById('newDriverBirthCity');
const newDriverBirthPostalCode = document.getElementById('newDriverBirthPostalCode');
const newDriverPhone = document.getElementById('newDriverPhone');
const newDriverAddress = document.getElementById('newDriverAddress');
const newDriverPostalCode = document.getElementById('newDriverPostalCode');
const newDriverCity = document.getElementById('newDriverCity');
const newDriverLicenseNumber = document.getElementById('newDriverLicenseNumber');
const newDriverLicenseIssueDate = document.getElementById('newDriverLicenseIssueDate');
const newDriverLicenseExpiry = document.getElementById('newDriverLicenseExpiry');
const addDriverError = document.getElementById('addDriverError');
const deleteDriverModal = document.getElementById('deleteDriverModal');
const deleteDriverName = document.getElementById('deleteDriverName');

let selectedDriverId = null;
let activeDriverId = null;
let activeDriverMenuButton = null;
let pendingDeleteDriverId = null;
let driverEditMode = false;

const driverEditableFields = [
  driverLastName,
  driverFirstName,
  driverStatus,
  driverBirthDate,
  driverBirthCity,
  driverBirthPostalCode,
  driverPhone,
  driverAddress,
  driverPostalCode,
  driverCity,
  driverLicenseNumber,
  driverLicenseIssueDate,
  driverLicenseExpiry
].filter(Boolean);


driverList.addEventListener('click',event=>{
  const menuButton = event.target.closest('[data-driver-menu]');
  if(menuButton){
    event.stopPropagation();
    openDriverActionsMenu(menuButton,menuButton.dataset.driverMenu);
    return;
  }

  const item = event.target.closest('[data-driver-id]');
  if(!item) return;
  if(window.dashboardAllowLeave && !window.dashboardAllowLeave())return;
  closeDriverActionsMenu();
  selectedDriverId = item.dataset.driverId;
  renderDriverList();
  fillDriverForm();
});

driverSearch.addEventListener('input',renderDriverList);
driverStatusFilter?.addEventListener('change',renderDriverList);

driverPostalCode.addEventListener('input',()=>{
  driverPostalCode.value = driverPostalCode.value.replace(/\D/g,'').slice(0,5);
});

editDriverButton?.addEventListener('click',()=>{
  if(!getSelectedDriver()) return;
  setDriverEditMode(true);
  driverSaveNotice.style.color = '#8e98a2';
  driverSaveNotice.textContent = 'Modification activée.';
  driverLastName.focus();
});

cancelDriverEditButton?.addEventListener('click',()=>{
  fillDriverForm();
});

saveDriverButton.addEventListener('click',()=>{
  const item = getSelectedDriver();
  if(!item) return;

  const nextStatus=normalizeDriverStatus(driverStatus.value);
  const currentName=driverDisplayName(item);
  const leaving=nextStatus==='inactive' && normalizeDriverStatus(item.status)!=='inactive';
  const previousProfile=JSON.parse(JSON.stringify(item));
  const departureRows=leaving?affectations.filter(row=>normalizeAffText(row.name)===normalizeAffText(currentName)):[];
  const release=departureRows.length>0 && confirm(`Ce chauffeur quitte l'entreprise. Libérer ses ${departureRows.length} affectation(s) ?\n\nOK : libérer les véhicules et conserver les affectations dans son historique.\nAnnuler : garder ses affectations actuelles.`);
  const assignmentCount=affectations.filter(assignment=>normalizeAffText(assignment.name)===normalizeAffText(currentName)).length;
  if(nextStatus!=='regional' && nextStatus!=='inactive' && assignmentCount>1){
    driverSaveNotice.style.color='#ff7373';
    driverSaveNotice.textContent=`Ce chauffeur possède ${assignmentCount} affectations. Réduisez-les à une avant de passer en ${DRIVER_STATUSES[nextStatus]}.`;
    driverStatus.value=normalizeDriverStatus(item.status);
    return;
  }

  item.lastName = driverLastName.value.trim().toUpperCase();
  item.firstName = driverFirstName.value.trim();
  item.status = nextStatus;
  item.birthDate = driverBirthDate.value;
  item.birthCity = driverBirthCity.value.trim();
  item.birthPostalCode = driverBirthPostalCode.value.trim().toUpperCase();
  item.phone = driverPhone.value.trim();
  item.address = driverAddress.value.trim();
  item.postalCode = driverPostalCode.value.trim();
  item.city = driverCity.value.trim();
  item.licenseNumber = driverLicenseNumber.value.trim();
  item.licenseIssueDate = driverLicenseIssueDate.value;
  item.licenseExpiry = driverLicenseExpiry.value;
  if(leaving){
    item.departureHistory=[...(item.departureHistory||[]),{date:new Date().toISOString(),released:release,assignments:JSON.parse(JSON.stringify(departureRows))}];
  }

  const saved = saveDriverProfiles();
  if(!saved){Object.keys(item).forEach(key=>delete item[key]);Object.assign(item,previousProfile);}
  if(saved && release){
    const previousAssignments=affectations;
    affectations=affectations.filter(row=>!departureRows.includes(row));
    if(!saveAffectations()){
      affectations=previousAssignments;
      item.departureHistory[item.departureHistory.length-1].released=false;
      saveDriverProfiles();
      alert('Le statut inactif est enregistré, mais les affectations n’ont pas pu être libérées. Elles sont conservées.');
    }
    renderAffectations();renderParkTable();
  }
  driverDetailName.textContent = driverDisplayName(item);
  driverBigAvatar.textContent = driverInitials(item);
  driverSaveNotice.style.color = saved ? '#57d883' : '#ff7373';
  driverSaveNotice.textContent = saved ? 'Modifications enregistrées.' : 'Impossible d’enregistrer les modifications.';
  if(saved) setDriverEditMode(false);
  renderDriverList();
});


newDriverPostalCode.addEventListener('input',()=>{
  newDriverPostalCode.value = newDriverPostalCode.value.replace(/\D/g,'').slice(0,5);
});

document.getElementById('addDriver').addEventListener('click',openAddDriverModal);
document.getElementById('closeAddDriver').addEventListener('click',closeAddDriverModal);
document.getElementById('cancelAddDriver').addEventListener('click',closeAddDriverModal);
addDriverModal.addEventListener('click',event=>{
  if(event.target === addDriverModal) closeAddDriverModal();
});

addDriverForm.addEventListener('submit',event=>{
  event.preventDefault();
  const lastName = newDriverLastName.value.trim().toUpperCase();
  const firstName = newDriverFirstName.value.trim();

  if(!lastName || !firstName){
    addDriverError.textContent = 'Le nom et le prénom sont obligatoires.';
    return;
  }

  const exists = driverProfiles.some(item=>
    normalizeAffText(`${item.lastName} ${item.firstName}`) === normalizeAffText(`${lastName} ${firstName}`)
  );
  if(exists){
    addDriverError.textContent = 'Ce chauffeur existe déjà dans la liste.';
    return;
  }

  const item = createDriverFromName(`${lastName} ${firstName}`);
  item.lastName = lastName;
  item.firstName = firstName;
  item.status = normalizeDriverStatus(newDriverStatus.value);
  item.birthDate = newDriverBirthDate.value;
  item.birthCity = newDriverBirthCity.value.trim();
  item.birthPostalCode = newDriverBirthPostalCode.value.trim().toUpperCase();
  item.phone = newDriverPhone.value.trim();
  item.address = newDriverAddress.value.trim();
  item.postalCode = newDriverPostalCode.value.trim();
  item.city = newDriverCity.value.trim();
  item.licenseNumber = newDriverLicenseNumber.value.trim();
  item.licenseIssueDate = newDriverLicenseIssueDate.value;
  item.licenseExpiry = newDriverLicenseExpiry.value;
  driverProfiles.push(item);
  saveDriverProfiles();
  selectedDriverId = item.id;
  closeAddDriverModal();
  driverSearch.value = '';
  renderDriverList();
  fillDriverForm();
});

deleteDriverOption.addEventListener('click',()=>{
  if(!activeDriverId) return;
  pendingDeleteDriverId = activeDriverId;
  const item = driverProfiles.find(driver=>driver.id === activeDriverId);
  deleteDriverName.textContent = item ? driverDisplayName(item) : '';
  closeDriverActionsMenu();
  deleteDriverModal.hidden = false;
  syncDriverModalState();
});


document.getElementById('closeDeleteDriver').addEventListener('click',closeDeleteDriverModal);
document.getElementById('cancelDeleteDriver').addEventListener('click',closeDeleteDriverModal);
deleteDriverModal.addEventListener('click',event=>{
  if(event.target === deleteDriverModal) closeDeleteDriverModal();
});
document.getElementById('confirmDeleteDriver').addEventListener('click',()=>{
  if(!pendingDeleteDriverId) return;
  const removed=driverProfiles.find(item=>item.id===pendingDeleteDriverId);
  driverProfiles = driverProfiles.filter(item=>item.id !== pendingDeleteDriverId);
  if(!saveDriverProfiles()){if(removed)driverProfiles.push(removed);return;}
  if(removed)window.dashboardOfferUndo?.('Chauffeur supprimé',()=>{
    if(driverProfiles.some(row=>row.id===removed.id||normalizeAffText(driverDisplayName(row))===normalizeAffText(driverDisplayName(removed))))return false;
    driverProfiles.push(removed);
    if(!saveDriverProfiles()){driverProfiles=driverProfiles.filter(row=>row!==removed);return false;}
    renderDriverList();fillDriverForm();return true;
  });
  if(selectedDriverId === pendingDeleteDriverId) selectedDriverId = null;
  saveDriverProfiles();
  closeDeleteDriverModal();
  renderDriverList();
  fillDriverForm();
});

document.addEventListener('click',event=>{
  if(!driverActionsMenu.hidden &&
     !driverActionsMenu.contains(event.target) &&
     !event.target.closest('[data-driver-menu]')){
    closeDriverActionsMenu();
  }
});
window.addEventListener('resize',closeDriverActionsMenu);
window.addEventListener('scroll',closeDriverActionsMenu,true);


document.getElementById('exportDriversCsv').addEventListener('click',()=>{
  const headers = [
    'Nom','Prénom','Type de chauffeur','Date de naissance','Ville de naissance','Code postal ville de naissance','Téléphone','Adresse','Code postal','Ville',
    'N° permis','Délivrance permis','Expiration permis'
  ];
  const rows = [...driverProfiles]
    .sort((a,b)=>a.lastName.localeCompare(b.lastName,'fr',{sensitivity:'base'}))
    .map(item=>[
      item.lastName,item.firstName,driverStatusLabel(item),item.birthDate,item.birthCity,item.birthPostalCode,item.phone,item.address,item.postalCode,item.city,
      item.licenseNumber,item.licenseIssueDate,item.licenseExpiry
    ]);

  const csv = '\uFEFF' + [
    headers.map(driverCsvEscape).join(';'),
    ...rows.map(row=>row.map(driverCsvEscape).join(';'))
  ].join('\r\n');

  const blob = new Blob([csv],{type:'text/csv;charset=utf-8;'});
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = 'Chauffeurs.csv';
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
});

document.addEventListener('keydown',event=>{
  if(event.key !== 'Escape') return;
  if(!deleteDriverModal.hidden) closeDeleteDriverModal();
  else if(!addDriverModal.hidden) closeAddDriverModal();
  else closeDriverActionsMenu();
});

renderDriverList();
fillDriverForm();


/* ===== PAGE SINISTRE ===== */
const CLAIM_STORAGE_KEY = 'hessers-claims-v2';
const CLAIM_EVENTS_KEY = 'hessers-claim-events-v2';
const CLAIM_FILE_DB = 'hessers-claim-files-v1';
const CLAIM_FILE_STORE = 'files';

let claimData = [];
let claimEventsData = [];
let selectedClaimId = null;
let claimDraftSnapshot = null;

try{
  const storedClaims = JSON.parse(localStorage.getItem(CLAIM_STORAGE_KEY));
  if(Array.isArray(storedClaims)) claimData = storedClaims;
}catch(error){
  console.warn('Impossible de lire les sinistres enregistrés.',error);
}

try{
  const storedEvents = JSON.parse(localStorage.getItem(CLAIM_EVENTS_KEY));
  if(Array.isArray(storedEvents)) claimEventsData = storedEvents;
}catch(error){
  console.warn('Impossible de lire l’historique des sinistres.',error);
}

const claimTable = document.getElementById('claimTable');
const claimTableWrap = document.querySelector('.claim-table-wrap');
const claimSearch = document.getElementById('claimSearch');
const claimCountLabel = document.getElementById('claimCountLabel');
const claimDetailEmpty = document.getElementById('claimDetailEmpty');
const claimDetailContent = document.getElementById('claimDetailContent');
const claimAttachmentInput = document.getElementById('claimAttachmentInput');
const claimAttachmentList = document.getElementById('claimAttachmentList');
const downloadClaimInvoiceTemplate = document.getElementById('downloadClaimInvoiceTemplate');
const scaniaPartButton = document.getElementById('scaniaPartButton');
const claimTimeline = document.getElementById('claimTimeline');

const claimActionsMenu = document.getElementById('claimActionsMenu');
const deleteClaimOption = document.getElementById('deleteClaimOption');
const deleteClaimModal = document.getElementById('deleteClaimModal');
const deleteClaimNumber = document.getElementById('deleteClaimNumber');

const SCANIA_PARTS = `SCA 3024478|GRILLE DE CALAN|389,17
SCA 3194780|VENTILATEUR|1571,61
SCA 3237859|CONDENSEUR DE C|1481,34
SCA 2898837|ECHANGEUR INTER|1829,66
SCA 2403939|COLLIER A RUBAN|49,07
SCA 2552202|RADIATEUR|1470,06
SCA 2426764|DEFLECTEUR DE V|323,32
SCA 2629014|SUPPORT|13,86
SCA 2629012|SUPPORT|29,39
SCA 2920175|GRILLE DE CALAN|233,45
SCA 2614806|PIECE D'EXTREMI|70,8
SCA 2614805|PIECE D'EXTREMI|70,8
SCA 2650885|CHARNIERE|328,36
SCA 2650884|CHARNIERE|328,36
SCA 3209827|PROFIL|180,49
SCA 3209826|PROFIL|180,49
SCA 0815873|VIS|1,23
SCA 2978232|PANNEAU|25,3
SCA 2978230|PANNEAU|25,3
SCA 2307678|TAMIS|166,89
SCA 2329070|BAGUETTE|82,59
SCA 1878539|COLLIER DE MAIN|2,23
SCA 2252077|ATTACHE|1,24
SCA 2978236|PANNEAU|43,86
SCA 2978233|PANNEAU|67,41
SCA 2978234|PANNEAU|43,86
SCA 2978238|PANNEAU|16,91
SCA 2978237|PANNEAU|16,91
SCA 3122017|ECROU CLIP|2,79
SCA 2894752|STRUCTURE|1756,27
SCA 1341110|BUTEE|8,15
SCA 2325455|COLLIER DE MAIN|2,98
SCA 2329769|ECROU CLIP|1,7
SCA 2307674|TAMIS|144
SCA 2286062|PANNEAU|505,05
SCA 2077926|COUVERCLE DE PA|452,6
SCA 2334040|COUVERCLE|2,15
SCA 2645905|SUPPORT|49,25
SCA 2660205|SUPPORT|58,29
SCA 2256137|COUVERCLE|22,61
SCA 2128511|COUVERCLE|4,63
SCA 2128512|COUVERCLE|4,63
SCA 2077928|COUVERCLE DE PA|581,12
SCA 2986740|COUVERCLE|22,32
SCA 3191854|ECU DIS|2767,14
SCA 2545649|TAMIS|80,91
SCA 2988982|SUPPORT|98,39
SCA 2264830|SUPPORT|9,54
SCA 2271664|ESSUIE LAVE PHA|190,7
SCA 2443110|RACCORD RAPIDE|11,89
SCA 2948550|FEU ANTIBROUILL|309,94
SCA 2650533|SUPPORT|63,78
SCA 3082333|PARE CHOCS|701,73
SCA 3148185|PROJECTEUR|1628
SCA 2620784|JOINT|19,42
SCA 2609156|PANNEAU DE GARN|77,89
SCA 2649555|SUPPORT|114,86
SCA 2707304|COUVERCLE|12,28
DIV INGREDIENTV|INGREDIENT VERNIS|61
SCA 2731830|COUVERCLE DE PA|452,6
SCA 1388070|GARNITURE ANTIV|25,16
SCA 1783287|CAPTEUR DE POSI|204,34
SCA 1367260|JOINT|0,8
SCA 1529441|JOINT TORIQUE|1,82
SCA 2673796|VIS|6,98
SCA 2684667|JOINT|12,09
SCA 1472718|JOINT TORIQUE|7,86
SCA 3165362|ANNEAU D'ETANCH|38,09
SCA 1536775|RONDELLE|2,89
SCA 1494100|JOINT TORIQUE|7,5
SCA 1897125|RONDELLE|9,16
SCA 1422950|BROCHE PLATE DE|1,25
SCA 3207403|FLEXIBLE DE LIQ|66,8
PRA 6110|NETTOYANT FREIN|3,03
SCA 2230750|JONCTION DE CAP|509,48
SCA 2329070|BAGUETTE|76,14
SCA 2978233|PANNEAU|62,13
SCA 2077926|COUVERCLE DE PA|342,2
SCA 2731830|COUVERCLE DE PA|342,2
SCA 2077928|COUVERCLE DE PA|458,7
SCA 2717829|SUPPORT|108,58
SCA 2625706|FEU ANTIBROUILLARD|329,51
SCA 2674391|PROJECTEUR|1577,36
SCA 2609157|PANNEAU DE GARN|74,66
SCA 2707335|COUVERCLE|11,79
SCA 2978234|PANNEAU|40,41
SCA 2978236|PANNEAU|40,41
TRE EXT|PEINTURE WHITE IVORY|850
SCA 2286062|PANNEAU|445,39
SCA 2978846|PANNEAU|26,71
SCA 1511237|RACCORD DE CONT|52,51
SCA 2894752|STRUCTURE|1542,55
SCA 2346372|PARE CHOCS|742,76
SCA 2626258|SUPPORT|236,58
SCA 2649863|SUPPORT|83,54
SCA 2625705|FEU ANTIBROUILLARD|329,51
SCA 2556764|VIS|0,58
SCA 2294126|VIS A EMBASE|4,4
SCA 2372927|SUPPORT|29,51
SCA 2223647|COLLIER DE MAIN|2,4
SCA 2331501|SUPPORT|41,63
SCA 2491806|CHARNIERE|43
SCA 2674390|PROJECTEUR|1378,74
SCA 2341862|DEFLECTEUR D'AI|28,55
SCA 1505286|VIS A EMBASE|6,34
SCA 2239982|COLLIER DE MAIN|2,2
SCA 2334520|COUVERCLE|10,31
SCA 2790473|SUPPORT|342,12
SCA 2649717|SUPPORT D'EMMAR|126,92
SCA 2660206|SUPPORT|53,42
SCA 2595870|MARCHEPIED|148,21
SCA 2334728|LED|99,79
SCA 1912553|CONNECTEUR|9,61
SCA 1443344|DOUILLE PLATE D|0,55
SCA 2374726|COUVERCLE|16,84
SCA 2256141|COUVERCLE|19,93
SCA 2626271|SUPPORT|282,36
SCA 2649718|SUPPORT D'EMMAR|126,92
SCA 2790474|SUPPORT|342,12
SCA 2874904|SUPPORT|62,07
SCA 2599300|PANNEAU|574,46
SCA 2077927|BUMPER COV|238,62
SCA 2297984|PANNEAU DE GARN|122,96
SCA 2297996|PANNEAU DE GARN|122,96
SCA 2656511|ECRAN THERMIQUE|756,42
SCA 2716021|JUPE LATERALE|241,91
SCA 2338061|JUPE LATERALE|262,43
SCA 2271666|ESSUIE LAVE PHA|167,77
SCA 3004480|ROUE A DISQUE|523,63
SCA 2668247|AILE|249,53
SCA 2668246|AILE|249,53
SCA 2246831|LAMPE|172,25
SCA 2900087|SUPPORT|67,8`.split('\n').map(row=>row.split('|'));

let scaniaPartsModal = null;
const closeScaniaPartsModal = ()=>{
  if(!scaniaPartsModal) return;
  scaniaPartsModal.hidden = true;
  if(!document.querySelector('.modal-overlay:not([hidden])')) document.body.classList.remove('modal-open');
};
const renderScaniaParts = filter=>{
  const body = scaniaPartsModal?.querySelector('#scaniaPartsBody');
  if(!body) return;
  const needle = String(filter || '').trim().toLocaleLowerCase('fr');
  const rows = SCANIA_PARTS.filter(([reference,designation])=>
    !needle || `${reference} ${designation}`.toLocaleLowerCase('fr').includes(needle)
  );
  body.innerHTML = rows.map(([reference,designation,price])=>`<tr><td>${reference}</td><td>${designation}</td><td>${price} €</td></tr>`).join('') || '<tr><td colspan="3">Aucune pièce trouvée.</td></tr>';
  const count = scaniaPartsModal.querySelector('#scaniaPartsCount');
  if(count) count.textContent = `${rows.length} pièce${rows.length > 1 ? 's' : ''}`;
};
const openScaniaPartsModal = ()=>{
  if(!scaniaPartsModal){
    scaniaPartsModal = document.createElement('div');
    scaniaPartsModal.className = 'modal-overlay';
    scaniaPartsModal.id = 'scaniaPartsModal';
    scaniaPartsModal.hidden = true;
    scaniaPartsModal.innerHTML = `<div class="modal-card scania-parts-modal-card" role="dialog" aria-modal="true" aria-labelledby="scaniaPartsTitle">
      <div class="scania-parts-head"><div><h2 id="scaniaPartsTitle">Pièces Scania</h2><p id="scaniaPartsCount"></p></div><button class="modal-close-btn" type="button" aria-label="Fermer">×</button></div>
      <input class="scania-parts-search" id="scaniaPartsSearch" type="search" placeholder="Rechercher une référence ou une pièce..." autocomplete="off">
      <div class="scania-parts-table-wrap"><table class="scania-parts-table"><thead><tr><th>Référence</th><th>Désignation</th><th>Prix HT (€)</th></tr></thead><tbody id="scaniaPartsBody"></tbody></table></div>
    </div>`;
    scaniaPartsModal.addEventListener('click',event=>{
      if(event.target === scaniaPartsModal || event.target.closest('.modal-close-btn')) closeScaniaPartsModal();
    });
    scaniaPartsModal.querySelector('#scaniaPartsSearch').addEventListener('input',event=>renderScaniaParts(event.target.value));
    document.body.appendChild(scaniaPartsModal);
  }
  scaniaPartsModal.querySelector('#scaniaPartsSearch').value = '';
  renderScaniaParts('');
  scaniaPartsModal.hidden = false;
  document.body.classList.add('modal-open');
  scaniaPartsModal.querySelector('#scaniaPartsSearch').focus();
};
scaniaPartButton.addEventListener('click',openScaniaPartsModal);

let activeClaimMenuId = null;
let activeClaimMenuButton = null;
let pendingDeleteClaimId = null;


claimTable.addEventListener('click',event=>{
  const menuButton = event.target.closest('[data-claim-menu]');
  if(menuButton){
    event.stopPropagation();
    openClaimActionsMenu(menuButton,menuButton.dataset.claimMenu);
    return;
  }

  const row = event.target.closest('tr[data-claim-id]');
  if(!row) return;

  closeClaimActionsMenu();
  selectedClaimId = row.dataset.claimId;
  renderClaims();
  loadClaimDetail();
});

claimSearch.addEventListener('input',renderClaims);

deleteClaimOption.addEventListener('click',()=>{
  if(!activeClaimMenuId) return;
  const id = activeClaimMenuId;
  closeClaimActionsMenu();
  openDeleteClaimModal(id);
});

document.getElementById('confirmDeleteClaim').addEventListener('click',async()=>{
  if(!pendingDeleteClaimId) return;

  const id = pendingDeleteClaimId;
  const item = claimData.find(claim=>claim.id === id);
  const number = item?.number ? `Dossier ${item.number}` : 'Sinistre sans n° de dossier';

  await deleteAllClaimFiles(id);

  claimData = claimData.filter(claim=>claim.id !== id);

  if(selectedClaimId === id){
    selectedClaimId = null;
    claimDraftSnapshot = null;
  }

  saveClaims();
  addClaimEvent(`${number} supprimé`);
  closeDeleteClaimModal();
  renderClaims();
  loadClaimDetail();
});

document.getElementById('closeDeleteClaim').addEventListener('click',closeDeleteClaimModal);
document.getElementById('cancelDeleteClaim').addEventListener('click',closeDeleteClaimModal);

deleteClaimModal.addEventListener('click',event=>{
  if(event.target === deleteClaimModal){
    closeDeleteClaimModal();
  }
});

document.addEventListener('click',event=>{
  if(
    !claimActionsMenu.hidden &&
    !claimActionsMenu.contains(event.target) &&
    !event.target.closest('[data-claim-menu]')
  ){
    closeClaimActionsMenu();
  }
});

window.addEventListener('resize',closeClaimActionsMenu);
window.addEventListener('scroll',closeClaimActionsMenu,true);


document.getElementById('addClaim').addEventListener('click',()=>{
  const item = {
    id:'claim_'+Date.now()+'_'+Math.random().toString(36).slice(2),
    number:'',
    date:new Date().toISOString().slice(0,10),
    driver:'',
    vehicle:'',
    type:'',
    status:'Ouvert',
    insurance:'AXA France',
    thirdParty:'',
    cost:'',
    description:'',
    progress:0
  };

  claimData.push(item);
  selectedClaimId = item.id;
  saveClaims();
  addClaimEvent('Nouveau sinistre créé');
  claimSearch.value = '';
  renderClaims();
  loadClaimDetail();
});

document.getElementById('saveClaim').addEventListener('click',()=>{
  const item = getSelectedClaim();
  if(!item) return;

  readClaimFormInto(item);
  saveClaims();
  addClaimEvent(`${item.number ? 'Dossier '+item.number : 'Sinistre sans n° de dossier'} enregistré`);
  renderClaims();
  loadClaimDetail();
});

document.getElementById('cancelClaimChanges').addEventListener('click',()=>{
  const item = getSelectedClaim();
  if(!item || !claimDraftSnapshot) return;

  Object.keys(item).forEach(key=>delete item[key]);
  Object.assign(item,JSON.parse(JSON.stringify(claimDraftSnapshot)));

  renderClaims();
  loadClaimDetail();
});

/* ----- Suivi manuel ----- */


claimTimeline.addEventListener('click',event=>{
  const step = event.target.closest('.claim-step[data-stage]');
  const item = getSelectedClaim();
  if(!step || !item) return;

  item.progress = Number(step.dataset.stage);
  saveClaims();

  const labels = ['Déclaré','Envoyé à l’assurance','Expertise','Clôturé'];
  addClaimEvent(`${item.number ? 'Dossier '+item.number : 'Sinistre sans n° de dossier'} : suivi → ${labels[item.progress]}`);
  renderClaimTimeline();
});

/* ----- Pièces jointes réelles via IndexedDB ----- */


claimAttachmentInput.addEventListener('change',async()=>{
  const item = getSelectedClaim();
  if(!item || !claimAttachmentInput.files.length) return;

  const files = [...claimAttachmentInput.files];

  try{
    for(const file of files){
      await putClaimFile(item.id,file);
    }
    addClaimEvent(
      `${files.length} pièce${files.length > 1 ? 's' : ''} jointe${files.length > 1 ? 's' : ''} ajoutée${files.length > 1 ? 's' : ''} à ${item.number || 'un sinistre sans n° de dossier'}`
    );
  }catch(error){
    console.warn('Impossible d’ajouter une pièce jointe.',error);
    alert('Impossible d’enregistrer la pièce jointe dans ce navigateur.');
  }

  claimAttachmentInput.value = '';
  renderClaimAttachments();
});

claimAttachmentList.addEventListener('click',async event=>{
  const button = event.target.closest('[data-delete-file]');
  const item = getSelectedClaim();
  if(!button || !item) return;

  try{
    await deleteClaimFile(button.dataset.deleteFile);
    addClaimEvent(`${item.number ? 'Pièce jointe supprimée de '+item.number : 'Pièce jointe supprimée d’un sinistre sans n° de dossier'}`);
    renderClaimAttachments();
  }catch(error){
    console.warn('Impossible de supprimer la pièce jointe.',error);
  }
});

const invoiceHtml = value=>String(value || '')
  .replace(/&/g,'&amp;')
  .replace(/</g,'&lt;')
  .replace(/>/g,'&gt;')
  .replace(/"/g,'&quot;')
  .replace(/'/g,'&#039;');

const invoiceDate = value=>{
  const parts = String(value || '').split('-');
  return parts.length === 3 ? `${parts[2]}/${parts[1]}/${parts[0]}` : '';
};

const invoiceAmount = value=>{
  const amount = Number(String(value || '').replace(',','.'));
  return Number.isFinite(amount) && amount > 0
    ? `${amount.toFixed(2).replace('.',',')} €`
    : '- €';
};

let invoicePreviewUrl = '';
let invoicePreviewOverlay = null;

const closeInvoicePreview = ()=>{
  if(!invoicePreviewOverlay) return;
  invoicePreviewOverlay.hidden = true;
  invoicePreviewOverlay.querySelector('.invoice-preview-frame').src = 'about:blank';
  if(invoicePreviewUrl){
    URL.revokeObjectURL(invoicePreviewUrl);
    invoicePreviewUrl = '';
  }
  if(!document.querySelector('.modal-overlay:not([hidden])')) document.body.classList.remove('modal-open');
};

const ensureInvoicePreview = ()=>{
  if(invoicePreviewOverlay) return invoicePreviewOverlay;

  invoicePreviewOverlay = document.createElement('div');
  invoicePreviewOverlay.className = 'modal-overlay';
  invoicePreviewOverlay.id = 'invoicePreviewModal';
  invoicePreviewOverlay.hidden = true;
  invoicePreviewOverlay.innerHTML = `<div class="invoice-preview-modal-card" role="dialog" aria-modal="true" aria-label="Aperçu de la facture">
    <button class="invoice-preview-close" type="button" aria-label="Fermer">×</button>
    <iframe class="invoice-preview-frame" title="Aperçu de la facture"></iframe>
  </div>`;
  invoicePreviewOverlay.addEventListener('click',event=>{
    if(event.target === invoicePreviewOverlay || event.target.closest('.invoice-preview-close')) closeInvoicePreview();
  });
  document.body.appendChild(invoicePreviewOverlay);
  return invoicePreviewOverlay;
};

downloadClaimInvoiceTemplate.addEventListener('click',()=>{
  const item = getSelectedClaim() || {};
  const number = invoiceHtml(item.number || '');
  const vehicle = invoiceHtml(item.vehicle || '');
  const date = invoiceDate(item.date);
  const description = invoiceHtml(item.description || '');
  const cost = invoiceAmount(item.cost);
  const invoiceDocument = `<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Facture Réparations Atelier</title>
<style>
*{box-sizing:border-box;font-family:Arial,sans-serif;-webkit-print-color-adjust:exact;print-color-adjust:exact}
body{background:#fff;color:#111;margin:0;padding:0;min-height:100vh}
.toolbar{position:absolute;top:20px;left:20px;z-index:2;display:flex;justify-content:flex-start}
.print-button{border:0;border-radius:5px;background:#db3333;color:#fff;cursor:pointer;font-weight:bold;padding:10px 16px}
.container{width:100%;min-height:100vh;margin:0;border:0;display:flex;flex-direction:column}
.header{background:#ff0d0d;color:#fff;text-align:center;font-weight:bold;font-size:28px;line-height:1.3;padding:10px}
.info{background:#e6e6e6;border-bottom:1px solid #000}
.info-top{display:grid;grid-template-columns:57% 43%;padding:40px 10px 0;font-weight:bold}
.info-top>span:last-child{margin-left:0;text-align:left}
.info-top .editable{display:inline-block;min-width:180px;text-align:left;font-weight:normal}
.info-middle{display:grid;grid-template-columns:57% 43%;margin-top:15px}
.info-middle div{border-top:1px solid #000;border-right:1px solid #000;text-align:center;font-weight:bold;padding:10px}
.info-middle div:last-child{border-right:0}
.info-bottom{display:grid;grid-template-columns:57% 43%}
.address{border-right:1px solid #000;border-top:1px solid #000;padding:10px;min-height:80px;line-height:1.6}
.date{border-top:1px solid #000;text-align:center;padding-top:20px}
.spacer{height:40px;background:#e6e6e6}
.facture-table{width:100%;flex:1;border-collapse:collapse}
.facture-table th{background:#1f4e79;color:#fff;text-align:left;padding:6px}
.facture-table td{border:1px solid #d0d0d0;height:20px;padding:4px}
.editable{cursor:text;outline:0;min-width:18px}
.editable:hover,.editable:focus{box-shadow:inset 0 0 0 2px rgba(219,51,51,.28);background-color:rgba(255,255,255,.35)}
.col-heures{width:120px;text-align:center}.col-prix{width:165px;background:#f3e6bd;text-align:right}.col-montant{width:200px;background:#d8e6f3;text-align:right}
.invoice-total-label{background:#d8e6f3;text-align:right;font-weight:bold}
.text-line{height:40px}.center{text-align:center}.right{text-align:right}
@media print{html,body{background:#fff!important;-webkit-print-color-adjust:exact;print-color-adjust:exact}.toolbar{display:none}.container{width:100%;border:0}.info,.facture-table{break-inside:avoid}.header,.facture-table th,.col-prix,.col-montant,.invoice-total-label{print-color-adjust:exact;-webkit-print-color-adjust:exact}.info{border-bottom:.5px solid #000!important}.info-middle div,.address,.date{border-color:#000!important;border-style:solid;border-width:.5px!important}.facture-table td{border:0!important}.facture-table th{border:.5px solid #1f4e79!important}}
</style>
</head>
<body>
<div class="toolbar"><button class="print-button" type="button" onclick="window.print()">Imprimer</button></div>
<div class="container">
  <div class="header">FACTURE RÉPARATIONS ATELIER<br>ESSERS</div>
  <div class="info">
    <div class="info-top"><span>Sinistre n° <span class="editable" contenteditable="true" spellcheck="false">${number}</span></span><span>Immatriculation : <span class="editable" contenteditable="true" spellcheck="false">${vehicle}</span></span></div>
    <div class="info-middle"><div>Adresse Facturation</div><div>Date</div></div>
    <div class="info-bottom"><div class="address">AXA France<br>Agence G.CHIRAT &amp; F. BERTRAND<br>27 ROUTE NATIONALE 7<br>69210 LENTILLY</div><div class="date editable" contenteditable="true" spellcheck="false">${invoiceHtml(date)}</div></div>
    <div class="spacer"></div>
  </div>
  <table class="facture-table">
    <thead><tr><th>Désignation</th><th class="col-heures">Heures</th><th class="col-prix">Prix Unitaire</th><th class="col-montant">Montant HT</th></tr></thead>
    <tbody>
      <tr><td></td><td></td><td class="col-prix"></td><td class="col-montant"></td></tr>
      <tr class="text-line"><td class="editable" contenteditable="true" spellcheck="false">V/REF : ${vehicle}${number ? ` · DOSSIER ${number}` : ''}</td><td></td><td class="col-prix"></td><td class="col-montant"></td></tr>
      <tr class="text-line"><td class="editable" contenteditable="true" spellcheck="false">${description || 'Réparation et remise en état du véhicule'}</td><td></td><td class="col-prix"></td><td class="col-montant"></td></tr>
      <tr><td class="editable" contenteditable="true" spellcheck="false">Réparation / prestation</td><td class="center editable invoice-hours" contenteditable="true" spellcheck="false">1</td><td class="col-prix editable invoice-unit-price" contenteditable="true" spellcheck="false">${cost}</td><td class="col-montant invoice-line-amount">${cost}</td></tr>
      <tr><td class="editable" contenteditable="true" spellcheck="false">Pièces et fournitures</td><td class="center editable invoice-hours" contenteditable="true" spellcheck="false"></td><td class="col-prix editable invoice-unit-price" contenteditable="true" spellcheck="false"></td><td class="col-montant invoice-line-amount"></td></tr>
      <tr><td class="editable" contenteditable="true" spellcheck="false">Forfait peinture</td><td class="center editable invoice-hours" contenteditable="true" spellcheck="false"></td><td class="col-prix editable invoice-unit-price" contenteditable="true" spellcheck="false"></td><td class="col-montant invoice-line-amount">- €</td></tr>
      <tr><td class="editable" contenteditable="true" spellcheck="false">&nbsp;</td><td class="editable invoice-hours" contenteditable="true" spellcheck="false"></td><td class="col-prix editable invoice-unit-price" contenteditable="true" spellcheck="false"></td><td class="col-montant invoice-line-amount"></td></tr>
      <tr><td class="editable" contenteditable="true" spellcheck="false">&nbsp;</td><td class="editable invoice-hours" contenteditable="true" spellcheck="false"></td><td class="col-prix editable invoice-unit-price" contenteditable="true" spellcheck="false"></td><td class="col-montant invoice-line-amount"></td></tr>
      <tr><td class="editable" contenteditable="true" spellcheck="false">&nbsp;</td><td class="editable invoice-hours" contenteditable="true" spellcheck="false"></td><td class="col-prix editable invoice-unit-price" contenteditable="true" spellcheck="false"></td><td class="col-montant invoice-line-amount"></td></tr>
      <tr><td class="editable" contenteditable="true" spellcheck="false">&nbsp;</td><td class="editable invoice-hours" contenteditable="true" spellcheck="false"></td><td class="col-prix editable invoice-unit-price" contenteditable="true" spellcheck="false"></td><td class="col-montant invoice-line-amount"></td></tr>
      <tr><td class="editable" contenteditable="true" spellcheck="false">&nbsp;</td><td class="editable invoice-hours" contenteditable="true" spellcheck="false"></td><td class="col-prix editable invoice-unit-price" contenteditable="true" spellcheck="false"></td><td class="col-montant invoice-line-amount"></td></tr>
      <tr><td class="editable" contenteditable="true" spellcheck="false">&nbsp;</td><td class="editable invoice-hours" contenteditable="true" spellcheck="false"></td><td class="col-prix editable invoice-unit-price" contenteditable="true" spellcheck="false"></td><td class="col-montant invoice-line-amount"></td></tr>
      <tr><td class="invoice-total-label" colspan="3"><strong>TOTAL TTC</strong></td><td class="col-montant invoice-total"><strong>${cost}</strong></td></tr>
    </tbody>
  </table>
</div>
<script>
const parseInvoiceAmount = value => {
  const normalized = value.replace(/\\s/g,'').replace(/€/g,'').replace(',','.');
  const amount = Number.parseFloat(normalized.replace(/[^0-9.-]/g,''));
  return Number.isFinite(amount) ? amount : 0;
};
const updateInvoiceLine = row => {
  const hours = parseInvoiceAmount(row.querySelector('.invoice-hours')?.textContent || '');
  const unitPriceCell = row.querySelector('.invoice-unit-price');
  const amountCell = row.querySelector('.invoice-line-amount');
  const hasHours = row.querySelector('.invoice-hours')?.textContent.trim();
  const hasUnitPrice = unitPriceCell?.textContent.trim();
  if(!amountCell || (!hasHours && !hasUnitPrice)){
    if(amountCell) amountCell.textContent = '';
    return;
  }
  const amount = hours * parseInvoiceAmount(unitPriceCell?.textContent || '');
  amountCell.textContent = amount.toFixed(2).replace('.',',') + ' €';
};
const updateInvoiceTotal = () => {
  const amounts = [...document.querySelectorAll('.invoice-line-amount')];
  const total = amounts.reduce((sum,cell)=>sum + parseInvoiceAmount(cell.textContent),0);
  const totalCell = document.querySelector('.invoice-total');
  if(totalCell) totalCell.textContent = total.toFixed(2).replace('.',',') + ' €';
};
document.querySelectorAll('.invoice-hours,.invoice-unit-price').forEach(cell=>cell.addEventListener('input',event=>{
  updateInvoiceLine(event.target.closest('tr'));
  updateInvoiceTotal();
}));
document.querySelectorAll('.editable').forEach(cell=>cell.addEventListener('input',updateInvoiceTotal));
document.querySelectorAll('.invoice-line-amount').forEach(cell=>updateInvoiceLine(cell.closest('tr')));
updateInvoiceTotal();
</script>
</body>
</html>`;

  if(invoicePreviewUrl) URL.revokeObjectURL(invoicePreviewUrl);
  invoicePreviewUrl = URL.createObjectURL(new Blob([invoiceDocument],{type:'text/html;charset=utf-8'}));
  const preview = ensureInvoicePreview();
  preview.querySelector('.invoice-preview-frame').src = invoicePreviewUrl;
  preview.hidden = false;
  document.body.classList.add('modal-open');
  addClaimEvent(`Facture générée pour ${item.number || 'le sinistre sélectionné'}`);
});

/* ----- Cartes du bas ----- */


document.addEventListener('keydown',event=>{
  if(event.key !== 'Escape') return;
  if(scaniaPartsModal && !scaniaPartsModal.hidden) closeScaniaPartsModal();
  else if(invoicePreviewOverlay && !invoicePreviewOverlay.hidden) closeInvoicePreview();
  else if(!deleteClaimModal.hidden) closeDeleteClaimModal();
  else closeClaimActionsMenu();
});

renderClaims();
renderClaimEvents();
loadClaimDetail();


/* ===== VIDANGE TFMO + IMPORT JEF ===== */
const INITIAL_VIDANGE_DATA = [{"id":"vidange_5","excelRow":5,"registration":"HH-234-XG","lastName":"RONZEL","firstName":"Grégory","excelDriverName":"RONZEL Grégory","currentKm":25227,"lastMajorKm":null,"lastGarageKm":null,"sameInterval":20000,"differentInterval":20000,"excelNextOil":-5227,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_6","excelRow":6,"registration":"HJ-538-PR","lastName":"Y2","firstName":"Etienne","excelDriverName":"Y2 Etienne","currentKm":24094,"lastMajorKm":null,"lastGarageKm":null,"sameInterval":20000,"differentInterval":20000,"excelNextOil":-4094,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_7","excelRow":7,"registration":"HK-636-FD","lastName":"VIGNERON","firstName":"Arnaud","excelDriverName":"VIGNERON Arnaud","currentKm":51604,"lastMajorKm":null,"lastGarageKm":null,"sameInterval":50000,"differentInterval":100000,"excelNextOil":-1604,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_8","excelRow":8,"registration":"HF-509-JT","lastName":"AFONSO","firstName":"Pierre","excelDriverName":"AFONSO Pierre","currentKm":150514,"lastMajorKm":100000,"lastGarageKm":100000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":-514,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_9","excelRow":9,"registration":"GS-117-EJ","lastName":"CHTIOUI","firstName":"Selim","excelDriverName":"CHTIOUI Selim","currentKm":422200,"lastMajorKm":372000,"lastGarageKm":372000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":-200,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_10","excelRow":10,"registration":"GS-722-DS","lastName":"LOUVET","firstName":"David","excelDriverName":"LOUVET David","currentKm":417731,"lastMajorKm":368000,"lastGarageKm":368000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":269,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_11","excelRow":11,"registration":"HF-268-JT","lastName":"SOUBEYRAND","firstName":"Juan","excelDriverName":"SOUBEYRAND Juan","currentKm":146899,"lastMajorKm":98000,"lastGarageKm":98000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":1101,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_12","excelRow":12,"registration":"GN-463-VP","lastName":"TIXIER","firstName":"Marc","excelDriverName":"TIXIER Marc","currentKm":505282,"lastMajorKm":457000,"lastGarageKm":457000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":1718,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_13","excelRow":13,"registration":"HK-057-QD","lastName":"ABDULAH","firstName":"Jeremy","excelDriverName":"ABDULAH Jeremy","currentKm":47123,"lastMajorKm":null,"lastGarageKm":null,"sameInterval":50000,"differentInterval":100000,"excelNextOil":2877,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_14","excelRow":14,"registration":"HK-527-QR","lastName":"VIVIN","firstName":"Margot","excelDriverName":"VIVIN Margot","currentKm":47089,"lastMajorKm":null,"lastGarageKm":null,"sameInterval":50000,"differentInterval":100000,"excelNextOil":2911,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_15","excelRow":15,"registration":"GH-923-HL","lastName":"FELIX","firstName":"Pierre","excelDriverName":"FELIX Pierre","currentKm":632730,"lastMajorKm":536000,"lastGarageKm":587000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":3270,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_16","excelRow":16,"registration":"HK-327-KT","lastName":"RHULAND","firstName":"MARTIN","excelDriverName":"RHULAND MARTIN","currentKm":46069,"lastMajorKm":null,"lastGarageKm":null,"sameInterval":50000,"differentInterval":100000,"excelNextOil":3931,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_17","excelRow":17,"registration":"GN-465-VP","lastName":"FERRAND","firstName":"Charlotte","excelDriverName":"FERRAND Charlotte","currentKm":496764,"lastMajorKm":452000,"lastGarageKm":452000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":5236,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_18","excelRow":18,"registration":"GR-128-QR","lastName":"DOMINICONE","firstName":"Geoffrey","excelDriverName":"DOMINICONE Geoffrey","currentKm":410256,"lastMajorKm":366000,"lastGarageKm":366000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":5744,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_19","excelRow":19,"registration":"GJ-262-RS","lastName":"PERARD","firstName":"Jean Francois","excelDriverName":"PERARD Jean Francois","currentKm":571718,"lastMajorKm":528000,"lastGarageKm":528000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":6282,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_20","excelRow":20,"registration":"GS-047-GE","lastName":"GRONDIN","firstName":"Olivier","excelDriverName":"GRONDIN Olivier","currentKm":407655,"lastMajorKm":364000,"lastGarageKm":364000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":6345,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_21","excelRow":21,"registration":"HD-814-RJ","lastName":"DURONZELLE","firstName":"Christopher","excelDriverName":"DURONZELLE Christopher","currentKm":198394,"lastMajorKm":105000,"lastGarageKm":155000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":6606,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_22","excelRow":22,"registration":"GR-277-XH","lastName":"BLONDIN","firstName":"Pierrick","excelDriverName":"BLONDIN Pierrick","currentKm":414379,"lastMajorKm":321000,"lastGarageKm":370000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":6621,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_23","excelRow":23,"registration":"GP-302-VN","lastName":"ZAK","firstName":"Vladimir","excelDriverName":"ZAK Vladimir","currentKm":461763,"lastMajorKm":369000,"lastGarageKm":423000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":7237,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_24","excelRow":24,"registration":"GS-304-EJ","lastName":"JACQUES","firstName":"Sébastien","excelDriverName":"JACQUES Sébastien","currentKm":406380,"lastMajorKm":364000,"lastGarageKm":364000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":7620,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_25","excelRow":25,"registration":"GS-048-GE","lastName":"DIDIER","firstName":"Philippe","excelDriverName":"DIDIER Philippe","currentKm":407117,"lastMajorKm":365000,"lastGarageKm":365000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":7883,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_26","excelRow":26,"registration":"GZ-587-GB","lastName":"BREVET","firstName":"Arnaud","excelDriverName":"BREVET Arnaud","currentKm":296887,"lastMajorKm":205000,"lastGarageKm":266000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":8113,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_27","excelRow":27,"registration":"HF-418-JT","lastName":"SICLER","firstName":"Mickael","excelDriverName":"SICLER Mickael","currentKm":146442,"lastMajorKm":105000,"lastGarageKm":105000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":8558,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_28","excelRow":28,"registration":"GF-845-FH","lastName":"CARDOSO","firstName":"Michael","excelDriverName":"CARDOSO Michael","currentKm":641865,"lastMajorKm":601000,"lastGarageKm":601000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":9135,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_29","excelRow":29,"registration":"HK-989-QC","lastName":"RICHEZ","firstName":"BENOIT","excelDriverName":"RICHEZ BENOIT","currentKm":40813,"lastMajorKm":null,"lastGarageKm":null,"sameInterval":50000,"differentInterval":100000,"excelNextOil":9187,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_30","excelRow":30,"registration":"GF-130-GJ","lastName":"LOUIS","firstName":"Jimmy","excelDriverName":"LOUIS Jimmy","currentKm":635442,"lastMajorKm":595000,"lastGarageKm":595000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":9558,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_31","excelRow":31,"registration":"GT-943-KY","lastName":"OLIVIER","firstName":"Joseph","excelDriverName":"OLIVIER Joseph","currentKm":383129,"lastMajorKm":294000,"lastGarageKm":343000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":10871,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_32","excelRow":32,"registration":"GG-208-VK","lastName":"BARRY","firstName":"Ousmane","excelDriverName":"BARRY Ousmane","currentKm":594598,"lastMajorKm":506000,"lastGarageKm":556000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":11402,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_33","excelRow":33,"registration":"GQ-334-HM","lastName":"DEGRAS","firstName":"Andree","excelDriverName":"DEGRAS Andree","currentKm":454589,"lastMajorKm":366000,"lastGarageKm":418000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":11411,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_34","excelRow":34,"registration":"GF-209-GJ","lastName":"GERME","firstName":"Ludovic","excelDriverName":"GERME Ludovic","currentKm":644775,"lastMajorKm":607000,"lastGarageKm":607000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":12225,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_35","excelRow":35,"registration":"HF-390-LL","lastName":"CHAVET","firstName":"Jeremy","excelDriverName":"CHAVET Jeremy","currentKm":142558,"lastMajorKm":105000,"lastGarageKm":105000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":12442,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_36","excelRow":36,"registration":"GV-292-AQ","lastName":"OBE","firstName":"Dorian","excelDriverName":"OBE Dorian","currentKm":386361,"lastMajorKm":299000,"lastGarageKm":355000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":12639,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_37","excelRow":37,"registration":"GE-841-ZY","lastName":"VOSKER","firstName":"Stephane","excelDriverName":"VOSKER Stephane","currentKm":641092,"lastMajorKm":604000,"lastGarageKm":604000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":12908,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_38","excelRow":38,"registration":"GF-546-HB","lastName":"REGIONAL","firstName":"","excelDriverName":"REGIONAL","currentKm":587914,"lastMajorKm":501000,"lastGarageKm":547000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":13086,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_39","excelRow":39,"registration":"GV-262-XQ","lastName":"MAZILLE","firstName":"John","excelDriverName":"MAZILLE John","currentKm":370848,"lastMajorKm":284000,"lastGarageKm":343000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":13152,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_40","excelRow":40,"registration":"GZ-324-GG","lastName":"LEFRANCOIS","firstName":"Denis","excelDriverName":"LEFRANCOIS Denis","currentKm":294788,"lastMajorKm":208000,"lastGarageKm":256000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":13212,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_41","excelRow":41,"registration":"GV-261-XQ","lastName":"AURIOU","firstName":"Geoffrey","excelDriverName":"AURIOU Geoffrey","currentKm":372358,"lastMajorKm":286000,"lastGarageKm":334000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":13642,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_42","excelRow":42,"registration":"GG-979-ZW","lastName":"COUTURE","firstName":"Damien","excelDriverName":"COUTURE Damien","currentKm":569325,"lastMajorKm":533000,"lastGarageKm":533000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":13675,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_43","excelRow":43,"registration":"GV-259-XQ","lastName":"PATURET","firstName":"Steeve","excelDriverName":"PATURET Steeve","currentKm":327161,"lastMajorKm":291000,"lastGarageKm":291000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":13839,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_44","excelRow":44,"registration":"GV-263-XQ","lastName":"DAURAT","firstName":"Agathe","excelDriverName":"DAURAT Agathe","currentKm":369071,"lastMajorKm":283000,"lastGarageKm":331000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":13929,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_45","excelRow":45,"registration":"HE-611-AE","lastName":"CARLIER","firstName":"Mathieu","excelDriverName":"CARLIER Mathieu","currentKm":193950,"lastMajorKm":108000,"lastGarageKm":163000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":14050,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_46","excelRow":46,"registration":"HF-366-JT","lastName":"COIUTTO","firstName":"Gregory","excelDriverName":"COIUTTO Gregory","currentKm":135661,"lastMajorKm":100000,"lastGarageKm":100000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":14339,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_47","excelRow":47,"registration":"GH-043-HM","lastName":"NEVEU","firstName":"Antoine","excelDriverName":"NEVEU Antoine","currentKm":620560,"lastMajorKm":535000,"lastGarageKm":589000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":14440,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_48","excelRow":48,"registration":"GV-293-AQ","lastName":"MORNET","firstName":"Jordan","excelDriverName":"MORNET Jordan","currentKm":372550,"lastMajorKm":287000,"lastGarageKm":338000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":14450,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_49","excelRow":49,"registration":"GR-338-XH","lastName":"VANECHOP","firstName":"Rodolphe","excelDriverName":"VANECHOP Rodolphe","currentKm":407538,"lastMajorKm":322000,"lastGarageKm":371000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":14462,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_50","excelRow":50,"registration":"GR-841-QT","lastName":"DARCQUE","firstName":"Eric","excelDriverName":"DARCQUE Eric","currentKm":407269,"lastMajorKm":372000,"lastGarageKm":372000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":14731,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_51","excelRow":51,"registration":"GS-718-BN","lastName":"SENSE","firstName":"Francky","excelDriverName":"SENSE Francky","currentKm":408070,"lastMajorKm":373000,"lastGarageKm":373000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":14930,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_52","excelRow":52,"registration":"HD-863-XF","lastName":"PIERREMONT","firstName":"Anthony","excelDriverName":"PIERREMONT Anthony","currentKm":185000,"lastMajorKm":100000,"lastGarageKm":150000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":15000,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_53","excelRow":53,"registration":"GP-299-VN","lastName":"GUICHARD","firstName":"Cyril","excelDriverName":"GUICHARD Cyril","currentKm":451690,"lastMajorKm":367000,"lastGarageKm":415000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":15310,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_54","excelRow":54,"registration":"GV-291-AQ","lastName":"HENNER","firstName":"Marc","excelDriverName":"HENNER Marc","currentKm":376496,"lastMajorKm":292000,"lastGarageKm":341000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":15504,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_55","excelRow":55,"registration":"HE-496-CG","lastName":"WIEST","firstName":"Patrick","excelDriverName":"WIEST Patrick","currentKm":177415,"lastMajorKm":93000,"lastGarageKm":150000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":15585,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_56","excelRow":56,"registration":"GH-044-HM","lastName":"BENGUADDA","firstName":"","excelDriverName":"BENGUADDA","currentKm":565260,"lastMajorKm":531000,"lastGarageKm":531000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":15740,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_57","excelRow":57,"registration":"GN-510-PA","lastName":"TSCHIRRET","firstName":"Lionel","excelDriverName":"TSCHIRRET Lionel","currentKm":476085,"lastMajorKm":442000,"lastGarageKm":442000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":15915,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_58","excelRow":58,"registration":"HH-295-XC","lastName":"MOREL","firstName":"Gérald","excelDriverName":"MOREL Gérald","currentKm":4072,"lastMajorKm":null,"lastGarageKm":null,"sameInterval":20000,"differentInterval":20000,"excelNextOil":15928,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_59","excelRow":59,"registration":"HD-021-SF","lastName":"CARLIER","firstName":"Antoine","excelDriverName":"CARLIER Antoine","currentKm":186002,"lastMajorKm":102000,"lastGarageKm":150000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":15998,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_60","excelRow":60,"registration":"HE-442-CG","lastName":"LECLAIRE","firstName":"Marcel","excelDriverName":"LECLAIRE Marcel","currentKm":182903,"lastMajorKm":99000,"lastGarageKm":150000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":16097,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_61","excelRow":61,"registration":"GG-978-ZW","lastName":"GYOKERES","firstName":"Michel","excelDriverName":"GYOKERES Michel","currentKm":609392,"lastMajorKm":526000,"lastGarageKm":582000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":16608,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_62","excelRow":62,"registration":"GP-098-ZD","lastName":"SAINT MAXIN","firstName":"Gaylor","excelDriverName":"SAINT MAXIN Gaylor","currentKm":453610,"lastMajorKm":371000,"lastGarageKm":424000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":17390,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_63","excelRow":63,"registration":"GH-105-HJ","lastName":"LACROIX","firstName":"Damien","excelDriverName":"LACROIX Damien","currentKm":615365,"lastMajorKm":533000,"lastGarageKm":587000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":17635,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_64","excelRow":64,"registration":"GV-914-QX","lastName":"PIOUD","firstName":"Florent","excelDriverName":"PIOUD Florent","currentKm":375038,"lastMajorKm":293000,"lastGarageKm":345000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":17962,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_65","excelRow":65,"registration":"GS-045-GE","lastName":"FORTAS","firstName":"Marine","excelDriverName":"FORTAS Marine","currentKm":397801,"lastMajorKm":366000,"lastGarageKm":366000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":18199,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_66","excelRow":66,"registration":"GT-858-KY","lastName":"CUISINIER","firstName":"Kelly","excelDriverName":"CUISINIER Kelly","currentKm":384669,"lastMajorKm":303000,"lastGarageKm":353000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":18331,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_67","excelRow":67,"registration":"GH-681-MG","lastName":"SIMONS","firstName":"Allan","excelDriverName":"SIMONS Allan","currentKm":599890,"lastMajorKm":519000,"lastGarageKm":574000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":19110,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_68","excelRow":68,"registration":"GV-983-HT","lastName":"STUDER","firstName":"Marc","excelDriverName":"STUDER Marc","currentKm":368727,"lastMajorKm":288000,"lastGarageKm":339000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":19273,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_69","excelRow":69,"registration":"HK-616-QR","lastName":"LE COINT","firstName":"Daniel","excelDriverName":"LE COINT Daniel","currentKm":30519,"lastMajorKm":null,"lastGarageKm":null,"sameInterval":50000,"differentInterval":100000,"excelNextOil":19481,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_70","excelRow":70,"registration":"HK-682-QR","lastName":"BIMONT","firstName":"Christophe","excelDriverName":"BIMONT Christophe","currentKm":30468,"lastMajorKm":null,"lastGarageKm":null,"sameInterval":50000,"differentInterval":100000,"excelNextOil":19532,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_71","excelRow":71,"registration":"HL-859-JP","lastName":"BOTTINO","firstName":"Mickael","excelDriverName":"BOTTINO Mickael","currentKm":30400,"lastMajorKm":null,"lastGarageKm":null,"sameInterval":50000,"differentInterval":100000,"excelNextOil":19600,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_72","excelRow":72,"registration":"GV-913-QX","lastName":"LUGAND","firstName":"J-P","excelDriverName":"LUGAND J-P","currentKm":370002,"lastMajorKm":290000,"lastGarageKm":341000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":19998,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_73","excelRow":73,"registration":"GV-974-MD","lastName":"MAZALLON","firstName":"Christian","excelDriverName":"MAZALLON Christian","currentKm":367779,"lastMajorKm":288000,"lastGarageKm":349000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":20221,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_74","excelRow":74,"registration":"GV-248-SY","lastName":"ANGIBAUD","firstName":"Romuald","excelDriverName":"ANGIBAUD Romuald","currentKm":364582,"lastMajorKm":285000,"lastGarageKm":343000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":20418,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_75","excelRow":75,"registration":"HE-461-CG","lastName":"DERNONCOURT","firstName":"Bruno","excelDriverName":"DERNONCOURT Bruno","currentKm":179536,"lastMajorKm":100000,"lastGarageKm":150000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":20464,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_76","excelRow":76,"registration":"HL-038-KG","lastName":"PERNIN","firstName":"Lucas","excelDriverName":"PERNIN Lucas","currentKm":29425,"lastMajorKm":null,"lastGarageKm":null,"sameInterval":50000,"differentInterval":100000,"excelNextOil":20575,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_77","excelRow":77,"registration":"HL-361-JP","lastName":"PHILIPPE-PLANCON","firstName":"Athéa","excelDriverName":"PHILIPPE-PLANCON Athéa","currentKm":28903,"lastMajorKm":null,"lastGarageKm":null,"sameInterval":50000,"differentInterval":100000,"excelNextOil":21097,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_78","excelRow":78,"registration":"GZ-323-GG","lastName":"BARDET","firstName":"Christophe","excelDriverName":"BARDET Christophe","currentKm":280683,"lastMajorKm":202000,"lastGarageKm":254000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":21317,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_79","excelRow":79,"registration":"HD-909-WC","lastName":"GARCIA","firstName":"Pedro","excelDriverName":"GARCIA Pedro","currentKm":181639,"lastMajorKm":104000,"lastGarageKm":160000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":22361,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_80","excelRow":80,"registration":"GF-549-HB","lastName":"VIRFOLET","firstName":"Eric","excelDriverName":"VIRFOLET Eric","currentKm":664272,"lastMajorKm":587000,"lastGarageKm":640000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":22728,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_81","excelRow":81,"registration":"GV-915-QX","lastName":"LE CAILLEC","firstName":"Eric","excelDriverName":"LE CAILLEC Eric","currentKm":358788,"lastMajorKm":282000,"lastGarageKm":334000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":23212,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_82","excelRow":82,"registration":"GP-298-VN","lastName":"DUMAINE","firstName":"Geoffrey","excelDriverName":"DUMAINE Geoffrey","currentKm":451778,"lastMajorKm":375000,"lastGarageKm":426000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":23222,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_83","excelRow":83,"registration":"GV-981-HT","lastName":"BAIKRICH","firstName":"Romain","excelDriverName":"BAIKRICH Romain","currentKm":364244,"lastMajorKm":288000,"lastGarageKm":28800,"sameInterval":50000,"differentInterval":100000,"excelNextOil":23756,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_84","excelRow":84,"registration":"GE-839-ZY","lastName":"GROLET","firstName":"Lucas","excelDriverName":"GROLET Lucas","currentKm":633116,"lastMajorKm":607000,"lastGarageKm":607000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":23884,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_85","excelRow":85,"registration":"HL-730-JP","lastName":"DE VRIENDT","firstName":"Thierry","excelDriverName":"DE VRIENDT Thierry","currentKm":25370,"lastMajorKm":null,"lastGarageKm":null,"sameInterval":50000,"differentInterval":100000,"excelNextOil":24630,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_86","excelRow":86,"registration":"HE-582-AE","lastName":"MICHEL","firstName":"Mickael","excelDriverName":"MICHEL Mickael","currentKm":177866,"lastMajorKm":103000,"lastGarageKm":156000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":25134,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_87","excelRow":87,"registration":"HD-295-WD","lastName":"REIS PINHO","firstName":"Manuel","excelDriverName":"REIS PINHO Manuel","currentKm":174769,"lastMajorKm":100000,"lastGarageKm":150000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":25231,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_88","excelRow":88,"registration":"GH-682-MG","lastName":"AUGER","firstName":"Clément","excelDriverName":"AUGER Clément","currentKm":603567,"lastMajorKm":529000,"lastGarageKm":584000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":25433,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_89","excelRow":89,"registration":"HF-402-LL","lastName":"GENOUDET","firstName":"Christophe","excelDriverName":"GENOUDET Christophe","currentKm":124251,"lastMajorKm":100000,"lastGarageKm":100000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":25749,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_90","excelRow":90,"registration":"HE-634-AE","lastName":"REIS","firstName":"Baptiste","excelDriverName":"REIS Baptiste","currentKm":175044,"lastMajorKm":101000,"lastGarageKm":157000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":25956,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_91","excelRow":91,"registration":"GV-290-AQ","lastName":"AGASSE","firstName":"Fréderic","excelDriverName":"AGASSE Fréderic","currentKm":360768,"lastMajorKm":287000,"lastGarageKm":341000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":26232,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_92","excelRow":92,"registration":"HF-538-JT","lastName":"CHARPENTIER","firstName":"Hervé","excelDriverName":"CHARPENTIER Hervé","currentKm":126207,"lastMajorKm":103000,"lastGarageKm":103000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":26793,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_93","excelRow":93,"registration":"HL-120-KG","lastName":"ASSATI","firstName":"Teddy","excelDriverName":"ASSATI Teddy","currentKm":23166,"lastMajorKm":null,"lastGarageKm":null,"sameInterval":50000,"differentInterval":100000,"excelNextOil":26834,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_94","excelRow":94,"registration":"HD-835-SE","lastName":"BOWE","firstName":"Geoffrey","excelDriverName":"BOWE Geoffrey","currentKm":180906,"lastMajorKm":108000,"lastGarageKm":157000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":27094,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_95","excelRow":95,"registration":"GH-082-HJ","lastName":"BENOIST","firstName":"Olivier","excelDriverName":"BENOIST Olivier","currentKm":606104,"lastMajorKm":534000,"lastGarageKm":589000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":27896,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_96","excelRow":96,"registration":"GE-843-ZY","lastName":"BOIS","firstName":"Lionel","excelDriverName":"BOIS Lionel","currentKm":618475,"lastMajorKm":597000,"lastGarageKm":597000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":28525,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_97","excelRow":97,"registration":"GV-911-QX","lastName":"BALLION","firstName":"Eric","excelDriverName":"BALLION Eric","currentKm":355450,"lastMajorKm":284000,"lastGarageKm":336000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":28550,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_98","excelRow":98,"registration":"GG-341-YH","lastName":"SAMAIN","firstName":"Jérome","excelDriverName":"SAMAIN Jérome","currentKm":597260,"lastMajorKm":526000,"lastGarageKm":579000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":28740,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_99","excelRow":99,"registration":"GP-200-SB","lastName":"ST LOUIS","firstName":"Thierry","excelDriverName":"ST LOUIS Thierry","currentKm":494648,"lastMajorKm":474000,"lastGarageKm":474000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":29352,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_100","excelRow":100,"registration":"HF-425-LL","lastName":"SAUGER","firstName":"Willy","excelDriverName":"SAUGER Willy","currentKm":124112,"lastMajorKm":104000,"lastGarageKm":104000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":29888,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_101","excelRow":101,"registration":"GS-999-BM","lastName":"JOLLY","firstName":"Johan","excelDriverName":"JOLLY Johan","currentKm":429540,"lastMajorKm":360000,"lastGarageKm":409000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":30460,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_102","excelRow":102,"registration":"HD-141-WD","lastName":"VERCOUTRE","firstName":"Eddy","excelDriverName":"VERCOUTRE Eddy","currentKm":170455,"lastMajorKm":101000,"lastGarageKm":153000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":30545,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_103","excelRow":103,"registration":"GZ-327-GG","lastName":"BALAZS","firstName":"Victoria","excelDriverName":"BALAZS Victoria","currentKm":273408,"lastMajorKm":204000,"lastGarageKm":257000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":30592,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_104","excelRow":104,"registration":"GG-977-ZW","lastName":"CHARLES","firstName":"Ludji","excelDriverName":"CHARLES Ludji","currentKm":605308,"lastMajorKm":536000,"lastGarageKm":589000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":30692,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_105","excelRow":105,"registration":"GR-296-JZ","lastName":"TORTIELLO","firstName":"Damien","excelDriverName":"TORTIELLO Damien","currentKm":435267,"lastMajorKm":366000,"lastGarageKm":417000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":30733,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_106","excelRow":106,"registration":"GF-264-BF","lastName":"DHONTH","firstName":"Erick","excelDriverName":"DHONTH Erick","currentKm":654892,"lastMajorKm":586000,"lastGarageKm":640000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":31108,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_107","excelRow":107,"registration":"GE-875-ZY","lastName":"PEREIRA","firstName":"Teddy","excelDriverName":"PEREIRA Teddy","currentKm":661826,"lastMajorKm":593000,"lastGarageKm":645000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":31174,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_108","excelRow":108,"registration":"GR-290-GV","lastName":"DOMINGO","firstName":"Bonaventure","excelDriverName":"DOMINGO Bonaventure","currentKm":436508,"lastMajorKm":368000,"lastGarageKm":419000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":31492,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_109","excelRow":109,"registration":"HJ-023-WH","lastName":"MONTOIS","firstName":"Jason","excelDriverName":"MONTOIS Jason","currentKm":68451,"lastMajorKm":null,"lastGarageKm":51000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":31549,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_110","excelRow":110,"registration":"GP-309-VN","lastName":"MARTEL","firstName":"Jean Philippe","excelDriverName":"MARTEL Jean Philippe","currentKm":478263,"lastMajorKm":460000,"lastGarageKm":460000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":31737,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_111","excelRow":111,"registration":"GV-246-SY","lastName":"RIBOTTE","firstName":"Dominique","excelDriverName":"RIBOTTE Dominique","currentKm":350083,"lastMajorKm":282000,"lastGarageKm":332000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":31917,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_112","excelRow":112,"registration":"FS-608-VL","lastName":"PAUL","firstName":"Franck","excelDriverName":"PAUL Franck","currentKm":675686,"lastMajorKm":658000,"lastGarageKm":658000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":32314,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_113","excelRow":113,"registration":"HD-843-RJ","lastName":"LECLERC","firstName":"Florian","excelDriverName":"LECLERC Florian","currentKm":167472,"lastMajorKm":100000,"lastGarageKm":150000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":32528,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_114","excelRow":114,"registration":"GT-666-KY","lastName":"MOURET","firstName":"Thierry","excelDriverName":"MOURET Thierry","currentKm":402993,"lastMajorKm":386000,"lastGarageKm":386000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":33007,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_115","excelRow":115,"registration":"GW-084-EQ","lastName":"LUTROT","firstName":"Benjamin","excelDriverName":"LUTROT Benjamin","currentKm":349625,"lastMajorKm":283000,"lastGarageKm":340000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":33375,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_116","excelRow":116,"registration":"HD-958-SE","lastName":"OTT","firstName":"Damien","excelDriverName":"OTT Damien","currentKm":169767,"lastMajorKm":104000,"lastGarageKm":160000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":34233,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_117","excelRow":117,"registration":"GF-847-FH","lastName":"PAUL","firstName":"Vincent","excelDriverName":"PAUL Vincent","currentKm":634230,"lastMajorKm":619000,"lastGarageKm":619000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":34770,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_118","excelRow":118,"registration":"GR-259-WZ","lastName":"CHARRON","firstName":"Mario","excelDriverName":"CHARRON Mario","currentKm":438179,"lastMajorKm":373000,"lastGarageKm":426000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":34821,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_119","excelRow":119,"registration":"GZ-767-NH","lastName":"ROUAG","firstName":"Badredine","excelDriverName":"ROUAG Badredine","currentKm":289754,"lastMajorKm":125000,"lastGarageKm":177000,"sameInterval":50000,"differentInterval":200000,"excelNextOil":35246,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_120","excelRow":120,"registration":"GV-980-HT","lastName":"TAILLARD","firstName":"Samuel","excelDriverName":"TAILLARD Samuel","currentKm":348773,"lastMajorKm":285000,"lastGarageKm":335000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":36227,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_121","excelRow":121,"registration":"GR-472-GV","lastName":"JAMBON","firstName":"Eddy","excelDriverName":"JAMBON Eddy","currentKm":433195,"lastMajorKm":370000,"lastGarageKm":423000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":36805,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_122","excelRow":122,"registration":"HL-178-KG","lastName":"AZOUA","firstName":"ABDEL","excelDriverName":"AZOUA ABDEL","currentKm":13116,"lastMajorKm":null,"lastGarageKm":null,"sameInterval":50000,"differentInterval":100000,"excelNextOil":36884,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_123","excelRow":123,"registration":"HF-246-JT","lastName":"DESSEIGNE","firstName":"Cédric","excelDriverName":"DESSEIGNE Cédric","currentKm":160681,"lastMajorKm":98000,"lastGarageKm":147000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":37319,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_124","excelRow":124,"registration":"GR-784-QT","lastName":"MARMAGNE","firstName":"Benjamin","excelDriverName":"MARMAGNE Benjamin","currentKm":390957,"lastMajorKm":379000,"lastGarageKm":379000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":38043,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_125","excelRow":125,"registration":"GC-786-FX","lastName":"FRANGUIAN","firstName":"","excelDriverName":"FRANGUIAN","currentKm":729938,"lastMajorKm":668000,"lastGarageKm":720000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":38062,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_126","excelRow":126,"registration":"GT-763-KY","lastName":"DE LA ROCHE","firstName":"Gaetan","excelDriverName":"DE LA ROCHE Gaetan","currentKm":393653,"lastMajorKm":382000,"lastGarageKm":382000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":38347,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_127","excelRow":127,"registration":"HJ-717-TY","lastName":"SOLD","firstName":"Jean Louis","excelDriverName":"SOLD Jean Louis","currentKm":61582,"lastMajorKm":null,"lastGarageKm":50000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":38418,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_128","excelRow":128,"registration":"HE-476-CG","lastName":"MATOS","firstName":"Tonio","excelDriverName":"MATOS Tonio","currentKm":162031,"lastMajorKm":102000,"lastGarageKm":153000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":39969,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_129","excelRow":129,"registration":"GH-683-MG","lastName":"JOUIN","firstName":"Evan","excelDriverName":"JOUIN Evan","currentKm":594747,"lastMajorKm":535000,"lastGarageKm":584000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":40253,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_130","excelRow":130,"registration":"GR-901-XD","lastName":"BROSSARD","firstName":"Axel","excelDriverName":"BROSSARD Axel","currentKm":423527,"lastMajorKm":365000,"lastGarageKm":417000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":41473,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_131","excelRow":131,"registration":"HJ-541-TY","lastName":"SAUZET","firstName":"JD","excelDriverName":"SAUZET JD","currentKm":58169,"lastMajorKm":null,"lastGarageKm":48000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":41831,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_132","excelRow":132,"registration":"GR-935-PW","lastName":"BART","firstName":"Gregory","excelDriverName":"BART Gregory","currentKm":423942,"lastMajorKm":366000,"lastGarageKm":415000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":42058,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_133","excelRow":133,"registration":"GF-843-FH","lastName":"CAPITAINE","firstName":"Olivier","excelDriverName":"CAPITAINE Olivier","currentKm":650649,"lastMajorKm":593000,"lastGarageKm":642000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":42351,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_134","excelRow":134,"registration":"HF-378-JT","lastName":"KULA","firstName":"Erdogan","excelDriverName":"KULA Erdogan","currentKm":161345,"lastMajorKm":104000,"lastGarageKm":158000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":42655,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_135","excelRow":135,"registration":"GZ-932-NJ","lastName":"CLOSE","firstName":"Handy","excelDriverName":"CLOSE Handy","currentKm":239526,"lastMajorKm":233000,"lastGarageKm":233000,"sameInterval":50000,"differentInterval":125000,"excelNextOil":43474,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_136","excelRow":136,"registration":"GH-922-HL","lastName":"FOURNET","firstName":"Dominique","excelDriverName":"FOURNET Dominique","currentKm":592337,"lastMajorKm":536000,"lastGarageKm":585000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":43663,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_137","excelRow":137,"registration":"GN-349-FX","lastName":"MONTEIRO","firstName":"José","excelDriverName":"MONTEIRO José","currentKm":510918,"lastMajorKm":455000,"lastGarageKm":507000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":44082,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_138","excelRow":138,"registration":"HK-922-FK","lastName":"DEBOST","firstName":"Raphael","excelDriverName":"DEBOST Raphael","currentKm":55620,"lastMajorKm":null,"lastGarageKm":50000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":44380,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_139","excelRow":139,"registration":"HK-904-JG","lastName":"CHERVET","firstName":"Clement","excelDriverName":"CHERVET Clement","currentKm":54638,"lastMajorKm":null,"lastGarageKm":49000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":45362,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_140","excelRow":140,"registration":"GF-844-FH","lastName":"DE OLIVEIRA","firstName":"Joao","excelDriverName":"DE OLIVEIRA Joao","currentKm":657645,"lastMajorKm":604000,"lastGarageKm":652000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":46355,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_141","excelRow":141,"registration":"GC-112-JB","lastName":"BOUFFARTIGUES","firstName":"Guy","excelDriverName":"BOUFFARTIGUES Guy","currentKm":722391,"lastMajorKm":669000,"lastGarageKm":719000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":46609,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_142","excelRow":142,"registration":"GH-684-MG","lastName":"TINE","firstName":"Thomas","excelDriverName":"TINE Thomas","currentKm":592006,"lastMajorKm":539000,"lastGarageKm":586000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":46994,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_143","excelRow":143,"registration":"GV-294-AQ","lastName":"MARGERIE","firstName":"Tom","excelDriverName":"MARGERIE Tom","currentKm":335928,"lastMajorKm":283000,"lastGarageKm":330000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":47072,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_144","excelRow":144,"registration":"HF-450-JT","lastName":"LARTAUD","firstName":"Romain","excelDriverName":"LARTAUD Romain","currentKm":151765,"lastMajorKm":99000,"lastGarageKm":148000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":47235,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_145","excelRow":145,"registration":"HK-982-FK","lastName":"RICHEZ","firstName":"Eric","excelDriverName":"RICHEZ Eric","currentKm":52755,"lastMajorKm":null,"lastGarageKm":49000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":47245,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_146","excelRow":146,"registration":"HK-660-QC","lastName":"SANZ","firstName":"Pierre","excelDriverName":"SANZ Pierre","currentKm":51315,"lastMajorKm":null,"lastGarageKm":47000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":48685,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_147","excelRow":147,"registration":"GG-980-ZW","lastName":"KIZILKILIC","firstName":"Cezig","excelDriverName":"KIZILKILIC Cezig","currentKm":582143,"lastMajorKm":531000,"lastGarageKm":579000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":48857,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_148","excelRow":148,"registration":"GE-842-ZY","lastName":"BERTHE","firstName":"Gwenael","excelDriverName":"BERTHE Gwenael","currentKm":663893,"lastMajorKm":613000,"lastGarageKm":661000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":49107,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_149","excelRow":149,"registration":"HK-367-KT","lastName":"POURRAT","firstName":"Valentin","excelDriverName":"POURRAT Valentin","currentKm":48194,"lastMajorKm":null,"lastGarageKm":48000,"sameInterval":50000,"differentInterval":100000,"excelNextOil":51806,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_150","excelRow":150,"registration":"GZ-325-NJ","lastName":"PLATEAU","firstName":"Francois","excelDriverName":"PLATEAU Francois","currentKm":267171,"lastMajorKm":119000,"lastGarageKm":169000,"sameInterval":120000,"differentInterval":200000,"excelNextOil":51829,"dataSource":"excel","_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_park_FW266JB","registration":"FW266JB","lastName":"","firstName":"","excelDriverName":"","currentKm":null,"lastMajorKm":null,"lastGarageKm":null,"sameInterval":50000,"differentInterval":100000,"excelNextOil":null,"dataSource":"parc-only","needsData":true,"_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_park_GD135CB","registration":"GD135CB","lastName":"","firstName":"","excelDriverName":"","currentKm":null,"lastMajorKm":null,"lastGarageKm":null,"sameInterval":50000,"differentInterval":100000,"excelNextOil":null,"dataSource":"parc-only","needsData":true,"_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"},{"id":"vidange_park_HJ717SP","registration":"HJ717SP","lastName":"","firstName":"","excelDriverName":"","currentKm":null,"lastMajorKm":null,"lastGarageKm":null,"sameInterval":50000,"differentInterval":100000,"excelNextOil":null,"dataSource":"parc-only","needsData":true,"_modifiedBy":"THEMIA","_modifiedAt":"2026-10-08T12:00:00Z"}];
const TECH_DEADLINE_STORAGE_KEY='hessers-technical-deadlines-v1';
const INITIAL_TECH_DEADLINES=[{"id":"tachy_4","category":"tachy","registration":"GZ-587-GB","driver":"BREVET Arnaud","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2024-09-11","nextControl":"2026-09-11","company":"TFMO","operator":"Jerome","excelRow":4},{"id":"tachy_5","category":"tachy","registration":"GZ-323-GG","driver":"BARDET Christophe","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"","nextControl":"2026-09-13","company":"TFMO","operator":"Laurent","excelRow":5},{"id":"tachy_6","category":"tachy","registration":"GZ-324-GG","driver":"LEFRANCOIS Denis","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2024-09-23","nextControl":"2026-09-23","company":"TFMO","operator":"Christophe","excelRow":6},{"id":"tachy_7","category":"tachy","registration":"GZ-325-NJ","driver":"PLATEAU Francois","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2024-10-07","nextControl":"2026-10-07","company":"TFMO","operator":"Jerome","excelRow":7},{"id":"tachy_8","category":"tachy","registration":"GZ-767-NH","driver":"ROUAG Badredine","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2024-10-07","nextControl":"2026-10-07","company":"TFMO","operator":"Christophe","excelRow":8},{"id":"tachy_9","category":"tachy","registration":"GZ-932-NJ","driver":"CLOSE Handy","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"","nextControl":"2026-10-07","company":"TFMO","operator":"Laurent","excelRow":9},{"id":"tachy_10","category":"tachy","registration":"FW-266-JB","driver":"ABBE Eric","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"01/12*/2024","nextControl":"2026-12-02","company":"TFMO","operator":"Jerome","excelRow":10},{"id":"tachy_11","category":"tachy","registration":"GF-549-HB","driver":"VIRFOLLET Eric","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"","nextControl":"2026-12-11","company":"TFMO","operator":"Laurent","excelRow":11},{"id":"tachy_12","category":"tachy","registration":"GC-786-FX","driver":"FRANGUIAN Patrick","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2024-12-18","nextControl":"2026-12-18","company":"TFMO","operator":"Jerome","excelRow":12},{"id":"tachy_13","category":"tachy","registration":"GE-875-ZY","driver":"PEREIRA Brigitte","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2024-12-23","nextControl":"2026-12-23","company":"TFMO","operator":"Jerome","excelRow":13},{"id":"tachy_14","category":"tachy","registration":"GN-349-FX","driver":"MONTEIRO JOSE","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-01-09","nextControl":"2027-01-09","company":"TFMO","operator":"Jerome","excelRow":14},{"id":"tachy_15","category":"tachy","registration":"GN-465-VP","driver":"FERRAND Charlotte","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-01-10","nextControl":"2027-01-10","company":"TFMO","operator":"Jerome","excelRow":15},{"id":"tachy_16","category":"tachy","registration":"GN-510-PA","driver":"TSCHIRRET LIONEL","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-01-10","nextControl":"2027-01-10","company":"TFMO","operator":"Laurent","excelRow":16},{"id":"tachy_17","category":"tachy","registration":"GP-298-VN","driver":"DUMAINE GEOFFREY","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-01-13","nextControl":"2027-01-13","company":"TFMO","operator":"Laurent","excelRow":17},{"id":"tachy_18","category":"tachy","registration":"GP-299-VN","driver":"GUICHARD Cyril","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-01-14","nextControl":"2027-01-14","company":"TFMO","operator":"Christophe","excelRow":18},{"id":"tachy_19","category":"tachy","registration":"GH-681-MG","driver":"SIMONS ALLAN","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-01-15","nextControl":"2027-01-15","company":"TFMO","operator":"Raphael","excelRow":19},{"id":"tachy_20","category":"tachy","registration":"GP-098-ZD","driver":"SAINT MAXIN Gaylor","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-01-17","nextControl":"2027-01-17","company":"TFMO","operator":"Laurent","excelRow":20},{"id":"tachy_21","category":"tachy","registration":"GH-044-HM","driver":"BENGUEDDA AHMED","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-01-21","nextControl":"2027-01-21","company":"TFMO","operator":"Jerome","excelRow":21},{"id":"tachy_22","category":"tachy","registration":"GH-043-HM","driver":"NEVEU ANTOINE","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-02-11","nextControl":"2027-02-11","company":"TFMO","operator":"Raphael","excelRow":22},{"id":"tachy_23","category":"tachy","registration":"GG-977-ZW","driver":"CHARLES Ludji","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-02-12","nextControl":"2027-02-12","company":"TFMO","operator":"Laurent","excelRow":23},{"id":"tachy_24","category":"tachy","registration":"GE-842-ZY","driver":"BERTHE Gwenael","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-02-18","nextControl":"2027-02-18","company":"TFMO","operator":"Laurent","excelRow":24},{"id":"tachy_25","category":"tachy","registration":"GG-979-ZW","driver":"COUTURE DAMIEN","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-02-18","nextControl":"2027-02-18","company":"TFMO","operator":"Laurent","excelRow":25},{"id":"tachy_26","category":"tachy","registration":"GF-209-GJ","driver":"GERME Ludovic","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-02-20","nextControl":"2027-02-20","company":"TFMO","operator":"Laurent","excelRow":26},{"id":"tachy_27","category":"tachy","registration":"GE-843-ZY","driver":"GOUTRY Alexandre","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-02-26","nextControl":"2027-02-26","company":"TFMO","operator":"Jerome","excelRow":27},{"id":"tachy_28","category":"tachy","registration":"GP-309-VN","driver":"MARTEL JEAN-PHILIPPE","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-02-27","nextControl":"2027-02-27","company":"TFMO","operator":"Christophe","excelRow":28},{"id":"tachy_29","category":"tachy","registration":"GP-200-SB","driver":"SAINT LOUIS THIERRY","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-03-25","nextControl":"2027-03-25","company":"TFMO","operator":"Laurent","excelRow":29},{"id":"tachy_30","category":"tachy","registration":"GC-112-JB","driver":"BOUFFARTIGUE Guy","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-03-26","nextControl":"2027-03-26","company":"TFMO","operator":"Christophe","excelRow":30},{"id":"tachy_31","category":"tachy","registration":"GF-130-GJ","driver":"LOUIS Jimmy","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-03-27","nextControl":"2027-03-27","company":"TFMO","operator":"Laurent","excelRow":31},{"id":"tachy_32","category":"tachy","registration":"GP-302-VN","driver":"ZAK Vladimir","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-03-28","nextControl":"2027-03-28","company":"TFMO","operator":"Raphael","excelRow":32},{"id":"tachy_33","category":"tachy","registration":"GE-839-ZY","driver":"GROLET Jérome","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-04-01","nextControl":"2027-04-01","company":"TFMO","operator":"Jerome","excelRow":33},{"id":"tachy_34","category":"tachy","registration":"GF-845-FH","driver":"CARDOSO Mickael","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-04-01","nextControl":"2027-04-01","company":"TFMO","operator":"Raphael","excelRow":34},{"id":"tachy_35","category":"tachy","registration":"GN-463-VP","driver":"TIXIER LUDOVIC","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-04-01","nextControl":"2027-04-01","company":"TFMO","operator":"Jerome","excelRow":35},{"id":"tachy_36","category":"tachy","registration":"GG-341-YH","driver":"SAMAIN JÉRÔME","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-04-02","nextControl":"2027-04-02","company":"TFMO","operator":"Laurent","excelRow":36},{"id":"tachy_37","category":"tachy","registration":"GG-978-ZW","driver":"GYOKERES MICHEL","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-04-02","nextControl":"2027-04-02","company":"TFMO","operator":"Raphael","excelRow":37},{"id":"tachy_38","category":"tachy","registration":"GF-264-BF","driver":"DHONDT Eric","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-04-03","nextControl":"2027-04-03","company":"TFMO","operator":"Laurent","excelRow":38},{"id":"tachy_39","category":"tachy","registration":"HK-989-QC","driver":"RICHEZ Benoit","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"","nextControl":"2027-04-20","company":"TFMO","operator":"Laurent","excelRow":39},{"id":"tachy_40","category":"tachy","registration":"GG-208-VK","driver":"BARRY Ousmane","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-04-23","nextControl":"2027-04-23","company":"TFMO","operator":"Jerome","excelRow":40},{"id":"tachy_41","category":"tachy","registration":"GH-683-MG","driver":"JOUIN EVAN","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-04-23","nextControl":"2027-04-23","company":"TFMO","operator":"Raphael","excelRow":41},{"id":"tachy_42","category":"tachy","registration":"GH-682-MG","driver":"AUGER CLÉMENT","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-04-24","nextControl":"2027-04-24","company":"TFMO","operator":"Raphael","excelRow":42},{"id":"tachy_43","category":"tachy","registration":"GE-841-ZY","driver":"VOSKERITCHIAN Stephane","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-04-25","nextControl":"2027-04-25","company":"TFMO","operator":"Laurent","excelRow":43},{"id":"tachy_44","category":"tachy","registration":"HE-476-CG","driver":"MATOS Tonio","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-05-12","nextControl":"2027-05-12","company":"TFMO","operator":"Christophe","excelRow":44},{"id":"tachy_45","category":"tachy","registration":"HE-442-CG","driver":"QUENELLE Anthony","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-05-13","nextControl":"2027-05-13","company":"TFMO","operator":"Laurent","excelRow":45},{"id":"tachy_46","category":"tachy","registration":"HE-461-CG","driver":"DERNONCOURT Bruno","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-05-13","nextControl":"2027-05-13","company":"TFMO","operator":"Christophe","excelRow":46},{"id":"tachy_47","category":"tachy","registration":"HE-611-AE","driver":"RAINHO GOMES Joao","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-05-13","nextControl":"2027-05-13","company":"TFMO","operator":"Laurent","excelRow":47},{"id":"tachy_48","category":"tachy","registration":"HE-634-AE","driver":"REIS Baptiste","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-05-13","nextControl":"2027-05-13","company":"TFMO","operator":"Laurent","excelRow":48},{"id":"tachy_49","category":"tachy","registration":"HE-496-CG","driver":"WIEST Patrick","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-05-14","nextControl":"2027-05-14","company":"TFMO","operator":"Jerome","excelRow":49},{"id":"tachy_50","category":"tachy","registration":"HE-582-AE","driver":"MICHEL Michael","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-05-14","nextControl":"2027-05-14","company":"TFMO","operator":"Jerome","excelRow":50},{"id":"tachy_51","category":"tachy","registration":"GH-684-MG","driver":"TINE Thomas","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-05-15","nextControl":"2027-05-15","company":"TFMO","operator":"Laurent","excelRow":51},{"id":"tachy_52","category":"tachy","registration":"HF-366-JT","driver":"COIUTTO Gregory","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-05-15","nextControl":"2027-05-15","company":"TFMO","operator":"Jerome","excelRow":52},{"id":"tachy_53","category":"tachy","registration":"HF-378-JT","driver":"KULA Erdogan","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-05-16","nextControl":"2027-05-16","company":"TFMO","operator":"Christophe","excelRow":53},{"id":"tachy_54","category":"tachy","registration":"HF-246-JT","driver":"DESSEIGNE Cedric","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-05-19","nextControl":"2027-05-19","company":"TFMO","operator":"Laurent","excelRow":54},{"id":"tachy_55","category":"tachy","registration":"HF-268-JT","driver":"SOUBEYRAND Juan","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-05-19","nextControl":"2027-05-19","company":"TFMO","operator":"Christophe","excelRow":55},{"id":"tachy_56","category":"tachy","registration":"HD-814-RJ","driver":"DURONZELLE Christopher","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-05-23","nextControl":"2027-05-23","company":"TFMO","operator":"Laurent","excelRow":56},{"id":"tachy_57","category":"tachy","registration":"HD-843-RJ","driver":"LECLERC Florian","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-05-23","nextControl":"2027-05-23","company":"TFMO","operator":"Jerome","excelRow":57},{"id":"tachy_58","category":"tachy","registration":"GG-980-ZW","driver":"KIZILKILIC Cegiz","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2026-06-02","nextControl":"2027-05-25","company":"TFMO","operator":"Christophe","excelRow":58},{"id":"tachy_59","category":"tachy","registration":"HD-021-SF","driver":"CARLIER Antoine","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-05-26","nextControl":"2027-05-26","company":"TFMO","operator":"Raphael","excelRow":59},{"id":"tachy_60","category":"tachy","registration":"HD-835-SE","driver":"BOWE Geoffrey","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-05-26","nextControl":"2027-05-26","company":"TFMO","operator":"Laurent","excelRow":60},{"id":"tachy_61","category":"tachy","registration":"HD-958-SE","driver":"OTT Damien","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-05-26","nextControl":"2027-05-26","company":"TFMO","operator":"Laurent","excelRow":61},{"id":"tachy_62","category":"tachy","registration":"GF-844-FH","driver":"DE OLIVEIRA JOAO","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2024-02-19","nextControl":"2027-05-27","company":"TFMO","operator":"Laurent","excelRow":62},{"id":"tachy_63","category":"tachy","registration":"HD-141-WD","driver":"VERCOUTRE Eddy","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-05-30","nextControl":"2027-05-30","company":"TFMO","operator":"Laurent","excelRow":63},{"id":"tachy_64","category":"tachy","registration":"HD-295-WD","driver":"REIS PINHO Manuel","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-05-30","nextControl":"2027-05-30","company":"TFMO","operator":"Raphael","excelRow":64},{"id":"tachy_65","category":"tachy","registration":"HD-909-WC","driver":"GARCIA Pedro","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-05-30","nextControl":"2027-05-30","company":"TFMO","operator":"Laurent","excelRow":65},{"id":"tachy_66","category":"tachy","registration":"GF-843-FH","driver":"CAPITAINE Olivier","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2024-03-05","nextControl":"2027-06-02","company":"TFMO","operator":"Christophe","excelRow":66},{"id":"tachy_67","category":"tachy","registration":"GF-546-HB","driver":"GIABBANI Hedi","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2024-03-01","nextControl":"2027-06-03","company":"TFMO","operator":"Jerome","excelRow":67},{"id":"tachy_68","category":"tachy","registration":"HD-863-XF","driver":"ALBRAN Johan","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-06-03","nextControl":"2027-06-03","company":"TFMO","operator":"Christophe","excelRow":68},{"id":"tachy_69","category":"tachy","registration":"GF-847-FH","driver":"PAUL Vincent","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2024-03-05","nextControl":"2027-06-04","company":"TFMO","operator":"Jerome","excelRow":69},{"id":"tachy_70","category":"tachy","registration":"GH-922-HL","driver":"FOURNET DOMINIQUE","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-06-04","nextControl":"2027-06-04","company":"TFMO","operator":"Raphael","excelRow":70},{"id":"tachy_71","category":"tachy","registration":"GH-923-HL","driver":"FELIX PIERRE","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-06-04","nextControl":"2027-06-04","company":"TFMO","operator":"Christophe","excelRow":71},{"id":"tachy_72","category":"tachy","registration":"GH-105-HJ","driver":"LACROIX DAMIEN","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-06-05","nextControl":"2027-06-05","company":"TFMO","operator":"Christophe","excelRow":72},{"id":"tachy_73","category":"tachy","registration":"GJ-262-RS","driver":"PERARD Jean Francois","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-06-06","nextControl":"2027-06-06","company":"TFMO","operator":"Laurent","excelRow":73},{"id":"tachy_74","category":"tachy","registration":"GQ-334-HM","driver":"DEGRAS ANDRÉ","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-07-29","nextControl":"2027-07-29","company":"TFMO","operator":"Raphael","excelRow":74},{"id":"tachy_75","category":"tachy","registration":"HF-425-LL","driver":"SAUGER Willy","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-08-14","nextControl":"2027-08-14","company":"TFMO","operator":"Jerome","excelRow":75},{"id":"tachy_76","category":"tachy","registration":"HF-418-JT","driver":"SICLER Mickael","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-08-18","nextControl":"2027-08-18","company":"TFMO","operator":"Jerome","excelRow":76},{"id":"tachy_77","category":"tachy","registration":"HF-450-JT","driver":"LARTAUD Romain","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-08-19","nextControl":"2027-08-19","company":"TFMO","operator":"Christophe","excelRow":77},{"id":"tachy_78","category":"tachy","registration":"HF-509-JT","driver":"AFONSO Pierre","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-08-19","nextControl":"2027-08-19","company":"TFMO","operator":"Raphael","excelRow":78},{"id":"tachy_79","category":"tachy","registration":"HF-538-JT","driver":"CHARPENTIER Hervé","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-08-22","nextControl":"2027-08-22","company":"TFMO","operator":"Raphael","excelRow":79},{"id":"tachy_80","category":"tachy","registration":"HF-390-LL","driver":"CHAVET Jeremy","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-08-25","nextControl":"2027-08-25","company":"TFMO","operator":"Raphael","excelRow":80},{"id":"tachy_81","category":"tachy","registration":"HF-402-LL","driver":"GENOUDET Christophe","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-08-26","nextControl":"2027-08-26","company":"TFMO","operator":"Jerome","excelRow":81},{"id":"tachy_82","category":"tachy","registration":"GR-296-JZ","driver":"TORTIELLO Damien","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-09-15","nextControl":"2027-09-15","company":"TFMO","operator":"Jerome","excelRow":82},{"id":"tachy_83","category":"tachy","registration":"GR-290-GV","driver":"DOMINGO BONAVENTURE","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-09-16","nextControl":"2027-09-16","company":"TFMO","operator":"Christophe","excelRow":83},{"id":"tachy_84","category":"tachy","registration":"GR-472-GV","driver":"JAMBON EDDY","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-09-16","nextControl":"2027-09-16","company":"TFMO","operator":"Christophe","excelRow":84},{"id":"tachy_85","category":"tachy","registration":"GR-935-PW","driver":"BART GRÉGORY","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-09-18","nextControl":"2027-09-18","company":"TFMO","operator":"Laurent","excelRow":85},{"id":"tachy_86","category":"tachy","registration":"GR-901-XD","driver":"BROSSARD","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-09-19","nextControl":"2027-09-19","company":"TFMO","operator":"Laurent","excelRow":86},{"id":"tachy_87","category":"tachy","registration":"GR-128-QR","driver":"DOMINICONE GEOFFREY","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-09-23","nextControl":"2027-09-23","company":"TFMO","operator":"Jerome","excelRow":87},{"id":"tachy_88","category":"tachy","registration":"GR-841-QT","driver":"DARCQUE ERIC","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-09-23","nextControl":"2027-09-23","company":"TFMO","operator":"Raphael","excelRow":88},{"id":"tachy_89","category":"tachy","registration":"GS-045-GE","driver":"FORTAS Marine","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-09-25","nextControl":"2027-09-25","company":"TFMO","operator":"Laurent","excelRow":89},{"id":"tachy_90","category":"tachy","registration":"GR-259-WZ","driver":"CHARRON MARIO","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-10-01","nextControl":"2027-10-01","company":"TFMO","operator":"Raphael","excelRow":90},{"id":"tachy_91","category":"tachy","registration":"GS-718-BN","driver":"SENSE FRANCKY","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-10-01","nextControl":"2027-10-01","company":"TFMO","operator":"Laurent","excelRow":91},{"id":"tachy_92","category":"tachy","registration":"GR-277-XH","driver":"BLONDIN PIERRICK","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-10-08","nextControl":"2027-10-08","company":"TFMO","operator":"Laurent","excelRow":92},{"id":"tachy_93","category":"tachy","registration":"GR-784-QT","driver":"MARMAGNE BENJAMIN","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-10-08","nextControl":"2027-10-08","company":"TFMO","operator":"Laurent","excelRow":93},{"id":"tachy_94","category":"tachy","registration":"GR-338-XH","driver":"VANECHOP RODOLPHE","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-10-13","nextControl":"2027-10-13","company":"TFMO","operator":"Laurent","excelRow":94},{"id":"tachy_95","category":"tachy","registration":"GS-117-EJ","driver":"CHTIOUI Selim","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-10-13","nextControl":"2027-10-13","company":"TFMO","operator":"Christophe","excelRow":95},{"id":"tachy_96","category":"tachy","registration":"GS-304-EJ","driver":"JACQUES SÉBASTIEN","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-10-16","nextControl":"2027-10-16","company":"TFMO","operator":"Jerome","excelRow":96},{"id":"tachy_97","category":"tachy","registration":"GS-047-GE","driver":"GRONDIN OLIVIER","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-10-20","nextControl":"2027-10-20","company":"TFMO","operator":"Raphael","excelRow":97},{"id":"tachy_98","category":"tachy","registration":"GS-999-BM","driver":"MEENS Alexandre","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-10-20","nextControl":"2027-10-20","company":"TFMO","operator":"Laurent","excelRow":98},{"id":"tachy_99","category":"tachy","registration":"GS-048-GE","driver":"DIDIER PHILIPPE","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-10-21","nextControl":"2027-10-21","company":"TFMO","operator":"Laurent","excelRow":99},{"id":"tachy_100","category":"tachy","registration":"GS-722-DS","driver":"LOUVET DAVID","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2025-10-28","nextControl":"2027-10-28","company":"TFMO","operator":"Laurent","excelRow":100},{"id":"tachy_101","category":"tachy","registration":"GT-763-KY","driver":"COLAERT Jonathan","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2024-01-09","nextControl":"2027-12-10","company":"TFMO","operator":"Laurent","excelRow":101},{"id":"tachy_102","category":"tachy","registration":"GT-858-KY","driver":"CUISINIER KÉLLY","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2024-01-03","nextControl":"2027-12-18","company":"TFMO","operator":"Jerome","excelRow":102},{"id":"tachy_103","category":"tachy","registration":"GV-974-MD","driver":"MAZALLON CHRISTIAN","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2024-03-05","nextControl":"2027-12-18","company":"TFMO","operator":"Christophe","excelRow":103},{"id":"tachy_104","category":"tachy","registration":"GT-943-KY","driver":"OLIVIER JOSEPH","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2024-01-03","nextControl":"2027-12-23","company":"TFMO","operator":"Laurent","excelRow":104},{"id":"tachy_105","category":"tachy","registration":"GV-292-AQ","driver":"OBE DORIAN","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2024-02-08","nextControl":"2027-12-26","company":"TFMO","operator":"Laurent","excelRow":105},{"id":"tachy_106","category":"tachy","registration":"GV-290-AQ","driver":"AGASSE FRÉDÉRIC","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2024-02-08","nextControl":"2028-01-14","company":"TFMO","operator":"Raphael","excelRow":106},{"id":"tachy_107","category":"tachy","registration":"GV-246-SY","driver":"RIBOTTE DOMINIQUE","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2024-02-18","nextControl":"2028-01-21","company":"TFMO","operator":"Raphael","excelRow":107},{"id":"tachy_108","category":"tachy","registration":"GV-291-AQ","driver":"HENNER MARC","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2024-02-08","nextControl":"2028-01-27","company":"TFMO","operator":"Jerome","excelRow":108},{"id":"tachy_109","category":"tachy","registration":"GV-980-HT","driver":"TAILLARD SAMUEL","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2024-02-26","nextControl":"2028-01-27","company":"TFMO","operator":"Raphael","excelRow":109},{"id":"tachy_110","category":"tachy","registration":"GV-983-HT","driver":"STUDER MARC","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2024-02-26","nextControl":"2028-02-03","company":"TFMO","operator":"Jerome","excelRow":110},{"id":"tachy_111","category":"tachy","registration":"GV-293-AQ","driver":"MORNET Jordan","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2024-02-15","nextControl":"2028-02-04","company":"TFMO","operator":"Laurent","excelRow":111},{"id":"tachy_112","category":"tachy","registration":"HH-234-XG","driver":"RONZEL Grégory","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"","nextControl":"2028-02-06","company":"TFMO","operator":"Jerome","excelRow":112},{"id":"tachy_113","category":"tachy","registration":"GZ-327-GG","driver":"BALAZ Viktoria","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2026-03-09","nextControl":"2028-02-09","company":"TFMO","operator":"Raphael","excelRow":113},{"id":"tachy_114","category":"tachy","registration":"GV-913-QX","driver":"LUGAND JEAN-PHILIPPE","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2024-03-12","nextControl":"2028-02-13","company":"TFMO","operator":"Jerome","excelRow":114},{"id":"tachy_115","category":"tachy","registration":"GV-915-QX","driver":"LE CAILLEC ERIC","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2024-03-12","nextControl":"2028-02-17","company":"TFMO","operator":"Raphael","excelRow":115},{"id":"tachy_116","category":"tachy","registration":"GV-981-HT","driver":"BAIKRICH ROMAIN","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2024-03-01","nextControl":"2028-02-20","company":"TFMO","operator":"Jerome","excelRow":116},{"id":"tachy_117","category":"tachy","registration":"GV-911-QX","driver":"BALLION Eric","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2024-03-12","nextControl":"2028-02-24","company":"TFMO","operator":"Christophe","excelRow":117},{"id":"tachy_118","category":"tachy","registration":"GV-914-QX","driver":"MHUN Stéphane","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2024-03-19","nextControl":"2028-02-24","company":"TFMO","operator":"Laurent","excelRow":118},{"id":"tachy_119","category":"tachy","registration":"GV-259-XQ","driver":"PATURET STEVE","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2024-03-22","nextControl":"2028-02-26","company":"TFMO","operator":"Christophe","excelRow":119},{"id":"tachy_120","category":"tachy","registration":"GV-248-SY","driver":"ANGIBAUD ROMUALD","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2024-03-15","nextControl":"2028-02-27","company":"TFMO","operator":"Christophe","excelRow":120},{"id":"tachy_121","category":"tachy","registration":"GV-262-XQ","driver":"MAZILLE JOHN","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2024-03-14","nextControl":"2028-03-01","company":"TFMO","operator":"Christophe","excelRow":121},{"id":"tachy_122","category":"tachy","registration":"HJ-717-SP","driver":"SOLD Jean-Louis","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"","nextControl":"2028-03-02","company":"TFMO","operator":"Jerome","excelRow":122},{"id":"tachy_123","category":"tachy","registration":"HH-295-XC","driver":"MOREL Gérald","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"","nextControl":"2028-03-04","company":"TFMO","operator":"Jerome","excelRow":123},{"id":"tachy_124","category":"tachy","registration":"GW-084-EQ","driver":"LUTROT Benjamin","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2024-03-26","nextControl":"2028-03-09","company":"TFMO","operator":"Raphael","excelRow":124},{"id":"tachy_125","category":"tachy","registration":"GV-263-XQ","driver":"DAURAT AGATHE","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2024-03-22","nextControl":"2028-03-10","company":"TFMO","operator":"Christophe","excelRow":125},{"id":"tachy_126","category":"tachy","registration":"HJ-023-WH","driver":"MONTOIS Jason","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"","nextControl":"2028-03-10","company":"TFMO","operator":"Christophe","excelRow":126},{"id":"tachy_127","category":"tachy","registration":"HJ-541-TY","driver":"SAUZET Jean David","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"","nextControl":"2028-03-10","company":"TFMO","operator":"Jerome","excelRow":127},{"id":"tachy_128","category":"tachy","registration":"GV-261-XQ","driver":"AURIOU GEOFFREY","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2024-03-22","nextControl":"2028-03-16","company":"TFMO","operator":"Jerome","excelRow":128},{"id":"tachy_129","category":"tachy","registration":"HJ-538-PR","driver":"Yé Etienne","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"","nextControl":"2028-03-16","company":"TFMO","operator":"Jerome","excelRow":129},{"id":"tachy_130","category":"tachy","registration":"HK-636-FD","driver":"VIGNERON Arnaud","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"","nextControl":"2028-03-30","company":"TFMO","operator":"Laurent","excelRow":130},{"id":"tachy_131","category":"tachy","registration":"HK-982-FK","driver":"RICHEZ Eric","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"","nextControl":"2028-04-02","company":"TFMO","operator":"Laurent","excelRow":131},{"id":"tachy_132","category":"tachy","registration":"HK-922-FK","driver":"DEBOST Raphael","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"","nextControl":"2028-04-03","company":"TFMO","operator":"Jerome","excelRow":132},{"id":"tachy_133","category":"tachy","registration":"HK-904-JG","driver":"CHERVET Clément","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"","nextControl":"2028-04-07","company":"TFMO","operator":"Christophe","excelRow":133},{"id":"tachy_134","category":"tachy","registration":"HK-327-KT","driver":"RUHLAND Martin","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"","nextControl":"2028-04-09","company":"TFMO","operator":"Jerome","excelRow":134},{"id":"tachy_135","category":"tachy","registration":"HK-367-KT","driver":"POURRAT Valentin","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"","nextControl":"2028-04-14","company":"TFMO","operator":"Jerome","excelRow":135},{"id":"tachy_136","category":"tachy","registration":"HK-660-QC","driver":"SANZ Pierre","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"","nextControl":"2028-04-15","company":"TFMO","operator":"Jerome","excelRow":136},{"id":"tachy_137","category":"tachy","registration":"HK-057-QD","driver":"ABDULAH Jeremy","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"","nextControl":"2028-04-17","company":"TFMO","operator":"Jerome","excelRow":137},{"id":"tachy_138","category":"tachy","registration":"GH-082-HJ","driver":"BENOIST Olivier","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2026-06-01","nextControl":"2028-05-31","company":"TFMO","operator":"Christophe","excelRow":138},{"id":"tachy_139","category":"tachy","registration":"GV-294-AQ","driver":"MARGERIE Tom","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2026-07-13","nextControl":"2028-07-12","company":"TFMO","operator":"Christophe","excelRow":139},{"id":"tachy_140","category":"tachy","registration":"HL-361-JP","driver":"PHILIPPE PLANCON Athéa","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"","nextControl":"2028-04-18","company":"TFMO","operator":"Christophe","excelRow":140},{"id":"tachy_141","category":"tachy","registration":"HK-527-QR","driver":"VIVIN Margot","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"","nextControl":"2028-04-20","company":"TFMO","operator":"Christophe","excelRow":141},{"id":"tachy_142","category":"tachy","registration":"HK-616-QR","driver":"LE COINT Daniel","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"","nextControl":"2028-04-20","company":"TFMO","operator":"Laurent","excelRow":142},{"id":"tachy_143","category":"tachy","registration":"HK-682-QR","driver":"BIMONT Christophe","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"","nextControl":"2028-04-20","company":"TFMO","operator":"Laurent","excelRow":143},{"id":"tachy_144","category":"tachy","registration":"GT-666-KY","driver":"MOURET THIERRY","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2024-09-09","nextControl":"2028-08-23","company":"TFMO","operator":"Christophe","excelRow":144},{"id":"tachy_145","category":"tachy","registration":"HL-038-KG","driver":"PERNIN Lucas","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"","nextControl":"2028-04-24","company":"TFMO","operator":"Christophe","excelRow":145},{"id":"tachy_146","category":"tachy","registration":"FS-608-VL","driver":"PAUL Franck","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"2024-08-29","nextControl":"2027-08-25","company":"TFMO","operator":"Jerome","excelRow":146},{"id":"tachy_147","category":"tachy","registration":"HL-120-KG","driver":"ASSATI Teddy","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"","nextControl":"2028-04-27","company":"TFMO","operator":"Raphael","excelRow":147},{"id":"tachy_148","category":"tachy","registration":"HL-730-JP","driver":"DE VRIENDT Thierry","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"","nextControl":"2028-04-27","company":"TFMO","operator":"Raphael","excelRow":148},{"id":"tachy_149","category":"tachy","registration":"HL-859-JP","driver":"BOTTINO Mickael","control":"TACHY","label":"controle du chronotachygraphe","lastControl":"","nextControl":"2028-04-27","company":"TFMO","operator":"Christophe","excelRow":149},{"id":"mines_4","category":"mines","registration":"HF-538-JT","driver":"CHARPENTIER Hervé","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2026-09-02","company":"TFMO","operator":"Raphael","excelRow":4},{"id":"mines_5","category":"mines","registration":"HF-390-LL","driver":"CHAVET Jeremy","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2026-09-08","company":"TFMO","operator":"Raphael","excelRow":5},{"id":"mines_6","category":"mines","registration":"GR-901-XD","driver":"BROSSARD Axel","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2026-09-19","company":"TFMO","operator":"Laurent","excelRow":6},{"id":"mines_7","category":"mines","registration":"GZ-538-FZ","driver":"BREVET Arnaud","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2026-09-22","company":"TFMO","operator":"Jerome","excelRow":7},{"id":"mines_8","category":"mines","registration":"GZ-587-GB","driver":"BREVET Arnaud","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2026-09-22","company":"TFMO","operator":"Jerome","excelRow":8},{"id":"mines_9","category":"mines","registration":"HA-530-BB","driver":"CHAVET Jérémy","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2026-09-22","company":"TFMO","operator":"Raphael","excelRow":9},{"id":"mines_10","category":"mines","registration":"FP-846-HB","driver":"REIS PINHO Manuel","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2026-09-24","company":"TFMO","operator":"Raphael","excelRow":10},{"id":"mines_11","category":"mines","registration":"GZ-767-NH","driver":"ROUAG Badredine","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2026-10-01","company":"TFMO","operator":"Christophe","excelRow":11},{"id":"mines_12","category":"mines","registration":"GR-311-QX","driver":"DHONDT Eric","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2026-10-02","company":"TFMO","operator":"Laurent","excelRow":12},{"id":"mines_13","category":"mines","registration":"EV-920-ND","driver":"AFONSO Pierre","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2026-10-07","company":"TFMO","operator":"Raphael","excelRow":13},{"id":"mines_14","category":"mines","registration":"GR-153-QX","driver":"BOTTINO MICKAEL","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2026-10-07","company":"TFMO","operator":"Christophe","excelRow":14},{"id":"mines_15","category":"mines","registration":"FP-005-MT","driver":"SAUZET JEAN DAVID","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2026-10-08","company":"TFMO","operator":"Jerome","excelRow":15},{"id":"mines_16","category":"mines","registration":"FC-271-JP","driver":"MOURET Thierry","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2026-10-09","company":"TFMO","operator":"Christophe","excelRow":16},{"id":"mines_17","category":"mines","registration":"FD-158-GZ","driver":"OTT Damien","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2026-10-09","company":"TFMO","operator":"Laurent","excelRow":17},{"id":"mines_18","category":"mines","registration":"FX-943-DY","driver":"LOUVET DAVID","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2026-10-10","company":"TFMO","operator":"Laurent","excelRow":18},{"id":"mines_19","category":"mines","registration":"FP-486-LT","driver":"VIVIN Margo","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2026-10-14","company":"TFMO","operator":"Jerome","excelRow":19},{"id":"mines_20","category":"mines","registration":"GR-259-WZ","driver":"CHARRON MARIO","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2026-10-14","company":"TFMO","operator":"Raphael","excelRow":20},{"id":"mines_21","category":"mines","registration":"GS-047-GE","driver":"GRONDIN OLIVIER","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2026-10-14","company":"TFMO","operator":"Raphael","excelRow":21},{"id":"mines_22","category":"mines","registration":"GZ-636-VC","driver":"ROUAG Badredine","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2026-10-14","company":"TFMO","operator":"Christophe","excelRow":22},{"id":"mines_23","category":"mines","registration":"FB-024-HM","driver":"DOMINGO Kouassi Bonaventure","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2026-10-15","company":"TFMO","operator":"Christophe","excelRow":23},{"id":"mines_24","category":"mines","registration":"GR-290-GV","driver":"DOMINGO BONAVENTURE","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2026-10-15","company":"TFMO","operator":"Christophe","excelRow":24},{"id":"mines_25","category":"mines","registration":"GR-338-XH","driver":"VANECHOP RODOLPHE","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2026-10-15","company":"TFMO","operator":"Laurent","excelRow":25},{"id":"mines_26","category":"mines","registration":"EL-935-NX","driver":"SECOURS","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2026-10-16","company":"TFMO","operator":"Jerome","excelRow":26},{"id":"mines_27","category":"mines","registration":"ET-722-GM","driver":"GOUTRY Alexandre","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2026-10-16","company":"TFMO","operator":"Jerome","excelRow":27},{"id":"mines_28","category":"mines","registration":"EM-769-XQ","driver":"SECOURS","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2026-10-17","company":"TFMO","operator":"Christophe","excelRow":28},{"id":"mines_29","category":"mines","registration":"GS-304-EJ","driver":"JACQUES SÉBASTIEN","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2026-10-17","company":"TFMO","operator":"Jerome","excelRow":29},{"id":"mines_30","category":"mines","registration":"EM-487-KF","driver":"MAZILLE John","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2026-10-20","company":"TFMO","operator":"Christophe","excelRow":30},{"id":"mines_31","category":"mines","registration":"FE-466-WB","driver":"MEENS Alexandre","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2026-10-20","company":"TFMO","operator":"Laurent","excelRow":31},{"id":"mines_32","category":"mines","registration":"GR-472-GV","driver":"JAMBON EDDY","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2026-10-20","company":"TFMO","operator":"Christophe","excelRow":32},{"id":"mines_33","category":"mines","registration":"GS-048-GE","driver":"DIDIER PHILIPPE","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2026-10-20","company":"TFMO","operator":"Laurent","excelRow":33},{"id":"mines_34","category":"mines","registration":"GS-999-BM","driver":"MEENS Alexandre","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2026-10-20","company":"TFMO","operator":"Laurent","excelRow":34},{"id":"mines_35","category":"mines","registration":"ET-323-JK","driver":"BOIS Lionel","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2026-10-21","company":"TFMO","operator":"Jerome","excelRow":35},{"id":"mines_36","category":"mines","registration":"EV-719-RW","driver":"ZAK Vladimir","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2026-10-21","company":"TFMO","operator":"Raphael","excelRow":36},{"id":"mines_37","category":"mines","registration":"EV-993-VW","driver":"BALAZS Victoria","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2026-10-21","company":"TFMO","operator":"Raphael","excelRow":37},{"id":"mines_38","category":"mines","registration":"FD-560-ZA","driver":"RICHEZ Benoit","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2026-10-21","company":"TFMO","operator":"Laurent","excelRow":38},{"id":"mines_39","category":"mines","registration":"FN-318-AE","driver":"BENOIST OLIVIER","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2026-10-21","company":"TFMO","operator":"Christophe","excelRow":39},{"id":"mines_40","category":"mines","registration":"FP-352-HB","driver":"MONTEIRO GONCALVES JOSE","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2026-10-21","company":"TFMO","operator":"Jerome","excelRow":40},{"id":"mines_41","category":"mines","registration":"FX-235-DZ","driver":"ANGIBAUD Romuald","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2026-10-21","company":"TFMO","operator":"Christophe","excelRow":41},{"id":"mines_42","category":"mines","registration":"GS-722-DS","driver":"LOUVET DAVID","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2026-10-21","company":"TFMO","operator":"Laurent","excelRow":42},{"id":"mines_43","category":"mines","registration":"GV-981-HT","driver":"BAIKRICH ROMAIN","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2026-10-21","company":"TFMO","operator":"Jerome","excelRow":43},{"id":"mines_44","category":"mines","registration":"FC-123-XW","driver":"BAIKRICH Romain","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2026-10-22","company":"TFMO","operator":"Jerome","excelRow":44},{"id":"mines_45","category":"mines","registration":"GS-117-EJ","driver":"CHTIOUI Selim","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2026-10-22","company":"TFMO","operator":"Christophe","excelRow":45},{"id":"mines_46","category":"mines","registration":"GZ-714-YX","driver":"WIEST Patrick","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2026-10-22","company":"TFMO","operator":"Jerome","excelRow":46},{"id":"mines_47","category":"mines","registration":"GZ-932-NJ","driver":"CLOSE Handy","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2026-10-22","company":"TFMO","operator":"Laurent","excelRow":47},{"id":"mines_48","category":"mines","registration":"GS-045-GE","driver":"FORTAS Marine","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2026-10-23","company":"TFMO","operator":"Laurent","excelRow":48},{"id":"mines_49","category":"mines","registration":"FY-434-KV","driver":"KULA Erdogan","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2026-10-24","company":"TFMO","operator":"Christophe","excelRow":49},{"id":"mines_50","category":"mines","registration":"FY-710-LP","driver":"STUDER Marc","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2026-10-28","company":"TFMO","operator":"Jerome","excelRow":50},{"id":"mines_51","category":"mines","registration":"GF-549-HB","driver":"VIRFOLLET Eric","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2026-10-28","company":"TFMO","operator":"Laurent","excelRow":51},{"id":"mines_52","category":"mines","registration":"GM-818-YK","driver":"TAILLARD Samuel","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2026-10-28","company":"TFMO","operator":"Laurent","excelRow":52},{"id":"mines_53","category":"mines","registration":"GV-980-HT","driver":"TAILLARD SAMUEL","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2026-10-28","company":"TFMO","operator":"Laurent","excelRow":53},{"id":"mines_54","category":"mines","registration":"GV-983-HT","driver":"STUDER MARC","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2026-10-28","company":"TFMO","operator":"Jerome","excelRow":54},{"id":"mines_55","category":"mines","registration":"GF-813-TL","driver":"COLAERT Jonathan","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2026-10-30","company":"TFMO","operator":"Laurent","excelRow":55},{"id":"mines_56","category":"mines","registration":"GT-763-KY","driver":"COLAERT Jonathan","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2026-10-30","company":"TFMO","operator":"Laurent","excelRow":56},{"id":"mines_57","category":"mines","registration":"EW-279-WG","driver":"MARTEL Jean Philippe","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2026-10-31","company":"TFMO","operator":"Christophe","excelRow":57},{"id":"mines_58","category":"mines","registration":"FP-428-QV","driver":"FRANGUIAN Patrick","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2026-11-04","company":"TFMO","operator":"Jerome","excelRow":58},{"id":"mines_59","category":"mines","registration":"FX-889-NM","driver":"RICHEZ Eric","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2026-11-05","company":"TFMO","operator":"Laurent","excelRow":59},{"id":"mines_60","category":"mines","registration":"EJ-207-GD","driver":"BENGUEDDA Ahmed","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2026-11-10","company":"TFMO","operator":"Jerome","excelRow":60},{"id":"mines_61","category":"mines","registration":"FA-792-LQ","driver":"HOAREAU Eric","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2026-11-10","company":"TFMO","operator":"Jerome","excelRow":61},{"id":"mines_62","category":"mines","registration":"FX-700-MM","driver":"ASSATI Teddy","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2026-11-13","company":"TFMO","operator":"Raphael","excelRow":62},{"id":"mines_63","category":"mines","registration":"GE-875-ZY","driver":"PEREIRA Brigitte/CHAMORRO","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2026-11-13","company":"TFMO","operator":"Jerome","excelRow":63},{"id":"mines_64","category":"mines","registration":"GE-607-NA","driver":"CHARPENTIER Hervé","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2026-11-18","company":"TFMO","operator":"Raphael","excelRow":64},{"id":"mines_65","category":"mines","registration":"EL-782-BE","driver":"BARRY Ousmane","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2026-11-20","company":"TFMO","operator":"Laurent","excelRow":65},{"id":"mines_66","category":"mines","registration":"ET-986-HR","driver":"RODRIGUES MATOS Antonio","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2026-11-25","company":"TFMO","operator":"Christophe","excelRow":66},{"id":"mines_67","category":"mines","registration":"EV-704-XC","driver":"ABBE Eric","genre":"TAUTLINER","control":"MINES","label":"passage aux mines","nextControl":"2026-11-25","company":"TFMO","operator":"Jerome","excelRow":67},{"id":"mines_68","category":"mines","registration":"DA-434-VE","driver":"ABBE Eric","genre":"TAUTLINER","control":"MINES","label":"passage aux mines","nextControl":"2026-11-27","company":"TFMO","operator":"Jerome","excelRow":68},{"id":"mines_69","category":"mines","registration":"FE-790-ME","driver":"PAUL Vincent","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2026-12-04","company":"TFMO","operator":"Jerome","excelRow":69},{"id":"mines_70","category":"mines","registration":"FW-266-JB","driver":"ABBE Eric","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2026-12-08","company":"TFMO","operator":"Jerome","excelRow":70},{"id":"mines_71","category":"mines","registration":"GE-947-EM","driver":"MAZALLON Christian","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2026-12-11","company":"TFMO","operator":"Christophe","excelRow":71},{"id":"mines_72","category":"mines","registration":"GV-974-MD","driver":"MAZALLON CHRISTIAN","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2026-12-11","company":"TFMO","operator":"Christophe","excelRow":72},{"id":"mines_73","category":"mines","registration":"GT-858-KY","driver":"CUISINIER Kelly","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2026-12-15","company":"TFMO","operator":"Jerome","excelRow":73},{"id":"mines_74","category":"mines","registration":"GX-330-CQ","driver":"CUISINIER Kelly","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2026-12-15","company":"TFMO","operator":"Jerome","excelRow":74},{"id":"mines_75","category":"mines","registration":"EJ-464-GD","driver":"EL BOUHOUJ Mustapha","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2026-12-17","company":"TFMO","operator":"Jerome","excelRow":75},{"id":"mines_76","category":"mines","registration":"FY-654-RJ","driver":"AGASSE Frédéric","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2026-12-17","company":"TFMO","operator":"Raphael","excelRow":76},{"id":"mines_77","category":"mines","registration":"GT-666-KY","driver":"MOURET THIERRY","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2026-12-17","company":"TFMO","operator":"Christophe","excelRow":77},{"id":"mines_78","category":"mines","registration":"GV-290-AQ","driver":"AGASSE FRÉDÉRIC","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2026-12-17","company":"TFMO","operator":"Raphael","excelRow":78},{"id":"mines_79","category":"mines","registration":"GF-845-FH","driver":"CARDOSO Mickael","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2026-12-23","company":"TFMO","operator":"Raphael","excelRow":79},{"id":"mines_80","category":"mines","registration":"FX-027-RZ","driver":"ALBRAN Johan","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2026-12-29","company":"TFMO","operator":"Christophe","excelRow":80},{"id":"mines_81","category":"mines","registration":"GT-943-KY","driver":"OLIVIER JOSEPH","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2026-12-30","company":"TFMO","operator":"Laurent","excelRow":81},{"id":"mines_82","category":"mines","registration":"FE-415-YZ","driver":"SECOURS","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-01-05","company":"TFMO","operator":"Jerome","excelRow":82},{"id":"mines_83","category":"mines","registration":"FP-749-PL","driver":"OBE Dorian","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-01-05","company":"TFMO","operator":"Laurent","excelRow":83},{"id":"mines_84","category":"mines","registration":"GV-292-AQ","driver":"OBE DORIAN","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-01-05","company":"TFMO","operator":"Laurent","excelRow":84},{"id":"mines_85","category":"mines","registration":"GE-842-ZY","driver":"BERTHE Gwenael","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-01-06","company":"TFMO","operator":"Laurent","excelRow":85},{"id":"mines_86","category":"mines","registration":"GE-843-ZY","driver":"GOUTRY Alexandre","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-01-06","company":"TFMO","operator":"Jerome","excelRow":86},{"id":"mines_87","category":"mines","registration":"FP-020-MJ","driver":"SECOURS","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-01-07","company":"TFMO","operator":"Raphael","excelRow":87},{"id":"mines_88","category":"mines","registration":"FP-362-RM","driver":"GYOKERES Michel","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-01-07","company":"TFMO","operator":"Raphael","excelRow":88},{"id":"mines_89","category":"mines","registration":"GF-765-CC","driver":"LE CAILLEC Eric","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-01-07","company":"TFMO","operator":"Raphael","excelRow":89},{"id":"mines_90","category":"mines","registration":"GV-915-QX","driver":"LE CAILLEC ERIC","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-01-07","company":"TFMO","operator":"Raphael","excelRow":90},{"id":"mines_91","category":"mines","registration":"HL-859-JP","driver":"BOTTINO Mickael","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-01-07","company":"TFMO","operator":"Christophe","excelRow":91},{"id":"mines_92","category":"mines","registration":"GF-874-VT","driver":"ABDULAH Jeremy","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-01-08","company":"TFMO","operator":"Jerome","excelRow":92},{"id":"mines_93","category":"mines","registration":"GR-694-KT","driver":"MICHEL Michaël","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-01-09","company":"TFMO","operator":"Jerome","excelRow":93},{"id":"mines_94","category":"mines","registration":"HF-418-JT","driver":"SICLER Mickael","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-01-09","company":"TFMO","operator":"Jerome","excelRow":94},{"id":"mines_95","category":"mines","registration":"GJ-812-NQ","driver":"SOLD Jean louis","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-01-09","company":"TFMO","operator":"Jerome","excelRow":95},{"id":"mines_96","category":"mines","registration":"GV-246-SY","driver":"RIBOTTE DOMINIQUE","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-01-12","company":"TFMO","operator":"Raphael","excelRow":96},{"id":"mines_97","category":"mines","registration":"GM-931-YK","driver":"FOURNET DOMINIQUE","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-01-13","company":"TFMO","operator":"Raphael","excelRow":97},{"id":"mines_98","category":"mines","registration":"EK-238-WZ","driver":"MARGERIE TOM","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-01-19","company":"TFMO","operator":"Christophe","excelRow":98},{"id":"mines_99","category":"mines","registration":"GV-294-AQ","driver":"MARGERIE Tom","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-01-19","company":"TFMO","operator":"Christophe","excelRow":99},{"id":"mines_100","category":"mines","registration":"GE-841-ZY","driver":"VOSKERITCHIAN Stephane","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-01-22","company":"TFMO","operator":"Laurent","excelRow":100},{"id":"mines_101","category":"mines","registration":"GF-209-GJ","driver":"GERME Ludovic","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-01-23","company":"TFMO","operator":"Laurent","excelRow":101},{"id":"mines_102","category":"mines","registration":"GF-775-KA","driver":"GERME Ludovic","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-01-23","company":"TFMO","operator":"Laurent","excelRow":102},{"id":"mines_103","category":"mines","registration":"GF-844-FH","driver":"DE OLIVEIRA JOAO","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-01-23","company":"TFMO","operator":"Laurent","excelRow":103},{"id":"mines_104","category":"mines","registration":"GN-306-SB","driver":"DE OLIVEIRA Joao","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-01-23","company":"TFMO","operator":"Laurent","excelRow":104},{"id":"mines_105","category":"mines","registration":"GF-264-BF","driver":"DHONDT Eric","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-01-27","company":"TFMO","operator":"Laurent","excelRow":105},{"id":"mines_106","category":"mines","registration":"GV-291-AQ","driver":"HENNER MARC","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-01-27","company":"TFMO","operator":"Jerome","excelRow":106},{"id":"mines_107","category":"mines","registration":"HH-234-XG","driver":"RONZEL Grégory","genre":"Porteur","control":"MINES","label":"passage aux mines","nextControl":"2027-01-28","company":"TFMO","operator":"Jerome","excelRow":107},{"id":"mines_108","category":"mines","registration":"HH-295-XC","driver":"MOREL Gérald","genre":"Porteur","control":"MINES","label":"passage aux mines","nextControl":"2027-01-28","company":"TFMO","operator":"Jerome","excelRow":108},{"id":"mines_109","category":"mines","registration":"GV-293-AQ","driver":"MORNET Jordan","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-01-29","company":"TFMO","operator":"Laurent","excelRow":109},{"id":"mines_110","category":"mines","registration":"EK-624-LY","driver":"RUHLAND Martin","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-02-02","company":"TFMO","operator":"Jerome","excelRow":110},{"id":"mines_111","category":"mines","registration":"GF-847-FH","driver":"PAUL Vincent","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-02-02","company":"TFMO","operator":"Jerome","excelRow":111},{"id":"mines_112","category":"mines","registration":"EQ-705-FJ","driver":"SECOURS","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-02-08","company":"TFMO","operator":"Jerome","excelRow":112},{"id":"mines_113","category":"mines","registration":"GZ-323-GG","driver":"BARDET Christophe","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-02-09","company":"TFMO","operator":"Laurent","excelRow":113},{"id":"mines_114","category":"mines","registration":"GZ-967-PD","driver":"BARDET Christophe","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-02-09","company":"TFMO","operator":"Laurent","excelRow":114},{"id":"mines_115","category":"mines","registration":"GF-547-AS","driver":"FELIX Pierre","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-02-09","company":"TFMO","operator":"Christophe","excelRow":115},{"id":"mines_116","category":"mines","registration":"GH-923-HL","driver":"FELIX PIERRE","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-02-09","company":"TFMO","operator":"Christophe","excelRow":116},{"id":"mines_117","category":"mines","registration":"GV-913-QX","driver":"LUGAND JEAN-PHILIPPE","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-02-10","company":"TFMO","operator":"Jerome","excelRow":117},{"id":"mines_118","category":"mines","registration":"GF-546-HB","driver":"GIABBANI Hedi","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-02-11","company":"TFMO","operator":"Jerome","excelRow":118},{"id":"mines_119","category":"mines","registration":"GV-248-SY","driver":"ANGIBAUD Romuald","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-02-11","company":"TFMO","operator":"Christophe","excelRow":119},{"id":"mines_120","category":"mines","registration":"GV-911-QX","driver":"BALLION Eric","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-02-13","company":"TFMO","operator":"Christophe","excelRow":120},{"id":"mines_121","category":"mines","registration":"FX-568-JR","driver":"MONTOIS Jason","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-02-16","company":"TFMO","operator":"Christophe","excelRow":121},{"id":"mines_122","category":"mines","registration":"FX-992-VM","driver":"LARTAUD Romain","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-02-16","company":"TFMO","operator":"Christophe","excelRow":122},{"id":"mines_123","category":"mines","registration":"GF-130-GJ","driver":"LOUIS Jimmy","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-02-16","company":"TFMO","operator":"Laurent","excelRow":123},{"id":"mines_124","category":"mines","registration":"FY-630-MR","driver":"BIMONT Christophe","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-02-17","company":"TFMO","operator":"Laurent","excelRow":124},{"id":"mines_125","category":"mines","registration":"GE-839-ZY","driver":"GROLET Jérôme","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-02-17","company":"TFMO","operator":"Jerome","excelRow":125},{"id":"mines_126","category":"mines","registration":"FM-017-YT","driver":"CAPITAINE Olivier","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-02-18","company":"TFMO","operator":"Christophe","excelRow":126},{"id":"mines_127","category":"mines","registration":"GF-843-FH","driver":"CAPITAINE Olivier","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-02-18","company":"TFMO","operator":"Christophe","excelRow":127},{"id":"mines_128","category":"mines","registration":"GG-326-DT","driver":"POURRAT Valentin","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-02-18","company":"TFMO","operator":"Christophe","excelRow":128},{"id":"mines_129","category":"mines","registration":"GE-007-XT","driver":"LECLAIR Marcel","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-02-25","company":"TFMO","operator":"Jerome","excelRow":129},{"id":"mines_130","category":"mines","registration":"GV-914-QX","driver":"MHUN Stéphane","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-02-25","company":"TFMO","operator":"Raphael","excelRow":130},{"id":"mines_131","category":"mines","registration":"GP-242-AG","driver":"PATURET Steve Louis Andre","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-02-26","company":"TFMO","operator":"Christophe","excelRow":131},{"id":"mines_132","category":"mines","registration":"GV-259-XQ","driver":"PATURET STEVE","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-02-26","company":"TFMO","operator":"Christophe","excelRow":132},{"id":"mines_133","category":"mines","registration":"GG-081-TV","driver":"DAURAT Agathe","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-03-02","company":"TFMO","operator":"Christophe","excelRow":133},{"id":"mines_134","category":"mines","registration":"GV-263-XQ","driver":"DAURAT AGATHE","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-03-02","company":"TFMO","operator":"Christophe","excelRow":134},{"id":"mines_135","category":"mines","registration":"FY-406-EX","driver":"KIZILKILIC Cegiz","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-03-03","company":"TFMO","operator":"Christophe","excelRow":135},{"id":"mines_136","category":"mines","registration":"GG-980-ZW","driver":"KIZILKILIC Cegiz","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-03-03","company":"TFMO","operator":"Christophe","excelRow":136},{"id":"mines_137","category":"mines","registration":"GP-243-EN","driver":"LOUIS JIMMY","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-03-04","company":"TFMO","operator":"Laurent","excelRow":137},{"id":"mines_138","category":"mines","registration":"GH-082-HJ","driver":"BENOIST Olivier","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-03-08","company":"TFMO","operator":"Christophe","excelRow":138},{"id":"mines_139","category":"mines","registration":"FG-344-CP","driver":"SANZ Pierre","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-03-11","company":"TFMO","operator":"Jerome","excelRow":139},{"id":"mines_140","category":"mines","registration":"HJ-538-PR","driver":"Yé Etienne","genre":"Porteur","control":"MINES","label":"passage aux mines","nextControl":"2027-03-11","company":"TFMO","operator":"Jerome","excelRow":140},{"id":"mines_141","category":"mines","registration":"GV-261-XQ","driver":"AURIOU Geoffrey","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-03-16","company":"TFMO","operator":"Jerome","excelRow":141},{"id":"mines_142","category":"mines","registration":"GY-165-AL","driver":"AURIOU Geoffrey","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-03-16","company":"TFMO","operator":"Jerome","excelRow":142},{"id":"mines_143","category":"mines","registration":"HJ-717-SP","driver":"SOLD Jean louis","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-03-18","company":"TFMO","operator":"Jerome","excelRow":143},{"id":"mines_144","category":"mines","registration":"HJ-541-TY","driver":"SAUZET Jean-David","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-03-20","company":"TFMO","operator":"Jerome","excelRow":144},{"id":"mines_145","category":"mines","registration":"EK-529-WZ","driver":"JAMBON Eddy","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-03-23","company":"TFMO","operator":"Christophe","excelRow":145},{"id":"mines_146","category":"mines","registration":"FG-604-RZ","driver":"RIBOTTE Dominique","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-03-23","company":"TFMO","operator":"Raphael","excelRow":146},{"id":"mines_147","category":"mines","registration":"GN-284-SP","driver":"TSCHIRRET Lionel","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-03-23","company":"TFMO","operator":"Laurent","excelRow":147},{"id":"mines_148","category":"mines","registration":"GW-677-XE","driver":"DERNONCOURT Bruno","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-03-23","company":"TFMO","operator":"Christophe","excelRow":148},{"id":"mines_149","category":"mines","registration":"GN-739-CR","driver":"COIUTTO Gregory","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-03-24","company":"TFMO","operator":"Jerome","excelRow":149},{"id":"mines_150","category":"mines","registration":"HJ-023-WH","driver":"MONTOIS Jason","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-03-24","company":"TFMO","operator":"Christophe","excelRow":150},{"id":"mines_151","category":"mines","registration":"FJ-305-RG","driver":"TINE Thomas","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-03-25","company":"TFMO","operator":"Laurent","excelRow":151},{"id":"mines_152","category":"mines","registration":"GN-349-FX","driver":"MONTEIRO JOSE","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-03-25","company":"TFMO","operator":"Jerome","excelRow":152},{"id":"mines_153","category":"mines","registration":"GN-465-VP","driver":"FERRAND Charlotte","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-03-25","company":"TFMO","operator":"Jerome","excelRow":153},{"id":"mines_154","category":"mines","registration":"EX-656-KK","driver":"SECOURS","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-03-30","company":"TFMO","operator":"Jerome","excelRow":154},{"id":"mines_155","category":"mines","registration":"EK-544-ZJ","driver":"SAMAIN Jérôme","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-04-01","company":"TFMO","operator":"Laurent","excelRow":155},{"id":"mines_156","category":"mines","registration":"FP-279-RM","driver":"SAINT MAXIN Gaylor","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-04-02","company":"TFMO","operator":"Laurent","excelRow":156},{"id":"mines_157","category":"mines","registration":"GW-576-ZD","driver":"VIRFOLLET Eric","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-04-02","company":"TFMO","operator":"Laurent","excelRow":157},{"id":"mines_158","category":"mines","registration":"EX-016-PM","driver":"TIXIER LUDOVIC","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-04-06","company":"TFMO","operator":"Christophe","excelRow":158},{"id":"mines_159","category":"mines","registration":"GN-463-VP","driver":"TIXIER LUDOVIC","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-04-06","company":"TFMO","operator":"Christophe","excelRow":159},{"id":"mines_160","category":"mines","registration":"GW-573-HJ","driver":"SICLER MICKAEL","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-04-12","company":"TFMO","operator":"Jerome","excelRow":160},{"id":"mines_161","category":"mines","registration":"HK-636-FD","driver":"VIGNERON Arnaud","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-04-13","company":"TFMO","operator":"Laurent","excelRow":161},{"id":"mines_162","category":"mines","registration":"GN-510-PA","driver":"TSCHIRRET LIONEL","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-04-14","company":"TFMO","operator":"Laurent","excelRow":162},{"id":"mines_163","category":"mines","registration":"HK-922-FK","driver":"DEBOST Raphaël","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-04-14","company":"TFMO","operator":"Jerome","excelRow":163},{"id":"mines_164","category":"mines","registration":"HK-982-FK","driver":"RICHEZ Eric","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-04-14","company":"TFMO","operator":"Laurent","excelRow":164},{"id":"mines_165","category":"mines","registration":"GH-684-MG","driver":"TINE Thomas","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-04-15","company":"TFMO","operator":"Laurent","excelRow":165},{"id":"mines_166","category":"mines","registration":"GW-635-LF","driver":"VANECHOP Rodolphe","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-04-16","company":"TFMO","operator":"Laurent","excelRow":166},{"id":"mines_167","category":"mines","registration":"GM-675-YK","driver":"BOUFFARTIGUES Guy","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-04-19","company":"TFMO","operator":"Christophe","excelRow":167},{"id":"mines_168","category":"mines","registration":"FA-558-LQ","driver":"PEREIRA Brigitte","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-04-21","company":"TFMO","operator":"Jerome","excelRow":168},{"id":"mines_169","category":"mines","registration":"GV-262-XQ","driver":"MAZILLE JOHN","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-04-21","company":"TFMO","operator":"Christophe","excelRow":169},{"id":"mines_170","category":"mines","registration":"HK-904-JG","driver":"CHERVET Clément","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-04-21","company":"TFMO","operator":"Christophe","excelRow":170},{"id":"mines_171","category":"mines","registration":"GW-084-EQ","driver":"LUTROT BENJAMIN","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-04-22","company":"TFMO","operator":"Raphael","excelRow":171},{"id":"mines_172","category":"mines","registration":"HK-327-KT","driver":"RUHLAND Martin","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-04-24","company":"TFMO","operator":"Jerome","excelRow":172},{"id":"mines_173","category":"mines","registration":"HK-367-KT","driver":"POURRAT Valentin","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-04-24","company":"TFMO","operator":"Christophe","excelRow":173},{"id":"mines_174","category":"mines","registration":"FY-344-SC","driver":"COUTURE Damien","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-04-27","company":"TFMO","operator":"Laurent","excelRow":174},{"id":"mines_175","category":"mines","registration":"EZ-585-DB","driver":"SECOURS","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-05-04","company":"TFMO","operator":"Jerome","excelRow":175},{"id":"mines_176","category":"mines","registration":"FJ-092-RG","driver":"de VRIENDT Thierry","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-05-04","company":"TFMO","operator":"Raphael","excelRow":176},{"id":"mines_177","category":"mines","registration":"EM-391-MZ","driver":"VOSKERITCHIAN Roger","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-05-05","company":"TFMO","operator":"Laurent","excelRow":177},{"id":"mines_178","category":"mines","registration":"EQ-113-HY","driver":"LACROIX Damien","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-05-05","company":"TFMO","operator":"Christophe","excelRow":178},{"id":"mines_179","category":"mines","registration":"GH-105-HJ","driver":"LACROIX DAMIEN","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-05-05","company":"TFMO","operator":"Christophe","excelRow":179},{"id":"mines_180","category":"mines","registration":"HK-057-QD","driver":"ABDULAH Jeremy","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-05-05","company":"TFMO","operator":"Jerome","excelRow":180},{"id":"mines_181","category":"mines","registration":"HK-660-QC","driver":"SANZ Pierre","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-05-05","company":"TFMO","operator":"Jerome","excelRow":181},{"id":"mines_182","category":"mines","registration":"HK-989-QC","driver":"RICHEZ Benoit","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-05-05","company":"TFMO","operator":"Laurent","excelRow":182},{"id":"mines_183","category":"mines","registration":"GG-208-VK","driver":"BARRY Ousmane","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-05-06","company":"TFMO","operator":"Jerome","excelRow":183},{"id":"mines_184","category":"mines","registration":"GW-765-XB","driver":"DOMINICONE Geoffrey","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-05-06","company":"TFMO","operator":"Jerome","excelRow":184},{"id":"mines_185","category":"mines","registration":"HD-835-SE","driver":"BOWE Geoffrey","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-05-06","company":"TFMO","operator":"Laurent","excelRow":185},{"id":"mines_186","category":"mines","registration":"FG-833-RZ","driver":"CHTIOUI Selim","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-05-10","company":"TFMO","operator":"Christophe","excelRow":186},{"id":"mines_187","category":"mines","registration":"GG-181-DT","driver":"PERARD Jean-François","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-05-10","company":"TFMO","operator":"Laurent","excelRow":187},{"id":"mines_188","category":"mines","registration":"GG-978-ZW","driver":"GYOKERES MICHEL","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-05-10","company":"TFMO","operator":"Raphael","excelRow":188},{"id":"mines_189","category":"mines","registration":"GN-834-TH","driver":"SOUBEYRAND Juan","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-05-10","company":"TFMO","operator":"Christophe","excelRow":189},{"id":"mines_190","category":"mines","registration":"GJ-792-FL","driver":"CLOSE Handy","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-05-11","company":"TFMO","operator":"Laurent","excelRow":190},{"id":"mines_191","category":"mines","registration":"EL-020-TH","driver":"VERCOUTRE Eddy","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-05-12","company":"TFMO","operator":"Laurent","excelRow":191},{"id":"mines_192","category":"mines","registration":"HD-141-WD","driver":"VERCOUTRE Eddy","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-05-12","company":"TFMO","operator":"Laurent","excelRow":192},{"id":"mines_193","category":"mines","registration":"FE-809-DR","driver":"DEGRAS André","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-05-13","company":"TFMO","operator":"Raphael","excelRow":193},{"id":"mines_194","category":"mines","registration":"GG-489-CS","driver":"AUGER Clément","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-05-14","company":"TFMO","operator":"Raphael","excelRow":194},{"id":"mines_195","category":"mines","registration":"GH-682-MG","driver":"AUGER CLÉMENT","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-05-14","company":"TFMO","operator":"Raphael","excelRow":195},{"id":"mines_196","category":"mines","registration":"EP-965-QB","driver":"SECOURS","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-05-17","company":"TFMO","operator":"Jerome","excelRow":196},{"id":"mines_197","category":"mines","registration":"FG-767-DM","driver":"FORTAS Marine","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-05-17","company":"TFMO","operator":"Laurent","excelRow":197},{"id":"mines_198","category":"mines","registration":"GH-683-MG","driver":"JOUIN EVAN","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-05-17","company":"TFMO","operator":"Raphael","excelRow":198},{"id":"mines_199","category":"mines","registration":"GW-731-NW","driver":"GRONDIN OLIVIER","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-05-17","company":"TFMO","operator":"Raphael","excelRow":199},{"id":"mines_200","category":"mines","registration":"GX-608-ZX","driver":"JOUIN Evan","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-05-17","company":"TFMO","operator":"Raphael","excelRow":200},{"id":"mines_201","category":"mines","registration":"HD-295-WD","driver":"REIS PINHO Manuel","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-05-17","company":"TFMO","operator":"Raphael","excelRow":201},{"id":"mines_202","category":"mines","registration":"HD-814-RJ","driver":"DURONZELLE Christopher","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-05-17","company":"TFMO","operator":"Laurent","excelRow":202},{"id":"mines_203","category":"mines","registration":"EZ-217-DB","driver":"DURONZELLE Christopher","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-05-18","company":"TFMO","operator":"Laurent","excelRow":203},{"id":"mines_204","category":"mines","registration":"GH-043-HM","driver":"NEVEU ANTOINE","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-05-18","company":"TFMO","operator":"Laurent","excelRow":204},{"id":"mines_205","category":"mines","registration":"GH-922-HL","driver":"FOURNET DOMINIQUE","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-05-18","company":"TFMO","operator":"Raphael","excelRow":205},{"id":"mines_206","category":"mines","registration":"FS-333-ML","driver":"CARLIER Antoine","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-05-19","company":"TFMO","operator":"Raphael","excelRow":206},{"id":"mines_207","category":"mines","registration":"GP-299-VN","driver":"GUICHARD Cyril","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-05-19","company":"TFMO","operator":"Christophe","excelRow":207},{"id":"mines_208","category":"mines","registration":"HD-021-SF","driver":"CARLIER Antoine","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-05-19","company":"TFMO","operator":"Raphael","excelRow":208},{"id":"mines_209","category":"mines","registration":"FS-047-LH","driver":"GARCIA DE OLIVEIRA Pedro","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-05-20","company":"TFMO","operator":"Laurent","excelRow":209},{"id":"mines_210","category":"mines","registration":"GA-667-ZN","driver":"GUICHARD Cyril","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-05-20","company":"TFMO","operator":"Christophe","excelRow":210},{"id":"mines_211","category":"mines","registration":"GC-786-FX","driver":"FRANGUIAN Patrick","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-05-20","company":"TFMO","operator":"Jerome","excelRow":211},{"id":"mines_212","category":"mines","registration":"HD-909-WC","driver":"GARCIA Pedro","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-05-20","company":"TFMO","operator":"Laurent","excelRow":212},{"id":"mines_213","category":"mines","registration":"EP-333-RR","driver":"SECOURS","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-05-21","company":"TFMO","operator":"Jerome","excelRow":213},{"id":"mines_214","category":"mines","registration":"ET-665-HR","driver":"CARDOSO Mickaël","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-05-21","company":"TFMO","operator":"Raphael","excelRow":214},{"id":"mines_215","category":"mines","registration":"GG-550-TE","driver":"HENNER Marc","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-05-21","company":"TFMO","operator":"Jerome","excelRow":215},{"id":"mines_216","category":"mines","registration":"GP-397-TZ","driver":"CHARRON MARIO","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-05-21","company":"TFMO","operator":"Raphael","excelRow":216},{"id":"mines_217","category":"mines","registration":"GX-247-ML","driver":"JACQUES Sébastien","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-05-21","company":"TFMO","operator":"Jerome","excelRow":217},{"id":"mines_218","category":"mines","registration":"GH-681-MG","driver":"SIMONS ALLAN","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-05-25","company":"TFMO","operator":"Raphael","excelRow":218},{"id":"mines_219","category":"mines","registration":"GR-177-DK","driver":"SIMONS Allan","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-05-25","company":"TFMO","operator":"Raphael","excelRow":219},{"id":"mines_220","category":"mines","registration":"HD-843-RJ","driver":"LECLERC Florian","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-05-25","company":"TFMO","operator":"Jerome","excelRow":220},{"id":"mines_221","category":"mines","registration":"HD-863-XF","driver":"ALBRAN Johan","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-05-25","company":"TFMO","operator":"Christophe","excelRow":221},{"id":"mines_222","category":"mines","registration":"HD-958-SE","driver":"OTT Damien","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-05-25","company":"TFMO","operator":"Laurent","excelRow":222},{"id":"mines_223","category":"mines","registration":"EV-317-LE","driver":"DARCQUE Eric","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-05-26","company":"TFMO","operator":"Raphael","excelRow":223},{"id":"mines_224","category":"mines","registration":"GG-977-ZW","driver":"CHARLES Ludji","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-05-26","company":"TFMO","operator":"Laurent","excelRow":224},{"id":"mines_225","category":"mines","registration":"GP-200-SB","driver":"SAINT LOUIS THIERRY","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-05-26","company":"TFMO","operator":"Laurent","excelRow":225},{"id":"mines_226","category":"mines","registration":"GP-986-RF","driver":"SAINT-LOUIS Thierry","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-05-26","company":"TFMO","operator":"Laurent","excelRow":226},{"id":"mines_227","category":"mines","registration":"GR-841-QT","driver":"DARCQUE ERIC","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-05-26","company":"TFMO","operator":"Raphael","excelRow":227},{"id":"mines_228","category":"mines","registration":"GX-807-XJ","driver":"CHARLES Ludji","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-05-26","company":"TFMO","operator":"Laurent","excelRow":228},{"id":"mines_229","category":"mines","registration":"GG-979-ZW","driver":"COUTURE DAMIEN","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-05-27","company":"TFMO","operator":"Laurent","excelRow":229},{"id":"mines_230","category":"mines","registration":"GP-302-VN","driver":"ZAK Vladimir","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-05-27","company":"TFMO","operator":"Raphael","excelRow":230},{"id":"mines_231","category":"mines","registration":"GG-986-YT","driver":"BALLION Eric","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-05-31","company":"TFMO","operator":"Christophe","excelRow":231},{"id":"mines_232","category":"mines","registration":"GA-173-YW","driver":"DUMAINE Geoffrey","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-06-01","company":"TFMO","operator":"Laurent","excelRow":232},{"id":"mines_233","category":"mines","registration":"GP-298-VN","driver":"DUMAINE GEOFFREY","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-06-01","company":"TFMO","operator":"Laurent","excelRow":233},{"id":"mines_234","category":"mines","registration":"GP-309-VN","driver":"MARTEL JEAN-PHILIPPE","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-06-01","company":"TFMO","operator":"Christophe","excelRow":234},{"id":"mines_235","category":"mines","registration":"HE-582-AE","driver":"MICHEL Michael","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-06-01","company":"TFMO","operator":"Jerome","excelRow":235},{"id":"mines_236","category":"mines","registration":"HE-442-CG","driver":"LECLAIR Maecel","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-06-02","company":"TFMO","operator":"Jerome","excelRow":236},{"id":"mines_237","category":"mines","registration":"EM-100-DW","driver":"OLIVIER Joseph","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-06-03","company":"TFMO","operator":"Laurent","excelRow":237},{"id":"mines_238","category":"mines","registration":"HE-461-CG","driver":"DERNONCOURT Bruno","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-06-03","company":"TFMO","operator":"Christophe","excelRow":238},{"id":"mines_239","category":"mines","registration":"HE-476-CG","driver":"MATOS Tonio","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-06-03","company":"TFMO","operator":"Christophe","excelRow":239},{"id":"mines_240","category":"mines","registration":"FZ-465-WB","driver":"REIS Baptiste","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-06-04","company":"TFMO","operator":"Laurent","excelRow":240},{"id":"mines_241","category":"mines","registration":"HE-496-CG","driver":"WIEST Patrick","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-06-04","company":"TFMO","operator":"Jerome","excelRow":241},{"id":"mines_242","category":"mines","registration":"HK-527-QR","driver":"VIVIN Margo","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-06-05","company":"TFMO","operator":"Christophe","excelRow":242},{"id":"mines_243","category":"mines","registration":"HK-616-QR","driver":"LE COINT Daniel","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-06-05","company":"TFMO","operator":"Laurent","excelRow":243},{"id":"mines_244","category":"mines","registration":"HK-682-QR","driver":"BIMONT Christophe","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-06-05","company":"TFMO","operator":"Laurent","excelRow":244},{"id":"mines_245","category":"mines","registration":"HE-634-AE","driver":"REIS Baptiste","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-06-06","company":"TFMO","operator":"Laurent","excelRow":245},{"id":"mines_246","category":"mines","registration":"FS-454-ML","driver":"RAINHO GOMES Joao","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-06-07","company":"TFMO","operator":"Laurent","excelRow":246},{"id":"mines_247","category":"mines","registration":"HE-611-AE","driver":"RAINHO GOMES Joao","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-06-07","company":"TFMO","operator":"Laurent","excelRow":247},{"id":"mines_248","category":"mines","registration":"HL-730-JP","driver":"DE VRIENDT Thierry","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-06-07","company":"TFMO","operator":"Raphael","excelRow":248},{"id":"mines_249","category":"mines","registration":"EJ-767-ES","driver":"SECOURS","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-06-08","company":"TFMO","operator":"Jerome","excelRow":249},{"id":"mines_250","category":"mines","registration":"GB-312-JX","driver":"PHILIPPE -PLANCON Athéa","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-06-08","company":"TFMO","operator":"Christophe","excelRow":250},{"id":"mines_251","category":"mines","registration":"GG-341-YH","driver":"SAMAIN JÉRÔME","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-06-10","company":"TFMO","operator":"Laurent","excelRow":251},{"id":"mines_252","category":"mines","registration":"GH-044-HM","driver":"BENGUEDDA AHMED","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-06-10","company":"TFMO","operator":"Jerome","excelRow":252},{"id":"mines_253","category":"mines","registration":"GX-215-XJ","driver":"LUGAND Jean-Philippe","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-06-11","company":"TFMO","operator":"Jerome","excelRow":253},{"id":"mines_254","category":"mines","registration":"GP-283-RQ","driver":"DIDIER Philippe","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-06-16","company":"TFMO","operator":"Laurent","excelRow":254},{"id":"mines_255","category":"mines","registration":"GY-841-AK","driver":"MHUN Stéphane","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-06-16","company":"TFMO","operator":"Raphael","excelRow":255},{"id":"mines_256","category":"mines","registration":"EK-216-TW","driver":"SECOURS","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-06-25","company":"TFMO","operator":"Raphael","excelRow":256},{"id":"mines_257","category":"mines","registration":"GR-448-KS","driver":"LUTROT Benjamin","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-06-29","company":"TFMO","operator":"Raphael","excelRow":257},{"id":"mines_258","category":"mines","registration":"FD-386-SW","driver":"BERTHE Gwenael","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-07-01","company":"TFMO","operator":"Laurent","excelRow":258},{"id":"mines_259","category":"mines","registration":"GQ-334-HM","driver":"DEGRAS ANDRÉ","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-07-07","company":"TFMO","operator":"Raphael","excelRow":259},{"id":"mines_260","category":"mines","registration":"FJ-996-RF","driver":"BROSSARD Axel","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-11-08","company":"TFMO","operator":"Laurent","excelRow":260},{"id":"mines_261","category":"mines","registration":"HL-361-JP","driver":"PHILIPPE -PLANCON Athéa","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-06-17","company":"TFMO","operator":"Christophe","excelRow":261},{"id":"mines_262","category":"mines","registration":"FA-604-LR","driver":"GROLET Jérôme","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-08-17","company":"TFMO","operator":"Jerome","excelRow":262},{"id":"mines_263","category":"mines","registration":"HL-038-KG","driver":"PERNIN LUCAS","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-06-18","company":"TFMO","operator":"Christophe","excelRow":263},{"id":"mines_264","category":"mines","registration":"HL-120-KG","driver":"ASSATI Teddy","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-06-18","company":"TFMO","operator":"Raphael","excelRow":264},{"id":"mines_265","category":"mines","registration":"FS-195-ML","driver":"LECLERC Florian","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2026-08-18","company":"TFMO","operator":"Jerome","excelRow":265},{"id":"mines_266","category":"mines","registration":"GR-952-DJ","driver":"VIGNERON ARNAUD","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2026-08-18","company":"TFMO","operator":"Laurent","excelRow":266},{"id":"mines_267","category":"mines","registration":"HF-268-JT","driver":"SOUBEYRAND Juan","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2026-08-18","company":"TFMO","operator":"Christophe","excelRow":267},{"id":"mines_268","category":"mines","registration":"GJ-795-KQ","driver":"GENOUDET Christophe","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-08-18","company":"TFMO","operator":"Jerome","excelRow":268},{"id":"mines_269","category":"mines","registration":"HF-378-JT","driver":"KULA Erdogan","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-08-18","company":"TFMO","operator":"Christophe","excelRow":269},{"id":"mines_270","category":"mines","registration":"HF-509-JT","driver":"AFONSO Pierre","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-08-18","company":"TFMO","operator":"Raphael","excelRow":270},{"id":"mines_271","category":"mines","registration":"EV-609-SF","driver":"TORTIELLO DAMIEN","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-08-19","company":"TFMO","operator":"Christophe","excelRow":271},{"id":"mines_272","category":"mines","registration":"FS-939-LG","driver":"CHERVET CLEMENT","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-08-19","company":"TFMO","operator":"Christophe","excelRow":272},{"id":"mines_273","category":"mines","registration":"GR-296-JZ","driver":"TORTIELLO Damien","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-08-19","company":"TFMO","operator":"Christophe","excelRow":273},{"id":"mines_274","category":"mines","registration":"FN-391-HF","driver":"LE COINT Daniel","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-08-20","company":"TFMO","operator":"Laurent","excelRow":274},{"id":"mines_275","category":"mines","registration":"FP-299-LZ","driver":"SAUGER Willy Alain Edmon","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-08-20","company":"TFMO","operator":"Christophe","excelRow":275},{"id":"mines_276","category":"mines","registration":"GR-128-QR","driver":"DOMINICONE GEOFFREY","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-08-20","company":"TFMO","operator":"Jerome","excelRow":276},{"id":"mines_277","category":"mines","registration":"HF-366-JT","driver":"COIUTTO Gregory","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-08-20","company":"TFMO","operator":"Jerome","excelRow":277},{"id":"mines_278","category":"mines","registration":"HF-425-LL","driver":"SAUGER Willy","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-08-20","company":"TFMO","operator":"Christophe","excelRow":278},{"id":"mines_279","category":"mines","registration":"FD-009-KR","driver":"BLONDIN Pierrick","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-08-23","company":"TFMO","operator":"Laurent","excelRow":279},{"id":"mines_280","category":"mines","registration":"FE-439-RH","driver":"FERRAND Charlotte","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-08-23","company":"TFMO","operator":"Jerome","excelRow":280},{"id":"mines_281","category":"mines","registration":"GJ-551-HK","driver":"PERNIN LUCAS","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-08-23","company":"TFMO","operator":"Christophe","excelRow":281},{"id":"mines_282","category":"mines","registration":"GR-277-XH","driver":"BLONDIN PIERRICK","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-08-23","company":"TFMO","operator":"Laurent","excelRow":282},{"id":"mines_283","category":"mines","registration":"GZ-324-GG","driver":"LEFRANCOIS Denis","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-08-23","company":"TFMO","operator":"Christophe","excelRow":283},{"id":"mines_284","category":"mines","registration":"GZ-444-HE","driver":"LEFRANCOIS Denis","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-08-23","company":"TFMO","operator":"Christophe","excelRow":284},{"id":"mines_285","category":"mines","registration":"HF-450-JT","driver":"LARTAUD Romain","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-08-23","company":"TFMO","operator":"Christophe","excelRow":285},{"id":"mines_286","category":"mines","registration":"FS-002-MM","driver":"MORNET Jordan","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-08-24","company":"TFMO","operator":"Laurent","excelRow":286},{"id":"mines_287","category":"mines","registration":"GC-112-JB","driver":"BOUFFARTIGUE Guy","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-08-24","company":"TFMO","operator":"Christophe","excelRow":287},{"id":"mines_288","category":"mines","registration":"GR-935-PW","driver":"BART GRÉGORY","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-08-24","company":"TFMO","operator":"Laurent","excelRow":288},{"id":"mines_289","category":"mines","registration":"FP-056-MJ","driver":"BART Grégory","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-08-24","company":"TFMO","operator":"Laurent","excelRow":289},{"id":"mines_290","category":"mines","registration":"FD-666-GY","driver":"BOWE GEOFFREY","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-08-24","company":"TFMO","operator":"Laurent","excelRow":290},{"id":"mines_291","category":"mines","registration":"GP-098-ZD","driver":"SAINT MAXIN Gaylor","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-08-24","company":"TFMO","operator":"Laurent","excelRow":291},{"id":"mines_292","category":"mines","registration":"FS-608-VL","driver":"PAUL Franck","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-08-25","company":"TFMO","operator":"Jerome","excelRow":292},{"id":"mines_293","category":"mines","registration":"EK-012-VG","driver":"PAUL Franck","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-08-25","company":"TFMO","operator":"Jerome","excelRow":293},{"id":"mines_294","category":"mines","registration":"GJ-262-RS","driver":"PERARD Jean-Francois","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-08-26","company":"TFMO","operator":"Laurent","excelRow":294},{"id":"mines_295","category":"mines","registration":"EQ-370-FK","driver":"MARMAGNE Benjamin","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-07-27","company":"TFMO","operator":"Laurent","excelRow":295},{"id":"mines_296","category":"mines","registration":"GR-784-QT","driver":"MARMAGNE BENJAMIN","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-07-27","company":"TFMO","operator":"Laurent","excelRow":296},{"id":"mines_297","category":"mines","registration":"GZ-327-GG","driver":"BALAZ Viktoria","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-07-27","company":"TFMO","operator":"Raphael","excelRow":297},{"id":"mines_298","category":"mines","registration":"GS-718-BN","driver":"SENSE FRANCKY","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-08-27","company":"TFMO","operator":"Laurent","excelRow":298},{"id":"mines_299","category":"mines","registration":"GZ-028-QT","driver":"SENSE Francky","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-08-27","company":"TFMO","operator":"Laurent","excelRow":299},{"id":"mines_300","category":"mines","registration":"HF-402-LL","driver":"GENOUDET Christophe","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-08-27","company":"TFMO","operator":"Jerome","excelRow":300},{"id":"mines_301","category":"mines","registration":"GJ-610-HD","driver":"DEBOST Raphaël","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-07-30","company":"TFMO","operator":"Jerome","excelRow":301},{"id":"mines_302","category":"mines","registration":"GZ-325-NJ","driver":"PLATEAU Francois","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-08-30","company":"TFMO","operator":"Christophe","excelRow":302},{"id":"mines_303","category":"mines","registration":"GF-941-CC","driver":"PLATEAU Francois","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-08-30","company":"TFMO","operator":"Christophe","excelRow":303},{"id":"mines_304","category":"mines","registration":"FD-019-GD","driver":"DESSEIGNE Cedric","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-08-30","company":"TFMO","operator":"Laurent","excelRow":304},{"id":"mines_305","category":"mines","registration":"HF-246-JT","driver":"DESSEIGNE Cedric","genre":"Tracteurs","control":"MINES","label":"passage aux mines","nextControl":"2027-08-30","company":"TFMO","operator":"Laurent","excelRow":305},{"id":"mines_306","category":"mines","registration":"FD-238-GD","driver":"NEVEU Antoine Jacques","genre":"Semis Remorques","control":"MINES","label":"passage aux mines","nextControl":"2027-08-31","company":"TFMO","operator":"Laurent","excelRow":306},{"id":"limiteur_4","category":"limiteur","registration":"GP-302-VN","driver":"ZAK Vladimir","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2026-09-08","company":"TFMO","operator":"Raphael","excelRow":4},{"id":"limiteur_5","category":"limiteur","registration":"GJ-262-RS","driver":"PERARD Jean-Francois","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2026-09-10","company":"TFMO","operator":"Laurent","excelRow":5},{"id":"limiteur_6","category":"limiteur","registration":"GG-977-ZW","driver":"CHARLES Ludji","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2026-09-17","company":"TFMO","operator":"Laurent","excelRow":6},{"id":"limiteur_7","category":"limiteur","registration":"GR-935-PW","driver":"BART GRÉGORY","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2026-09-18","company":"TFMO","operator":"Laurent","excelRow":7},{"id":"limiteur_8","category":"limiteur","registration":"GR-901-XD","driver":"BROSSARD Axel","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2026-09-19","company":"TFMO","operator":"Laurent","excelRow":8},{"id":"limiteur_9","category":"limiteur","registration":"GZ-324-GG","driver":"LEFRANCOIS Denis","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2026-09-22","company":"TFMO","operator":"Christophe","excelRow":9},{"id":"limiteur_10","category":"limiteur","registration":"GR-841-QT","driver":"DARCQUE ERIC","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2026-09-22","company":"TFMO","operator":"Raphael","excelRow":10},{"id":"limiteur_11","category":"limiteur","registration":"HF-418-JT","driver":"SICLER Mickael","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2026-09-22","company":"TFMO","operator":"Jerome","excelRow":11},{"id":"limiteur_12","category":"limiteur","registration":"GS-045-GE","driver":"FORTAS Marine","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2026-09-25","company":"TFMO","operator":"Laurent","excelRow":12},{"id":"limiteur_13","category":"limiteur","registration":"GZ-323-GG","driver":"BARDET Christophe","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2026-09-26","company":"TFMO","operator":"Laurent","excelRow":13},{"id":"limiteur_14","category":"limiteur","registration":"HF-509-JT","driver":"AFONSO Pierre","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2026-09-26","company":"TFMO","operator":"Raphael","excelRow":14},{"id":"limiteur_15","category":"limiteur","registration":"HF-538-JT","driver":"CHARPENTIER Hervé","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2026-09-26","company":"TFMO","operator":"Raphael","excelRow":15},{"id":"limiteur_16","category":"limiteur","registration":"GZ-767-NH","driver":"ROUAG Badredine","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2026-09-30","company":"TFMO","operator":"Christophe","excelRow":16},{"id":"limiteur_17","category":"limiteur","registration":"GR-259-WZ","driver":"CHARRON MARIO","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2026-10-01","company":"TFMO","operator":"Raphael","excelRow":17},{"id":"limiteur_18","category":"limiteur","registration":"GS-718-BN","driver":"SENSE FRANCKY","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2026-10-01","company":"TFMO","operator":"Laurent","excelRow":18},{"id":"limiteur_19","category":"limiteur","registration":"GH-923-HL","driver":"FELIX PIERRE","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2026-10-02","company":"TFMO","operator":"Christophe","excelRow":19},{"id":"limiteur_20","category":"limiteur","registration":"HF-390-LL","driver":"CHAVET Jeremy","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2026-10-03","company":"TFMO","operator":"Raphael","excelRow":20},{"id":"limiteur_21","category":"limiteur","registration":"GR-277-XH","driver":"BLONDIN PIERRICK","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2026-10-07","company":"TFMO","operator":"Laurent","excelRow":21},{"id":"limiteur_22","category":"limiteur","registration":"GV-293-AQ","driver":"MORNET Jordan","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2026-10-07","company":"TFMO","operator":"Laurent","excelRow":22},{"id":"limiteur_23","category":"limiteur","registration":"GC-112-JB","driver":"BOUFFARTIGUE Guy","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2026-10-08","company":"TFMO","operator":"Christophe","excelRow":23},{"id":"limiteur_24","category":"limiteur","registration":"GR-784-QT","driver":"MARMAGNE BENJAMIN","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2026-10-08","company":"TFMO","operator":"Laurent","excelRow":24},{"id":"limiteur_25","category":"limiteur","registration":"GP-309-VN","driver":"MARTEL JEAN-PHILIPPE","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2026-10-09","company":"TFMO","operator":"Christophe","excelRow":25},{"id":"limiteur_26","category":"limiteur","registration":"GE-839-ZY","driver":"GROLET Jérome","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2026-10-10","company":"TFMO","operator":"Jerome","excelRow":26},{"id":"limiteur_27","category":"limiteur","registration":"GE-875-ZY","driver":"PEREIRA Brigitte","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2026-10-11","company":"TFMO","operator":"Jerome","excelRow":27},{"id":"limiteur_28","category":"limiteur","registration":"GR-290-GV","driver":"DOMINGO BONAVENTURE","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2026-10-13","company":"TFMO","operator":"Christophe","excelRow":28},{"id":"limiteur_29","category":"limiteur","registration":"GS-117-EJ","driver":"CHTIOUI Selim","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2026-10-13","company":"TFMO","operator":"Christophe","excelRow":29},{"id":"limiteur_30","category":"limiteur","registration":"GS-304-EJ","driver":"JACQUES SÉBASTIEN","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2026-10-16","company":"TFMO","operator":"Jerome","excelRow":30},{"id":"limiteur_31","category":"limiteur","registration":"GR-472-GV","driver":"JAMBON EDDY","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2026-10-20","company":"TFMO","operator":"Christophe","excelRow":31},{"id":"limiteur_32","category":"limiteur","registration":"GS-047-GE","driver":"GRONDIN OLIVIER","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2026-10-20","company":"TFMO","operator":"Raphael","excelRow":32},{"id":"limiteur_33","category":"limiteur","registration":"GS-048-GE","driver":"DIDIER PHILIPPE","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2026-10-20","company":"TFMO","operator":"Laurent","excelRow":33},{"id":"limiteur_34","category":"limiteur","registration":"GS-999-BM","driver":"MEENS Alexandre","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2026-10-20","company":"TFMO","operator":"Laurent","excelRow":34},{"id":"limiteur_35","category":"limiteur","registration":"GZ-932-NJ","driver":"CLOSE Handy","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2026-10-22","company":"TFMO","operator":"Laurent","excelRow":35},{"id":"limiteur_36","category":"limiteur","registration":"GR-338-XH","driver":"VANECHOP RODOLPHE","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2026-10-23","company":"TFMO","operator":"Laurent","excelRow":36},{"id":"limiteur_37","category":"limiteur","registration":"GS-722-DS","driver":"LOUVET DAVID","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2026-10-28","company":"TFMO","operator":"Laurent","excelRow":37},{"id":"limiteur_38","category":"limiteur","registration":"GF-549-HB","driver":"VIRFOLLET Eric","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2026-10-30","company":"TFMO","operator":"Laurent","excelRow":38},{"id":"limiteur_39","category":"limiteur","registration":"GT-763-KY","driver":"COLAERT Jonathan","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2026-10-30","company":"TFMO","operator":"Laurent","excelRow":39},{"id":"limiteur_40","category":"limiteur","registration":"GE-841-ZY","driver":"VOSKERITCHIAN Stephane","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2026-11-10","company":"TFMO","operator":"Laurent","excelRow":40},{"id":"limiteur_41","category":"limiteur","registration":"GP-299-VN","driver":"GUICHARD Cyril","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2026-12-03","company":"TFMO","operator":"Christophe","excelRow":41},{"id":"limiteur_42","category":"limiteur","registration":"GH-681-MG","driver":"SIMONS ALLAN","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2026-12-07","company":"TFMO","operator":"Raphael","excelRow":42},{"id":"limiteur_43","category":"limiteur","registration":"FW-266-JB","driver":"ABBE Eric","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2026-12-08","company":"TFMO","operator":"Jerome","excelRow":43},{"id":"limiteur_44","category":"limiteur","registration":"GV-290-AQ","driver":"AGASSE FRÉDÉRIC","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2026-12-10","company":"TFMO","operator":"Raphael","excelRow":44},{"id":"limiteur_45","category":"limiteur","registration":"GT-858-KY","driver":"CUISINIER KÉLLY","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2026-12-15","company":"TFMO","operator":"Jerome","excelRow":45},{"id":"limiteur_46","category":"limiteur","registration":"GT-666-KY","driver":"MOURET THIERRY","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2026-12-17","company":"TFMO","operator":"Christophe","excelRow":46},{"id":"limiteur_47","category":"limiteur","registration":"GV-915-QX","driver":"LE CAILLEC ERIC","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2026-12-22","company":"TFMO","operator":"Raphael","excelRow":47},{"id":"limiteur_48","category":"limiteur","registration":"GF-845-FH","driver":"CARDOSO Mickael","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2026-12-23","company":"TFMO","operator":"Raphael","excelRow":48},{"id":"limiteur_49","category":"limiteur","registration":"GF-847-FH","driver":"PAUL Vincent","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2026-12-24","company":"TFMO","operator":"Jerome","excelRow":49},{"id":"limiteur_50","category":"limiteur","registration":"GT-943-KY","driver":"OLIVIER JOSEPH","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2026-12-24","company":"TFMO","operator":"Laurent","excelRow":50},{"id":"limiteur_51","category":"limiteur","registration":"GV-292-AQ","driver":"OBE DORIAN","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2026-12-31","company":"TFMO","operator":"Laurent","excelRow":51},{"id":"limiteur_52","category":"limiteur","registration":"GE-842-ZY","driver":"BERTHE Gwenael","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-01-06","company":"TFMO","operator":"Laurent","excelRow":52},{"id":"limiteur_53","category":"limiteur","registration":"HL-038-KG","driver":"PERNIN Lucas","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-01-07","company":"TFMO","operator":"Christophe","excelRow":53},{"id":"limiteur_54","category":"limiteur","registration":"HL-859-JP","driver":"BOTTINO Mickael","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-01-07","company":"TFMO","operator":"Christophe","excelRow":54},{"id":"limiteur_55","category":"limiteur","registration":"GN-510-PA","driver":"TSCHIRRET LIONEL","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-01-07","company":"TFMO","operator":"Laurent","excelRow":55},{"id":"limiteur_56","category":"limiteur","registration":"GE-843-ZY","driver":"GOUTRY Alexandre","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-01-13","company":"TFMO","operator":"Jerome","excelRow":56},{"id":"limiteur_57","category":"limiteur","registration":"GV-980-HT","driver":"TAILLARD SAMUEL","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-01-14","company":"TFMO","operator":"Laurent","excelRow":57},{"id":"limiteur_58","category":"limiteur","registration":"DJ-413-WF","driver":"PORTEUR","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-01-15","company":"TFMO","operator":"Jerome","excelRow":58},{"id":"limiteur_59","category":"limiteur","registration":"GF-209-GJ","driver":"GERME Ludovic","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-01-16","company":"TFMO","operator":"Laurent","excelRow":59},{"id":"limiteur_60","category":"limiteur","registration":"GV-294-AQ","driver":"MARGERIE Tom","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-01-19","company":"TFMO","operator":"Christophe","excelRow":60},{"id":"limiteur_61","category":"limiteur","registration":"GV-246-SY","driver":"RIBOTTE DOMINIQUE","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-01-21","company":"TFMO","operator":"Raphael","excelRow":61},{"id":"limiteur_62","category":"limiteur","registration":"GV-291-AQ","driver":"HENNER MARC","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-01-23","company":"TFMO","operator":"Jerome","excelRow":62},{"id":"limiteur_63","category":"limiteur","registration":"GF-844-FH","driver":"DE OLIVEIRA JOAO","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-01-27","company":"TFMO","operator":"Laurent","excelRow":63},{"id":"limiteur_64","category":"limiteur","registration":"HH-234-XG","driver":"RONZEL Grégory","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-01-28","company":"TFMO","operator":"Jerome","excelRow":64},{"id":"limiteur_65","category":"limiteur","registration":"HH-295-XC","driver":"MOREL Gérald","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-01-28","company":"TFMO","operator":"Jerome","excelRow":65},{"id":"limiteur_66","category":"limiteur","registration":"GV-983-HT","driver":"STUDER MARC","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-02-03","company":"TFMO","operator":"Jerome","excelRow":66},{"id":"limiteur_67","category":"limiteur","registration":"GF-264-BF","driver":"DHONDT Eric","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-02-04","company":"TFMO","operator":"Laurent","excelRow":67},{"id":"limiteur_68","category":"limiteur","registration":"GV-913-QX","driver":"LUGAND JEAN-PHILIPPE","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-02-10","company":"TFMO","operator":"Jerome","excelRow":68},{"id":"limiteur_69","category":"limiteur","registration":"GV-248-SY","driver":"ANGIBAUD Romuald","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-02-11","company":"TFMO","operator":"Christophe","excelRow":69},{"id":"limiteur_70","category":"limiteur","registration":"GF-546-HB","driver":"GIABBANI Hedi","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-02-11","company":"TFMO","operator":"Jerome","excelRow":70},{"id":"limiteur_71","category":"limiteur","registration":"GF-130-GJ","driver":"LOUIS Jimmy","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-02-12","company":"TFMO","operator":"Laurent","excelRow":71},{"id":"limiteur_72","category":"limiteur","registration":"GV-911-QX","driver":"BALLION Eric","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-02-13","company":"TFMO","operator":"Christophe","excelRow":72},{"id":"limiteur_73","category":"limiteur","registration":"GF-843-FH","driver":"CAPITAINE Olivier","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-02-18","company":"TFMO","operator":"Christophe","excelRow":73},{"id":"limiteur_74","category":"limiteur","registration":"GV-981-HT","driver":"BAIKRICH ROMAIN","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-02-20","company":"TFMO","operator":"Jerome","excelRow":74},{"id":"limiteur_75","category":"limiteur","registration":"GV-259-XQ","driver":"PATURET STEVE","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-02-26","company":"TFMO","operator":"Christophe","excelRow":75},{"id":"limiteur_76","category":"limiteur","registration":"GV-262-XQ","driver":"MAZILLE JOHN","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-03-01","company":"TFMO","operator":"Christophe","excelRow":76},{"id":"limiteur_77","category":"limiteur","registration":"GV-263-XQ","driver":"DAURAT AGATHE","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-03-02","company":"TFMO","operator":"Christophe","excelRow":77},{"id":"limiteur_78","category":"limiteur","registration":"GH-044-HM","driver":"BENGUEDDA AHMED","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-03-06","company":"TFMO","operator":"Jerome","excelRow":78},{"id":"limiteur_79","category":"limiteur","registration":"GW-084-EQ","driver":"LUTROT BENJAMIN","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-03-09","company":"TFMO","operator":"Raphael","excelRow":79},{"id":"limiteur_80","category":"limiteur","registration":"GV-261-XQ","driver":"AURIOU GEOFFREY","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-03-16","company":"TFMO","operator":"Jerome","excelRow":80},{"id":"limiteur_81","category":"limiteur","registration":"HJ-538-PR","driver":"Yé Etienne","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-03-16","company":"TFMO","operator":"Jerome","excelRow":81},{"id":"limiteur_82","category":"limiteur","registration":"GN-349-FX","driver":"MONTEIRO JOSE","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-03-25","company":"TFMO","operator":"Jerome","excelRow":82},{"id":"limiteur_83","category":"limiteur","registration":"HJ-717-SP","driver":"SOLD Jean Louis","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-03-25","company":"TFMO","operator":"Jerome","excelRow":83},{"id":"limiteur_84","category":"limiteur","registration":"HJ-541-TY","driver":"SAUZET Jean-David","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-03-26","company":"TFMO","operator":"Jerome","excelRow":84},{"id":"limiteur_85","category":"limiteur","registration":"HJ-023-WH","driver":"MONTOIS Jason","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-03-29","company":"TFMO","operator":"Christophe","excelRow":85},{"id":"limiteur_86","category":"limiteur","registration":"GG-978-ZW","driver":"GYOKERES MICHEL","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-04-07","company":"TFMO","operator":"Raphael","excelRow":86},{"id":"limiteur_87","category":"limiteur","registration":"GH-683-MG","driver":"JOUIN EVAN","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-04-07","company":"TFMO","operator":"Raphael","excelRow":87},{"id":"limiteur_88","category":"limiteur","registration":"HK-922-FK","driver":"DEBOST Raphael","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-04-22","company":"TFMO","operator":"Jerome","excelRow":88},{"id":"limiteur_89","category":"limiteur","registration":"HD-835-SE","driver":"BOWE Geoffrey","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-04-23","company":"TFMO","operator":"Laurent","excelRow":89},{"id":"limiteur_90","category":"limiteur","registration":"GH-105-HJ","driver":"LACROIX DAMIEN","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-04-26","company":"TFMO","operator":"Christophe","excelRow":90},{"id":"limiteur_91","category":"limiteur","registration":"GH-684-MG","driver":"TINE Thomas","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-04-27","company":"TFMO","operator":"Laurent","excelRow":91},{"id":"limiteur_92","category":"limiteur","registration":"HK-636-FD","driver":"VIGNERON Arnaud","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-04-27","company":"TFMO","operator":"Laurent","excelRow":92},{"id":"limiteur_93","category":"limiteur","registration":"GP-200-SB","driver":"SAINT LOUIS THIERRY","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-05-04","company":"TFMO","operator":"Laurent","excelRow":93},{"id":"limiteur_94","category":"limiteur","registration":"HK-982-FK","driver":"RICHEZ Eric","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-05-04","company":"TFMO","operator":"Laurent","excelRow":94},{"id":"limiteur_95","category":"limiteur","registration":"HK-904-JG","driver":"CHERVET Clément","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-05-06","company":"TFMO","operator":"Christophe","excelRow":95},{"id":"limiteur_96","category":"limiteur","registration":"HE-442-CG","driver":"LECLAIR Marcel","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-05-06","company":"TFMO","operator":"Jerome","excelRow":96},{"id":"limiteur_97","category":"limiteur","registration":"GG-980-ZW","driver":"KIZILKILIC Cegiz","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-05-10","company":"TFMO","operator":"Christophe","excelRow":97},{"id":"limiteur_98","category":"limiteur","registration":"GH-082-HJ","driver":"BENOIST Olivier","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-05-10","company":"TFMO","operator":"Christophe","excelRow":98},{"id":"limiteur_99","category":"limiteur","registration":"GG-208-VK","driver":"BARRY Ousmane","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-05-10","company":"TFMO","operator":"Jerome","excelRow":99},{"id":"limiteur_100","category":"limiteur","registration":"HD-843-RJ","driver":"LECLERC Florian","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-05-11","company":"TFMO","operator":"Jerome","excelRow":100},{"id":"limiteur_101","category":"limiteur","registration":"GH-922-HL","driver":"FOURNET DOMINIQUE","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-05-12","company":"TFMO","operator":"Raphael","excelRow":101},{"id":"limiteur_102","category":"limiteur","registration":"HD-021-SF","driver":"CARLIER Antoine","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-05-14","company":"TFMO","operator":"Raphael","excelRow":102},{"id":"limiteur_103","category":"limiteur","registration":"GH-682-MG","driver":"AUGER CLÉMENT","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-05-17","company":"TFMO","operator":"Raphael","excelRow":103},{"id":"limiteur_104","category":"limiteur","registration":"GH-043-HM","driver":"NEVEU ANTOINE","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-05-18","company":"TFMO","operator":"Laurent","excelRow":104},{"id":"limiteur_105","category":"limiteur","registration":"HD-295-WD","driver":"REIS PINHO Manuel","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-05-18","company":"TFMO","operator":"Raphael","excelRow":105},{"id":"limiteur_106","category":"limiteur","registration":"HK-367-KT","driver":"POURRAT Valentin","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-05-19","company":"TFMO","operator":"Christophe","excelRow":106},{"id":"limiteur_107","category":"limiteur","registration":"HK-327-KT","driver":"RUHLAND Martin","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-05-19","company":"TFMO","operator":"Jerome","excelRow":107},{"id":"limiteur_108","category":"limiteur","registration":"GC-786-FX","driver":"FRANGUIAN Patrick","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-05-20","company":"TFMO","operator":"Jerome","excelRow":108},{"id":"limiteur_109","category":"limiteur","registration":"HD-814-RJ","driver":"DURONZELLE Christopher","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-05-21","company":"TFMO","operator":"Laurent","excelRow":109},{"id":"limiteur_110","category":"limiteur","registration":"HD-863-XF","driver":"ALBRAN Johan","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-05-25","company":"TFMO","operator":"Christophe","excelRow":110},{"id":"limiteur_111","category":"limiteur","registration":"HD-909-WC","driver":"GARCIA Pedro","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-05-25","company":"TFMO","operator":"Laurent","excelRow":111},{"id":"limiteur_112","category":"limiteur","registration":"HD-958-SE","driver":"OTT Damien","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-05-25","company":"TFMO","operator":"Laurent","excelRow":112},{"id":"limiteur_113","category":"limiteur","registration":"HK-660-QC","driver":"SANZ Pierre","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-05-28","company":"TFMO","operator":"Christophe","excelRow":113},{"id":"limiteur_114","category":"limiteur","registration":"GN-463-VP","driver":"TIXIER LUDOVIC","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-05-30","company":"TFMO","operator":"Christophe","excelRow":114},{"id":"limiteur_115","category":"limiteur","registration":"GG-979-ZW","driver":"COUTURE DAMIEN","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-06-01","company":"TFMO","operator":"Laurent","excelRow":115},{"id":"limiteur_116","category":"limiteur","registration":"GP-298-VN","driver":"DUMAINE GEOFFREY","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-06-01","company":"TFMO","operator":"Laurent","excelRow":116},{"id":"limiteur_117","category":"limiteur","registration":"HE-634-AE","driver":"REIS Baptiste","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-06-01","company":"TFMO","operator":"Laurent","excelRow":117},{"id":"limiteur_118","category":"limiteur","registration":"HK-057-QD","driver":"ABDULAH Jeremy","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-06-02","company":"TFMO","operator":"Jerome","excelRow":118},{"id":"limiteur_119","category":"limiteur","registration":"HE-461-CG","driver":"DERNONCOURT Bruno","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-06-03","company":"TFMO","operator":"Christophe","excelRow":119},{"id":"limiteur_120","category":"limiteur","registration":"HE-476-CG","driver":"MATOS Tonio","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-06-03","company":"TFMO","operator":"Christophe","excelRow":120},{"id":"limiteur_121","category":"limiteur","registration":"HD-141-WD","driver":"VERCOUTRE Eddy","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-06-03","company":"TFMO","operator":"Laurent","excelRow":121},{"id":"limiteur_122","category":"limiteur","registration":"HK-989-QC","driver":"RICHEZ Benoit","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-06-04","company":"TFMO","operator":"Laurent","excelRow":122},{"id":"limiteur_123","category":"limiteur","registration":"GV-974-MD","driver":"MAZALLON CHRISTIAN","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-06-07","company":"TFMO","operator":"Christophe","excelRow":123},{"id":"limiteur_124","category":"limiteur","registration":"GG-341-YH","driver":"SAMAIN JÉRÔME","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-06-07","company":"TFMO","operator":"Laurent","excelRow":124},{"id":"limiteur_125","category":"limiteur","registration":"GQ-334-HM","driver":"DEGRAS ANDRÉ","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-06-07","company":"TFMO","operator":"Raphael","excelRow":125},{"id":"limiteur_126","category":"limiteur","registration":"HE-611-AE","driver":"RAINHO GOMES Joao","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-06-07","company":"TFMO","operator":"Laurent","excelRow":126},{"id":"limiteur_127","category":"limiteur","registration":"HL-120-KG","driver":"ASSATI Teddy","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-06-07","company":"TFMO","operator":"Raphael","excelRow":127},{"id":"limiteur_128","category":"limiteur","registration":"HL-730-JP","driver":"DE VRIENDT Thierry","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-06-07","company":"TFMO","operator":"Raphael","excelRow":128},{"id":"limiteur_129","category":"limiteur","registration":"HE-582-AE","driver":"MICHEL Michael","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-06-08","company":"TFMO","operator":"Jerome","excelRow":129},{"id":"limiteur_130","category":"limiteur","registration":"GV-914-QX","driver":"MHUN Stéphane","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-06-10","company":"TFMO","operator":"Raphael","excelRow":130},{"id":"limiteur_131","category":"limiteur","registration":"HE-496-CG","driver":"WIEST Patrick","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-06-11","company":"TFMO","operator":"Jerome","excelRow":131},{"id":"limiteur_132","category":"limiteur","registration":"HK-527-QR","driver":"VIVIN Margot","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-10-06","company":"TFMO","operator":"Christophe","excelRow":132},{"id":"limiteur_133","category":"limiteur","registration":"HK-616-QR","driver":"LE COINT Daniel","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-06-16","company":"TFMO","operator":"Laurent","excelRow":133},{"id":"limiteur_134","category":"limiteur","registration":"HF-268-JT","driver":"SOUBEYRAND Juan","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-08-17","company":"TFMO","operator":"Christophe","excelRow":134},{"id":"limiteur_135","category":"limiteur","registration":"HK-682-QR","driver":"BIMONT Christophe","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-06-18","company":"TFMO","operator":"Laurent","excelRow":135},{"id":"limiteur_136","category":"limiteur","registration":"HF-378-JT","driver":"KULA Erdogan","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-08-18","company":"TFMO","operator":"Christophe","excelRow":136},{"id":"limiteur_137","category":"limiteur","registration":"GR-296-JZ","driver":"TORTIELLO Damien","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-08-18","company":"TFMO","operator":"Christophe","excelRow":137},{"id":"limiteur_138","category":"limiteur","registration":"GZ-587-GB","driver":"BREVET Arnaud","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-08-19","company":"TFMO","operator":"Jerome","excelRow":138},{"id":"limiteur_139","category":"limiteur","registration":"GR-128-QR","driver":"DOMINICONE GEOFFREY","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-08-20","company":"TFMO","operator":"Jerome","excelRow":139},{"id":"limiteur_140","category":"limiteur","registration":"HF-366-JT","driver":"COIUTTO Gregory","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-08-20","company":"TFMO","operator":"Jerome","excelRow":140},{"id":"limiteur_141","category":"limiteur","registration":"HF-425-LL","driver":"SAUGER Willy","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-08-20","company":"TFMO","operator":"Christophe","excelRow":141},{"id":"limiteur_142","category":"limiteur","registration":"GN-465-VP","driver":"FERRAND Charlotte","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-06-21","company":"TFMO","operator":"Jerome","excelRow":142},{"id":"limiteur_143","category":"limiteur","registration":"HF-450-JT","driver":"LARTAUD Romain","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-08-23","company":"TFMO","operator":"Christophe","excelRow":143},{"id":"limiteur_144","category":"limiteur","registration":"HL-361-JP","driver":"PHILIPPE-PLANCON Athéa","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-06-24","company":"TFMO","operator":"Christophe","excelRow":144},{"id":"limiteur_145","category":"limiteur","registration":"GP-098-ZD","driver":"SAINT MAXIN Gaylor","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-08-24","company":"TFMO","operator":"Laurent","excelRow":145},{"id":"limiteur_146","category":"limiteur","registration":"FS-608-VL","driver":"PAUL Franck","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-08-25","company":"TFMO","operator":"Jerome","excelRow":146},{"id":"limiteur_147","category":"limiteur","registration":"GZ-327-GG","driver":"BALAZ Viktoria","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-07-27","company":"TFMO","operator":"Raphael","excelRow":147},{"id":"limiteur_148","category":"limiteur","registration":"HF-402-LL","driver":"GENOUDET Christophe","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-08-27","company":"TFMO","operator":"Jerome","excelRow":148},{"id":"limiteur_149","category":"limiteur","registration":"GZ-325-NJ","driver":"PLATEAU Francois","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-08-30","company":"TFMO","operator":"Christophe","excelRow":149},{"id":"limiteur_150","category":"limiteur","registration":"HF-246-JT","driver":"DESSEIGNE Cedric","control":"LIMITEUR","label":"controle du limiteur de vitesse","lastControl":"","nextControl":"2027-08-30","company":"TFMO","operator":"Laurent","excelRow":150},{"id":"confinement_4","category":"confinement","registration":"FP-279-RM","driver":"SAINT MAXIN Gyalor","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2026-08-12","company":"TFMO","operator":"Laurent","excelRow":4},{"id":"confinement_5","category":"confinement","registration":"FY-344-SC","driver":"COUTURE Damien","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2026-08-12","company":"TFMO","operator":"Laurent","excelRow":5},{"id":"confinement_6","category":"confinement","registration":"FP-428-QV","driver":"FRANGUIAN Patrick","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2026-08-20","company":"TFMO","operator":"Jérôme","excelRow":6},{"id":"confinement_7","category":"confinement","registration":"GR-694-KT","driver":"MICHEL Michaël","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2026-09-03","company":"TFMO","operator":"Jérôme","excelRow":7},{"id":"confinement_8","category":"confinement","registration":"GJ-812-NQ","driver":"SOLD Jean louis","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2026-09-05","company":"TFMO","operator":"Jérôme","excelRow":8},{"id":"confinement_9","category":"confinement","registration":"GJ-792-FL","driver":"CLOSE Handy","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2026-09-16","company":"TFMO","operator":"Laurent","excelRow":9},{"id":"confinement_10","category":"confinement","registration":"EZ-217-DB","driver":"DURONZELLE Christopher","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2026-09-17","company":"TFMO","operator":"Laurent","excelRow":10},{"id":"confinement_11","category":"confinement","registration":"GR-952-DJ","driver":"VIGNERON ARNAUD","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2026-09-17","company":"TFMO","operator":"Laurent","excelRow":11},{"id":"confinement_12","category":"confinement","registration":"EP-965-QB","driver":"SECOURS","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2026-09-30","company":"TFMO","operator":"Jerome","excelRow":12},{"id":"confinement_13","category":"confinement","registration":"FJ-305-RG","driver":"TINE Thomas","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2026-09-30","company":"TFMO","operator":"Laurent","excelRow":13},{"id":"confinement_14","category":"confinement","registration":"FX-027-RZ","driver":"ALBRAN Johan","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2026-10-03","company":"TFMO","operator":"Christophe","excelRow":14},{"id":"confinement_15","category":"confinement","registration":"FP-352-HB","driver":"MONTEIRO GONCALVES JOSE","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2026-10-07","company":"TFMO","operator":"Jérôme","excelRow":15},{"id":"confinement_16","category":"confinement","registration":"GZ-028-QT","driver":"SENSE Francky","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2026-10-08","company":"TFMO","operator":"Jérôme","excelRow":16},{"id":"confinement_17","category":"confinement","registration":"GZ-967-PD","driver":"BARDET Christophe","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2026-10-08","company":"TFMO","operator":"Laurent","excelRow":17},{"id":"confinement_18","category":"confinement","registration":"FG-344-CP","driver":"SANZ Pierre","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2026-10-09","company":"TFMO","operator":"Jérôme","excelRow":18},{"id":"confinement_19","category":"confinement","registration":"FS-939-LG","driver":"CHERVET Clément","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2026-10-09","company":"TFMO","operator":"Christophe","excelRow":19},{"id":"confinement_20","category":"confinement","registration":"GJ-551-HK","driver":"PERNIN LUCAS","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2026-10-13","company":"TFMO","operator":"Christophe","excelRow":20},{"id":"confinement_21","category":"confinement","registration":"FP-005-MT","driver":"SAUZET JEAN DAVID","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2026-10-14","company":"TFMO","operator":"Jerome","excelRow":21},{"id":"confinement_22","category":"confinement","registration":"GJ-795-KQ","driver":"GENOUDET Christophe","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2026-10-14","company":"TFMO","operator":"Jérôme","excelRow":22},{"id":"confinement_23","category":"confinement","registration":"EQ-113-HY","driver":"LACROIX Damien","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2026-10-15","company":"TFMO","operator":"Christophe","excelRow":23},{"id":"confinement_24","category":"confinement","registration":"GZ-538-FZ","driver":"BREVET Arnaud","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2026-10-15","company":"TFMO","operator":"Jérôme","excelRow":24},{"id":"confinement_25","category":"confinement","registration":"GR-153-QX","driver":"BOTTINO MICKAEL","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2026-10-16","company":"TFMO","operator":"Christophe","excelRow":25},{"id":"confinement_26","category":"confinement","registration":"FB-024-HM","driver":"DOMINGO Kouassi Bonaventure","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2026-10-17","company":"TFMO","operator":"Christophe","excelRow":26},{"id":"confinement_27","category":"confinement","registration":"GZ-636-VC","driver":"ROUAG Badredine","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2026-10-21","company":"TFMO","operator":"Christophe","excelRow":27},{"id":"confinement_28","category":"confinement","registration":"HA-530-BB","driver":"CHAVET Jérémy","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2026-10-22","company":"TFMO","operator":"Raphaêl","excelRow":28},{"id":"confinement_29","category":"confinement","registration":"GZ-714-YX","driver":"WIEST Patrick","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2026-10-24","company":"TFMO","operator":"Jérôme","excelRow":29},{"id":"confinement_30","category":"confinement","registration":"FS-002-MM","driver":"MORNET Jordan","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2026-10-27","company":"TFMO","operator":"Laurent","excelRow":30},{"id":"confinement_31","category":"confinement","registration":"FG-767-DM","driver":"FORTAS Marine","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2026-10-28","company":"TFMO","operator":"Laurent","excelRow":31},{"id":"confinement_32","category":"confinement","registration":"FS-333-ML","driver":"CARLIER Antoine","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2026-10-28","company":"TFMO","operator":"Raphaêl","excelRow":32},{"id":"confinement_33","category":"confinement","registration":"GA-173-YW","driver":"DUMAINE Geoffrey","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2026-10-28","company":"TFMO","operator":"Laurent","excelRow":33},{"id":"confinement_34","category":"confinement","registration":"FY-434-KV","driver":"KULA Erdogan","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2026-10-29","company":"TFMO","operator":"Christophe","excelRow":34},{"id":"confinement_35","category":"confinement","registration":"GZ-444-HE","driver":"LEFRANCOIS Denis","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2026-10-29","company":"TFMO","operator":"Christophe","excelRow":35},{"id":"confinement_36","category":"confinement","registration":"EP-333-RR","driver":"SECOURS","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2026-10-31","company":"TFMO","operator":"Jérôme","excelRow":36},{"id":"confinement_37","category":"confinement","registration":"FD-158-GZ","driver":"OTT Damien","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2026-10-31","company":"TFMO","operator":"Raphaêl","excelRow":37},{"id":"confinement_38","category":"confinement","registration":"EK-012-VG","driver":"PAUL Franck","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2026-11-05","company":"TFMO","operator":"Jérôme","excelRow":38},{"id":"confinement_39","category":"confinement","registration":"FX-235-DZ","driver":"ANGIBAUD Romuald","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2026-11-05","company":"TFMO","operator":"Christophe","excelRow":39},{"id":"confinement_40","category":"confinement","registration":"FD-560-ZA","driver":"RICHEZ Benoit","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2026-11-06","company":"TFMO","operator":"Laurent","excelRow":40},{"id":"confinement_41","category":"confinement","registration":"EK-238-WZ","driver":"MARGERIE TOM","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2026-11-12","company":"TFMO","operator":"Christophe","excelRow":41},{"id":"confinement_42","category":"confinement","registration":"ET-722-GM","driver":"GOUTRY Alexandre","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2026-11-13","company":"TFMO","operator":"Jérôme","excelRow":42},{"id":"confinement_43","category":"confinement","registration":"EK-529-WZ","driver":"JAMBON Eddy","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2026-11-18","company":"TFMO","operator":"Christophe","excelRow":43},{"id":"confinement_44","category":"confinement","registration":"EK-624-LY","driver":"RHULAND Martin","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2026-11-20","company":"TFMO","operator":"Jérôme","excelRow":44},{"id":"confinement_45","category":"confinement","registration":"ET-323-JK","driver":"BOIS Lionel","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2026-11-25","company":"TFMO","operator":"Jérôme","excelRow":45},{"id":"confinement_46","category":"confinement","registration":"EZ-585-DB","driver":"SECOURS","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2026-11-25","company":"TFMO","operator":"Jérôme","excelRow":46},{"id":"confinement_47","category":"confinement","registration":"EL-782-BE","driver":"BARRY Ousmane","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2026-12-02","company":"TFMO","operator":"Jérôme","excelRow":47},{"id":"confinement_48","category":"confinement","registration":"FE-790-ME","driver":"PAUL Vincent","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2026-12-11","company":"TFMO","operator":"Jérôme","excelRow":48},{"id":"confinement_49","category":"confinement","registration":"FP-020-MJ","driver":"SECOURS","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-01-05","company":"TFMO","operator":"Jerome","excelRow":49},{"id":"confinement_50","category":"confinement","registration":"EL-020-TH","driver":"VERCOUTRE Eddy","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-01-06","company":"TFMO","operator":"Laurent","excelRow":50},{"id":"confinement_51","category":"confinement","registration":"EV-993-VW","driver":"BALAZS Victoria","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-01-08","company":"TFMO","operator":"Raphaêl","excelRow":51},{"id":"confinement_52","category":"confinement","registration":"ET-665-HR","driver":"CARDOSO Mickaël","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-01-09","company":"TFMO","operator":"Raphaêl","excelRow":52},{"id":"confinement_53","category":"confinement","registration":"FX-700-MM","driver":"ASSATI Teddy","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-01-21","company":"TFMO","operator":"Raphaêl","excelRow":53},{"id":"confinement_54","category":"confinement","registration":"FP-362-RM","driver":"GYOKERES Michel","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-01-23","company":"TFMO","operator":"Raphaêl","excelRow":54},{"id":"confinement_55","category":"confinement","registration":"FM-017-YT","driver":"CAPITAINE Olivier","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-01-24","company":"TFMO","operator":"Christophe","excelRow":55},{"id":"confinement_56","category":"confinement","registration":"FN-391-HF","driver":"LE COIN Daniel","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-01-28","company":"TFMO","operator":"Laurent","excelRow":56},{"id":"confinement_57","category":"confinement","registration":"GM-931-YK","driver":"FOURNET DOMINIQUE","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-01-28","company":"TFMO","operator":"Raphaêl","excelRow":57},{"id":"confinement_58","category":"confinement","registration":"HH-234-XG","driver":"RONZEL Grégory","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-01-28","company":"TFMO","operator":"Jerome","excelRow":58},{"id":"confinement_59","category":"confinement","registration":"HH-295-XC","driver":"MOREL Gérald","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-01-28","company":"TFMO","operator":"Jerome","excelRow":59},{"id":"confinement_60","category":"confinement","registration":"GE-607-NA","driver":"CHARPENTIER Hervé","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-01-29","company":"TFMO","operator":"Raphaêl","excelRow":60},{"id":"confinement_61","category":"confinement","registration":"FG-604-RZ","driver":"RIBOTTE Dominique","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-01-30","company":"TFMO","operator":"Raphaêl","excelRow":61},{"id":"confinement_62","category":"confinement","registration":"EL-935-NX","driver":"SECOURS","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-02-02","company":"TFMO","operator":"Jérôme","excelRow":62},{"id":"confinement_63","category":"confinement","registration":"FD-666-GY","driver":"BOWE GEOFFREY","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-02-03","company":"TFMO","operator":"Laurent","excelRow":63},{"id":"confinement_64","category":"confinement","registration":"EQ-705-FJ","driver":"SECOURS","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-02-04","company":"TFMO","operator":"Jérôme","excelRow":64},{"id":"confinement_65","category":"confinement","registration":"FA-604-LR","driver":"GROLET Jérôme","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-02-10","company":"TFMO","operator":"Jérôme","excelRow":65},{"id":"confinement_66","category":"confinement","registration":"EM-769-XQ","driver":"SECOURS","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-02-11","company":"TFMO","operator":"Christophe","excelRow":66},{"id":"confinement_67","category":"confinement","registration":"GF-775-KA","driver":"GERME Ludovic","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-02-11","company":"TFMO","operator":"Laurent","excelRow":67},{"id":"confinement_68","category":"confinement","registration":"GF-941-CC","driver":"PLATEAU Francois","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-02-11","company":"TFMO","operator":"Christophe","excelRow":68},{"id":"confinement_69","category":"confinement","registration":"GE-947-EM","driver":"MAZALLON Christian","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-02-16","company":"TFMO","operator":"Christophe","excelRow":69},{"id":"confinement_70","category":"confinement","registration":"EW-279-WG","driver":"MARTEL Jean Philippe","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-02-17","company":"TFMO","operator":"Christophe","excelRow":70},{"id":"confinement_71","category":"confinement","registration":"FE-415-YZ","driver":"SECOURS","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-02-17","company":"TFMO","operator":"Jérôme","excelRow":71},{"id":"confinement_72","category":"confinement","registration":"GM-818-YK","driver":"TAILLARD Samuel","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-02-17","company":"TFMO","operator":"Laurent","excelRow":72},{"id":"confinement_73","category":"confinement","registration":"FP-486-LT","driver":"VIVIN Margot","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-02-18","company":"TFMO","operator":"Christophe","excelRow":73},{"id":"confinement_74","category":"confinement","registration":"ET-986-HR","driver":"RODRIGUES MATOS Antonio","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-02-19","company":"TFMO","operator":"Christophe","excelRow":74},{"id":"confinement_75","category":"confinement","registration":"FA-792-LQ","driver":"HOAREAU Eric","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-02-19","company":"TFMO","operator":"Jérôme","excelRow":75},{"id":"confinement_76","category":"confinement","registration":"FP-846-HB","driver":"REIS PINHO Manuel","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-02-19","company":"TFMO","operator":"Raphaêl","excelRow":76},{"id":"confinement_77","category":"confinement","registration":"FC-123-XW","driver":"BAIKRICH Romain","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-02-20","company":"TFMO","operator":"Jérôme","excelRow":77},{"id":"confinement_78","category":"confinement","registration":"HH-295-XC","driver":"MOREL Gérald","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-02-22","company":"TFMO","operator":"Jerome","excelRow":78},{"id":"confinement_79","category":"confinement","registration":"EM-100-DW","driver":"OLIVIER Joseph","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-02-24","company":"TFMO","operator":"Laurent","excelRow":79},{"id":"confinement_80","category":"confinement","registration":"EQ-370-FK","driver":"MARMAGNE Benjamin","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-02-24","company":"TFMO","operator":"Laurent","excelRow":80},{"id":"confinement_81","category":"confinement","registration":"HH-234-XG","driver":"RONZEL Grégory","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-02-25","company":"TFMO","operator":"Jerome","excelRow":81},{"id":"confinement_82","category":"confinement","registration":"EM-487-KF","driver":"MAZILLE John","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-02-26","company":"TFMO","operator":"Christophe","excelRow":82},{"id":"confinement_83","category":"confinement","registration":"EV-719-RW","driver":"ZAK Vladimir","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-02-27","company":"TFMO","operator":"Raphaêl","excelRow":83},{"id":"confinement_84","category":"confinement","registration":"EX-656-KK","driver":"SECOURS","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-03-02","company":"TFMO","operator":"Jérôme","excelRow":84},{"id":"confinement_85","category":"confinement","registration":"FX-943-DY","driver":"LOUVET David","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-03-02","company":"TFMO","operator":"Laurent","excelRow":85},{"id":"confinement_86","category":"confinement","registration":"GE-007-XT","driver":"LECLAIR Marcel","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-03-04","company":"TFMO","operator":"Jérôme","excelRow":86},{"id":"confinement_87","category":"confinement","registration":"GW-765-XB","driver":"DOMINICONE Geoffrey","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-03-08","company":"TFMO","operator":"Jérôme","excelRow":87},{"id":"confinement_88","category":"confinement","registration":"FE-439-RH","driver":"FERRAND Charlotte","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-03-09","company":"TFMO","operator":"Laurent","excelRow":88},{"id":"confinement_89","category":"confinement","registration":"FX-992-VM","driver":"LARTAUD Romain","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-03-09","company":"TFMO","operator":"Christophe","excelRow":89},{"id":"confinement_90","category":"confinement","registration":"FD-386-SW","driver":"BERTHE Gwenael","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-03-13","company":"TFMO","operator":"Laurent","excelRow":90},{"id":"confinement_91","category":"confinement","registration":"HJ-538-PR","driver":"Yé Etienne","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-03-16","company":"TFMO","operator":"Jerome","excelRow":91},{"id":"confinement_92","category":"confinement","registration":"FP-056-MJ","driver":"BART Grégory","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-03-17","company":"TFMO","operator":"Laurent","excelRow":92},{"id":"confinement_93","category":"confinement","registration":"FD-238-GD","driver":"NEVEU Antoine Jacques","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-03-18","company":"TFMO","operator":"Laurent","excelRow":93},{"id":"confinement_94","category":"confinement","registration":"FD-019-GD","driver":"DESSEIGNE Cedric","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-03-24","company":"TFMO","operator":"Laurent","excelRow":94},{"id":"confinement_95","category":"confinement","registration":"FA-558-LQ","driver":"PEREIRA Brigitte","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-03-27","company":"TFMO","operator":"Jérôme","excelRow":95},{"id":"confinement_96","category":"confinement","registration":"FE-809-DR","driver":"DEGRAS André","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-03-30","company":"TFMO","operator":"Raphaêl","excelRow":96},{"id":"confinement_97","category":"confinement","registration":"HJ-538-PR","driver":"Yé Etienne","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-03-30","company":"TFMO","operator":"Jerome","excelRow":97},{"id":"confinement_98","category":"confinement","registration":"EK-701-NJ","driver":"SECOURS","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-04-01","company":"TFMO","operator":"Jérôme","excelRow":98},{"id":"confinement_99","category":"confinement","registration":"GF-813-TL","driver":"COLAERT","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-04-01","company":"TFMO","operator":"Laurent","excelRow":99},{"id":"confinement_100","category":"confinement","registration":"GN-306-SB","driver":"DE OLIVEIRA Joao","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-04-02","company":"TFMO","operator":"Laurent","excelRow":100},{"id":"confinement_101","category":"confinement","registration":"EV-609-SF","driver":"TORTIELLO DAMIEN","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-04-08","company":"TFMO","operator":"Christophe","excelRow":101},{"id":"confinement_102","category":"confinement","registration":"GN-834-TH","driver":"SOUBEYRAND Juan","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-04-08","company":"TFMO","operator":"Christophe","excelRow":102},{"id":"confinement_103","category":"confinement","registration":"EK-544-ZJ","driver":"SAMAIN Jérôme","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-04-10","company":"TFMO","operator":"Laurent","excelRow":103},{"id":"confinement_104","category":"confinement","registration":"FS-454-ML","driver":"RAINHO GOMES Joao","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-04-10","company":"TFMO","operator":"Laurent","excelRow":104},{"id":"confinement_105","category":"confinement","registration":"FG-833-RZ","driver":"CHTIOUI Selim","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-04-15","company":"TFMO","operator":"Christophe","excelRow":105},{"id":"confinement_106","category":"confinement","registration":"EJ-207-GD","driver":"BENGUEDDA Ahmed","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-04-16","company":"TFMO","operator":"Jérôme","excelRow":106},{"id":"confinement_107","category":"confinement","registration":"EJ-464-GD","driver":"EL BOUHOUJ Mustapha","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-04-16","company":"TFMO","operator":"Jérôme","excelRow":107},{"id":"confinement_108","category":"confinement","registration":"EK-216-TW","driver":"SECOURS","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-04-16","company":"TFMO","operator":"Jérôme","excelRow":108},{"id":"confinement_109","category":"confinement","registration":"GN-284-SP","driver":"TSCHIRRET Lionel","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-04-16","company":"TFMO","operator":"Laurent","excelRow":109},{"id":"confinement_110","category":"confinement","registration":"GG-489-CS","driver":"AUGER Clément","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-04-24","company":"TFMO","operator":"Raphaêl","excelRow":110},{"id":"confinement_111","category":"confinement","registration":"EJ-767-ES","driver":"COIUTTO Grégory","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-04-28","company":"TFMO","operator":"Jérôme","excelRow":111},{"id":"confinement_112","category":"confinement","registration":"FJ-092-RG","driver":"de VRIENDT Thierry","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-05-04","company":"TFMO","operator":"Raphaêl","excelRow":112},{"id":"confinement_113","category":"confinement","registration":"EV-317-LE","driver":"DARCQUE Eric","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-05-05","company":"TFMO","operator":"Raphaêl","excelRow":113},{"id":"confinement_114","category":"confinement","registration":"EV-920-ND","driver":"AFONSO Pierre","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-05-05","company":"TFMO","operator":"Raphaêl","excelRow":114},{"id":"confinement_115","category":"confinement","registration":"GG-326-DT","driver":"POURRAT Valentin","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-05-05","company":"TFMO","operator":"Christophe","excelRow":115},{"id":"confinement_116","category":"confinement","registration":"GM-675-YK","driver":"BOUFFARTIGUES Guy","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-05-05","company":"TFMO","operator":"Christophe","excelRow":116},{"id":"confinement_117","category":"confinement","registration":"FX-568-JR","driver":"MONTOIS Jason","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-05-06","company":"TFMO","operator":"Christophe","excelRow":117},{"id":"confinement_118","category":"confinement","registration":"GF-874-VT","driver":"ABDULAH Jérémy","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-05-11","company":"TFMO","operator":"Jerome","excelRow":118},{"id":"confinement_119","category":"confinement","registration":"GN-739-CR","driver":"COIUTTO Grégory","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-05-11","company":"TFMO","operator":"Jerome","excelRow":119},{"id":"confinement_120","category":"confinement","registration":"FC-271-JP","driver":"MOURET Thierry","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-05-13","company":"TFMO","operator":"Christophe","excelRow":120},{"id":"confinement_121","category":"confinement","registration":"GF-765-CC","driver":"LE CAILLEC Eric","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-05-13","company":"TFMO","operator":"Raphaêl","excelRow":121},{"id":"confinement_122","category":"confinement","registration":"GF-547-AS","driver":"FELIX Pierre","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-05-21","company":"TFMO","operator":"Christophe","excelRow":122},{"id":"confinement_123","category":"confinement","registration":"FY-710-LP","driver":"STUDER Marc","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-05-26","company":"TFMO","operator":"Jérôme","excelRow":123},{"id":"confinement_124","category":"confinement","registration":"GG-986-YT","driver":"BALLION Eric","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-05-26","company":"TFMO","operator":"Christophe","excelRow":124},{"id":"confinement_125","category":"confinement","registration":"FP-299-LZ","driver":"SAUGER Willy Alain Edmon","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-05-27","company":"TFMO","operator":"Christophe","excelRow":125},{"id":"confinement_126","category":"confinement","registration":"GR-448-KS","driver":"LUTROT Benjamin","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-05-30","company":"TFMO","operator":"Raphaêl","excelRow":126},{"id":"confinement_127","category":"confinement","registration":"GR-177-DK","driver":"SIMONS Allan","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-05-31","company":"TFMO","operator":"Raphaêl","excelRow":127},{"id":"confinement_128","category":"confinement","registration":"GP-397-TZ","driver":"CHARRON MARIO","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-06-01","company":"TFMO","operator":"Raphaêl","excelRow":128},{"id":"confinement_129","category":"confinement","registration":"FY-654-RJ","driver":"AGASSE Frédéric","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-06-03","company":"TFMO","operator":"Raphaêl","excelRow":129},{"id":"confinement_130","category":"confinement","registration":"GG-550-TE","driver":"HENNER Marc","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-06-04","company":"TFMO","operator":"Jérôme","excelRow":130},{"id":"confinement_131","category":"confinement","registration":"GW-731-NW","driver":"GRONDIN OLIVIER","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-06-04","company":"TFMO","operator":"Raphaêl","excelRow":131},{"id":"confinement_132","category":"confinement","registration":"GW-677-XE","driver":"DERNONCOURT Bruno","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-06-08","company":"TFMO","operator":"Christophe","excelRow":132},{"id":"confinement_133","category":"confinement","registration":"EM-391-MZ","driver":"VOSKERITCHIAN Roger","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-06-09","company":"TFMO","operator":"Laurent","excelRow":133},{"id":"confinement_134","category":"confinement","registration":"GG-181-DT","driver":"PERARD Jean-François","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-06-09","company":"TFMO","operator":"Laurent","excelRow":134},{"id":"confinement_135","category":"confinement","registration":"GP-986-RF","driver":"SAINT-LOUIS Thierry","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-06-09","company":"TFMO","operator":"Laurent","excelRow":135},{"id":"confinement_136","category":"confinement","registration":"GX-247-ML","driver":"JACQUES Sébastien","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-06-09","company":"TFMO","operator":"Laurent","excelRow":136},{"id":"confinement_137","category":"confinement","registration":"FZ-465-WB","driver":"REIS Baptiste","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-06-11","company":"TFMO","operator":"Laurent","excelRow":137},{"id":"confinement_138","category":"confinement","registration":"GW-635-LF","driver":"VANECHOP Rodolphe","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-06-11","company":"TFMO","operator":"Laurent","excelRow":138},{"id":"confinement_139","category":"confinement","registration":"FJ-996-RF","driver":"BROSSARD Axel","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-06-14","company":"TFMO","operator":"Laurent","excelRow":139},{"id":"confinement_140","category":"confinement","registration":"FX-889-NM","driver":"RICHEZ Eric","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-06-14","company":"TFMO","operator":"Laurent","excelRow":140},{"id":"confinement_141","category":"confinement","registration":"FP-749-PL","driver":"OBE Dorian","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-06-15","company":"TFMO","operator":"Laurent","excelRow":141},{"id":"confinement_142","category":"confinement","registration":"GP-243-EN","driver":"LOUIS JIMMY","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-06-15","company":"TFMO","operator":"Laurent","excelRow":142},{"id":"confinement_143","category":"confinement","registration":"FY-630-MR","driver":"BIMONT Christophe","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-06-17","company":"TFMO","operator":"Laurent","excelRow":143},{"id":"confinement_144","category":"confinement","registration":"GP-283-RQ","driver":"DIDIER Philippe","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-06-17","company":"TFMO","operator":"Laurent","excelRow":144},{"id":"confinement_145","category":"confinement","registration":"EX-016-PM","driver":"TIXIER LUDOVIC","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-06-18","company":"TFMO","operator":"Christophe","excelRow":145},{"id":"confinement_146","category":"confinement","registration":"GR-311-QX","driver":"DHONDT Eric","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-06-18","company":"TFMO","operator":"Jérôme","excelRow":146},{"id":"confinement_147","category":"confinement","registration":"FS-195-ML","driver":"LECLERC Florian","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-06-25","company":"TFMO","operator":"Jérôme","excelRow":147},{"id":"confinement_148","category":"confinement","registration":"GX-608-ZX","driver":"JOUIN Evan","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-07-23","company":"TFMO","operator":"Raphaêl","excelRow":148},{"id":"confinement_149","category":"confinement","registration":"FY-406-EX","driver":"KIZILKILIC Cegiz","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-10-08","company":"TFMO","operator":"Christophe","excelRow":149},{"id":"confinement_150","category":"confinement","registration":"GG-081-TV","driver":"DAURAT Agathe","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-10-08","company":"TFMO","operator":"Christophe","excelRow":150},{"id":"confinement_151","category":"confinement","registration":"GY-165-AL","driver":"AURIOU Geoffrey","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-10-08","company":"TFMO","operator":"Jérôme","excelRow":151},{"id":"confinement_152","category":"confinement","registration":"FN-318-AE","driver":"BENOIST OLIVIER","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-11-08","company":"TFMO","operator":"Christophe","excelRow":152},{"id":"confinement_153","category":"confinement","registration":"GW-573-HJ","driver":"SICLER MICKAEL","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-11-08","company":"TFMO","operator":"Jérôme","excelRow":153},{"id":"confinement_154","category":"confinement","registration":"GX-330-CQ","driver":"CUISINIER Kelly","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-12-08","company":"TFMO","operator":"Jérôme","excelRow":154},{"id":"confinement_155","category":"confinement","registration":"GA-667-ZN","driver":"GUICHARD Cyril","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-08-17","company":"TFMO","operator":"Christophe","excelRow":155},{"id":"confinement_156","category":"confinement","registration":"FE-466-WB","driver":"MEENS Alexandre","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-06-18","company":"TFMO","operator":"Laurent","excelRow":156},{"id":"confinement_157","category":"confinement","registration":"FS-047-LH","driver":"GARCIA DE OLIVEIRA Pedro","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-08-20","company":"TFMO","operator":"Laurent","excelRow":157},{"id":"confinement_158","category":"confinement","registration":"GX-807-XJ","driver":"CHARLES Ludji","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-08-20","company":"TFMO","operator":"Laurent","excelRow":158},{"id":"confinement_159","category":"confinement","registration":"GW-576-ZD","driver":"VIRFOLLET Eric","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-07-23","company":"TFMO","operator":"Laurent","excelRow":159},{"id":"confinement_160","category":"confinement","registration":"GY-841-AK","driver":"MHUN Stéphane","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-08-24","company":"TFMO","operator":"Raphaêl","excelRow":160},{"id":"confinement_161","category":"confinement","registration":"GB-312-JX","driver":"PHILIPPE -PLANCON Athéa","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-08-25","company":"TFMO","operator":"Christophe","excelRow":161},{"id":"confinement_162","category":"confinement","registration":"FD-009-KR","driver":"BLONDIN Pierrick","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-08-26","company":"TFMO","operator":"Laurent","excelRow":162},{"id":"confinement_163","category":"confinement","registration":"GP-242-AG","driver":"PATURET Steve Louis Andre","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-07-27","company":"TFMO","operator":"Christophe","excelRow":163},{"id":"confinement_164","category":"confinement","registration":"GJ-610-HD","driver":"DEBOST Raphaël","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-08-27","company":"TFMO","operator":"Jérôme","excelRow":164},{"id":"confinement_165","category":"confinement","registration":"GX-215-XJ","driver":"LUGAND Jean-Philippe","control":"CONFINEMENT","label":"","lastControl":"","nextControl":"2027-07-29","company":"TFMO","operator":"Jérôme","excelRow":165},{"id":"sanitaire_4","category":"sanitaire","registration":"FP-428-QV","driver":"FRANGUIAN Patrick","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2026-04-01","company":"TFMO","operator":"Jérôme","excelRow":4},{"id":"sanitaire_5","category":"sanitaire","registration":"EQ-370-FK","driver":"MARMAGNE Benjamin","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2026-09-01","company":"TFMO","operator":"Laurent","excelRow":5},{"id":"sanitaire_6","category":"sanitaire","registration":"FS-002-MM","driver":"WOLFF Romain","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2026-09-07","company":"TFMO","operator":"Laurent","excelRow":6},{"id":"sanitaire_7","category":"sanitaire","registration":"FS-195-ML","driver":"LECLERC Florian","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2026-09-07","company":"TFMO","operator":"Jérôme","excelRow":7},{"id":"sanitaire_8","category":"sanitaire","registration":"FS-454-ML","driver":"CARLIER Matthieu","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2029-07-31","company":"TFMO","operator":"Laurent","excelRow":8},{"id":"sanitaire_9","category":"sanitaire","registration":"ET-722-GM","driver":"GOUTRY Alexandre","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2027-01-15","company":"TFMO","operator":"Jérôme","excelRow":9},{"id":"sanitaire_10","category":"sanitaire","registration":"ET-986-HR","driver":"RODRIGUES MATOS Antonio","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2027-01-16","company":"TFMO","operator":"Christophe","excelRow":10},{"id":"sanitaire_11","category":"sanitaire","registration":"ET-323-JK","driver":"BOIS Lionel","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2027-01-31","company":"TFMO","operator":"Jérôme","excelRow":11},{"id":"sanitaire_12","category":"sanitaire","registration":"ET-665-HR","driver":"CARDOSO Mickaël","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2027-01-31","company":"TFMO","operator":"Raphaêl","excelRow":12},{"id":"sanitaire_13","category":"sanitaire","registration":"EV-317-LE","driver":"DARCQUE Eric","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2027-02-09","company":"TFMO","operator":"Raphaêl","excelRow":13},{"id":"sanitaire_14","category":"sanitaire","registration":"EV-609-SF","driver":"TORTIELLO DAMIEN","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2027-02-09","company":"TFMO","operator":"Christophe","excelRow":14},{"id":"sanitaire_15","category":"sanitaire","registration":"EV-719-RW","driver":"ZAK Vladimir","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2027-02-09","company":"TFMO","operator":"Raphaêl","excelRow":15},{"id":"sanitaire_16","category":"sanitaire","registration":"EV-920-ND","driver":"AFONSO Pierre","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2027-02-09","company":"TFMO","operator":"Raphaêl","excelRow":16},{"id":"sanitaire_17","category":"sanitaire","registration":"FX-235-DZ","driver":"ANGIBAUD Romuald","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2027-02-16","company":"TFMO","operator":"Raphaêl","excelRow":17},{"id":"sanitaire_18","category":"sanitaire","registration":"FX-568-JR","driver":"MONTOIS Jason","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2027-02-16","company":"TFMO","operator":"Christophe","excelRow":18},{"id":"sanitaire_19","category":"sanitaire","registration":"FX-943-DY","driver":"LOUVET David","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2027-02-16","company":"TFMO","operator":"Christophe","excelRow":19},{"id":"sanitaire_20","category":"sanitaire","registration":"FX-027-RZ","driver":"ALBRAN Johan","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2027-03-01","company":"TFMO","operator":"Christophe","excelRow":20},{"id":"sanitaire_21","category":"sanitaire","registration":"FX-700-MM","driver":"ASSATI Teddy","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2027-03-01","company":"TFMO","operator":"Raphaêl","excelRow":21},{"id":"sanitaire_22","category":"sanitaire","registration":"FX-889-NM","driver":"RICHEZ Eric","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2027-03-01","company":"TFMO","operator":"Jérôme","excelRow":22},{"id":"sanitaire_23","category":"sanitaire","registration":"FX-992-VM","driver":"LARTAUD Romain","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2027-03-01","company":"TFMO","operator":"Christophe","excelRow":23},{"id":"sanitaire_24","category":"sanitaire","registration":"FY-406-EX","driver":"KIZILKILIC Cegiz","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2027-03-01","company":"TFMO","operator":"Christophe","excelRow":24},{"id":"sanitaire_25","category":"sanitaire","registration":"EV-993-VW","driver":"BALAZS Victoria","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2027-03-18","company":"TFMO","operator":"Raphaêl","excelRow":25},{"id":"sanitaire_26","category":"sanitaire","registration":"FY-344-SC","driver":"COUTURE Damien","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2027-04-01","company":"TFMO","operator":"Jérôme","excelRow":26},{"id":"sanitaire_27","category":"sanitaire","registration":"FY-434-KV","driver":"KULA Erdogan","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2027-04-01","company":"TFMO","operator":"Christophe","excelRow":27},{"id":"sanitaire_28","category":"sanitaire","registration":"FY-630-MR","driver":"BIMONT Christophe","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2027-04-01","company":"TFMO","operator":"Laurent","excelRow":28},{"id":"sanitaire_29","category":"sanitaire","registration":"FY-654-RJ","driver":"AGASSE Frédéric","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2027-04-01","company":"TFMO","operator":"Raphaêl","excelRow":29},{"id":"sanitaire_30","category":"sanitaire","registration":"FY-710-LP","driver":"STUDER Marc","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2027-04-01","company":"TFMO","operator":"Jérôme","excelRow":30},{"id":"sanitaire_31","category":"sanitaire","registration":"EW-279-WG","driver":"MARTEL Jean Philippe","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2027-04-03","company":"TFMO","operator":"Christophe","excelRow":31},{"id":"sanitaire_32","category":"sanitaire","registration":"EX-656-KK","driver":"SECOURS","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2027-04-24","company":"TFMO","operator":"Jérôme","excelRow":32},{"id":"sanitaire_33","category":"sanitaire","registration":"EX-016-PM","driver":"TIXIER LUDOVIC","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2027-04-29","company":"TFMO","operator":"Christophe","excelRow":33},{"id":"sanitaire_34","category":"sanitaire","registration":"EZ-217-DB","driver":"LE COINT Daniel","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2027-06-27","company":"TFMO","operator":"Laurent","excelRow":34},{"id":"sanitaire_35","category":"sanitaire","registration":"EZ-585-DB","driver":"SECOURS","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2027-06-27","company":"TFMO","operator":"Jérôme","excelRow":35},{"id":"sanitaire_36","category":"sanitaire","registration":"GA-173-YW","driver":"DUMAINE Geoffrey","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2027-07-01","company":"TFMO","operator":"Jérôme","excelRow":36},{"id":"sanitaire_37","category":"sanitaire","registration":"GA-667-ZN","driver":"GUICHARD Cyril","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2027-07-01","company":"TFMO","operator":"Christophe","excelRow":37},{"id":"sanitaire_38","category":"sanitaire","registration":"GB-312-JX","driver":"PHILIPPE -PLANCON Athéa","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2027-07-01","company":"TFMO","operator":"Christophe","excelRow":38},{"id":"sanitaire_39","category":"sanitaire","registration":"FA-558-LQ","driver":"PEREIRA Brigitte","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2027-07-31","company":"TFMO","operator":"Jérôme","excelRow":39},{"id":"sanitaire_40","category":"sanitaire","registration":"FA-604-LR","driver":"GROLET Jérôme","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2027-07-31","company":"TFMO","operator":"Jérôme","excelRow":40},{"id":"sanitaire_41","category":"sanitaire","registration":"FA-792-LQ","driver":"HOAREAU Eric","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2027-08-31","company":"TFMO","operator":"Jérôme","excelRow":41},{"id":"sanitaire_42","category":"sanitaire","registration":"FB-024-HM","driver":"DOMINGO Kouassi Bonaventure","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2027-08-31","company":"TFMO","operator":"Christophe","excelRow":42},{"id":"sanitaire_43","category":"sanitaire","registration":"FC-123-XW","driver":"BAIKRICH Romain","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2027-12-09","company":"TFMO","operator":"Jérôme","excelRow":43},{"id":"sanitaire_44","category":"sanitaire","registration":"FC-271-JP","driver":"MOURET Thierry","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2027-12-31","company":"TFMO","operator":"Christophe","excelRow":44},{"id":"sanitaire_45","category":"sanitaire","registration":"FD-009-KR","driver":"BLONDIN Pierrick","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2027-12-31","company":"TFMO","operator":"Laurent","excelRow":45},{"id":"sanitaire_46","category":"sanitaire","registration":"FD-019-GD","driver":"DESSEIGNE Cedric","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2027-12-31","company":"TFMO","operator":"Laurent","excelRow":46},{"id":"sanitaire_47","category":"sanitaire","registration":"FD-158-GZ","driver":"OTT Damien","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2027-12-31","company":"TFMO","operator":"Laurent","excelRow":47},{"id":"sanitaire_48","category":"sanitaire","registration":"FD-238-GD","driver":"NEVEU Antoine Jacques","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2027-12-31","company":"TFMO","operator":"Laurent","excelRow":48},{"id":"sanitaire_49","category":"sanitaire","registration":"FD-386-SW","driver":"BERTHE Gwenael","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2027-12-31","company":"TFMO","operator":"Laurent","excelRow":49},{"id":"sanitaire_50","category":"sanitaire","registration":"FD-666-GY","driver":"BOWE GEOFFREY","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2027-12-31","company":"TFMO","operator":"Laurent","excelRow":50},{"id":"sanitaire_51","category":"sanitaire","registration":"FE-809-DR","driver":"LUTROT BENJAMIN","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2028-01-30","company":"TFMO","operator":"Raphaêl","excelRow":51},{"id":"sanitaire_52","category":"sanitaire","registration":"FD-560-ZA","driver":"RICHEZ Benoit","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2028-01-31","company":"TFMO","operator":"Laurent","excelRow":52},{"id":"sanitaire_53","category":"sanitaire","registration":"GE-947-EM","driver":"MAZALLON Christian","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2028-01-31","company":"TFMO","operator":"Christophe","excelRow":53},{"id":"sanitaire_54","category":"sanitaire","registration":"FZ-465-WB","driver":"REIS Baptiste","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2028-02-06","company":"TFMO","operator":"Laurent","excelRow":54},{"id":"sanitaire_55","category":"sanitaire","registration":"GE-007-XT","driver":"LECLAIR Marcel","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2028-02-15","company":"TFMO","operator":"Jérôme","excelRow":55},{"id":"sanitaire_56","category":"sanitaire","registration":"GE-607-NA","driver":"CHARPENTIER Hervé","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2028-02-15","company":"TFMO","operator":"Raphaêl","excelRow":56},{"id":"sanitaire_57","category":"sanitaire","registration":"FE-415-YZ","driver":"SECOURS","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2028-02-28","company":"TFMO","operator":"Jérôme","excelRow":57},{"id":"sanitaire_58","category":"sanitaire","registration":"FE-439-RH","driver":"FERRAND Charlotte","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2028-02-28","company":"TFMO","operator":"Jérôme","excelRow":58},{"id":"sanitaire_59","category":"sanitaire","registration":"FE-466-WB","driver":"JOLLY Johan","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2028-02-28","company":"TFMO","operator":"Laurent","excelRow":59},{"id":"sanitaire_60","category":"sanitaire","registration":"FE-790-ME","driver":"PAUL Vincent","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2028-02-28","company":"TFMO","operator":"Jérôme","excelRow":60},{"id":"sanitaire_61","category":"sanitaire","registration":"GF-547-AS","driver":"FELIX Pierre","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2028-03-04","company":"TFMO","operator":"Christophe","excelRow":61},{"id":"sanitaire_62","category":"sanitaire","registration":"GF-765-CC","driver":"LE CAILLEC Eric","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2028-03-04","company":"TFMO","operator":"Raphaêl","excelRow":62},{"id":"sanitaire_63","category":"sanitaire","registration":"GF-941-CC","driver":"PLATEAU Francois","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2028-03-04","company":"TFMO","operator":"Christophe","excelRow":63},{"id":"sanitaire_64","category":"sanitaire","registration":"GF-775-KA","driver":"GERME Ludovic","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2028-03-24","company":"TFMO","operator":"Laurent","excelRow":64},{"id":"sanitaire_65","category":"sanitaire","registration":"GF-813-TL","driver":"DE LA ROCHE SOUVESTRE JAMES GAETAN","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2028-04-12","company":"TFMO","operator":"Raphaêl","excelRow":65},{"id":"sanitaire_66","category":"sanitaire","registration":"GF-874-VT","driver":"ABDULAH Jérémy","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2028-04-12","company":"TFMO","operator":"Raphaêl","excelRow":66},{"id":"sanitaire_67","category":"sanitaire","registration":"FG-344-CP","driver":"SANZ Pierre","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2028-04-17","company":"TFMO","operator":"Jérôme","excelRow":67},{"id":"sanitaire_68","category":"sanitaire","registration":"FG-767-DM","driver":"FORTAS Marine","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2028-04-23","company":"TFMO","operator":"Laurent","excelRow":68},{"id":"sanitaire_69","category":"sanitaire","registration":"GG-489-CS","driver":"AUGER Clément","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2028-05-02","company":"TFMO","operator":"Raphaêl","excelRow":69},{"id":"sanitaire_70","category":"sanitaire","registration":"GG-181-DT","driver":"PERARD Jean-François","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2028-05-04","company":"TFMO","operator":"Laurent","excelRow":70},{"id":"sanitaire_71","category":"sanitaire","registration":"GG-326-DT","driver":"POURRAT Valentin","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2028-05-04","company":"TFMO","operator":"Christophe","excelRow":71},{"id":"sanitaire_72","category":"sanitaire","registration":"FG-604-RZ","driver":"RIBOTTE Dominique","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2028-05-05","company":"TFMO","operator":"Raphaêl","excelRow":72},{"id":"sanitaire_73","category":"sanitaire","registration":"FG-833-RZ","driver":"CHTIOUI Selim","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2028-05-07","company":"TFMO","operator":"Christophe","excelRow":73},{"id":"sanitaire_74","category":"sanitaire","registration":"GG-550-TE","driver":"HENNER Marc","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2028-06-07","company":"TFMO","operator":"Jérôme","excelRow":74},{"id":"sanitaire_75","category":"sanitaire","registration":"GG-081-TV","driver":"DAURAT Agathe","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2028-06-08","company":"TFMO","operator":"Christophe","excelRow":75},{"id":"sanitaire_76","category":"sanitaire","registration":"GG-986-YT","driver":"BALLION Eric","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2028-06-16","company":"TFMO","operator":"Christophe","excelRow":76},{"id":"sanitaire_77","category":"sanitaire","registration":"FJ-092-RG","driver":"de VRIENDT Thierry","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2028-06-26","company":"TFMO","operator":"Raphaêl","excelRow":77},{"id":"sanitaire_78","category":"sanitaire","registration":"FJ-305-RG","driver":"TINE Thomas","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2028-07-24","company":"TFMO","operator":"Laurent","excelRow":78},{"id":"sanitaire_79","category":"sanitaire","registration":"FJ-996-RF","driver":"MIDELET Fabrice","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2028-07-24","company":"TFMO","operator":"Laurent","excelRow":79},{"id":"sanitaire_80","category":"sanitaire","registration":"GJ-792-FL","driver":"CLOSE Handy","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2028-08-30","company":"TFMO","operator":"Laurent","excelRow":80},{"id":"sanitaire_81","category":"sanitaire","registration":"GJ-551-HK","driver":"PERNIN LUCAS","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2028-09-30","company":"TFMO","operator":"Christophe","excelRow":81},{"id":"sanitaire_82","category":"sanitaire","registration":"GJ-610-HD","driver":"DEBOST Raphaël","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2028-09-30","company":"TFMO","operator":"Jérôme","excelRow":82},{"id":"sanitaire_83","category":"sanitaire","registration":"GJ-795-KQ","driver":"GENOUDET Christophe","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2028-09-30","company":"TFMO","operator":"Jérôme","excelRow":83},{"id":"sanitaire_84","category":"sanitaire","registration":"GJ-812-NQ","driver":"SOLD Jean louis","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2028-09-30","company":"TFMO","operator":"Jérôme","excelRow":84},{"id":"sanitaire_85","category":"sanitaire","registration":"EJ-207-GD","driver":"BENGUEDDA Ahmed","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2028-11-17","company":"TFMO","operator":"Jérôme","excelRow":85},{"id":"sanitaire_86","category":"sanitaire","registration":"EJ-464-GD","driver":"EL BOUHOUJ Mustapha","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2028-11-18","company":"TFMO","operator":"Jérôme","excelRow":86},{"id":"sanitaire_87","category":"sanitaire","registration":"EJ-767-ES","driver":"COIUTTO Grégory","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2028-11-18","company":"TFMO","operator":"Jérôme","excelRow":87},{"id":"sanitaire_88","category":"sanitaire","registration":"EK-012-VG","driver":"PAUL Franck","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2028-11-18","company":"TFMO","operator":"Jérôme","excelRow":88},{"id":"sanitaire_89","category":"sanitaire","registration":"EK-216-TW","driver":"SECOURS","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2028-11-18","company":"TFMO","operator":"Jérôme","excelRow":89},{"id":"sanitaire_90","category":"sanitaire","registration":"EK-529-WZ","driver":"JAMBON Eddy","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2028-11-20","company":"TFMO","operator":"Christophe","excelRow":90},{"id":"sanitaire_91","category":"sanitaire","registration":"EK-624-LY","driver":"COUSIN Julien","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2028-11-20","company":"TFMO","operator":"Jérôme","excelRow":91},{"id":"sanitaire_92","category":"sanitaire","registration":"EK-238-WZ","driver":"MARGERIE TOM","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2028-11-21","company":"TFMO","operator":"Christophe","excelRow":92},{"id":"sanitaire_93","category":"sanitaire","registration":"EK-544-ZJ","driver":"SAMAIN Jérôme","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2028-11-21","company":"TFMO","operator":"Laurent","excelRow":93},{"id":"sanitaire_94","category":"sanitaire","registration":"EL-020-TH","driver":"VERCOUTRE Eddy","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2028-11-26","company":"TFMO","operator":"Laurent","excelRow":94},{"id":"sanitaire_95","category":"sanitaire","registration":"EL-126-NZ","driver":"SECOURS","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2028-11-27","company":"TFMO","operator":"Jérôme","excelRow":95},{"id":"sanitaire_96","category":"sanitaire","registration":"FM-017-YT","driver":"CAPITAINE Olivier","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2028-12-03","company":"TFMO","operator":"Christophe","excelRow":96},{"id":"sanitaire_97","category":"sanitaire","registration":"FN-318-AE","driver":"BENOIST OLIVIER","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2028-12-04","company":"TFMO","operator":"Christophe","excelRow":97},{"id":"sanitaire_98","category":"sanitaire","registration":"EL-782-BE","driver":"BARRY Ousmane","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2028-12-31","company":"TFMO","operator":"Jérôme","excelRow":98},{"id":"sanitaire_99","category":"sanitaire","registration":"EL-935-NX","driver":"SECOURS","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2028-12-31","company":"TFMO","operator":"Jérôme","excelRow":99},{"id":"sanitaire_100","category":"sanitaire","registration":"FP-352-HB","driver":"MONTEIRO GONCALVES JOSE","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2029-01-30","company":"TFMO","operator":"Jérôme","excelRow":100},{"id":"sanitaire_101","category":"sanitaire","registration":"EK-701-NJ","driver":"SECOURS","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2029-01-31","company":"TFMO","operator":"Jérôme","excelRow":101},{"id":"sanitaire_102","category":"sanitaire","registration":"FN-391-HF","driver":"DA SILVA COSTA Antonio","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2029-01-31","company":"TFMO","operator":"Christophe","excelRow":102},{"id":"sanitaire_103","category":"sanitaire","registration":"GM-931-YK","driver":"FOURNET DOMINIQUE","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2029-02-15","company":"TFMO","operator":"Raphaêl","excelRow":103},{"id":"sanitaire_104","category":"sanitaire","registration":"FP-846-HB","driver":"REIS PINHO Manuel","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2029-02-28","company":"TFMO","operator":"Raphaêl","excelRow":104},{"id":"sanitaire_105","category":"sanitaire","registration":"FP-486-LT","driver":"VIVIN Margot","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2029-02-28","company":"TFMO","operator":"Christophe","excelRow":105},{"id":"sanitaire_106","category":"sanitaire","registration":"FP-005-MT","driver":"SAUZET Jean David","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2029-02-28","company":"TFMO","operator":"Christophe","excelRow":106},{"id":"sanitaire_107","category":"sanitaire","registration":"FP-020-MJ","driver":"GUESPIN Pierre Alexandre","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2029-02-28","company":"TFMO","operator":"Raphaêl","excelRow":107},{"id":"sanitaire_108","category":"sanitaire","registration":"FP-299-LZ","driver":"SAUGER Willy Alain Edmon","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2029-02-28","company":"TFMO","operator":"Christophe","excelRow":108},{"id":"sanitaire_109","category":"sanitaire","registration":"GM-675-YK","driver":"BOUFFARTIGUES Guy","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2029-03-27","company":"TFMO","operator":"Christophe","excelRow":109},{"id":"sanitaire_110","category":"sanitaire","registration":"GM-818-YK","driver":"TAILLARD Samuel","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2029-03-27","company":"TFMO","operator":"Laurent","excelRow":110},{"id":"sanitaire_111","category":"sanitaire","registration":"GN-306-SB","driver":"DE OLIVEIRA Joao","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2029-03-31","company":"TFMO","operator":"Laurent","excelRow":111},{"id":"sanitaire_112","category":"sanitaire","registration":"GN-739-CR","driver":"PIERREMONT ANTHONY","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2029-03-31","company":"TFMO","operator":"Christophe","excelRow":112},{"id":"sanitaire_113","category":"sanitaire","registration":"EM-100-DW","driver":"OLIVIER Joseph","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2029-04-30","company":"TFMO","operator":"Jérôme","excelRow":113},{"id":"sanitaire_114","category":"sanitaire","registration":"FP-279-RM","driver":"SAINT MAXIN Gaylor","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2029-04-30","company":"TFMO","operator":"Laurent","excelRow":114},{"id":"sanitaire_115","category":"sanitaire","registration":"FP-749-PL","driver":"OBE Dorian","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2029-04-30","company":"TFMO","operator":"Jérôme","excelRow":115},{"id":"sanitaire_116","category":"sanitaire","registration":"GN-284-SP","driver":"TSCHIRRET Lionel","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2029-04-30","company":"TFMO","operator":"Laurent","excelRow":116},{"id":"sanitaire_117","category":"sanitaire","registration":"GN-834-TH","driver":"SOUBEYRAND Juan","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2029-04-30","company":"TFMO","operator":"Christophe","excelRow":117},{"id":"sanitaire_118","category":"sanitaire","registration":"GP-283-RQ","driver":"DIDIER Philippe","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2029-05-21","company":"TFMO","operator":"Jérôme","excelRow":118},{"id":"sanitaire_119","category":"sanitaire","registration":"GP-242-AG","driver":"PATURET Steve Louis Andre","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2029-05-22","company":"TFMO","operator":"Christophe","excelRow":119},{"id":"sanitaire_120","category":"sanitaire","registration":"GP-243-EN","driver":"LOUIS JIMMY","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2029-05-30","company":"TFMO","operator":"Laurent","excelRow":120},{"id":"sanitaire_121","category":"sanitaire","registration":"GP-986-RF","driver":"SAINT-LOUIS Thierry","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2029-05-30","company":"TFMO","operator":"Laurent","excelRow":121},{"id":"sanitaire_122","category":"sanitaire","registration":"EP-333-RR","driver":"SECOURS","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2029-05-31","company":"TFMO","operator":"Jérôme","excelRow":122},{"id":"sanitaire_123","category":"sanitaire","registration":"EP-965-QB","driver":"SECOURS","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2029-05-31","company":"TFMO","operator":"Raphaêl","excelRow":123},{"id":"sanitaire_124","category":"sanitaire","registration":"FP-056-MJ","driver":"BART Grégory","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2029-05-31","company":"TFMO","operator":"Jérôme","excelRow":124},{"id":"sanitaire_125","category":"sanitaire","registration":"FP-362-RM","driver":"GYOKERES Michel","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2029-05-31","company":"TFMO","operator":"Raphaêl","excelRow":125},{"id":"sanitaire_126","category":"sanitaire","registration":"EM-391-MZ","driver":"VOSKERITCHIAN Roger","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2029-05-31","company":"TFMO","operator":"Laurent","excelRow":126},{"id":"sanitaire_127","category":"sanitaire","registration":"EM-487-KF","driver":"MAZILLE John","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2029-05-31","company":"TFMO","operator":"Christophe","excelRow":127},{"id":"sanitaire_128","category":"sanitaire","registration":"EM-769-XQ","driver":"CHERVET CLEMENT","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2029-05-31","company":"TFMO","operator":"Christophe","excelRow":128},{"id":"sanitaire_129","category":"sanitaire","registration":"GP-397-TZ","driver":"CHARRON MARIO","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2029-06-26","company":"TFMO","operator":"Raphaêl","excelRow":129},{"id":"sanitaire_130","category":"sanitaire","registration":"FS-939-LG","driver":"DA COSTA Ricardo","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2029-06-30","company":"TFMO","operator":"Christophe","excelRow":130},{"id":"sanitaire_131","category":"sanitaire","registration":"FS-333-ML","driver":"CARLIER Antoine","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2029-06-30","company":"TFMO","operator":"Raphaêl","excelRow":131},{"id":"sanitaire_132","category":"sanitaire","registration":"EQ-113-HY","driver":"LACROIX Damien","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2029-06-30","company":"TFMO","operator":"Christophe","excelRow":132},{"id":"sanitaire_133","category":"sanitaire","registration":"GR-177-DK","driver":"SIMONS Allan","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2029-09-12","company":"TFMO","operator":"Raphaêl","excelRow":133},{"id":"sanitaire_134","category":"sanitaire","registration":"GR-952-DJ","driver":"VIGNERON ARNAUD","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2029-09-12","company":"TFMO","operator":"Laurent","excelRow":134},{"id":"sanitaire_135","category":"sanitaire","registration":"GR-448-KS","driver":"DEGRAS André","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2029-09-26","company":"TFMO","operator":"Raphaêl","excelRow":135},{"id":"sanitaire_136","category":"sanitaire","registration":"GR-694-KT","driver":"MICHEL Michaël","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2029-09-26","company":"TFMO","operator":"Jérôme","excelRow":136},{"id":"sanitaire_137","category":"sanitaire","registration":"GR-153-QX","driver":"BOTTINO MICKAEL","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2029-09-30","company":"TFMO","operator":"Christophe","excelRow":137},{"id":"sanitaire_138","category":"sanitaire","registration":"GR-311-QX","driver":"DHONDT Eric","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2029-09-30","company":"TFMO","operator":"Jérôme","excelRow":138},{"id":"sanitaire_139","category":"sanitaire","registration":"GW-573-HJ","driver":"SICLER MICKAEL","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2030-04-11","company":"TFMO","operator":"Jérôme","excelRow":139},{"id":"sanitaire_140","category":"sanitaire","registration":"GW-576-ZD","driver":"VIRFOLLET Eric","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2030-04-18","company":"TFMO","operator":"Laurent","excelRow":140},{"id":"sanitaire_141","category":"sanitaire","registration":"GW-635-LF","driver":"VANECHOP Rodolphe","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2030-04-18","company":"TFMO","operator":"Laurent","excelRow":141},{"id":"sanitaire_142","category":"sanitaire","registration":"GW-677-XE","driver":"DERNONCOURT Bruno","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2030-04-18","company":"TFMO","operator":"Christophe","excelRow":142},{"id":"sanitaire_143","category":"sanitaire","registration":"GW-765-XB","driver":"DOMINICONE Geoffrey","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2030-04-18","company":"TFMO","operator":"Jérôme","excelRow":143},{"id":"sanitaire_144","category":"sanitaire","registration":"GX-247-ML","driver":"JACQUES Sébastien","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2030-04-18","company":"TFMO","operator":"Jérôme","excelRow":144},{"id":"sanitaire_145","category":"sanitaire","registration":"GX-330-CQ","driver":"CUISINIER Kelly","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2030-04-18","company":"TFMO","operator":"Jérôme","excelRow":145},{"id":"sanitaire_146","category":"sanitaire","registration":"GW-731-NW","driver":"GRONDIN OLIVIER","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2030-04-24","company":"TFMO","operator":"Raphaêl","excelRow":146},{"id":"sanitaire_147","category":"sanitaire","registration":"GX-215-XJ","driver":"LUGAND Jean-Philippe","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2030-06-27","company":"TFMO","operator":"Jérôme","excelRow":147},{"id":"sanitaire_148","category":"sanitaire","registration":"GX-807-XJ","driver":"CHARLES Ludji","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2030-06-27","company":"TFMO","operator":"Raphaêl","excelRow":148},{"id":"sanitaire_149","category":"sanitaire","registration":"GX-608-ZX","driver":"JOUIN Evan","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2030-06-30","company":"TFMO","operator":"Raphaêl","excelRow":149},{"id":"sanitaire_150","category":"sanitaire","registration":"GY-165-AL","driver":"AURIOU Geoffrey","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2030-06-30","company":"TFMO","operator":"Jérôme","excelRow":150},{"id":"sanitaire_151","category":"sanitaire","registration":"GY-841-AK","driver":"PIOUD Florent","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2030-06-30","company":"TFMO","operator":"Jérôme","excelRow":151},{"id":"sanitaire_152","category":"sanitaire","registration":"GZ-444-HE","driver":"LEFRANCOIS Denis","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2030-09-30","company":"TFMO","operator":"Christophe","excelRow":152},{"id":"sanitaire_153","category":"sanitaire","registration":"GZ-538-FZ","driver":"BREVET Arnaud","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2030-09-30","company":"TFMO","operator":"Jérôme","excelRow":153},{"id":"sanitaire_154","category":"sanitaire","registration":"GZ-967-PD","driver":"BARDET Christophe","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2030-10-10","company":"TFMO","operator":"Jérôme","excelRow":154},{"id":"sanitaire_155","category":"sanitaire","registration":"GZ-028-QT","driver":"SENSE Francky","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2030-10-24","company":"TFMO","operator":"Jérôme","excelRow":155},{"id":"sanitaire_156","category":"sanitaire","registration":"GZ-636-VC","driver":"ROUAG Badredine","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2030-10-31","company":"TFMO","operator":"Christophe","excelRow":156},{"id":"sanitaire_157","category":"sanitaire","registration":"GZ-714-YX","driver":"WIEST Patrick","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2030-10-31","company":"TFMO","operator":"Jérôme","excelRow":157},{"id":"sanitaire_158","category":"sanitaire","registration":"HA-530-BB","driver":"CHAVET Jérémy","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2030-10-31","company":"TFMO","operator":"Raphaêl","excelRow":158},{"id":"sanitaire_159","category":"sanitaire","registration":"HH-234-XG","driver":"RONZEL Grégory","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2031-12-31","company":"TFMO","operator":"Jerome","excelRow":159},{"id":"sanitaire_160","category":"sanitaire","registration":"HH-295-XC","driver":"MOREL Gérald","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2031-12-31","company":"TFMO","operator":"Jerome","excelRow":160},{"id":"sanitaire_161","category":"sanitaire","registration":"HJ-538-PR","driver":"Yé Etienne","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2032-01-31","company":"TFMO","operator":"Jerome","excelRow":161},{"id":"sanitaire_162","category":"sanitaire","registration":"FS-047-LH","driver":"GARCIA DE OLIVEIRA Pedro","control":"SANITAIRE","label":"Renouvellement ATP","lastControl":"","nextControl":"2029-07-31","company":"TFMO","operator":"Laurent","excelRow":162}];
let technicalDeadlines=INITIAL_TECH_DEADLINES.map(item=>({...item}));
try{
  const storedTechnicalDeadlines=JSON.parse(localStorage.getItem(TECH_DEADLINE_STORAGE_KEY));
  if(Array.isArray(storedTechnicalDeadlines) && storedTechnicalDeadlines.length) technicalDeadlines=storedTechnicalDeadlines.filter(item=>item.category!=='hayon');
}catch(error){console.warn('Lecture des échéances techniques impossible.',error)}


const VIDANGE_STORAGE_KEY = 'hessers-vidange-tfmo-v4';

let vidangeData = INITIAL_VIDANGE_DATA.map(item=>({...item}));
try{
  const stored = JSON.parse(localStorage.getItem(VIDANGE_STORAGE_KEY));
  if(Array.isArray(stored) && stored.length){
    const storedByRegistration = new Map(stored.map(item=>[normalizeRegistration(item.registration),item]));
    vidangeData = INITIAL_VIDANGE_DATA.map(source=>({
      ...source,
      ...(storedByRegistration.get(normalizeRegistration(source.registration))||{}),
      sameInterval:source.sameInterval ?? 50000,
      differentInterval:source.differentInterval ?? 100000
    }));
  }
}catch(error){console.warn('Impossible de lire les données Vidange TFMO.',error)}

const vidTable=document.getElementById('vidTable');
const vidTableWrap=document.getElementById('vidTableWrap');
const vidSearch=document.getElementById('vidSearch');
const vidCountLabel=document.getElementById('vidCountLabel');
const vidDetailEmpty=document.getElementById('vidDetailEmpty');
const vidDetailContent=document.getElementById('vidDetailContent');

let selectedVidangeId=null;
let vidangeDraft=null;


['vidCurrentKm','vidLastMajorKm','vidLastGarageKm'].forEach(id=>{
  document.getElementById(id).addEventListener('input',e=>{
    e.target.value=e.target.value.replace(/[^\d]/g,'');
    const r=selectedVidRecord();if(!r)return;
    const temp={...r,
      currentKm:kmNumber(document.getElementById('vidCurrentKm').value),
      lastMajorKm:kmNumber(document.getElementById('vidLastMajorKm').value),
      lastGarageKm:kmNumber(document.getElementById('vidLastGarageKm').value)
    };
    refreshVidDetailComputed(temp);
  });
});
vidTable.addEventListener('click',e=>{
  const row=e.target.closest('tr[data-vid-id]');if(!row)return;
  selectedVidangeId=row.dataset.vidId;renderVidTable();loadVidDetail();
});
vidSearch.addEventListener('input',renderVidTable);
document.getElementById('saveVidRecord').addEventListener('click',()=>{
  const r=selectedVidRecord();if(!r)return;
  r.currentKm=kmNumber(document.getElementById('vidCurrentKm').value);
  r.lastMajorKm=kmNumber(document.getElementById('vidLastMajorKm').value);
  r.lastGarageKm=kmNumber(document.getElementById('vidLastGarageKm').value);
  const saved=saveVidangeData();renderVidTable();loadVidDetail();
  const n=document.getElementById('vidNotice');n.style.color=saved?'#57d883':'#ff7373';n.textContent=saved?'Modifications enregistrées.':'Impossible d’enregistrer les modifications.';
});
document.getElementById('cancelVidChanges').addEventListener('click',()=>{
  const r=selectedVidRecord();if(!r||!vidangeDraft)return;
  Object.keys(r).forEach(k=>delete r[k]);Object.assign(r,JSON.parse(JSON.stringify(vidangeDraft)));renderVidTable();loadVidDetail();
});


document.getElementById('printVidangeList').addEventListener('click',printVidangeSimple);


/* IMPORT JEF — fichier XLSX uniquement */
const jefModal=document.getElementById('jefModal');
const jefPreviewBody=document.getElementById('jefPreviewBody');
const jefSummary=document.getElementById('jefSummary');
const jefError=document.getElementById('jefError');
const jefFileName=document.getElementById('jefFileName');
const applyJef=document.getElementById('applyJef');
const jefXlsxInput=document.getElementById('jefXlsxInput');

let jefMatches=[];
let jefDetectedSheet='';


document.getElementById('importJef').addEventListener('click',()=>{
  jefXlsxInput.click();
});

document.getElementById('closeJefModal').addEventListener('click',closeJefModal);
document.getElementById('cancelJef').addEventListener('click',closeJefModal);
jefModal.addEventListener('click',event=>{
  if(event.target===jefModal) closeJefModal();
});


jefXlsxInput.addEventListener('change',async()=>{
  const file=jefXlsxInput.files?.[0];
  if(!file) return;

  if(!file.name.toLocaleLowerCase('fr').endsWith('.xlsx')){
    alert('Sélectionnez uniquement un fichier Excel au format .xlsx.');
    jefXlsxInput.value='';
    return;
  }

  openJefPreview(file.name);

  try{
    jefMatches=await parseJefXlsx(file);
    renderJefPreview();
  }catch(error){
    console.warn('Erreur pendant l’import JEF XLSX.',error);
    jefMatches=[];
    jefPreviewBody.innerHTML='';
    jefSummary.classList.remove('loading');
    jefSummary.textContent='Import impossible.';
    jefError.textContent=error?.message || 'Impossible de lire ce fichier Excel.';
    applyJef.disabled=true;
  }finally{
    // Permet de sélectionner à nouveau le même fichier si nécessaire.
    jefXlsxInput.value='';
  }
});

applyJef.addEventListener('click',()=>{
  const byId=new Map(vidangeData.map(record=>[record.id,record]));
  let updated=0,skipped=0,errors=0;

  jefMatches.forEach(match=>{
    if(!match.recordId){skipped++;return;}

    const record=byId.get(match.recordId);
    const km=Number(match.km);

    if(!record){skipped++;return;}
    if(!Number.isFinite(km) || km<0){errors++;return;}

    record.currentKm=Math.round(km);
    updated++;
  });

  saveVidangeData();
  renderVidTable();

  if(selectedVidangeId){
    loadVidDetail();
  }

  closeJefModal();

  alert(`Import JEF terminé : ${updated} mis à jour · 0 nouveau · ${skipped} ignoré${skipped>1?'s':''} · ${errors} erreur${errors>1?'s':''}.`);
});

document.addEventListener('keydown',event=>{
  if(event.key==='Escape' && !jefModal.hidden){
    closeJefModal();
  }
});
renderVidTable();
loadVidDetail();


/* ===== GESTION ADMINISTRATIVE ===== */
const ADMIN_FINE_KEY='hessers-admin-fines-v1';
const ADMIN_RUNGIS_KEY='hessers-admin-rungis-v2';
const ADMIN_SITES_KEY='hessers-admin-sites-v1';

const INITIAL_RUNGIS_CARDS=[{"id":"rungis_import_164","cardNumber":"164","vehicle":"FZ-065-RP"},{"id":"rungis_import_165","cardNumber":"165","vehicle":"GR-338-XH"},{"id":"rungis_import_174","cardNumber":"174","vehicle":"HD-863-XF"},{"id":"rungis_import_178","cardNumber":"178","vehicle":"FZ-070-RP"},{"id":"rungis_import_179","cardNumber":"179","vehicle":"GS-048-GE"},{"id":"rungis_import_181","cardNumber":"181","vehicle":"GV-294-AQ"},{"id":"rungis_import_182","cardNumber":"182","vehicle":"GC-112-JB"},{"id":"rungis_import_192","cardNumber":"192","vehicle":"GH-082-HJ"},{"id":"rungis_import_193","cardNumber":"193","vehicle":"HF-418-JT"},{"id":"rungis_import_196","cardNumber":"196","vehicle":"GV-263-XQ"},{"id":"rungis_import_197","cardNumber":"197","vehicle":"GV-259-XQ"},{"id":"rungis_import_202","cardNumber":"202","vehicle":"GP-302-VN"},{"id":"rungis_import_207","cardNumber":"207","vehicle":"GH-105-HJ"},{"id":"rungis_import_222","cardNumber":"222","vehicle":"HD-141-WD"},{"id":"rungis_import_225","cardNumber":"225","vehicle":"GP-309-VN"},{"id":"rungis_import_226","cardNumber":"226","vehicle":"GR-841-QT"},{"id":"rungis_import_240","cardNumber":"240","vehicle":"GE-839-ZY"},{"id":"rungis_import_241","cardNumber":"241","vehicle":"GS-999-BM"},{"id":"rungis_import_246","cardNumber":"246","vehicle":"GS-047-GE"},{"id":"rungis_import_254","cardNumber":"254","vehicle":"GT-763-KY"},{"id":"rungis_import_255","cardNumber":"255","vehicle":"GR-128-QR"},{"id":"rungis_import_260","cardNumber":"260","vehicle":"GV-261-XQ"},{"id":"rungis_import_267","cardNumber":"267","vehicle":"GH-681-MG"},{"id":"rungis_import_269","cardNumber":"269","vehicle":"GV-981-HT"},{"id":"rungis_import_278","cardNumber":"278","vehicle":"GP-200-SB"},{"id":"rungis_import_281","cardNumber":"281","vehicle":"GV-974-MD"},{"id":"rungis_import_283","cardNumber":"283","vehicle":"FW-353-JB"},{"id":"rungis_import_285","cardNumber":"285","vehicle":"GR-277-XH"},{"id":"rungis_import_286","cardNumber":"286","vehicle":"GV-262-XQ"},{"id":"rungis_import_287","cardNumber":"287","vehicle":"FX-237-AD"},{"id":"rungis_import_300","cardNumber":"300","vehicle":"HK-922-FK"},{"id":"rungis_import_301","cardNumber":"301","vehicle":"HJ-717-SP"},{"id":"rungis_import_303","cardNumber":"303","vehicle":"HJ-541-TY"},{"id":"rungis_import_305","cardNumber":"305","vehicle":"HD-958-SE"},{"id":"rungis_import_306","cardNumber":"306","vehicle":"GN-465-VP"},{"id":"rungis_import_307","cardNumber":"307","vehicle":"HK-982-FK"},{"id":"rungis_import_308","cardNumber":"308","vehicle":"HK-904-JG"},{"id":"rungis_import_309","cardNumber":"309","vehicle":"HK-367-KT"},{"id":"rungis_import_310","cardNumber":"310","vehicle":"HK-327-KT"},{"id":"rungis_import_311","cardNumber":"311","vehicle":"GP-299-VN"},{"id":"rungis_import_312","cardNumber":"312","vehicle":"HE-582-AE"},{"id":"rungis_import_313","cardNumber":"313","vehicle":"GR-296-JZ"},{"id":"rungis_import_314","cardNumber":"314","vehicle":"HK-660-QC"},{"id":"rungis_import_315","cardNumber":"315","vehicle":"GE-841-ZY"},{"id":"rungis_import_316","cardNumber":"316","vehicle":"GP-098-ZD"},{"id":"rungis_import_317","cardNumber":"317","vehicle":"HK-057-QD"},{"id":"rungis_import_318","cardNumber":"318","vehicle":"GC-786-FX"},{"id":"rungis_import_319","cardNumber":"319","vehicle":"HE-611-AE"},{"id":"rungis_import_320","cardNumber":"320","vehicle":"GV-292-AQ"},{"id":"rungis_import_321","cardNumber":"321","vehicle":"GF-209-GJ"},{"id":"rungis_import_322","cardNumber":"322","vehicle":"GT-943-KY"},{"id":"rungis_import_323","cardNumber":"323","vehicle":"HK-989-QC"},{"id":"rungis_import_324","cardNumber":"324","vehicle":"HF-366-JT"},{"id":"rungis_import_325","cardNumber":"325","vehicle":"GV-983-HT"},{"id":"rungis_import_326","cardNumber":"326","vehicle":"GH-043-HM"},{"id":"rungis_import_327","cardNumber":"327","vehicle":"HD-835-SE"},{"id":"rungis_import_328","cardNumber":"328","vehicle":"GZ-767-NH"},{"id":"rungis_import_329","cardNumber":"329","vehicle":"GS-722-DS"},{"id":"rungis_import_330","cardNumber":"330","vehicle":"HD-814-RJ"},{"id":"rungis_import_331","cardNumber":"331","vehicle":"GR-784-QT"},{"id":"rungis_import_332","cardNumber":"332","vehicle":"GG-979-ZW"},{"id":"rungis_import_333","cardNumber":"333","vehicle":"GZ-323-GG"},{"id":"rungis_import_334","cardNumber":"334","vehicle":"GP-298-VN"},{"id":"rungis_import_335","cardNumber":"335","vehicle":"HJ-023-WH"},{"id":"rungis_import_336","cardNumber":"336","vehicle":"GV-293-AQ"},{"id":"rungis_import_337","cardNumber":"337","vehicle":"GG-977-ZW"},{"id":"rungis_import_338","cardNumber":"338","vehicle":"GJ-262-RS"},{"id":"rungis_import_339","cardNumber":"339","vehicle":"GV-290-AQ"},{"id":"rungis_import_340","cardNumber":"340","vehicle":"GW-084-EQ"},{"id":"rungis_import_341","cardNumber":"341","vehicle":"GZ-325-NJ"},{"id":"rungis_import_342","cardNumber":"342","vehicle":"GN-510-PA"},{"id":"rungis_import_344","cardNumber":"344","vehicle":"GE-843-ZY"},{"id":"rungis_import_345","cardNumber":"345","vehicle":"GF-549-HB"},{"id":"rungis_import_346","cardNumber":"346","vehicle":"GS-718-BN"},{"id":"rungis_import_347","cardNumber":"347","vehicle":"HK-636-FD"},{"id":"rungis_import_348","cardNumber":"348","vehicle":"GR-901-XD"},{"id":"rungis_import_349","cardNumber":"349","vehicle":"GV-246-SY"},{"id":"rungis_import_350","cardNumber":"350","vehicle":"GH-683-MG"},{"id":"rungis_import_351","cardNumber":"351","vehicle":"GG-978-ZW"},{"id":"rungis_import_352","cardNumber":"352","vehicle":"GG-208-VK"},{"id":"rungis_import_353","cardNumber":"353","vehicle":"HF-538-JT"},{"id":"rungis_import_354","cardNumber":"354","vehicle":"GF-264-BF"},{"id":"rungis_import_355","cardNumber":"355","vehicle":"HE-476-CG"},{"id":"rungis_import_356","cardNumber":"356","vehicle":"FW-756-TB"},{"id":"rungis_import_358","cardNumber":"358","vehicle":"GR-935-PW"},{"id":"rungis_import_359","cardNumber":"359","vehicle":"GV-248-SY"},{"id":"rungis_import_360","cardNumber":"360","vehicle":"GF-843-FH"},{"id":"rungis_import_361","cardNumber":"361","vehicle":"GZ-324-GG"},{"id":"rungis_import_362","cardNumber":"362","vehicle":"GT-666-KY"},{"id":"rungis_import_363","cardNumber":"363","vehicle":"GF-845-FH"},{"id":"rungis_import_364","cardNumber":"364","vehicle":"GZ-327-GG"},{"id":"rungis_import_365","cardNumber":"365","vehicle":"HE-442-CG"},{"id":"rungis_import_368","cardNumber":"368","vehicle":"HK-527-KT"},{"id":"rungis_import_369","cardNumber":"369","vehicle":"GF-844-FH"},{"id":"rungis_import_370","cardNumber":"370","vehicle":"GN-463-VP"},{"id":"rungis_import_371","cardNumber":"371","vehicle":"GV-915-QX"},{"id":"rungis_import_372","cardNumber":"372","vehicle":"GF-847-FH"},{"id":"rungis_import_373","cardNumber":"373","vehicle":"GS-045-GE"},{"id":"rungis_import_374","cardNumber":"374","vehicle":"GV-915-QX"},{"id":"rungis_import_375","cardNumber":"375","vehicle":"HE-461-CG"},{"id":"rungis_import_376","cardNumber":"376","vehicle":"HE-634-AE"},{"id":"rungis_import_378","cardNumber":"378","vehicle":"GV-913-QX"},{"id":"rungis_import_379","cardNumber":"379","vehicle":"HK-682-QR"},{"id":"rungis_import_380","cardNumber":"380","vehicle":"HF-450-JT"},{"id":"rungis_import_381","cardNumber":"381","vehicle":"GS-304-EJ"},{"id":"rungis_import_382","cardNumber":"382","vehicle":"HF-378-JT"},{"id":"rungis_import_383","cardNumber":"383","vehicle":"GH-682-MG"},{"id":"rungis_import_384","cardNumber":"384","vehicle":"GQ-334-HM"},{"id":"rungis_import_385","cardNumber":"385","vehicle":"GE-875-ZY"},{"id":"rungis_import_386","cardNumber":"386","vehicle":"GE-842-ZY"},{"id":"rungis_import_387","cardNumber":"387","vehicle":"GH-923-HL"},{"id":"rungis_import_388","cardNumber":"388","vehicle":"HD-021-SF"},{"id":"rungis_import_389","cardNumber":"389","vehicle":"GR-259-WZ"},{"id":"rungis_import_390","cardNumber":"390","vehicle":"HD-843-RJ"},{"id":"rungis_import_391","cardNumber":"391","vehicle":"HF-390-LL"},{"id":"rungis_import_392","cardNumber":"392","vehicle":"GV-291-AQ"},{"id":"rungis_import_393","cardNumber":"393","vehicle":"HL-361-JP"},{"id":"rungis_import_394","cardNumber":"394","vehicle":"HL-859-JP"},{"id":"rungis_import_395","cardNumber":"395","vehicle":"HL-730-JP"},{"id":"rungis_import_396","cardNumber":"396","vehicle":"HD-909-WC"},{"id":"rungis_import_397","cardNumber":"397","vehicle":"HF-246-JT"},{"id":"rungis_import_398","cardNumber":"398","vehicle":"GH-684-MG"},{"id":"rungis_import_399","cardNumber":"399","vehicle":"HF-509-JT"},{"id":"rungis_import_400","cardNumber":"400","vehicle":"GR-472-GV"},{"id":"rungis_import_401","cardNumber":"401","vehicle":"GZ-587-GB"},{"id":"rungis_import_408","cardNumber":"408","vehicle":"GT-858-KY"},{"id":"rungis_import_409","cardNumber":"409","vehicle":"GR-290-GV"},{"id":"rungis_import_411","cardNumber":"411","vehicle":"GF-130-GJ"},{"id":"rungis_import_413","cardNumber":"413","vehicle":"HF-402-LL"},{"id":"rungis_import_414","cardNumber":"414","vehicle":"GN-349-FX"},{"id":"rungis_import_415","cardNumber":"415","vehicle":"GS-117-EJ"},{"id":"rungis_import_417","cardNumber":"417","vehicle":"HE-496-CG"},{"id":"rungis_import_418","cardNumber":"418","vehicle":"HD-295-WD"},{"id":"rungis_import_419","cardNumber":"419","vehicle":"GG-980-ZW"},{"id":"rungis_import_420","cardNumber":"420","vehicle":"GG-341-YH"},{"id":"rungis_import_421","cardNumber":"421","vehicle":"GZ-935-NJ"},{"id":"rungis_import_423","cardNumber":"423","vehicle":"HF-268-JT"},{"id":"rungis_import_424","cardNumber":"424","vehicle":"HF-425-LL"},{"id":"rungis_import_425","cardNumber":"425","vehicle":"GV-980-HT"},{"id":"rungis_import_426","cardNumber":"426","vehicle":"GH-922-HL"}];

let adminFines=[];
let adminRungis=INITIAL_RUNGIS_CARDS.map(item=>({...item}));
let adminSites={dkv:'',ids:'',lumesia:''};

try{
  const saved=JSON.parse(localStorage.getItem(ADMIN_FINE_KEY));
  if(Array.isArray(saved)) adminFines=saved;
}catch(error){console.warn(error)}
try{
  const saved=JSON.parse(localStorage.getItem(ADMIN_RUNGIS_KEY));
  if(Array.isArray(saved)) adminRungis=saved;
}catch(error){console.warn(error)}
try{
  const saved=JSON.parse(localStorage.getItem(ADMIN_SITES_KEY));
  if(saved && typeof saved==='object'){
    adminSites={...adminSites,...saved};
    if(!adminSites.ids && saved.ils) adminSites.ids=saved.ils;
    delete adminSites.ils;
  }
}catch(error){console.warn(error)}

let adminActiveTab='fines';
let adminActionType=null;
let adminActionId=null;
let editingFineId=null;
let editingRungisId=null;
let editingSiteKey=null;

const adminActionsMenu=document.getElementById('adminActionsMenu');
const fineTable=document.getElementById('fineTable');
const fineTableWrap=document.getElementById('fineTableWrap');
const rungisTable=document.getElementById('rungisTable');
const rungisTableWrap=document.getElementById('rungisTableWrap');


document.querySelectorAll('[data-admin-tab]').forEach(card=>card.addEventListener('click',()=>switchAdminTab(card.dataset.adminTab)));


document.getElementById('fineSearch').addEventListener('input',renderFines);
document.getElementById('fineListStatus')?.addEventListener('change',renderFines);

fineTable.addEventListener('click',event=>{
  // Le menu ••• garde son propre comportement.
  if(event.target.closest('[data-admin-menu-type]')) return;

  const row=event.target.closest('[data-fine-row]');
  if(!row) return;

  closeAdminActions();
  openFineModal(row.dataset.fineRow);
});


document.getElementById('rungisSearch').addEventListener('input',renderRungis);


/* Amende modal */
const fineModal=document.getElementById('fineModal');
const fineForm=document.getElementById('fineForm');
const fineDriverSelect=document.getElementById('fineDriver');
const openFineDriverProfileButton=document.getElementById('openFineDriverProfile');
const fineDriverPreview=document.getElementById('fineDriverPreview');
const closeFineDriverPreviewButton=document.getElementById('closeFineDriverPreview');


/* ===== PIÈCES JOINTES AMENDES ===== */
const FINE_FILES_FOLDER='pieces_jointes_amendes';
let pendingFineFiles=[];

const fineAttachmentInput=document.getElementById('fineAttachmentInput');
const fineAttachmentList=document.getElementById('fineAttachmentList');
const fineAttachmentWarning=document.getElementById('fineAttachmentWarning');
const addFineAttachmentButton=document.getElementById('addFineAttachment');


addFineAttachmentButton?.addEventListener('click',()=>{
  if(!sharedConnected){
    fineAttachmentWarning.hidden=false;
    dashboardToast(
      'Stockage partagé requis',
      'Connecte le dossier data avant d’ajouter une pièce jointe.',
      'warn',
      3500
    );
    return;
  }
  fineAttachmentInput.click();
});

fineAttachmentInput?.addEventListener('change',()=>{
  if(!fineAttachmentInput.files?.length) return;

  pendingFineFiles.push(...fineAttachmentInput.files);
  fineAttachmentInput.value='';
  renderFineAttachments();
});

fineAttachmentList?.addEventListener('click',async event=>{
  const pendingButton=event.target.closest('[data-remove-pending-fine-file]');
  if(pendingButton){
    pendingFineFiles.splice(Number(pendingButton.dataset.removePendingFineFile),1);
    renderFineAttachments();
    return;
  }

  const deleteButton=event.target.closest('[data-delete-fine-file]');
  if(deleteButton && editingFineId){
    if(!confirm('Supprimer cette pièce jointe ?')) return;

    try{
      await deleteFineFile(deleteButton.dataset.deleteFineFile);
      await updateFineAttachmentCount(editingFineId);

      administratorWriteHistory({
        action:'Pièce jointe',
        section:'Amendes',
        entity:adminFines.find(x=>x.id===editingFineId)?.reference || editingFineId,
        detail:'Suppression d’une pièce jointe'
      });

      await renderFineAttachments();
    }catch(error){
      dashboardToast('Suppression impossible',String(error),'error',4000);
    }
    return;
  }

  const openButton=event.target.closest('[data-open-fine-file]');
  if(openButton){
    await openFineFile(openButton.dataset.openFineFile);
  }
});


fineDriverSelect?.addEventListener('input',()=>{
  updateFineDriverProfileButton();
  if(fineDriverPreview && !fineDriverPreview.hidden){
    const profile=findFineDriverProfile(String(fineDriverSelect.value||'').trim());
    if(profile) renderFineDriverPreview(profile);
    else closeFineDriverPreview();
  }
});
fineDriverSelect?.addEventListener('change',()=>{
  updateFineDriverProfileButton();
  if(fineDriverPreview && !fineDriverPreview.hidden){
    const profile=findFineDriverProfile(String(fineDriverSelect.value||'').trim());
    if(profile) renderFineDriverPreview(profile);
    else closeFineDriverPreview();
  }
});
openFineDriverProfileButton?.addEventListener('click',openFineSelectedDriverProfile);
closeFineDriverPreviewButton?.addEventListener('click',closeFineDriverPreview);

function autocompleteFineField(input,options,normalize){
  if(!input) return;
  input.addEventListener('keydown',event=>{
    if(event.key!=='Tab'||event.shiftKey) return;
    const query=normalize(input.value);
    if(!query) return;
    const exact=options.find(option=>normalize(option)===query);
    if(exact){input.value=exact;return;}
    const match=options.find(option=>normalize(option).startsWith(query));
    if(match) input.value=match;
  });
}
const fineVehicleInput=document.getElementById('fineVehicle');
const fineOffenseInput=document.getElementById('fineOffense');
autocompleteFineField(fineVehicleInput,vehicleOptionsForAdmin().map(x=>x.value),value=>normalizeRegistration(value));
autocompleteFineField(fineDriverSelect,driverOptionsForAdmin(),value=>adminNorm(value));
autocompleteFineField(fineOffenseInput,[...new Set(adminFines.map(item=>String(item.offense||'').trim()).filter(Boolean))],value=>adminNorm(value));
fineVehicleInput?.addEventListener('blur',()=>{
  const query=normalizeRegistration(fineVehicleInput.value);
  const exact=vehicleOptionsForAdmin().map(x=>x.value).find(option=>normalizeRegistration(option)===query);
  if(exact) fineVehicleInput.value=exact;
});

document.getElementById('addFine').addEventListener('click',()=>openFineModal());
document.getElementById('closeFineModal').addEventListener('click',closeFineModal);
document.getElementById('cancelFineModal').addEventListener('click',closeFineModal);
fineModal.addEventListener('click',e=>{if(e.target===fineModal)closeFineModal()});
fineForm.addEventListener('submit',async e=>{
  e.preventDefault();

  const data={
    date:document.getElementById('fineDate').value,
    vehicle:document.getElementById('fineVehicle').value,
    driver:document.getElementById('fineDriver').value,
    amount:document.getElementById('fineAmount').value.trim(),
    offense:document.getElementById('fineOffense').value.trim(),
    reference:document.getElementById('fineReference').value.trim(),
    status:document.getElementById('fineStatus').value,
    notes:document.getElementById('fineNotes').value.trim()
  };

  let fineId=editingFineId;

  if(editingFineId){
    const item=adminFines.find(x=>x.id===editingFineId);
    if(item) Object.assign(item,data);
  }else{
    fineId='fine_'+Date.now()+'_'+Math.random().toString(36).slice(2);
    adminFines.push({id:fineId,attachmentCount:0,...data});
  }

  saveAdminFines();

  const filesToSave=[...pendingFineFiles];

  if(filesToSave.length){
    if(!sharedConnected){
      dashboardToast(
        'Amende enregistrée sans les fichiers',
        'Le stockage partagé n’est pas connecté.',
        'warn',
        4000
      );
    }else{
      try{
        for(const file of filesToSave){
          await putFineFile(fineId,file);
        }

        const item=adminFines.find(x=>x.id===fineId);
        if(item){
          const files=await getFineFiles(fineId);
          item.attachmentCount=files.length;
          saveAdminFines();
        }

        administratorWriteHistory({
          action:'Pièce jointe',
          section:'Amendes',
          entity:data.reference || fineId,
          detail:`${filesToSave.length} fichier${filesToSave.length>1?'s':''} ajouté${filesToSave.length>1?'s':''}`
        });
      }catch(error){
        dashboardToast(
          'Fichier(s) non enregistré(s)',
          String(error),
          'error',
          4500
        );
      }
    }
  }

  closeFineModal();
  renderFines();
});

/* Rungis modal */
const rungisModal=document.getElementById('rungisModal');
const rungisForm=document.getElementById('rungisForm');
const rungisError=document.getElementById('rungisError');


document.getElementById('rungisVehicle').addEventListener('change',updateRungisParkPreview);
document.getElementById('addRungis').addEventListener('click',()=>openRungisModal());
document.getElementById('closeRungisModal').addEventListener('click',closeRungisModal);
document.getElementById('cancelRungisModal').addEventListener('click',closeRungisModal);
rungisModal.addEventListener('click',e=>{if(e.target===rungisModal)closeRungisModal()});

rungisForm.addEventListener('submit',e=>{
  e.preventDefault();

  const cardNumber=document.getElementById('rungisCardNumber').value.trim();
  const vehicle=document.getElementById('rungisVehicle').value;

  if(!cardNumber){
    rungisError.textContent='Renseignez le n° de carte.';
    return;
  }

  const duplicate=adminRungis.some(item=>
    item.id!==editingRungisId &&
    String(item.cardNumber||'').trim().toLocaleLowerCase('fr')===cardNumber.toLocaleLowerCase('fr')
  );

  if(duplicate){
    rungisError.textContent='Ce n° de carte existe déjà.';
    return;
  }

  const data={cardNumber,vehicle};

  if(editingRungisId){
    const item=adminRungis.find(x=>x.id===editingRungisId);
    if(item) Object.assign(item,data);
  }else{
    adminRungis.push({
      id:'rungis_'+Date.now()+'_'+Math.random().toString(36).slice(2),
      ...data
    });
  }

  saveAdminRungis();
  closeRungisModal();
  renderRungis();
});

/* Context menu */

document.addEventListener('click',e=>{
  const button=e.target.closest('[data-admin-menu-type]');
  if(button){
    e.stopPropagation();
    adminActionType=button.dataset.adminMenuType;adminActionId=button.dataset.adminMenuId;
    const notifyButton=document.getElementById('adminNotifyAction');
    if(notifyButton) notifyButton.hidden=adminActionType!=='fine';
    adminActionsMenu.hidden=false;
    const r=button.getBoundingClientRect(),m=adminActionsMenu.getBoundingClientRect();
    adminActionsMenu.style.left=Math.max(10,Math.min(r.right-m.width,window.innerWidth-m.width-10))+'px';
    let top=r.bottom+6;if(top+m.height>window.innerHeight-10)top=r.top-m.height-6;
    adminActionsMenu.style.top=Math.max(10,top)+'px';
    return;
  }
  if(!adminActionsMenu.hidden&&!adminActionsMenu.contains(e.target))closeAdminActions();
});
function fineNotifyPhone(profile){
  const raw=String(profile?.phone||profile?.personal||'').replace(/[^+0-9]/g,'');
  if(!raw) return '';
  if(raw.startsWith('+')) return raw;
  if(raw.startsWith('00')) return '+'+raw.slice(2);
  if(raw.startsWith('0')) return '+33'+raw.slice(1);
  return raw;
}

document.getElementById('adminNotifyAction')?.addEventListener('click',()=>{
  const type=adminActionType,id=adminActionId;closeAdminActions();
  if(type!=='fine'){
    dashboardToast('Action indisponible','La notification est réservée aux amendes.','warn');
    return;
  }
  const item=adminFines.find(x=>x.id===id);
  if(!item) return;
  const driverName=String(item.driver||'').trim();
  const profile=findFineDriverProfile(driverName);
  const phone=fineNotifyPhone(profile);
  const date=item.date?new Date(item.date+'T00:00:00').toLocaleDateString('fr-FR'):'';
  const message=[
    `Bonjour ${driverName||''},`.trim(),
    `Nous t'informons qu'une contravention a été enregistrée à ton nom${date?` le ${date}`:''}${item.vehicle?`, véhicule ${item.vehicle}`:''}.`,
    item.offense?`Motif : ${item.offense}.`:'',
    'Merci de prendre contact avec le service parc dès que possible.'
  ].filter(Boolean).join('\n');
  if(!phone){
    dashboardToast('Téléphone manquant',`Aucun numéro trouvé pour ${driverName||'ce chauffeur'} dans sa fiche.`,'warn',4500);
    return;
  }
  const smsUrl=`sms:${phone}?&body=${encodeURIComponent(message)}`;
  const copyFallback=async()=>{
    try{
      await navigator.clipboard.writeText(`${phone}\n\n${message}`);
      dashboardToast('Message copié',`Le message pour ${driverName} et son numéro sont dans le presse-papiers.`,'success',4500);
    }catch(error){
      dashboardToast('Envoi impossible','Aucune application SMS n’est configurée sur ce poste.','error',4500);
    }
  };
  let opened=false;
  const handleVisibility=()=>{if(document.hidden) opened=true;};
  document.addEventListener('visibilitychange',handleVisibility);
  window.open(smsUrl,'_self');
  setTimeout(()=>{
    document.removeEventListener('visibilitychange',handleVisibility);
    if(!opened) copyFallback();
  },800);
});
document.getElementById('adminEditAction').addEventListener('click',()=>{
  const type=adminActionType,id=adminActionId;closeAdminActions();
  if(type==='fine')openFineModal(id);else if(type==='rungis')openRungisModal(id);
});

/* Delete */
const adminDeleteModal=document.getElementById('adminDeleteModal');
let deleteAdminType=null,deleteAdminId=null;


document.getElementById('adminDeleteAction').addEventListener('click',()=>{
  const t=adminActionType,i=adminActionId;closeAdminActions();openAdminDelete(t,i);
});
document.getElementById('confirmAdminDelete').addEventListener('click',async()=>{
  if(deleteAdminType==='fine'){
    const fineId=deleteAdminId;

    try{
      await deleteAllFineFiles(fineId);
    }catch(error){
      console.warn('Impossible de supprimer les pièces jointes de l’amende.',error);
    }

    adminFines=adminFines.filter(x=>x.id!==fineId);
    saveAdminFines();
    renderFines();
  }
  else if(deleteAdminType==='rungis'){
    adminRungis=adminRungis.filter(x=>x.id!==deleteAdminId);
    saveAdminRungis();
    renderRungis();
  }
  closeAdminDelete();
});
document.getElementById('closeAdminDelete').addEventListener('click',closeAdminDelete);
document.getElementById('cancelAdminDelete').addEventListener('click',closeAdminDelete);
adminDeleteModal.addEventListener('click',e=>{if(e.target===adminDeleteModal)closeAdminDelete()});

/* Sites */


document.querySelectorAll('[data-edit-site]').forEach(btn=>btn.addEventListener('click',()=>openSiteUrlModal(btn.dataset.editSite)));
document.querySelectorAll('[data-open-site]').forEach(btn=>btn.addEventListener('click',()=>{
  const url=String(adminSites[btn.dataset.openSite]||'').trim();if(url)window.open(url,'_blank','noopener,noreferrer');
}));
document.getElementById('closeSiteUrlModal').addEventListener('click',closeSiteUrlModal);
document.getElementById('cancelSiteUrlModal').addEventListener('click',closeSiteUrlModal);
document.getElementById('siteUrlModal').addEventListener('click',e=>{if(e.target===document.getElementById('siteUrlModal'))closeSiteUrlModal()});
document.getElementById('siteUrlForm').addEventListener('submit',e=>{
  e.preventDefault();
  let url=document.getElementById('siteUrlInput').value.trim();
  if(url&&!/^https?:\/\//i.test(url))url='https://'+url;
  if(url){
    try{new URL(url)}catch(error){document.getElementById('siteUrlError').textContent='Adresse invalide.';return}
  }
  adminSites[editingSiteKey]=url;saveAdminSites();renderAdminSites();closeSiteUrlModal();
});

window.addEventListener('resize',closeAdminActions);
window.addEventListener('scroll',closeAdminActions,true);
document.addEventListener('keydown',e=>{
  if(e.key!=='Escape')return;
  if(!adminDeleteModal.hidden)closeAdminDelete();
  else if(!fineModal.hidden)closeFineModal();
  else if(!rungisModal.hidden)closeRungisModal();
  else if(!document.getElementById('siteUrlModal').hidden)closeSiteUrlModal();
  else closeAdminActions();
});

renderFines();
renderRungis();
renderAdminSites();
switchAdminTab('fines');


/* ===== PAGE CARBURANT ===== */
const FUEL_STORAGE_KEY='hessers-fuel-tracking-v1';

let fuelEntries=[];
try{
  const stored=JSON.parse(localStorage.getItem(FUEL_STORAGE_KEY));
  if(Array.isArray(stored)) fuelEntries=stored;
}catch(error){
  console.warn('Impossible de lire le suivi carburant.',error);
}

let editingFuelId=null;
let activeFuelMenuId=null;
let pendingDeleteFuelId=null;

const fuelTable=document.getElementById('fuelTable');
const fuelTableWrap=document.getElementById('fuelTableWrap');
const fuelSearch=document.getElementById('fuelSearch');
const fuelActionsMenu=document.getElementById('fuelActionsMenu');
const fuelModal=document.getElementById('fuelModal');
const deleteFuelModal=document.getElementById('deleteFuelModal');


fuelSearch.addEventListener('input',renderFuelTable);
document.getElementById('fuelStatsPeriod')?.addEventListener('change',renderFuelStatistics);

/* ----- Ajout / modification ----- */
const fuelForm=document.getElementById('fuelForm');
const fuelError=document.getElementById('fuelError');


document.getElementById('addFuelEntry').addEventListener('click',()=>openFuelModal());
document.getElementById('closeFuelModal').addEventListener('click',closeFuelModal);
document.getElementById('cancelFuelModal').addEventListener('click',closeFuelModal);
fuelModal.addEventListener('click',event=>{
  if(event.target===fuelModal) closeFuelModal();
});

fuelForm.addEventListener('submit',event=>{
  event.preventDefault();

  const supplier=document.getElementById('fuelSupplier').value.trim();

  if(!supplier){
    fuelError.textContent='Renseignez le fournisseur.';
    return;
  }

  const adblueQty=document.getElementById('fuelAdblueQty').value.trim();
  const adbluePrice=document.getElementById('fuelAdbluePrice').value.trim();
  if((adblueQty || adbluePrice) && supplier !== 'Granjon'){
    fuelError.textContent='L’AdBlue n’est disponible que chez Granjon.';
    return;
  }

  const data={
    supplier,
    orderDate:document.getElementById('fuelOrderDate').value,
    deliveryDate:document.getElementById('fuelDeliveryDate').value,
    dieselQty:document.getElementById('fuelDieselQty').value.trim(),
    gnrQty:document.getElementById('fuelGnrQty').value.trim(),
    adblueQty,
    dieselPrice:document.getElementById('fuelDieselPrice').value.trim(),
    gnrPrice:document.getElementById('fuelGnrPrice').value.trim(),
    adbluePrice
  };

  if(editingFuelId){
    const item=fuelEntries.find(entry=>entry.id===editingFuelId);
    if(item) Object.assign(item,data);
  }else{
    fuelEntries.push({
      id:'fuel_'+Date.now()+'_'+Math.random().toString(36).slice(2),
      ...data
    });
  }

  saveFuelEntries();
  closeFuelModal();
  renderFuelTable();
});

/* ----- Menu actions ----- */


fuelTable.addEventListener('click',event=>{
  const button=event.target.closest('[data-fuel-menu]');
  if(!button) return;

  event.stopPropagation();
  openFuelActionsMenu(button,button.dataset.fuelMenu);
});

document.getElementById('editFuelAction').addEventListener('click',()=>{
  const id=activeFuelMenuId;
  closeFuelActionsMenu();

  if(id) openFuelModal(id);
});

/* ----- Suppression ----- */


document.getElementById('deleteFuelAction').addEventListener('click',()=>{
  const id=activeFuelMenuId;
  closeFuelActionsMenu();

  if(id) openDeleteFuelModal(id);
});

document.getElementById('confirmDeleteFuel').addEventListener('click',()=>{
  if(!pendingDeleteFuelId) return;

  fuelEntries=fuelEntries.filter(item=>item.id!==pendingDeleteFuelId);

  saveFuelEntries();
  closeDeleteFuelModal();
  renderFuelTable();
});

document.getElementById('closeDeleteFuel').addEventListener('click',closeDeleteFuelModal);
document.getElementById('cancelDeleteFuel').addEventListener('click',closeDeleteFuelModal);
deleteFuelModal.addEventListener('click',event=>{
  if(event.target===deleteFuelModal){
    closeDeleteFuelModal();
  }
});

/* ----- Graphiques sans librairie externe ----- */


document.addEventListener('click',event=>{
  if(
    !fuelActionsMenu.hidden &&
    !fuelActionsMenu.contains(event.target) &&
    !event.target.closest('[data-fuel-menu]')
  ){
    closeFuelActionsMenu();
  }
});

let fuelResizeFrame=null;
window.addEventListener('resize',()=>{
  closeFuelActionsMenu();

  if(fuelResizeFrame) cancelAnimationFrame(fuelResizeFrame);
  fuelResizeFrame=requestAnimationFrame(()=>{
    requestAnimationFrame(()=>{
      fuelResizeFrame=null;
      renderFuelCharts();
    });
  });
});

window.addEventListener('scroll',closeFuelActionsMenu,true);

document.addEventListener('keydown',event=>{
  if(event.key!=='Escape') return;

  if(!deleteFuelModal.hidden) closeDeleteFuelModal();
  else if(!fuelModal.hidden) closeFuelModal();
  else closeFuelActionsMenu();
});

renderFuelTable();


/* ===== ACCUEIL DYNAMIQUE ===== */


document.querySelectorAll('[data-home-view]').forEach(element=>{
  element.addEventListener('click',()=>{
    const target=element.dataset.homeView;
    const navButton=[...navButtons].find(button=>button.dataset.view===target);

    if(!navButton) return;

    showView(
      target,
      target==='accueil'?'Gestion de Parc':navButton.innerText.trim(),
      target
    );

    if(target==='gestion-administrative'){
      const tab=element.dataset.homeAdminTab;

      if(tab && typeof switchAdminTab==='function'){
        switchAdminTab(tab);
      }

      const fineFilter=element.dataset.homeFineFilter;
      if(fineFilter){
        const search=document.getElementById('fineSearch');
        const status=document.getElementById('fineListStatus');
        if(search) search.value='';
        if(status){
          status.value=fineFilter;
          status.dispatchEvent(new Event('change',{bubbles:true}));
        }
      }
    }
  });
});

refreshHomeDashboard();


/* ===== RECHERCHE GLOBALE ===== */
const globalSearch=document.getElementById('globalSearch');
const globalSearchResults=document.getElementById('globalSearchResults');
const globalSearchClear=document.getElementById('globalSearchClear');

let globalSearchMatches=[];
let globalSearchActiveIndex=-1;


globalSearch.addEventListener('focus',renderGlobalSearch);
globalSearch.addEventListener('input',renderGlobalSearch);

globalSearchClear.addEventListener('click',()=>{
  globalSearch.value='';
  globalSearchClear.hidden=true;
  globalSearch.focus();
  renderGlobalSearch();
});

globalSearchResults.addEventListener('click',event=>{
  const button=event.target.closest('[data-global-result]');
  if(!button) return;
  activateGlobalSearchResult(Number(button.dataset.globalResult));
});

globalSearch.addEventListener('keydown',event=>{
  if(globalSearchResults.hidden) return;

  const buttons=[...globalSearchResults.querySelectorAll('[data-global-result]')];
  if(!buttons.length) return;

  if(event.key==='ArrowDown'){
    event.preventDefault();
    globalSearchActiveIndex=(globalSearchActiveIndex+1)%buttons.length;
  }else if(event.key==='ArrowUp'){
    event.preventDefault();
    globalSearchActiveIndex=(globalSearchActiveIndex-1+buttons.length)%buttons.length;
  }else if(event.key==='Enter' && globalSearchActiveIndex>=0){
    event.preventDefault();
    activateGlobalSearchResult(globalSearchActiveIndex);
    return;
  }else if(event.key==='Escape'){
    closeGlobalSearch();
    return;
  }else{
    return;
  }

  buttons.forEach((button,index)=>{
    button.classList.toggle('active',index===globalSearchActiveIndex);
  });

  buttons[globalSearchActiveIndex]?.scrollIntoView({block:'nearest'});
});

document.addEventListener('click',event=>{
  if(
    !globalSearchResults.hidden &&
    !event.target.closest('.global-search-wrap')
  ){
    closeGlobalSearch();
  }
});


/* ===== IDENTIFIANT UTILISATEUR ===== */
const DASHBOARD_USER_KEY='hessers-dashboard-user-v1';
let dashboardUser=(localStorage.getItem(DASHBOARD_USER_KEY)||'').trim().toUpperCase();

const dashboardUserBadge=document.getElementById('dashboardUserBadge');
const dashboardUserLabel=document.getElementById('dashboardUserLabel');
const dashboardUserModal=document.getElementById('dashboardUserModal');
const dashboardUserInput=document.getElementById('dashboardUserInput');
const dashboardUserError=document.getElementById('dashboardUserError');
const saveDashboardUserButton=document.getElementById('saveDashboardUser');
const closeDashboardUserModal=document.getElementById('closeDashboardUserModal');


dashboardUserBadge.addEventListener('click',()=>openDashboardUserModal(false));
saveDashboardUserButton.addEventListener('click',saveDashboardUser);
closeDashboardUserModal.addEventListener('click',closeDashboardUserDialog);
dashboardUserModal.addEventListener('click',event=>{
  if(event.target===dashboardUserModal) closeDashboardUserDialog();
});
dashboardUserInput.addEventListener('keydown',event=>{
  if(event.key==='Enter'){
    event.preventDefault();
    saveDashboardUser();
  }
});
dashboardUserInput.addEventListener('input',()=>{
  dashboardUserInput.value=normalizeDashboardUser(dashboardUserInput.value);
  dashboardUserError.classList.remove('show');
});

refreshDashboardUserBadge();
if(!dashboardUser){
  setTimeout(()=>openDashboardUserModal(true),180);
}


/* ===== SUPERVISION ADMINISTRATEUR : CORE ===== */
const ADMINISTRATOR_USER='THEMIA';
const ADMIN_PRESENCE_FOLDER='presence';
const ADMIN_HISTORY_FOLDER='historique';
const ADMIN_PRESENCE_INTERVAL=30000;
const ADMIN_ONLINE_MAX_AGE=120000;
const ADMIN_HISTORY_MAX_RECORDS=400;

let administratorPresenceTimer=null;
let administratorPresenceUser='';
let administratorSessionStartedAt=new Date().toISOString();
let administratorConnectionLoggedUser='';
let administratorLastPresenceWrite=0;
let administratorLastKnownPage='accueil';


/* ===== STOCKAGE PARTAGÉ (DOSSIER PARTAGÉ) =====
   - Le localStorage reste un cache local pour conserver l'architecture existante.
   - Les données métier sont synchronisées avec des JSON du dossier partagé.
   - Chaque sauvegarde est fusionnée au niveau des enregistrements afin de limiter
     les écrasements lorsque deux utilisateurs modifient des éléments différents.
*/
const SHARED_DB_NAME='hessers-shared-folder-v1';
const SHARED_DB_STORE='handles';
const SHARED_HANDLE_KEY='groupdrive-data-folder';
const SHARED_POLL_MS=5000;

const SHARED_DATASETS=[
  {key:PARK_STORAGE_KEY,file:'parc.json',kind:'array',id:item=>normalizeRegistration(item?.registration)},
  {key:AFFECT_STORAGE_KEY,file:'affectations.json',kind:'array',id:item=>normalizeAffText(item?.name)},
  {key:DRIVER_STORAGE_KEY,file:'chauffeurs.json',kind:'array',id:item=>String(item?.id||'')},
  {key:CLAIM_STORAGE_KEY,file:'sinistres.json',kind:'array',id:item=>String(item?.id||'')},
  {key:CLAIM_EVENTS_KEY,file:'sinistres_historique.json',kind:'array',id:item=>String(item?.id||'')},
  {key:VIDANGE_STORAGE_KEY,file:'vidanges.json',kind:'array',id:item=>String(item?.id||normalizeRegistration(item?.registration)||'')},
  {key:TECH_DEADLINE_STORAGE_KEY,file:'echeances_techniques.json',kind:'array',id:item=>String(item?.id||'')},
  {key:ADMIN_FINE_KEY,file:'amendes.json',kind:'array',id:item=>String(item?.id||'')},
  {key:ADMIN_RUNGIS_KEY,file:'cartes_rungis.json',kind:'array',id:item=>String(item?.id||item?.cardNumber||'')},
  {key:ADMIN_SITES_KEY,file:'sites.json',kind:'object'},
  {key:FUEL_STORAGE_KEY,file:'carburant.json',kind:'array',id:item=>String(item?.id||'')}
];

const SHARED_DESCRIPTOR_BY_KEY=new Map(SHARED_DATASETS.map(item=>[item.key,item]));
const SHARED_ORIGINAL_SET_ITEM=Storage.prototype.setItem;
const SHARED_ORIGINAL_REMOVE_ITEM=Storage.prototype.removeItem;

let sharedDirectoryHandle=null;
let sharedConnected=false;
let sharedPollTimer=null;
let sharedWriteQueues=new Map();
let sharedLastLocalByKey=new Map();
let sharedRemoteSignatureByKey=new Map();
let sharedPendingRemote=new Map();
let sharedClientId='client_'+Math.random().toString(36).slice(2)+'_'+Date.now().toString(36);
let sharedLastSyncAt=null;
let sharedFilesReady=0;
let sharedSuppressLocalHook=false;

const sharedStorageButton=document.getElementById('sharedStorageButton');
const sharedStorageLabel=document.getElementById('sharedStorageLabel');
const sharedStorageHeroDot=document.getElementById('sharedStorageHeroDot');
const sharedStorageModal=document.getElementById('sharedStorageModal');
const closeSharedStorageModal=document.getElementById('closeSharedStorageModal');
const connectSharedStorageButton=document.getElementById('connectSharedStorage');
const syncSharedStorageButton=document.getElementById('syncSharedStorage');
const disconnectSharedStorageButton=document.getElementById('disconnectSharedStorage');
const sharedStorageState=document.getElementById('sharedStorageState');
const sharedStorageFolder=document.getElementById('sharedStorageFolder');
const sharedStorageLastSync=document.getElementById('sharedStorageLastSync');
const sharedStorageFileCount=document.getElementById('sharedStorageFileCount');
const sharedStorageMessage=document.getElementById('sharedStorageMessage');


Storage.prototype.setItem=function(key,value){
  const isShared=
    this===localStorage &&
    !sharedSuppressLocalHook &&
    sharedConnected &&
    SHARED_DESCRIPTOR_BY_KEY.has(key);

  let previous=null;
  let next=null;

  if(isShared){
    previous=sharedDeepClone(
      sharedLastLocalByKey.has(key)
        ? sharedLastLocalByKey.get(key)
        : sharedCurrentData(key)
    );
    try{next=JSON.parse(value)}catch(error){next=null}
  }

  const result=SHARED_ORIGINAL_SET_ITEM.call(this,key,value);

  if(isShared && next!==null){
    sharedLastLocalByKey.set(key,sharedDeepClone(next));
    sharedQueueSave(key,previous,next);
  }

  return result;
};

Storage.prototype.removeItem=function(key){
  const result=SHARED_ORIGINAL_REMOVE_ITEM.call(this,key);
  if(
    this===localStorage &&
    !sharedSuppressLocalHook &&
    sharedConnected &&
    SHARED_DESCRIPTOR_BY_KEY.has(key)
  ){
    const previous=sharedDeepClone(sharedLastLocalByKey.get(key));
    sharedLastLocalByKey.set(key,null);
    sharedQueueSave(key,previous,SHARED_DESCRIPTOR_BY_KEY.get(key).kind==='array'?[]:{});
  }
  return result;
};


sharedStorageButton.addEventListener('click',async()=>{
  if(sharedConnected){
    await sharedSyncFromDisk(true);
    return;
  }
  openSharedStorageModal();
});
closeSharedStorageModal.addEventListener('click',closeSharedStorageDialog);
sharedStorageModal.addEventListener('click',event=>{
  if(event.target===sharedStorageModal) closeSharedStorageDialog();
});
connectSharedStorageButton.addEventListener('click',sharedChooseDirectory);
syncSharedStorageButton.addEventListener('click',()=>sharedSyncFromDisk(true));
disconnectSharedStorageButton.addEventListener('click',async()=>{
  await sharedDisconnect();
  await sharedChooseDirectory();
});

window.addEventListener('focus',()=>{
  if(sharedConnected) sharedSyncFromDisk(false);
});
document.addEventListener('visibilitychange',()=>{
  if(!document.hidden && sharedConnected) sharedSyncFromDisk(false);
});

// Tentative de reconnexion automatique au lancement.
// Si Edge ne conserve pas l'autorisation, l'utilisateur clique simplement
// sur le bouton dossier dans la barre du haut pour la redonner.
(async()=>{
  if(typeof window.showDirectoryPicker!=='function'){
    sharedSetUiState('error','Pour accéder au dossier partagé, ouvre le dashboard avec Microsoft Edge ou Google Chrome à jour.');
    return;
  }

  const savedHandle=await loadSharedDirectoryHandle();
  if(savedHandle){
    sharedDirectoryHandle=savedHandle;
    const connected=await sharedConnect(savedHandle,{requestPermission:false});
    if(!connected){
      sharedSetUiState(
        'local',
        'Le dossier est déjà mémorisé. Clique sur le bouton <b>Autoriser l’accès</b> pour reprendre le partage.'
      );
    }
  }else{
    sharedSetUiState(
      'local',
      'Clique sur <b>Connecter le dossier Data</b>, puis sélectionne <b>Lissieu_Common &gt; GESTION PARC &gt; Dashboard &gt; Data</b>. À faire une seule fois sur cet ordinateur.'
    );
    setTimeout(openSharedStorageModal,450);
  }
})();


/* ===== PIÈCES JOINTES SINISTRES DANS LE DOSSIER PARTAGÉ ===== */
const SHARED_CLAIM_FILES_FOLDER='pieces_jointes_sinistres';


const localPutClaimFile=putClaimFile;
const localGetClaimFiles=getClaimFiles;
const localDeleteClaimFile=deleteClaimFile;

putClaimFile=async function(claimId,file){
  if(!sharedConnected) return localPutClaimFile(claimId,file);

  const dir=await sharedClaimFilesDirectory(true);
  const id='file_'+Date.now()+'_'+Math.random().toString(36).slice(2);
  const cleanClaim=sharedSafeFilePart(claimId);
  const cleanName=sharedSafeFilePart(file.name);
  const storedName=`${cleanClaim}__${id}__${cleanName}`;

  const handle=await dir.getFileHandle(storedName,{create:true});
  const writable=await handle.createWritable();
  await writable.write(file);
  await writable.close();

  return {
    key:'shared::'+storedName,
    claimId,
    id,
    name:file.name,
    type:file.type,
    size:file.size,
    blob:null,
    addedAt:new Date().toISOString()
  };
};

getClaimFiles=async function(claimId){
  if(!sharedConnected) return localGetClaimFiles(claimId);
  if(!claimId) return [];

  let dir;
  try{
    dir=await sharedClaimFilesDirectory(false);
  }catch(error){
    if(error?.name==='NotFoundError') return [];
    throw error;
  }

  const prefix=sharedSafeFilePart(claimId)+'__';
  const records=[];

  for await (const [storedName,handle] of dir.entries()){
    if(handle.kind!=='file' || !storedName.startsWith(prefix)) continue;
    const file=await handle.getFile();

    const firstSep=storedName.indexOf('__');
    const secondSep=storedName.indexOf('__',firstSep+2);
    const id=secondSep>firstSep ? storedName.slice(firstSep+2,secondSep) : storedName;
    const displayName=secondSep>=0 ? storedName.slice(secondSep+2) : storedName;

    records.push({
      key:'shared::'+storedName,
      claimId,
      id,
      name:displayName,
      type:file.type,
      size:file.size,
      blob:null,
      addedAt:new Date(file.lastModified).toISOString()
    });
  }

  return records.sort((a,b)=>String(a.addedAt).localeCompare(String(b.addedAt)));
};

deleteClaimFile=async function(key){
  if(!sharedConnected || !String(key||'').startsWith('shared::')){
    return localDeleteClaimFile(key);
  }

  const dir=await sharedClaimFilesDirectory(false);
  const storedName=String(key).slice('shared::'.length);
  await dir.removeEntry(storedName);
};


/* ===== SÉCURITÉ ADMINISTRATEUR =====
   Le fichier data/admin_security.json ne contient jamais le mot de passe.
   Il contient seulement un sel aléatoire et un hash PBKDF2-SHA256.
*/
const ADMIN_SECURITY_FILE='admin_security.json';
const ADMIN_SECURITY_ITERATIONS=310000;
const ADMIN_SECURITY_TIMEOUT=15*60*1000;
const ADMIN_SECURITY_MIN_LENGTH=8;

let adminSecurityUnlocked=false;
let adminSecurityUnlockedUntil=0;
let adminSecurityMode='login';
let adminSecurityResolver=null;
let adminSecurityFailures=0;
let adminSecurityBlockedUntil=0;

const adminSecurityModal=document.getElementById('adminSecurityModal');
const adminSecurityIntro=document.getElementById('adminSecurityIntro');
const adminSecurityPassword=document.getElementById('adminSecurityPassword');
const adminSecurityConfirm=document.getElementById('adminSecurityConfirm');
const adminSecurityConfirmWrap=document.getElementById('adminSecurityConfirmWrap');
const adminSecurityError=document.getElementById('adminSecurityError');
const adminSecuritySubmit=document.getElementById('adminSecuritySubmit');
const adminSecurityCancel=document.getElementById('adminSecurityCancel');
const adminSecurityClose=document.getElementById('adminSecurityClose');
const adminSecurityChip=document.getElementById('adminSecurityChip');
const adminSecurityChipText=document.getElementById('adminSecurityChipText');
const adminSecurityLockButton=document.getElementById('adminSecurityLockButton');
const adminSecurityChangeButton=document.getElementById('adminSecurityChangeButton');


adminSecuritySubmit.addEventListener('click',adminSecuritySubmitForm);
adminSecurityCancel.addEventListener('click',()=>adminSecurityCloseModal(false));
adminSecurityClose.addEventListener('click',()=>adminSecurityCloseModal(false));
adminSecurityModal.addEventListener('click',event=>{
  if(event.target===adminSecurityModal) adminSecurityCloseModal(false);
});

adminSecurityPassword.addEventListener('keydown',event=>{
  if(event.key!=='Enter') return;
  event.preventDefault();
  if(adminSecurityMode==='login') adminSecuritySubmitForm();
  else adminSecurityConfirm.focus();
});
adminSecurityConfirm.addEventListener('keydown',event=>{
  if(event.key==='Enter'){
    event.preventDefault();
    adminSecuritySubmitForm();
  }
});

adminSecurityLockButton.addEventListener('click',()=>adminSecurityLock(true));
adminSecurityChangeButton.addEventListener('click',adminSecurityChangePasswordFlow);

['click','keydown','touchstart'].forEach(type=>{
  document.addEventListener(type,()=>{
    if(
      adminSecurityUnlocked &&
      document.querySelector('.view.active')?.id==='administrateur'
    ){
      adminSecurityTouch();
    }
  },{passive:true});
});

setInterval(()=>{
  if(adminSecurityUnlocked) adminSecurityIsUnlocked();
  adminSecurityUpdateUi();
},15000);

adminSecurityUpdateUi();


/* ===== PAGE ADMINISTRATEUR : INTERFACE ===== */
let administratorPresenceRecords=[];
let administratorHistoryRecords=[];
let administratorRefreshTimer=null;
let administratorRefreshRunning=false;

const superadminState=document.getElementById('superadminState');
const superadminStateText=document.getElementById('superadminStateText');
const superadminOnlineCount=document.getElementById('superadminOnlineCount');
const superadminLoginToday=document.getElementById('superadminLoginToday');
const superadminActionsToday=document.getElementById('superadminActionsToday');
const superadminLastActivity=document.getElementById('superadminLastActivity');
const superadminLastActivityUser=document.getElementById('superadminLastActivityUser');
const superadminOnlineBadge=document.getElementById('superadminOnlineBadge');
const superadminOnlineTable=document.getElementById('superadminOnlineTable');
const superadminOnlineEmpty=document.getElementById('superadminOnlineEmpty');
const superadminLoginTable=document.getElementById('superadminLoginTable');
const superadminLoginEmpty=document.getElementById('superadminLoginEmpty');
const superadminHistoryTable=document.getElementById('superadminHistoryTable');
const superadminHistoryEmpty=document.getElementById('superadminHistoryEmpty');
const superadminHistoryCount=document.getElementById('superadminHistoryCount');
const superadminHistorySearch=document.getElementById('superadminHistorySearch');
const superadminUserFilter=document.getElementById('superadminUserFilter');
const superadminActionFilter=document.getElementById('superadminActionFilter');
const superadminRefreshButton=document.getElementById('superadminRefresh');
const superadminExportButton=document.getElementById('superadminExport');


superadminRefreshButton.addEventListener('click',administratorRefreshDashboard);
superadminHistorySearch.addEventListener('input',administratorRenderHistory);
superadminUserFilter.addEventListener('change',administratorRenderHistory);
superadminActionFilter.addEventListener('change',administratorRenderHistory);
superadminExportButton.addEventListener('click',administratorExportCsv);

refreshAdministratorAccess();

/* Historique des pièces jointes sinistres */
const administratorBasePutClaimFile=putClaimFile;
const administratorBaseDeleteClaimFile=deleteClaimFile;

putClaimFile=async function(claimId,file){
  const result=await administratorBasePutClaimFile(claimId,file);

  if(sharedConnected){
    administratorWriteHistory({
      action:'Pièce jointe',
      section:'Sinistre',
      entity:String(claimId||''),
      detail:'Ajout du fichier '+String(file?.name||'')
    });
  }

  return result;
};

deleteClaimFile=async function(key){
  const result=await administratorBaseDeleteClaimFile(key);

  if(sharedConnected){
    administratorWriteHistory({
      action:'Pièce jointe',
      section:'Sinistre',
      entity:'Pièce jointe',
      detail:'Suppression d’un fichier'
    });
  }

  return result;
};


/* =========================================================
   V2 PRODUCTION
   ========================================================= */

/* ---------- Helpers ---------- */


/* ---------- Toasts ---------- */
const dashboardToastStack=document.getElementById('dashboardToastStack');
let dashboardLastSaveToast=0;


/* ---------- Validation ---------- */


/* Validation active avant enregistrement de certains formulaires */
document.getElementById('saveVidRecord')?.addEventListener('click',event=>{
  const current=kmNumber(document.getElementById('vidCurrentKm')?.value);
  const major=kmNumber(document.getElementById('vidLastMajorKm')?.value);
  const garage=kmNumber(document.getElementById('vidLastGarageKm')?.value);
  if(current!==null && ((major!==null && current<major)||(garage!==null && current<garage))){
    event.preventDefault();
    event.stopImmediatePropagation();
    const notice=document.getElementById('vidNotice');
    if(notice){
      notice.style.color='#ff7373';
      notice.textContent='Le kilométrage actuel ne peut pas être inférieur à un kilométrage d’entretien déjà enregistré.';
    }
  }
},true);

saveDriverButton?.addEventListener('click',event=>{
  const license=String(driverLicenseNumber?.value||'').trim().toUpperCase();
  if(!license) return;
  const selected=getSelectedDriver();
  const duplicate=driverProfiles.find(d=>d.id!==selected?.id && String(d.licenseNumber||'').trim().toUpperCase()===license);
  if(duplicate){
    event.preventDefault();
    event.stopImmediatePropagation();
    driverSaveNotice.style.color='#ff7373';
    driverSaveNotice.textContent=`Ce n° de permis est déjà utilisé par ${driverDisplayName(duplicate)}.`;
  }
},true);

addDriverForm?.addEventListener('submit',event=>{
  const license=String(newDriverLicenseNumber?.value||'').trim().toUpperCase();
  if(!license) return;
  const duplicate=driverProfiles.find(d=>String(d.licenseNumber||'').trim().toUpperCase()===license);
  if(duplicate){
    event.preventDefault();
    event.stopImmediatePropagation();
    addDriverError.textContent=`Ce n° de permis est déjà utilisé par ${driverDisplayName(duplicate)}.`;
  }
},true);

fuelForm?.addEventListener('submit',event=>{
  const ids=['fuelDieselQty','fuelGnrQty','fuelAdblueQty','fuelDieselPrice','fuelGnrPrice','fuelAdbluePrice'];
  for(const id of ids){
    const value=document.getElementById(id)?.value?.trim();
    if(!value) continue;
    const n=Number(value.replace(/\s/g,'').replace(',','.'));
    if(!Number.isFinite(n)||n<0){
      event.preventDefault();
      event.stopImmediatePropagation();
      fuelError.textContent='Les quantités et prix carburant doivent être des nombres positifs.';
      return;
    }
  }
},true);

fineForm?.addEventListener('submit',event=>{
  const input=document.getElementById('fineAmount');
  if(!input?.value?.trim()) return;
  const n=Number(input.value.replace(',','.'));
  if(!Number.isFinite(n)||n<0){
    event.preventDefault();
    event.stopImmediatePropagation();
    fineError.textContent='Le montant doit être un nombre positif.';
  }
},true);

/* ---------- Qualité Admin ---------- */
const qualityScore=document.getElementById('qualityScore');
const qualityTitle=document.getElementById('qualityTitle');
const qualitySubtitle=document.getElementById('qualitySubtitle');
const qualityList=document.getElementById('qualityList');
document.getElementById('qualityRefresh')?.addEventListener('click',dashboardRenderQuality);


/* ---------- Notifications ---------- */
const notificationBell=document.getElementById('notificationBell');
const notificationBadge=document.getElementById('notificationBadge');
const notificationPanel=document.getElementById('notificationPanel');
const notificationList=document.getElementById('notificationList');
const notificationClose=document.getElementById('notificationClose');
const notificationSubtitle=document.getElementById('notificationSubtitle');
const notificationQuickVehicles=document.getElementById('notificationQuickVehicles');

const DASHBOARD_RECENTS_KEY='hessers-recent-vehicles-v1';
const DASHBOARD_FAVORITES_KEY='hessers-favorite-vehicles-v1';


notificationBell?.addEventListener('click',event=>{
  event.stopPropagation();
  dashboardRefreshNotifications();
  notificationPanel.hidden=!notificationPanel.hidden;
});
notificationClose?.addEventListener('click',()=>notificationPanel.hidden=true);
notificationList?.addEventListener('click',event=>{
  const row=event.target.closest('[data-notification-index]');
  if(!row) return;
  const item=notificationList._dashboardItems?.[Number(row.dataset.notificationIndex)];
  if(item) dashboardOpenNotification(item);
});
notificationQuickVehicles?.addEventListener('click',event=>{
  const btn=event.target.closest('[data-quick-vehicle]');
  if(btn) dashboardOpenVehicleDossier(btn.dataset.quickVehicle);
});
document.addEventListener('click',event=>{
  if(!notificationPanel?.hidden && !notificationPanel.contains(event.target) && !notificationBell.contains(event.target)){
    notificationPanel.hidden=true;
  }
});

/* ---------- Fiche véhicule ---------- */
const vehicleDossierModal=document.getElementById('vehicleDossierModal');
const vehicleDossierBody=document.getElementById('vehicleDossierBody');
const vehicleDossierTitle=document.getElementById('vehicleDossierTitle');
const vehicleDossierClose=document.getElementById('vehicleDossierClose');
let dashboardCurrentVehicleDossier='';


vehicleDossierClose?.addEventListener('click',dashboardCloseVehicleDossier);
vehicleDossierModal?.addEventListener('click',event=>{
  if(event.target===vehicleDossierModal) dashboardCloseVehicleDossier();
});
vehicleDossierBody?.addEventListener('click',event=>{
  const go=event.target.closest('[data-vehicle-go]');
  if(!go) return;
  const view=go.dataset.vehicleGo;
  const plate=dashboardCurrentVehicleDossier;
  dashboardCloseVehicleDossier();
  const nav=[...navButtons].find(b=>b.dataset.view===view);
  if(nav) showView(view,nav.innerText.trim(),view);
  if(view==='suivi-technique'&&plate){
    vidSearch.value=plate;renderVidTable();
  }
  if(view==='sinistre'&&plate){
    claimSearch.value=plate;renderClaims();
  }
});
parkTable?.addEventListener('click',event=>{
  const cell=event.target.closest('[data-open-vehicle]');
  if(cell && !event.target.closest('.row-menu')) dashboardOpenVehicleDossier(cell.dataset.openVehicle);
});
affTable?.addEventListener('click',event=>{
  const cell=event.target.closest('[data-open-vehicle]');
  if(cell && !event.target.closest('.row-menu')) dashboardOpenVehicleDossier(cell.dataset.openVehicle);
});

/* ---------- Conflits multi-utilisateurs ---------- */
const sharedConflictModal=document.getElementById('sharedConflictModal');
const sharedConflictItems=document.getElementById('sharedConflictItems');
const sharedConflictBanner=document.getElementById('sharedConflictBanner');
let sharedConflictResolver=null;


document.getElementById('sharedConflictReload')?.addEventListener('click',()=>dashboardResolveConflictChoice(false));
document.getElementById('sharedConflictKeep')?.addEventListener('click',()=>dashboardResolveConflictChoice(true));

/* ---------- Sauvegardes / restauration ---------- */
const DASHBOARD_BACKUP_FOLDER='sauvegardes';
let dashboardBackupInProgress=false;
let dashboardBackupReadyForDay='';


document.getElementById('backupNow')?.addEventListener('click',async event=>{
  const button=event.currentTarget;
  button.disabled=true;
  try{
    const name=dashboardBackupTimestampName('manuel');
    const created=await dashboardCreateBackup(name,'Sauvegarde manuelle');
    if(!created) throw new Error('Une sauvegarde est déjà en cours.');
    dashboardToast('Sauvegarde créée',name,'success');
    await dashboardRefreshBackupList();
  }catch(error){
    dashboardToast('Sauvegarde impossible',String(error),'error',4500);
  }finally{
    button.disabled=false;
  }
});
document.getElementById('backupRefresh')?.addEventListener('click',dashboardRefreshBackupList);
document.getElementById('backupList')?.addEventListener('click',event=>{
  const button=event.target.closest('[data-restore-backup]');
  if(button) dashboardRestoreBackup(button.dataset.restoreBackup);
});
function dashboardExportLocalBackup(){
  const datasets={};
  SHARED_DATASETS.forEach(descriptor=>{
    try{
      const raw=localStorage.getItem(descriptor.key);
      if(raw!==null) datasets[descriptor.key]=JSON.parse(raw);
    }catch(error){console.warn('Jeu local ignoré pendant l’export.',descriptor.key,error);}
  });
  const payload={version:1,createdAt:new Date().toISOString(),datasets};
  const blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'});
  const url=URL.createObjectURL(blob);const link=document.createElement('a');
  link.href=url;link.download=`dashboard_local_${new Date().toISOString().slice(0,10)}.json`;
  document.body.appendChild(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),500);
}
async function dashboardImportLocalBackup(file){
  const payload=JSON.parse(await file.text());
  if(!payload||typeof payload.datasets!=='object') throw new Error('Fichier de sauvegarde invalide.');
  const allowed=new Map(SHARED_DATASETS.map(item=>[item.key,item]));
  const keys=Object.keys(payload.datasets).filter(key=>allowed.has(key));
  if(!keys.length) throw new Error('Aucun jeu de données compatible.');
  if(!confirm(`Restaurer ${keys.length} jeu${keys.length>1?'x':''} de données locaux ?\n\nLa page sera rechargée après restauration.`)) return;
  keys.forEach(key=>localStorage.setItem(key,JSON.stringify(payload.datasets[key])));
  location.reload();
}
document.getElementById('backupLocalExport')?.addEventListener('click',dashboardExportLocalBackup);
document.getElementById('backupLocalImport')?.addEventListener('click',()=>document.getElementById('backupLocalInput')?.click());
document.getElementById('backupLocalInput')?.addEventListener('change',async event=>{
  const file=event.target.files?.[0];event.target.value='';
  if(!file)return;
  try{await dashboardImportLocalBackup(file);}
  catch(error){dashboardToast('Restauration impossible',String(error?.message||error),'error',5000);}
});

/* ---------- Admin refresh enrichi ---------- */
const dashboardOriginalAdminRefresh=administratorRefreshDashboard;
administratorRefreshDashboard=async function(){
  await dashboardOriginalAdminRefresh();
  dashboardRenderQuality();
  await dashboardRefreshBackupList();
  if(typeof dashboardRefreshUpdateUi==='function'){
    await dashboardRefreshUpdateUi();
  }
};

/* ---------- Raccourcis ---------- */
const shortcutHelp=document.getElementById('shortcutHelp');
let shortcutHelpTimer=null;

document.addEventListener('keydown',event=>{
  const tag=document.activeElement?.tagName?.toLowerCase();
  const typing=['input','textarea','select'].includes(tag);

  if((event.ctrlKey||event.metaKey) && event.key.toLowerCase()==='k'){
    event.preventDefault();
    globalSearch.focus();
    globalSearch.select();
    dashboardFlashShortcutHelp();
    return;
  }

  if(event.key==='Escape'){
    notificationPanel.hidden=true;
    if(!vehicleDossierModal.hidden) dashboardCloseVehicleDossier();
  }

  if(!typing && event.altKey && event.key.toLowerCase()==='p'){
    event.preventDefault();
    showView('parc','Parc','parc');
    dashboardFlashShortcutHelp();
  }
  if(!typing && event.altKey && event.key.toLowerCase()==='a'){
    event.preventDefault();
    showView('affectations','Affectations','affectations');
    dashboardFlashShortcutHelp();
  }
  if(!typing && event.key==='?'){
    dashboardFlashShortcutHelp();
  }
});

/* ---------- Final refresh ---------- */
setTimeout(()=>{
  dashboardRefreshNotifications();
  dashboardRenderQuality();
  dashboardRefreshBackupList();
},700);


/* ===== MENU LATÉRAL RÉDUCTIBLE ===== */
const SIDEBAR_COLLAPSED_KEY='hessers-sidebar-collapsed-v1';
const appShell=document.querySelector('.app');
const sidebarCollapseButton=document.getElementById('sidebarCollapseButton');
const sidebarCollapseLabel=document.getElementById('sidebarCollapseLabel');
const sidebarHamburger=document.getElementById('sidebarHamburger');


sidebarCollapseButton?.addEventListener('click',dashboardToggleSidebar);

dashboardSetSidebarCollapsed(
  localStorage.getItem(SIDEBAR_COLLAPSED_KEY)==='1',
  false
);


/* ===== MISE À JOUR DU DASHBOARD DEPUIS ADMIN ===== */
const DASHBOARD_ROOT_DB='hessers-dashboard-root-v1';
const DASHBOARD_ROOT_STORE='handles';
const DASHBOARD_ROOT_HANDLE_KEY='dashboard-root-folder';
const DASHBOARD_HTML_BACKUP_FOLDER='Sauvegardes_dashboard';
const DASHBOARD_UPDATE_META_FILE='dashboard_update.json';
const DASHBOARD_FIXED_HTML_NAME='Dashboard.html';
const DASHBOARD_UPDATE_POLL_MS=15000;
const DASHBOARD_LOADED_AT=Date.now();

let dashboardRootHandle=null;
let dashboardRootAuthorized=false;
let dashboardUpdatePollTimer=null;
let dashboardUpdateLastSeenStamp=0;

const dashboardAuthorizeRootButton=document.getElementById('dashboardAuthorizeRoot');
const dashboardUpdateButton=document.getElementById('dashboardUpdateButton');
const dashboardRestorePreviousButton=document.getElementById('dashboardRestorePrevious');
const dashboardUpdateRootChip=document.getElementById('dashboardUpdateRootChip');
const dashboardUpdateCurrentFileChip=document.getElementById('dashboardUpdateCurrentFileChip');
const dashboardUpdateBackupCount=document.getElementById('dashboardUpdateBackupCount');

const dashboardUpdateModal=document.getElementById('dashboardUpdateModal');
const dashboardUpdateModalClose=document.getElementById('dashboardUpdateModalClose');
const dashboardUpdateModalCancel=document.getElementById('dashboardUpdateModalCancel');
const dashboardUpdateSelectFile=document.getElementById('dashboardUpdateSelectFile');

const dashboardVersionBanner=document.getElementById('dashboardVersionBanner');
const dashboardVersionLater=document.getElementById('dashboardVersionLater');
const dashboardVersionReload=document.getElementById('dashboardVersionReload');


dashboardAuthorizeRootButton?.addEventListener('click',()=>dashboardAuthorizeRoot(Boolean(dashboardRootAuthorized)));
dashboardUpdateButton?.addEventListener('click',async()=>{
  if(typeof adminSecurityIsUnlocked==='function' && !adminSecurityIsUnlocked()){
    const allowed=await adminSecurityRequestAccess();
    if(!allowed) return;
  }

  if(!dashboardRootAuthorized){
    dashboardToast('Dossier à autoriser','Clique d’abord sur « Autoriser le dossier » dans la section mise à jour.','warn',5000);
    return;
  }

  dashboardOpenUpdateModal();
});
dashboardRestorePreviousButton?.addEventListener('click',dashboardRestorePreviousHtml);

dashboardUpdateModalClose?.addEventListener('click',dashboardCloseUpdateModal);
dashboardUpdateModalCancel?.addEventListener('click',dashboardCloseUpdateModal);
dashboardUpdateModal?.addEventListener('click',event=>{
  if(event.target===dashboardUpdateModal) dashboardCloseUpdateModal();
});
dashboardUpdateSelectFile?.addEventListener('click',dashboardPickUpdateFile);

dashboardVersionReload?.addEventListener('click',()=>{ location.href=dashboardFixedHtmlUrl(); });
dashboardVersionLater?.addEventListener('click',()=>dashboardVersionBanner.hidden=true);

(async()=>{
  dashboardUpdateCurrentFileChip.textContent='Fichier : '+dashboardCurrentHtmlFilename();

  const saved=await dashboardLoadRootHandle();
  if(saved){
    dashboardRootHandle=saved;
    dashboardRootAuthorized=await dashboardRootHasPermission(saved,false);
  }

  await dashboardRefreshUpdateUi();

  if(dashboardRootAuthorized){
    try{
      const meta=await dashboardReadUpdateMeta();
      dashboardUpdateLastSeenStamp=Number(meta?.updatedAtMs)||0;
    }catch(error){}

    dashboardUpdatePollTimer=setInterval(
      dashboardCheckForNewHtmlVersion,
      DASHBOARD_UPDATE_POLL_MS
    );
  }
})();


/* ===== DARK / WHITE MODE ===== */
const THEME_STORAGE_KEY='hessers-dashboard-theme-v1';
const themeSwitch=document.getElementById('themeSwitch');


let savedDashboardTheme='dark';
try{
  savedDashboardTheme=localStorage.getItem(THEME_STORAGE_KEY)||'dark';
}catch(error){
  savedDashboardTheme='dark';
}

applyDashboardTheme(savedDashboardTheme==='white'?'white':'dark');

themeSwitch.addEventListener('click',()=>{
  applyDashboardTheme(
    document.body.classList.contains('white-mode')?'dark':'white'
  );
});
