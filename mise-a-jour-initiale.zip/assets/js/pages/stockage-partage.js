function sharedDeepClone(value){
  return value === undefined ? undefined : JSON.parse(JSON.stringify(value));
}

function sharedFormatTime(date){
  if(!date) return '—';
  return new Intl.DateTimeFormat('fr-FR',{hour:'2-digit',minute:'2-digit',second:'2-digit'}).format(date);
}

function sharedSetUiState(mode,message){
  sharedStorageButton.classList.remove('connected','syncing','error');
  sharedStorageHeroDot.className='shared-storage-hero-dot';
  closeSharedStorageModal.hidden=!sharedConnected;

  if(mode==='connected'){
    sharedStorageButton.classList.add('connected');
    sharedStorageHeroDot.classList.add('connected');
    sharedStorageButton.title='Stockage partagé connecté';
    sharedStorageLabel.textContent='Partagé';
    sharedStorageState.textContent='Stockage partagé actif';
    sharedStorageFolder.textContent='Dossier '+(sharedDirectoryHandle?.name || 'data')+' connecté automatiquement.';
    sharedStorageMessage.className='shared-storage-message ok';
    sharedStorageMessage.innerHTML=message || 'Les données sont partagées entre les utilisateurs du Groupdrive.';
    connectSharedStorageButton.hidden=true;
    syncSharedStorageButton.hidden=false;
    syncSharedStorageButton.disabled=false;
    disconnectSharedStorageButton.hidden=false;
    disconnectSharedStorageButton.disabled=false;
    disconnectSharedStorageButton.textContent='Changer de dossier';
  }else if(mode==='syncing'){
    sharedStorageButton.classList.add('syncing');
    sharedStorageButton.title='Synchronisation en cours';
    sharedStorageLabel.textContent='Synchro…';
    sharedStorageState.textContent='Synchronisation…';
    sharedStorageFolder.textContent='Mise à jour des données partagées.';
    sharedStorageMessage.className='shared-storage-message warn';
    sharedStorageMessage.innerHTML=message || 'Synchronisation avec le Groupdrive…';
  }else if(mode==='error'){
    sharedStorageButton.classList.add('error');
    sharedStorageHeroDot.classList.add('error');
    sharedStorageButton.title='Erreur du stockage partagé';
    sharedStorageLabel.textContent='Erreur';
    sharedStorageState.textContent='Connexion impossible';
    sharedStorageFolder.textContent=sharedDirectoryHandle?.name
      ? 'Dossier '+sharedDirectoryHandle.name
      : 'Dossier data non connecté';
    sharedStorageMessage.className='shared-storage-message error';
    sharedStorageMessage.innerHTML=message || 'Impossible d’accéder au stockage partagé.';
    connectSharedStorageButton.hidden=false;
    connectSharedStorageButton.textContent=sharedDirectoryHandle
      ? 'Réessayer l’autorisation'
      : 'Activer le stockage partagé';
    syncSharedStorageButton.hidden=true;
    disconnectSharedStorageButton.hidden=true;
    setTimeout(()=>{ if(!sharedConnected) openSharedStorageModal(); },120);
  }else{
    sharedStorageButton.title='Stockage partagé à activer';
    sharedStorageLabel.textContent='À activer';
    sharedStorageState.textContent=sharedDirectoryHandle ? 'Autorisation requise' : 'À activer';
    sharedStorageFolder.textContent=sharedDirectoryHandle
      ? 'Le dossier '+sharedDirectoryHandle.name+' est déjà mémorisé.'
      : 'Sélectionne une fois le dossier Dashboard ou Data du Groupdrive.';
    sharedStorageMessage.className='shared-storage-message warn';
    sharedStorageMessage.innerHTML=message || (
      sharedDirectoryHandle
        ? 'Clique sur <b>Autoriser</b>. Tu n’auras normalement pas à rechercher le dossier de nouveau.'
        : 'Première utilisation uniquement : sélectionne le dossier <b>Dashboard</b> ou <b>Data</b> du Groupdrive.'
    );
    connectSharedStorageButton.hidden=false;
    connectSharedStorageButton.textContent=sharedDirectoryHandle
      ? 'Autoriser'
      : 'Activer le stockage partagé';
    syncSharedStorageButton.hidden=true;
    disconnectSharedStorageButton.hidden=true;
    setTimeout(()=>{ if(!sharedConnected) openSharedStorageModal(); },120);
  }

  sharedStorageLastSync.textContent=sharedFormatTime(sharedLastSyncAt);
  sharedStorageFileCount.textContent=`${sharedFilesReady} / ${SHARED_DATASETS.length}`;
}

async function sharedHasPermission(handle,request=false){
  if(!handle) return false;
  const options={mode:'readwrite'};
  try{
    if(await handle.queryPermission(options)==='granted') return true;
    if(request && await handle.requestPermission(options)==='granted') return true;
  }catch(error){
    console.warn('Vérification permission Groupdrive impossible.',error);
  }
  return false;
}

async function sharedReadDocument(descriptor){
  if(!sharedDirectoryHandle) return null;
  try{
    const fileHandle=await sharedDirectoryHandle.getFileHandle(descriptor.file);
    const file=await fileHandle.getFile();
    const raw=await file.text();
    const doc=JSON.parse(raw);
    if(doc && Object.prototype.hasOwnProperty.call(doc,'data')){
      return {
        ...doc,
        _lastModified:file.lastModified
      };
    }
    return {
      version:1,
      updatedAt:new Date(file.lastModified).toISOString(),
      updatedBy:'ancien-format',
      data:doc,
      _lastModified:file.lastModified
    };
  }catch(error){
    if(error?.name==='NotFoundError') return null;
    throw error;
  }
}

async function sharedWriteDocument(descriptor,data){
  if(!sharedDirectoryHandle) throw new Error('Dossier Groupdrive non connecté.');

  const fileHandle=await sharedDirectoryHandle.getFileHandle(descriptor.file,{create:true});
  const writable=await fileHandle.createWritable();
  const doc={
    version:1,
    updatedAt:new Date().toISOString(),
    updatedBy:dashboardUser || sharedClientId,
    data
  };
  await writable.write(JSON.stringify(doc,null,2));
  await writable.close();

  const file=await fileHandle.getFile();
  const signature=`${file.lastModified}|${doc.updatedAt}|${doc.updatedBy}`;
  sharedRemoteSignatureByKey.set(descriptor.key,signature);
  sharedLastSyncAt=new Date();
  return doc;
}

function sharedCurrentData(key){
  if(key===PARK_STORAGE_KEY) return sharedDeepClone(parkData);
  if(key===AFFECT_STORAGE_KEY) return sharedDeepClone(affectations);
  if(key===DRIVER_STORAGE_KEY) return sharedDeepClone(driverProfiles);
  if(key===CLAIM_STORAGE_KEY) return sharedDeepClone(claimData);
  if(key===CLAIM_EVENTS_KEY) return sharedDeepClone(claimEventsData);
  if(key===VIDANGE_STORAGE_KEY) return sharedDeepClone(vidangeData);
  if(key===TECH_DEADLINE_STORAGE_KEY) return sharedDeepClone(technicalDeadlines);
  if(key===ADMIN_FINE_KEY) return sharedDeepClone(adminFines);
  if(key===ADMIN_RUNGIS_KEY) return sharedDeepClone(adminRungis);
  if(key===ADMIN_SITES_KEY) return sharedDeepClone(adminSites);
  if(key===FUEL_STORAGE_KEY) return sharedDeepClone(fuelEntries);
  return null;
}

function sharedWriteLocalCache(key,data){
  try{
    sharedSuppressLocalHook=true;
    SHARED_ORIGINAL_SET_ITEM.call(localStorage,key,JSON.stringify(data));
  }catch(error){
    console.warn('Impossible de mettre à jour le cache local.',error);
  }finally{
    sharedSuppressLocalHook=false;
  }
  sharedLastLocalByKey.set(key,sharedDeepClone(data));
}

function sharedRefreshUiForKey(key){
  try{
    if(key===PARK_STORAGE_KEY){
      renderParkTable();
      renderAffectations();
    }
    if(key===AFFECT_STORAGE_KEY){
      renderAffectations();
      renderParkTable();
    }
    if(key===DRIVER_STORAGE_KEY){
      if(selectedDriverId && !driverProfiles.some(item=>item.id===selectedDriverId)) selectedDriverId=null;
      renderDriverList();
      fillDriverForm();
    }
    if(key===CLAIM_STORAGE_KEY){
      if(selectedClaimId && !claimData.some(item=>item.id===selectedClaimId)) selectedClaimId=null;
      renderClaims();
      loadClaimDetail();
      renderClaimTimeline();
      renderClaimAttachments();
    }
    if(key===CLAIM_EVENTS_KEY){
      renderClaimEvents();
    }
    if(key===VIDANGE_STORAGE_KEY){
      if(selectedVidangeId && !vidangeData.some(item=>item.id===selectedVidangeId)) selectedVidangeId=null;
      renderVidTable();
      loadVidDetail();
    }
    if(key===TECH_DEADLINE_STORAGE_KEY && typeof window.technicalRefreshAll==='function') window.technicalRefreshAll();
    if(key===ADMIN_FINE_KEY) renderFines();
    if(key===ADMIN_RUNGIS_KEY) renderRungis();
    if(key===ADMIN_SITES_KEY) renderAdminSites();
    if(key===FUEL_STORAGE_KEY){
      renderFuelTable();
      renderFuelCharts();
    }
    refreshHomeDashboard();
  }catch(error){
    console.warn('Rafraîchissement interface après synchro impossible.',key,error);
  }
}

function sharedApplyData(key,data,refresh=true){
  const cloned=sharedDeepClone(data);

  if(key===PARK_STORAGE_KEY && Array.isArray(cloned)) parkData=cloned;
  else if(key===AFFECT_STORAGE_KEY && Array.isArray(cloned)) affectations=cloned;
  else if(key===DRIVER_STORAGE_KEY && Array.isArray(cloned)){
    let driverMigrationNeeded=false;
    driverProfiles=cloned.map(driver=>{
      const next={...driver};
      if(typeof next.birthPostalCode!=='string'){
        next.birthPostalCode='';
        driverMigrationNeeded=true;
      }
      const normalizedStatus=normalizeDriverStatus(next.status);
      if(next.status!==normalizedStatus){
        next.status=normalizedStatus;
        driverMigrationNeeded=true;
      }
      return next;
    });
    if(driverMigrationNeeded){
      setTimeout(()=>saveDriverProfiles(),0);
    }
  }
  else if(key===CLAIM_STORAGE_KEY && Array.isArray(cloned)) claimData=cloned;
  else if(key===CLAIM_EVENTS_KEY && Array.isArray(cloned)) claimEventsData=cloned.slice(0,30);
  else if(key===VIDANGE_STORAGE_KEY && Array.isArray(cloned)) vidangeData=cloned;
  else if(key===TECH_DEADLINE_STORAGE_KEY && Array.isArray(cloned)) technicalDeadlines=cloned.filter(item=>item.category!=='hayon');
  else if(key===ADMIN_FINE_KEY && Array.isArray(cloned)) adminFines=cloned;
  else if(key===ADMIN_RUNGIS_KEY && Array.isArray(cloned)) adminRungis=cloned;
  else if(key===ADMIN_SITES_KEY && cloned && typeof cloned==='object'){
    adminSites={dkv:'',ids:'',lumesia:'',...cloned};
    if(!adminSites.ids && cloned.ils) adminSites.ids=cloned.ils;
    delete adminSites.ils;
  }
  else if(key===FUEL_STORAGE_KEY && Array.isArray(cloned)) fuelEntries=cloned;
  else return;

  sharedWriteLocalCache(key,sharedCurrentData(key));
  if(refresh) sharedRefreshUiForKey(key);
}

function sharedRecordMap(descriptor,array){
  const map=new Map();
  (Array.isArray(array)?array:[]).forEach((item,index)=>{
    const id=descriptor.id?.(item);
    const safeId=id || `__index_${index}`;
    map.set(String(safeId),item);
  });
  return map;
}

function sharedMergeDelta(descriptor,previous,next,remote){
  if(descriptor.kind==='object'){
    const prev=previous && typeof previous==='object' ? previous : {};
    const after=next && typeof next==='object' ? next : {};
    const latest=remote && typeof remote==='object' ? {...remote} : {};

    const keys=new Set([...Object.keys(prev),...Object.keys(after)]);
    let objectChanged=false;
    keys.forEach(key=>{
      if(!(key in after)){
        if(key in prev){
          delete latest[key];
          objectChanged=true;
        }
      }else if(JSON.stringify(prev[key])!==JSON.stringify(after[key])){
        latest[key]=sharedDeepClone(after[key]);
        objectChanged=true;
      }
    });
    if(objectChanged){
      latest._modifiedBy=dashboardUser || sharedClientId;
      latest._modifiedAt=new Date().toISOString();
    }
    return latest;
  }

  const prevArray=Array.isArray(previous)?previous:[];
  const nextArray=Array.isArray(next)?next:[];
  const remoteArray=Array.isArray(remote)?remote:[];

  const prevMap=sharedRecordMap(descriptor,prevArray);
  const nextMap=sharedRecordMap(descriptor,nextArray);
  const remoteMap=sharedRecordMap(descriptor,remoteArray);

  // suppressions locales
  for(const id of prevMap.keys()){
    if(!nextMap.has(id)) remoteMap.delete(id);
  }

  // ajouts / modifications locales
  for(const [id,item] of nextMap.entries()){
    const before=prevMap.get(id);
    if(!prevMap.has(id) || JSON.stringify(before)!==JSON.stringify(item)){
      const stamped=sharedDeepClone(item);
      const now=new Date().toISOString();

      if(stamped && typeof stamped==='object'){
        stamped._modifiedBy=dashboardUser || sharedClientId;
        stamped._modifiedAt=now;

        if(!prevMap.has(id)){
          stamped._createdBy=stamped._createdBy || dashboardUser || sharedClientId;
          stamped._createdAt=stamped._createdAt || now;
        }else if(before && typeof before==='object'){
          stamped._createdBy=stamped._createdBy || before._createdBy;
          stamped._createdAt=stamped._createdAt || before._createdAt;
        }
      }

      remoteMap.set(id,stamped);
    }
  }

  // On conserve l'ordre distant autant que possible, puis les nouveaux éléments.
  const result=[];
  const used=new Set();

  for(const item of remoteArray){
    const id=String(descriptor.id?.(item)||'');
    if(!id || used.has(id) || !remoteMap.has(id)) continue;
    result.push(remoteMap.get(id));
    used.add(id);
  }

  for(const [id,item] of remoteMap.entries()){
    if(!used.has(id)){
      result.push(item);
      used.add(id);
    }
  }

  return result;
}

async function sharedQueueSave(key,previous,next){
  const descriptor=SHARED_DESCRIPTOR_BY_KEY.get(key);
  if(!descriptor || !sharedConnected) return;

  const oldQueue=sharedWriteQueues.get(key)||Promise.resolve();

  const newQueue=oldQueue.then(async()=>{
    sharedSetUiState('syncing','Enregistrement des modifications dans le Groupdrive…');

    try{
      await dashboardEnsureDailyBackup().catch(error=>console.warn('Sauvegarde quotidienne indisponible.',error));

      const remoteDoc=await sharedReadDocument(descriptor);
      const remoteData=remoteDoc ? remoteDoc.data : previous;

      const conflict=dashboardDetectSharedConflict(descriptor,previous,next,remoteData);
      if(conflict){
        const keepLocal=await dashboardAskSharedConflict(descriptor,conflict,remoteDoc);
        if(!keepLocal){
          sharedApplyData(key,remoteData,true);
          sharedLastLocalByKey.set(key,sharedDeepClone(remoteData));
          sharedSetUiState('connected','Version partagée rechargée.');
          dashboardToast('Version partagée rechargée','Votre modification locale a été abandonnée.','warn');
          return;
        }

        administratorWriteHistory({
          action:'Conflit',
          section:administratorSectionLabel(descriptor),
          entity:conflict.labels.join(', '),
          detail:'Version locale conservée après conflit multi-utilisateurs'
        });
      }

      const merged=sharedMergeDelta(descriptor,previous,next,remoteData);

      await sharedWriteDocument(descriptor,merged);

      // Journal administrateur : uniquement l'action locale qui vient d'être validée.
      administratorLogDatasetChanges(descriptor,previous,next).catch(error=>
        console.warn('Journalisation de la modification impossible.',error)
      );

      // On ne réinjecte le résultat fusionné dans l'interface que si aucune
      // sauvegarde plus récente du même jeu de données n'a déjà été demandée.
      // Cela évite qu'une écriture réseau un peu lente fasse revenir l'écran
      // à l'état précédent pendant que l'utilisateur continue de modifier.
      const currentLocal=sharedLastLocalByKey.get(key);
      if(JSON.stringify(currentLocal)===JSON.stringify(next)){
        sharedApplyData(key,merged,false);
        sharedLastLocalByKey.set(key,sharedDeepClone(merged));
      }

      sharedSetUiState('connected','Modifications enregistrées dans le Groupdrive.');
      dashboardToastSharedSave();
      dashboardRefreshNotifications();
    }catch(error){
      console.error('Échec sauvegarde Groupdrive.',key,error);
      sharedSetUiState(
        'error',
        'La modification reste visible sur ce poste, mais son enregistrement dans le Groupdrive a échoué.<br><b>'+String(error)+'</b>'
      );
    }
  }).finally(()=>{
    if(sharedWriteQueues.get(key)===newQueue){
      sharedWriteQueues.delete(key);
    }
  });

  sharedWriteQueues.set(key,newQueue);
}

function sharedUserIsEditing(){
  if(document.querySelector('.modal-overlay:not([hidden])')) return true;

  const active=document.activeElement;
  if(!active) return false;

  if(active.matches('textarea,select,[contenteditable="true"]')) return true;

  if(active.matches('input')){
    const type=(active.getAttribute('type')||'text').toLowerCase();
    return type!=='search';
  }

  return false;
}

async function sharedSyncFromDisk(force=false){
  if(!sharedConnected || !sharedDirectoryHandle) return;

  try{
    if(!(await sharedHasPermission(sharedDirectoryHandle,false))){
      sharedConnected=false;
      sharedSetUiState('local','Edge doit de nouveau autoriser l’accès au dossier <b>data</b>.');
      return;
    }

    const editing=sharedUserIsEditing();

    for(const descriptor of SHARED_DATASETS){
      if(sharedWriteQueues.has(descriptor.key)) continue;

      const doc=await sharedReadDocument(descriptor);
      if(!doc) continue;

      const signature=`${doc._lastModified||0}|${doc.updatedAt||''}|${doc.updatedBy||''}`;
      const previousSignature=sharedRemoteSignatureByKey.get(descriptor.key);

      if(force || (previousSignature && signature!==previousSignature)){
        if(editing && !force){
          sharedPendingRemote.set(descriptor.key,{doc,signature});
          continue;
        }
        sharedApplyData(descriptor.key,doc.data,true);
      }

      sharedRemoteSignatureByKey.set(descriptor.key,signature);
    }

    if(!editing && sharedPendingRemote.size){
      for(const [key,pending] of sharedPendingRemote.entries()){
        sharedApplyData(key,pending.doc.data,true);
        sharedRemoteSignatureByKey.set(key,pending.signature);
      }
      sharedPendingRemote.clear();
    }

    sharedLastSyncAt=new Date();
    sharedSetUiState(
      'connected',
      sharedPendingRemote.size
        ? 'Une mise à jour distante est en attente pendant ta saisie.'
        : 'Les données sont synchronisées avec le Groupdrive.'
    );
    dashboardRefreshNotifications();
    if(document.querySelector('.view.active')?.id==='administrateur'){
      dashboardRenderQuality();
      dashboardRefreshBackupList();
    }
  }catch(error){
    console.error('Synchronisation Groupdrive impossible.',error);
    sharedSetUiState('error','Impossible de lire le Groupdrive.<br><b>'+String(error)+'</b>');
  }
}

async function sharedInitializeFiles(){
  sharedFilesReady=0;
  sharedSetUiState('syncing','Initialisation des fichiers partagés…');

  for(const descriptor of SHARED_DATASETS){
    let doc=await sharedReadDocument(descriptor);

    if(!doc){
      const current=sharedCurrentData(descriptor.key);
      await sharedWriteDocument(descriptor,current);
      doc=await sharedReadDocument(descriptor);
    }else{
      sharedApplyData(descriptor.key,doc.data,false);
    }

    if(doc){
      const signature=`${doc._lastModified||0}|${doc.updatedAt||''}|${doc.updatedBy||''}`;
      sharedRemoteSignatureByKey.set(descriptor.key,signature);
      sharedLastLocalByKey.set(descriptor.key,sharedCurrentData(descriptor.key));
      sharedFilesReady++;
      sharedSetUiState('syncing','Préparation des données partagées…');
    }
  }

  // Une seule remise à jour globale après le chargement des 10 fichiers.
  renderParkTable();
  renderAffectations();
  renderDriverList();
  fillDriverForm();
  renderClaims();
  loadClaimDetail();
  renderClaimEvents();
  renderClaimTimeline();
  renderClaimAttachments();
  renderVidTable();
  loadVidDetail();
  renderFines();
  renderRungis();
  renderAdminSites();
  renderFuelTable();
  renderFuelCharts();
  refreshHomeDashboard();

  sharedLastSyncAt=new Date();
}

async function sharedFindDataDirectory(handle){
  try{
    await handle.getFileHandle('parc.json');
    return handle;
  }catch(error){
    if(error?.name!=='NotFoundError') throw error;
  }

  for(const folderName of ['Data','data']){
    try{
      const dataHandle=await handle.getDirectoryHandle(folderName);
      await dataHandle.getFileHandle('parc.json');
      return dataHandle;
    }catch(error){
      if(error?.name!=='NotFoundError') throw error;
    }
  }

  return null;
}

async function sharedConnect(handle,{requestPermission=false}={}){
  if(!handle) return false;

  sharedDirectoryHandle=handle;
  sharedSetUiState('syncing','Vérification de l’accès au dossier…');

  const allowed=await sharedHasPermission(handle,requestPermission);
  if(!allowed){
    sharedConnected=false;
    sharedSetUiState(
      'local',
      'Le dossier <b>'+String(handle.name||'data')+'</b> est mémorisé, mais Edge attend ton autorisation.'
    );
    return false;
  }

  try{
    const dataHandle=await sharedFindDataDirectory(handle);
    if(!dataHandle){
      throw new Error('Le dossier sélectionné ne contient pas le dossier Data ni le fichier parc.json.');
    }
    sharedDirectoryHandle=dataHandle;

    // Test lecture/écriture réel
    const testHandle=await sharedDirectoryHandle.getFileHandle('.dashboard-access-test.json',{create:true});
    const writable=await testHandle.createWritable();
    await writable.write(JSON.stringify({checkedAt:new Date().toISOString(),user:dashboardUser || sharedClientId}));
    await writable.close();

    sharedConnected=true;
    await saveSharedDirectoryHandle(handle);
    await sharedInitializeFiles();
    await dashboardEnsureDailyBackup().catch(error=>console.warn('Sauvegarde automatique indisponible.',error));
    await administratorStartPresence(false);
    dashboardRefreshNotifications();

    if(sharedPollTimer) clearInterval(sharedPollTimer);
    sharedPollTimer=setInterval(()=>sharedSyncFromDisk(false),SHARED_POLL_MS);

    sharedSetUiState(
      'connected',
      'Connexion réussie. Les données sont maintenant partagées automatiquement.'
    );
    if(!sharedStorageModal.hidden){
      setTimeout(closeSharedStorageDialog,550);
    }
    return true;
  }catch(error){
    sharedConnected=false;
    sharedSetUiState(
      'error',
      'Le dossier a été sélectionné mais l’accès lecture/écriture a échoué.<br><b>'+String(error)+'</b>'
    );
    return false;
  }
}

async function sharedChooseDirectory(){
  if(window.__dashboardSharedPickerActive) return;
  window.__dashboardSharedPickerActive=true;

  if(typeof window.showDirectoryPicker!=='function'){
    sharedSetUiState(
      'error',
      'Cette version d’Edge ne fournit pas l’API nécessaire pour accéder au dossier partagé.'
    );
    window.__dashboardSharedPickerActive=false;
    return;
  }

  try{
    // Si un handle est déjà mémorisé, on tente d'abord de réautoriser celui-ci.
    if(sharedDirectoryHandle && !sharedConnected){
      const reconnected=await sharedConnect(sharedDirectoryHandle,{requestPermission:true});
      if(reconnected) return;
    }

    const handle=await window.showDirectoryPicker({mode:'readwrite'});
    await sharedConnect(handle,{requestPermission:true});
  }catch(error){
    if(error?.name==='AbortError') return;
    sharedSetUiState('error','Connexion au dossier impossible.<br><b>'+String(error)+'</b>');
  }finally{
    window.__dashboardSharedPickerActive=false;
  }
}

async function sharedDisconnect(){
  await administratorStopPresence(true);

  if(sharedPollTimer){
    clearInterval(sharedPollTimer);
    sharedPollTimer=null;
  }

  await Promise.allSettled([...sharedWriteQueues.values()]);
  sharedWriteQueues.clear();
  sharedPendingRemote.clear();

  sharedConnected=false;
  sharedDirectoryHandle=null;
  sharedFilesReady=0;
  sharedRemoteSignatureByKey.clear();
  sharedLastLocalByKey.clear();
  await forgetSharedDirectoryHandle();

  sharedSetUiState(
    'local',
    'Ce navigateur est déconnecté du Groupdrive. Le dashboard utilise temporairement son cache local.'
  );
}

function sharedSafeFilePart(value){
  return String(value||'')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g,'')
    .replace(/[<>:"/\\|?*\x00-\x1F]/g,'_')
    .replace(/\s+/g,' ')
    .trim()
    .slice(0,120) || 'fichier';
}

async function sharedClaimFilesDirectory(create=false){
  if(!sharedConnected || !sharedDirectoryHandle) return null;
  return await sharedDirectoryHandle.getDirectoryHandle(
    SHARED_CLAIM_FILES_FOLDER,
    {create}
  );
}
