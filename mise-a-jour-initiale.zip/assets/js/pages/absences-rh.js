/* Scan data stays in memory; only reviewed parking cell references are exported. */
(()=>{
  'use strict';
  const normal = value => String(value || '').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toUpperCase().replace(/[^A-Z0-9]+/g,' ').trim();
  function candidates(name, entries) {
    const n=normal(name);
    return entries.filter(e=>n===normal(e.name)||n.startsWith(normal(e.name)+' '));
  }
  function wordsFromTSV(tsv) {
    return tsv.split(/\r?\n/).slice(1).map(line=>line.split('\t')).filter(c=>c[0]==='5'&&c.slice(11).join('\t').trim()).map(c=>({
      text:c.slice(11).join('\t').trim(), x:+c[6], y:+c[7], w:+c[8], h:+c[9], confidence:+c[10], line:c.slice(1,5).join('-')
    }));
  }
  function nameLines(words) {
    const groups=new Map();
    for(const word of words) { if(!groups.has(word.line))groups.set(word.line,[]); groups.get(word.line).push(word); }
    return [...groups.values()].map(ws=>({name:ws.map(w=>w.text).join(' ').replace(/^[|\[\] ]+/,''), y:Math.min(...ws.map(w=>w.y)), bottom:Math.max(...ws.map(w=>w.y+w.h))}))
      .filter(r=>/[a-zA-ZÀ-ÿ]{3}/.test(r.name)&&! /^(total|commentaires|régionaux|regionaux|septembre|semaine)\b/i.test(r.name)).sort((a,b)=>a.y-b.y);
  }
  if(typeof module!=='undefined')module.exports={normal,candidates,wordsFromTSV,nameLines};
  if(typeof document==='undefined')return;
  const page=document.createElement('section'); page.id='absences-rh'; page.className='view';
  page.innerHTML=`<h1>Absences RH</h1>
    <div class="rh-controls">
      <label>Scan couleur (JPG / PNG)<input id="rh-image" type="file" accept="image/jpeg,image/png"></label>
      <label>Fichier parking<input id="rh-parking" type="file" accept=".xls,.xlsx"></label>
      <label>Semaine à appliquer<input id="rh-week" type="week" required></label>
    </div>
    <div class="rh-note">Lecture sur cet ordinateur. Internet est nécessaire au chargement du moteur de reconnaissance. Aucun scan RH n'est envoyé.</div>
    <div id="rh-status" class="rh-status" role="status" aria-live="polite">Importez le scan et le fichier parking.</div>
    <div class="rh-layout">
      <div><div class="rh-controls"><label>Zone à encadrer<select id="rh-zone"><option value="names">Noms des chauffeurs</option><option value="week">Colonne de la semaine choisie</option></select></label><button id="rh-rotate" type="button">Tourner de 90°</button></div>
        <div class="rh-note">Encadrez les noms, puis les cases de la semaine, sans les en-têtes ni les totaux. Pour les régionaux, faites une deuxième lecture avant d'exporter.</div>
        <canvas id="rh-scan" class="rh-scan" width="600" height="100" aria-label="Scan : tracer les deux zones de lecture"></canvas>
        <div class="rh-controls"><button id="rh-read" class="rh-primary" disabled>Lire les zones</button><button id="rh-cancel" hidden>Annuler la lecture</button></div>
      </div>
      <div><h2>Vérification</h2><div class="rh-note">Un « 1 » ou une couleur propose une absence. Vérifiez chaque ligne : une couleur seule ne suffit pas à confirmer.</div>
        <div class="rh-table"><table><thead><tr><th>Lecture du scan</th><th>Nom dans le parking</th><th>Cette semaine</th></tr></thead><tbody id="rh-rows"></tbody></table></div>
        <button id="rh-add" type="button">Ajouter une ligne oubliée</button>
        <label class="rh-check"><input type="checkbox" id="rh-confirm">J'ai vérifié les noms, les absences et la semaine sur le scan.</label>
        <button id="rh-export" class="rh-primary" disabled>Exporter les repères pour Excel</button>
        <div class="rh-note">L'export ne modifie pas le classeur. L'outil Excel fourni crée une copie avec de petits carrés rouges, sans changer les noms ni les plaques.</div>
        <a href="assets/maintenance/Absences-RH-mode-emploi.txt" download>Mode d'emploi Excel</a>
      </div>
    </div>`;
  document.querySelector('.view').parentElement.append(page);
  const nav=document.createElement('button'); nav.className='nav-btn'; nav.dataset.view='absences-rh';
  nav.innerHTML='<span class="nav-ico" aria-hidden="true">□</span><span>Absences RH</span>';
  const driverNav=document.querySelector('.nav-btn[data-view="chauffeurs"]');
  (driverNav || document.querySelector('.nav-btn')).after(nav);
  const $=id=>document.getElementById('rh-'+id);
  const canvas=$('scan'), ctx=canvas.getContext('2d');
  let source=null, entries=[], rows=[], zones={}, start=null, worker=null, busy=false, generation=0;
  const scriptLoads={};
  const loadScript=src=>scriptLoads[src]||(scriptLoads[src]=new Promise((resolve,reject)=>{
    const s=document.createElement('script');s.src=src;s.onload=resolve;s.onerror=()=>{delete scriptLoads[src];reject(Error('Impossible de charger '+src));};document.head.append(s);
  }));
  function status(s) {$('status').textContent=s;}
  function invalidate() {$('confirm').checked=false; controls();}
  function controls() {
    $('read').disabled=busy||!source||!entries.length||!zones.names||!zones.week;
    $('export').disabled=busy||!rows.length||!$('week').value||!$('confirm').checked||rows.some(r=>r.state!=='ignore'&&(!r.target||r.state==='review'));
    for(const id of ['image','parking','rotate','add','week'])$(id).disabled=busy;
    $('cancel').hidden=!busy;
  }
  function paint() {
    ctx.clearRect(0,0,canvas.width,canvas.height);if(!source)return;
    ctx.drawImage(source,0,0);
    for(const [key,r] of Object.entries(zones)) {ctx.strokeStyle=key==='names'?'#0086d9':'#e3223e';ctx.lineWidth=Math.max(2,canvas.width/400);ctx.strokeRect(r.x,r.y,r.w,r.h);}
  }
  const point=e=>{const r=canvas.getBoundingClientRect();return{x:Math.max(0,Math.min(canvas.width,(e.clientX-r.left)*canvas.width/r.width)),y:Math.max(0,Math.min(canvas.height,(e.clientY-r.top)*canvas.height/r.height))};};
  canvas.onpointerdown=e=>{if(!source||busy)return;start=point(e);canvas.setPointerCapture(e.pointerId);};
  canvas.onpointermove=e=>{if(!start)return;const p=point(e);zones[$('zone').value]={x:Math.round(Math.min(start.x,p.x)),y:Math.round(Math.min(start.y,p.y)),w:Math.round(Math.abs(start.x-p.x)),h:Math.round(Math.abs(start.y-p.y))};paint();};
  canvas.onpointerup=()=>{if(!start)return;start=null;const r=zones[$('zone').value];if(r&& (r.w<10||r.h<10))delete zones[$('zone').value];paint();controls();};
  canvas.onpointercancel=()=>{start=null;};
  $('image').onchange=async()=>{
    const f=$('image').files[0];if(!f)return;
    if(f.size>25*1024*1024){status('Scan trop volumineux : maximum 25 Mo.');return;}
    if(rows.length&&!confirm('Remplacer le scan et effacer la vérification en cours ?'))return;
    try {const bitmap=await createImageBitmap(f);source=document.createElement('canvas');const scale=Math.min(1,2600/Math.max(bitmap.width,bitmap.height));source.width=Math.round(bitmap.width*scale);source.height=Math.round(bitmap.height*scale);source.getContext('2d').drawImage(bitmap,0,0,source.width,source.height);bitmap.close();canvas.width=source.width;canvas.height=source.height;zones={};rows=[];render();paint();status('Encadrez les noms puis la colonne de la semaine à traiter.');}
    catch(e){status('Image illisible. Utilisez un scan JPG ou PNG.');}invalidate();
  };
  $('rotate').onclick=()=>{if(!source)return;const c=document.createElement('canvas');c.width=source.height;c.height=source.width;const cx=c.getContext('2d');cx.translate(c.width,0);cx.rotate(Math.PI/2);cx.drawImage(source,0,0);source=c;canvas.width=c.width;canvas.height=c.height;zones={};paint();controls();};
  $('parking').onchange=async()=>{
    const f=$('parking').files[0];if(!f)return;
    entries=[]; rows=[];render();controls();
    try {
      if(f.size>20*1024*1024)throw Error('Fichier parking trop volumineux (20 Mo maximum).');
      await loadScript('assets/js/xlsx.full.min.js');
      const wb=XLSX.read(await f.arrayBuffer(),{type:'array'});
      for(const sheet of wb.SheetNames)for(const [address,cell] of Object.entries(wb.Sheets[sheet])) {
        if(address.startsWith('!')||cell.t!=='s'||!String(cell.v).trim())continue;
        const pos=XLSX.utils.decode_cell(address),next=wb.Sheets[sheet][XLSX.utils.encode_cell({r:pos.r,c:pos.c+1})];
        if(!next||! /^[A-Z]{2}[\s-]*\d{3}[\s-]*[A-Z]{2}$/i.test(String(next.v).trim()))continue;
        entries.push({id:sheet+'!'+address,sheet,address,name:String(cell.v)});
      }
      status(entries.length?entries.length+' emplacements chauffeur trouvés dans le parking.':'Aucun nom repéré à gauche des plaques. Vérifiez le modèle du fichier parking.');
    }catch(e){status('Lecture du parking impossible : '+e.message);}invalidate();
  };
  function crop(rect, monochrome=false) {
    const c=document.createElement('canvas');c.width=rect.w;c.height=rect.h;const x=c.getContext('2d');x.drawImage(source,rect.x,rect.y,rect.w,rect.h,0,0,rect.w,rect.h);
    if(monochrome) {const d=x.getImageData(0,0,c.width,c.height);for(let i=0;i<d.data.length;i+=4){const v=Math.max(d.data[i],d.data[i+1],d.data[i+2]);d.data[i]=d.data[i+1]=d.data[i+2]=v;}x.putImageData(d,0,0);}
    if(monochrome){const enlarged=document.createElement('canvas');enlarged.width=c.width*2;enlarged.height=c.height*2;enlarged.getContext('2d').drawImage(c,0,0,enlarged.width,enlarged.height);return enlarged;}
    return c;
  }
  function colorAt(rect) {
    const c=crop(rect),d=c.getContext('2d').getImageData(0,0,c.width,c.height).data;let n=0;
    for(let i=0;i<d.length;i+=4){const max=Math.max(d[i],d[i+1],d[i+2]),min=Math.min(d[i],d[i+1],d[i+2]);if(max-min>55&&max>100)n++;}
    return n/(d.length/4)>.18;
  }
  $('read').onclick=async()=>{
    if($('read').disabled)return;
    busy=true;const token=++generation;controls();let timeout, localWorker;
    try {
      await loadScript('assets/js/tesseract.min.js');
      const operation=(async()=>{
        localWorker=await Tesseract.createWorker('fra',1,{workerPath:'https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/worker.min.js',corePath:'https://cdn.jsdelivr.net/npm/tesseract.js-core@5.1.1',langPath:'https://tessdata.projectnaptha.com/4.0.0',logger:m=>{if(token===generation)status('Lecture du scan : '+Math.round((m.progress||0)*100)+' %');}});
        if(token!==generation){await localWorker.terminate();return;}
        worker=localWorker;
        await localWorker.setParameters({tessedit_pageseg_mode:'6'});
        const names=await localWorker.recognize(crop(zones.names,true),{},{tsv:true});
        if(token!==generation)return;
        await localWorker.setParameters({tessedit_pageseg_mode:'6',tessedit_char_whitelist:'1'});
        const marks=await localWorker.recognize(crop(zones.week,true),{},{tsv:true});
        if(token!==generation)return;
        const scaleWords=tsv=>wordsFromTSV(tsv).map(w=>({...w,x:w.x/2,y:w.y/2,w:w.w/2,h:w.h/2}));
        const detected=nameLines(scaleWords(names.data.tsv)), marksWords=scaleWords(marks.data.tsv);
        for(const r of detected) {
          const y=zones.names.y+(r.y+r.bottom)/2;
          if(y<zones.week.y||y>zones.week.y+zones.week.h)continue;
          const height=Math.max(8,r.bottom-r.y+6);
          const rect={x:zones.week.x+2,y:Math.max(zones.week.y,Math.round(y-height/2)),w:Math.max(1,zones.week.w-4),h:Math.round(height)};
          if(rect.y+rect.h>zones.week.y+zones.week.h)continue;
          const marked=marksWords.some(w=>w.text.includes('1')&&Math.abs(zones.week.y+w.y+w.h/2-y)<height/2);
          const colored=colorAt(rect), matches=candidates(r.name,entries);
          const proof=crop({x:zones.names.x,y:Math.max(0,Math.round(y-height/2)),w:zones.names.w,h:Math.round(height)}).toDataURL();
          rows.push({name:r.name,target:matches.length===1?matches[0].id:'',state:'review',suggestion:marked?'1 détecté':colored?'Case colorée':'Pas de marque détectée',proof,mark:crop(rect).toDataURL()});
        }
        render();invalidate();status(detected.length+' lignes lues. Vérifiez aussi les noms éventuellement oubliés et confirmez chaque statut.');
      })();
      await Promise.race([operation,new Promise((_,reject)=>{timeout=setTimeout(()=>reject(Error('Délai dépassé. Vérifiez Internet, puis réessayez.')),180000);})]);
    }catch(e){if(token===generation)status('Lecture interrompue : '+e.message+' Vous pouvez ajouter les lignes manuellement.');}
    finally{clearTimeout(timeout);if(token===generation){generation++;if(worker){await worker.terminate();worker=null;}busy=false;controls();}}
  };
  $('cancel').onclick=async()=>{generation++;if(worker){await worker.terminate();worker=null;}busy=false;status('Lecture annulée.');controls();};
  function render() {
    $('rows').replaceChildren();
    rows.forEach(r=>{
      const tr=document.createElement('tr'),name=document.createElement('td'),target=document.createElement('td'),state=document.createElement('td');
      const label=document.createElement('div');label.textContent=r.name;name.append(label);
      if(r.proof){const img=document.createElement('img');img.src=r.proof;img.className='rh-proof';img.alt='Nom sur le scan';name.append(img);}
      const select=document.createElement('select');select.setAttribute('aria-label','Chauffeur correspondant à '+r.name);select.add(new Option('Choisir le chauffeur',''));
      for(const e of entries)select.add(new Option(e.name+' · '+e.id,e.id));select.value=r.target;
      select.onchange=()=>{r.target=select.value;invalidate();};target.append(select);
      const s=document.createElement('select');s.setAttribute('aria-label','Absence de '+r.name);
      for(const [value,text] of [['review','À vérifier'],['absent','Absent'],['present','Non marqué absent'],['ignore','Ignorer cette ligne']])s.add(new Option(text,value));s.value=r.state;s.onchange=()=>{r.state=s.value;invalidate();};state.append(s);
      const hint=document.createElement('div');hint.textContent=r.suggestion||'Saisie manuelle';state.append(hint);
      if(r.mark){const img=document.createElement('img');img.src=r.mark;img.className='rh-proof';img.alt='Case de la semaine sur le scan';state.append(img);}
      tr.append(name,target,state);$('rows').append(tr);
    });controls();
  }
  $('add').onclick=()=>{rows.push({name:'Ligne ajoutée',target:'',state:'review'});render();invalidate();};
  $('week').onchange=invalidate;$('confirm').onchange=controls;
  $('export').onclick=()=>{
    if($('export').disabled)return;
    const selected=rows.filter(r=>r.state!=='ignore'), seen=new Set();
    for(const r of selected){if(seen.has(r.target)){status('Le même emplacement parking est sélectionné plusieurs fois. Corrigez ou ignorez le doublon.');return;}seen.add(r.target);}
    if(!selected.length){status('Aucune ligne à exporter.');return;}
    const quote=s=>'"'+String(s).replace(/"/g,'""')+'"';
    const data=[['Semaine','Feuille','Cellule','Nom','Absent'],...selected.map(r=>{const e=entries.find(e=>e.id===r.target);return[$('week').value,e.sheet,e.address,e.name,r.state==='absent'?'1':'0'];})];
    const blob=new Blob(['\uFEFF'+data.map(row=>row.map(quote).join(';')).join('\r\n')],{type:'text/csv;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='Absences-'+$('week').value+'.csv';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
    status('Repères exportés. Lancez Appliquer-absences.ps1 sur le PC avec Excel pour créer la copie du parking.');
  };
})();
