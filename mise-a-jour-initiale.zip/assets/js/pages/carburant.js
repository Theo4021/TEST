function fuelNorm(value){
  return String(value||'')
    .toLocaleLowerCase('fr')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g,'');
}

function fuelEscape(value){
  return String(value??'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function fuelNumber(value){
  if(value===null || value===undefined || value==='') return null;

  const cleaned=String(value)
    .trim()
    .replace(/\s/g,'')
    .replace(',','.');

  const number=Number(cleaned);
  return Number.isFinite(number)?number:null;
}

function fuelFormatPrice(value){
  const number=fuelNumber(value);
  return number===null
    ? '—'
    : number.toLocaleString('fr-FR',{
        minimumFractionDigits:2,
        maximumFractionDigits:2
      })+' €';
}

function fuelFormatQuantity(value){
  const number=fuelNumber(value);
  return number===null
    ? '—'
    : `${number.toLocaleString('fr-FR',{maximumFractionDigits:0})} L`;
}

function fuelFormatDate(value){
  if(!value) return '—';
  const date=new Date(value+'T00:00:00');
  return Number.isNaN(date.getTime())
    ? value
    : date.toLocaleDateString('fr-FR');
}

function fuelChartData(field){
  return [...fuelEntries]
    .filter(item=>fuelNumber(item[field])!==null && (item.deliveryDate||item.orderDate))
    .sort((a,b)=>
      String(a.deliveryDate||a.orderDate)
        .localeCompare(String(b.deliveryDate||b.orderDate))
    )
    .map(item=>({
      date:item.deliveryDate||item.orderDate,
      value:fuelNumber(item[field])
    }));
}
