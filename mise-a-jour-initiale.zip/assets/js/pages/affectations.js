function affectationHasIssue(item){
  return (
    (normalizeRegistration(item.tractor) && !vehicleExistsInPark(item.tractor,'Tracteur')) ||
    (normalizeRegistration(item.semi) && !vehicleExistsInPark(item.semi,'Semi'))
  );
}
