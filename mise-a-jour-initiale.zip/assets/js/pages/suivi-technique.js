function vidStatus(record){
  const next=calculateNextOil(record);
  if(!Number.isFinite(next))return{label:'À renseigner',className:'pending'};
  if(next<=0)return{label:'À faire',className:'late'};
  if(next<=5000)return{label:'À prévoir',className:'soon'};
  return{label:'À jour',className:'ok'};
}

function vidSearchText(value){
  return String(value||'').toLocaleLowerCase('fr').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9]/g,'');
}
