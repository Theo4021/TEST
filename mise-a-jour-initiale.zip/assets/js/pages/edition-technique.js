(()=>{
  const labels={tachy:'Tachygraphe',mines:'Mines',limiteur:'Limiteur de vitesse',confinement:'Confinement',sanitaire:'Sanitaire / ATP',vidange:'Vidanges'};
  const $=id=>document.getElementById(id);
  const dialog=document.createElement('dialog');dialog.id='technicalEditor';
  dialog.innerHTML='<form id="technicalEditorForm"><header class="modal-head"><div class="modal-title-wrap"><div class="modal-icon" id="technicalEditorIcon"></div><div><h2 id="technicalEditorTitle"></h2><p id="technicalEditorSubtitle"></p></div></div><button type="button" class="modal-close-btn" id="technicalEditorClose" aria-label="Fermer">×</button></header><div class="technical-editor-body"><div id="technicalEditorFields"></div><p id="technicalEditorError" role="alert"></p></div><div class="technical-editor-actions"><button type="button" id="technicalEditorDelete" hidden>Supprimer la ligne</button><button type="button" id="technicalEditorCancel" class="btn-secondary">Annuler</button><button type="submit" class="btn-primary">Enregistrer les modifications</button></div></form>';
  dialog.setAttribute('aria-labelledby','technicalEditorTitle');document.body.append(dialog);
  $('technicalEditorIcon').append(document.querySelector('#editVehicleOption svg').cloneNode(true));
  let category,id,baseline,initial,opener;
  const records=()=>category==='vidange'?vidangeData:technicalDeadlines;
  const normal=value=>normalizeRegistration(value);
  const snapshot=()=>JSON.stringify([...$('technicalEditorFields').querySelectorAll('input')].map(x=>[x.name,x.value]));
  const currentCategory=()=>Object.keys(labels).find(k=>labels[k]===$('technicalDeadlineTitle').textContent);
  function close(force=false){if(!force&&snapshot()!==initial&&!confirm('Abandonner les modifications ?'))return;dialog.close();opener?.focus();}
  function field(key,label,type,value,required=false){
    const wrap=document.createElement('label');wrap.textContent=label;
    const input=document.createElement('input');input.name=key;input.id='technicalEdit-'+key;input.type=type;input.value=value??'';input.required=required;
    if(type==='number'){input.min=key.endsWith('Interval')?'1':'0';input.step='1';}
    if(type==='text')input.maxLength=200;
    wrap.append(input);$('technicalEditorFields').append(wrap);return input;
  }
  function open(kind,recordId=null){
    category=kind;id=recordId;opener=document.activeElement;
    const r=id?records().find(x=>x.id===id):{};if(!r)return;
    baseline=id?JSON.stringify(r):null;
    $('technicalEditorTitle').textContent=(id?'Modifier · ':'Ajouter · ')+labels[kind];
    $('technicalEditorSubtitle').textContent=formatRegistration(r.registration||'');
    $('technicalEditorFields').replaceChildren();$('technicalEditorError').textContent='';
    const plate=field('registration','Immatriculation','text',r.registration,true);plate.maxLength=20;
    const driver=field('driver','Chauffeur affecté automatiquement','text','');driver.readOnly=true;
    const updateDriver=()=>{driver.value=window.technicalAssignedDriver?.(plate.value)||'Non affecté';};plate.addEventListener('input',updateDriver);updateDriver();
    if(kind==='vidange'){
      field('currentKm','Kilométrage actuel','number',r.currentKm,true);
      field('lastMajorKm','Km dernière grosse vidange','number',r.lastMajorKm);
      field('lastGarageKm','Km dernier passage garage','number',r.lastGarageKm);
      field('sameInterval','Intervalle si les deux kilométrages sont égaux','number',r.sameInterval??50000,true);
      field('differentInterval','Intervalle si les deux kilométrages sont différents','number',r.differentInterval??100000,true);
    }else{
      if(kind==='mines')field('genre','Genre','text',r.genre);
      field('label','Libellé','text',r.label);
      field('lastControl','Dernier contrôle','date',iso(r.lastControl));
      field('nextControl','Prochain contrôle','date',iso(r.nextControl),true);
      field('operator','Exploitant','text',r.operator);
      field('company','Société','text',r.company);
      field('control','Contrôle','text',r.control);
    }
    initial=snapshot();dialog.showModal();plate.focus();
  }
  function iso(value){const m=String(value||'').match(/^(\d{2})\/(\d{2})\/(\d{4})$/);return m?`${m[3]}-${m[2]}-${m[1]}`:value||'';}
  function persist(next){
    const previous=records();
    if(category==='vidange')vidangeData=next;else technicalDeadlines=next;
    let saved=false;try{saved=(category==='vidange'?saveVidangeData():saveTechnicalDeadlines())!==false;}catch(error){}
    if(!saved){if(category==='vidange')vidangeData=previous;else technicalDeadlines=previous;throw new Error('Enregistrement impossible. Vos modifications restent dans le formulaire.');}
    if(!id){
      const query=$(category==='vidange'?'vidSearch':'technicalDeadlineSearch');query.value='';
      for(const key of category==='vidange'?['vidStatusFilter']:['technicalDeadlineStatusFilter','technicalDeadlineWindowFilter']){const filter=$(key);if(filter)filter.value='';}
    }
    if(category==='vidange'){selectedVidangeId=id||next[next.length-1]?.id;renderVidTable();loadVidDetail();}
    window.technicalRefreshAll?.();window.technicalRenderDeadlineTableEnhanced?.();
    if(typeof refreshHomeDashboard==='function')refreshHomeDashboard();
    close(true);
  }
  function current(){const r=records().find(x=>x.id===id);if(id&&(!r||JSON.stringify(r)!==baseline))throw new Error('Cette ligne a changé entre-temps. Fermez puis rouvrez le formulaire.');return r;}
  $('technicalEditorForm').addEventListener('submit',event=>{
    event.preventDefault();$('technicalEditorError').textContent='';
    try{
      if(!$('technicalEditorForm').reportValidity())return;
      const old=current();const r={...old};
      for(const input of $('technicalEditorFields').querySelectorAll('input')){
        if(input.name==='driver')continue;
        r[input.name]=input.type==='number'?(input.value===''?null:Number(input.value)):input.value.trim();
      }
      if(!/^[a-zA-Z0-9 -]{3,20}$/.test(r.registration))throw new Error('Vérifiez l’immatriculation.');
      r.registration=formatRegistration(r.registration);
      if(records().some(x=>x.id!==id&&(category==='vidange'||x.category===category)&&normal(x.registration)===normal(r.registration)))throw new Error('Ce véhicule figure déjà dans cette rubrique. Modifiez sa ligne existante.');
      if(category!=='vidange'&&r.lastControl&&r.nextControl<r.lastControl)throw new Error('Le prochain contrôle doit être après le dernier contrôle.');
      if(category==='vidange'&&((r.lastGarageKm??0)>r.currentKm||(r.lastMajorKm??0)>r.currentKm))throw new Error('Le kilométrage actuel doit être au moins égal aux kilométrages d’entretien.');
      if(category!=='vidange')r.category=category;
      else {r.lastName=window.technicalAssignedDriver?.(r.registration)||'';r.firstName='';if(r.currentKm!==null)delete r.needsData;}
      r.id=id||('manual_'+Date.now()+'_'+Math.random().toString(36).slice(2));
      const next=id?records().map(x=>x.id===id?r:x):[...records(),r];
      persist(next);
    }catch(error){$('technicalEditorError').textContent=error.message;}
  });
  $('technicalEditorDelete').addEventListener('click',()=>{try{const r=current();if(!r||!confirm('Supprimer la ligne '+r.registration+' de '+labels[category]+' ? Le véhicule restera dans le parc.'))return;persist(records().filter(x=>x.id!==id));}catch(error){$('technicalEditorError').textContent=error.message;}});
  $('technicalEditorCancel').addEventListener('click',()=>close());
  $('technicalEditorClose').addEventListener('click',()=>close());
  dialog.addEventListener('cancel',event=>{event.preventDefault();close();});
  window.addEventListener('beforeunload',event=>{if(dialog.open&&snapshot()!==initial){event.preventDefault();event.returnValue='';}});
  const menu=document.createElement('div');menu.id='technicalRowMenu';menu.className='row-actions-menu';menu.hidden=true;menu.setAttribute('role','menu');document.body.append(menu);
  let menuButton=null;
  function hideMenu(focus=false){menu.hidden=true;menuButton?.setAttribute('aria-expanded','false');if(focus)menuButton?.focus();}
  function showMenu(button,kind,recordId){
    if(!menu.hidden&&menuButton===button){hideMenu(true);return;}
    hideMenu();menuButton=button;menu.replaceChildren();
    for(const [label,remove] of [['Modifier',false],['Supprimer',true]]){
      const action=$(remove?'deleteVehicleOption':'editVehicleOption').cloneNode(true);action.removeAttribute('id');
      action.addEventListener('click',()=>{
        hideMenu();
        if(!remove){open(kind,recordId);opener=button;return;}
        category=kind;id=recordId;opener=button;
        const record=records().find(x=>x.id===id);if(!record)return;baseline=JSON.stringify(record);
        if(!confirm('Supprimer la ligne '+record.registration+' de '+labels[kind]+' ? Si le véhicule reste au Parc, sa ligne sera recréée vide à la prochaine synchronisation.'))return;
        try{persist(records().filter(x=>x.id!==id));}catch(error){dashboardToast('Suppression impossible',error.message,'error',5000);}
      });menu.append(action);
    }
    menu.hidden=false;button.setAttribute('aria-expanded','true');
    const rect=button.getBoundingClientRect(),size=menu.getBoundingClientRect();
    menu.style.left=Math.max(8,Math.min(rect.right-size.width,window.innerWidth-size.width-8))+'px';
    menu.style.top=Math.max(8,rect.bottom+size.height+8>window.innerHeight?rect.top-size.height-6:rect.bottom+6)+'px';
    menu.querySelector('button').focus();
  }
  document.addEventListener('click',event=>{if(!menu.contains(event.target)&&event.target!==menuButton)hideMenu();});
  document.addEventListener('scroll',event=>{if(!menu.contains(event.target))hideMenu();},true);
  window.addEventListener('resize',()=>hideMenu());
  menu.addEventListener('keydown',event=>{
    if(event.key==='Escape'){event.preventDefault();hideMenu(true);}
    if(event.key==='Tab')hideMenu();
    if(['ArrowDown','ArrowUp','Home','End'].includes(event.key)){
      event.preventDefault();const items=[...menu.querySelectorAll('button')],i=items.indexOf(document.activeElement);
      items[event.key==='Home'?0:event.key==='End'?items.length-1:(i+(event.key==='ArrowDown'?1:-1)+items.length)%items.length].focus();
    }
  });
  function decorate(body,kind,attribute){
    const head=body.closest('table').querySelector('thead tr');
    if(head&&!head.querySelector('[data-tech-actions]')){const th=document.createElement('th');th.dataset.techActions='';th.textContent='ACTIONS';head.append(th);}
    for(const row of body.querySelectorAll('tr')){
      const recordId=row.getAttribute(attribute);if(!recordId){const td=row.querySelector('td[colspan]');if(td&&td.colSpan!==8)td.colSpan=8;continue;}
      if(row.querySelector('[data-tech-edit]'))continue;
      const cell=document.createElement('td');cell.dataset.techEdit='';const button=document.createElement('button');button.type='button';button.className='row-menu';button.textContent='•••';button.setAttribute('aria-label','Actions pour cette ligne');button.setAttribute('aria-haspopup','menu');button.setAttribute('aria-expanded','false');button.setAttribute('aria-controls','technicalRowMenu');button.addEventListener('click',event=>{event.stopPropagation();showMenu(button,kind||currentCategory(),recordId);});cell.append(button);row.append(cell);
    }
  }
  for(const [bodyId,kind,attribute] of [['technicalDeadlineBody',null,'data-tech-id'],['vidTable','vidange','data-vid-id']]){
    const body=$(bodyId);const render=()=>decorate(body,kind,attribute);new MutationObserver(render).observe(body,{childList:true,subtree:true});render();
  }
})();
