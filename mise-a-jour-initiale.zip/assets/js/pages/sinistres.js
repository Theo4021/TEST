function claimStatusClass(status){
  if(status === 'Clos') return 'closed';
  if(status === 'En attente') return 'wait';
  if(status === 'Urgent') return 'urgent';
  return 'open';
}

function claimDriverOptions(){
  const names = [];
  const seen = new Set();

  if(typeof driverProfiles !== 'undefined' && Array.isArray(driverProfiles)){
    driverProfiles.forEach(item=>{
      const name = [item.lastName,item.firstName].filter(Boolean).join(' ').trim();
      const key = normalizeClaimSearch(name);
      if(name && !seen.has(key)){
        seen.add(key);
        names.push(name);
      }
    });
  }

  if(typeof affectations !== 'undefined' && Array.isArray(affectations)){
    affectations.forEach(item=>{
      const name = String(item.name || '').trim();
      const key = normalizeClaimSearch(name);
      if(name && !seen.has(key)){
        seen.add(key);
        names.push(name);
      }
    });
  }

  return names.sort((a,b)=>a.localeCompare(b,'fr',{sensitivity:'base'}));
}

function claimVehicleOptions(){
  if(typeof parkData === 'undefined' || !Array.isArray(parkData)) return [];
  return [...parkData]
    .sort((a,b)=>{
      const order = {Tracteur:0,Semi:1};
      return (order[a.type]??9)-(order[b.type]??9) ||
        String(a.registration).localeCompare(String(b.registration),'fr',{numeric:true});
    })
    .map(item=>({
      value:formatRegistration(item.registration),
      label:`${formatRegistration(item.registration)} · ${item.type}${item.parkNumber ? ' · '+item.parkNumber : ''}`
    }));
}
