(()=>{
  let syncing=false;
  function sync(){
    if(syncing)return;syncing=true;
    try{
      const deadlines=[...technicalDeadlines],oil=[...vidangeData];
      const keys=new Set(deadlines.map(x=>x.category+':'+normalizeRegistration(x.registration)));
      const oilKeys=new Set(oil.map(x=>normalizeRegistration(x.registration)));
      for(const vehicle of parkData){
        const reg=normalizeRegistration(vehicle.registration);if(!reg)continue;
        const type=String(vehicle.type||'').toLowerCase();
        const tractor=type.includes('tracteur'),semi=type.includes('semi');if(!tractor&&!semi)continue;
        const registration=formatRegistration(reg);
        for(const category of tractor?['mines','tachy','limiteur']:['mines','confinement','sanitaire']){
          const key=category+':'+reg;if(keys.has(key))continue;
          deadlines.push({id:'auto_'+category+'_'+reg,category,registration,lastControl:'',nextControl:'',label:'',operator:'',company:'',genre:tractor?'Tracteur':'Semi-remorque',_fromPark:true});keys.add(key);
        }
        if(tractor&&!oilKeys.has(reg)){
          oil.push({id:'auto_vidange_'+reg,registration,currentKm:null,lastMajorKm:null,lastGarageKm:null,sameInterval:50000,differentInterval:100000,_fromPark:true});oilKeys.add(reg);
        }
      }
      let failed=false;
      if(deadlines.length!==technicalDeadlines.length){const old=technicalDeadlines;technicalDeadlines=deadlines;try{if(saveTechnicalDeadlines()===false)throw Error();}catch(error){technicalDeadlines=old;failed=true;}}
      if(oil.length!==vidangeData.length){const old=vidangeData;vidangeData=oil;try{if(saveVidangeData()===false)throw Error();}catch(error){vidangeData=old;failed=true;}}
      if(failed)dashboardToast('Suivi technique','Certaines lignes n’ont pas pu être enregistrées. Rouvrez le suivi technique pour réessayer.','error',6000);
      window.technicalRefreshAll?.();renderVidTable();
    }finally{syncing=false;}
  }
  const save=saveParkData;
  saveParkData=function(){const result=save.apply(this,arguments);if(result!==false)sync();return result;};
  const open=window.technicalOpenPage;
  window.technicalOpenPage=function(){sync();return open.apply(this,arguments);};
  document.addEventListener('dashboard-navigation',event=>{if(event.detail?.view==='suivi-technique')sync();});
  window.syncParkMaintenance=sync;
})();
