function vehicleExistsInPark(value,type){
  const normalized = normalizeRegistration(value);
  if(!normalized) return true;
  return parkData.some(item=>item.type === type && normalizeRegistration(item.registration) === normalized);
}

function vehicleOptions(type){
  return parkData
    .filter(item=>item.type === type)
    .sort((a,b)=>normalizeRegistration(a.registration).localeCompare(
      normalizeRegistration(b.registration),'fr',{numeric:true,sensitivity:'base'}
    ));
}

function vehicleOptionsForAdmin(){
  return [...parkData]
    .sort((a,b)=>{
      const order={Tracteur:0,Semi:1};
      return (order[a.type]??9)-(order[b.type]??9)||normalizeRegistration(a.registration).localeCompare(normalizeRegistration(b.registration),'fr',{numeric:true});
    })
    .map(v=>({value:formatRegistration(v.registration),label:`${formatRegistration(v.registration)} · ${v.type}${v.parkNumber?' · '+v.parkNumber:''}`}));
}
