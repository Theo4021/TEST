function driverStatusLabel(driver){ return DRIVER_STATUSES[normalizeDriverStatus(driver?.status)]||'Titulaire'; }

function driverIsInactive(driver){ return normalizeDriverStatus(driver?.status)==='inactive'; }

function driverByDisplayName(name){
  const key=normalizeAffText(name);
  return driverProfiles.find(driver=>normalizeAffText(driverDisplayName(driver))===key)||null;
}

function driverAllowsMultipleAssignments(name){
  const driver=driverByDisplayName(name);
  return !!driver && normalizeDriverStatus(driver.status)==='regional';
}

function driverDisplayName(item){
  return [item.lastName,item.firstName].filter(Boolean).join(' ').trim();
}

function driverInitials(item){
  const a = (item.lastName || '').trim().charAt(0);
  const b = (item.firstName || '').trim().charAt(0);
  return (a+b).toUpperCase() || '—';
}

function driverSecondaryLine(item){
  const parts = [];
  if(item.city) parts.push(item.city);
  if(item.phone) parts.push(item.phone);
  if(item.licenseNumber) parts.push('Permis ' + item.licenseNumber);
  return parts.join(' · ') || 'Informations à compléter';
}

function driverStatusBadge(item){
  const status=normalizeDriverStatus(item?.status);
  return `<span class="driver-status-badge ${status}">${DRIVER_STATUSES[status]}</span>`;
}

function driverCsvEscape(value){
  return `"${String(value ?? '').replace(/"/g,'""')}"`;
}

function driverOptionsForAdmin(){
  const names=[];
  const seen=new Set();
  if(Array.isArray(driverProfiles)){
    driverProfiles.forEach(x=>{
      const name=[x.lastName,x.firstName].filter(Boolean).join(' ').trim();
      const key=adminNorm(name);
      if(name&&!seen.has(key)){seen.add(key);names.push(name)}
    });
  }
  if(Array.isArray(affectations)){
    affectations.forEach(x=>{
      const name=String(x.name||'').trim();
      const key=adminNorm(name);
      if(name&&!seen.has(key)){seen.add(key);names.push(name)}
    });
  }
  return names.sort((a,b)=>a.localeCompare(b,'fr',{sensitivity:'base'}));
}
