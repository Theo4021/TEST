function homeSetText(id,value){
  const element=document.getElementById(id);
  if(element) element.textContent=value;
}

/* Panneaux secondaires repliables (Composition du parc, Repères administratifs, Carburant) */
const HOME_PANEL_COLLAPSE_KEY='hessers-dashboard-home-panels-v1';

function homeReadCollapsedPanels(){
  try{
    return JSON.parse(localStorage.getItem(HOME_PANEL_COLLAPSE_KEY))||{};
  }catch(error){
    return {};
  }
}

function homeSetPanelCollapsed(panel,collapsed){
  const key=panel.dataset.collapsible;
  panel.dataset.collapsed=collapsed?'true':'false';
  const toggle=panel.querySelector('.home-panel-toggle');
  if(toggle){
    toggle.setAttribute('aria-expanded',collapsed?'false':'true');
  }
  if(key){
    const state=homeReadCollapsedPanels();
    state[key]=collapsed;
    try{ localStorage.setItem(HOME_PANEL_COLLAPSE_KEY,JSON.stringify(state)); }catch(error){}
  }
}

function initHomeCollapsiblePanels(){
  const panels=document.querySelectorAll('#accueil [data-collapsible]');
  if(!panels.length||panels[0].dataset.homeCollapseReady) return;

  const state=homeReadCollapsedPanels();

  panels.forEach(panel=>{
    panel.dataset.homeCollapseReady='true';
    homeSetPanelCollapsed(panel,!!state[panel.dataset.collapsible]);
    panel.querySelector('.home-panel-toggle')?.addEventListener('click',()=>{
      homeSetPanelCollapsed(panel,panel.dataset.collapsed!=='true');
    });
  });
}

function homeRungisVehicleInfo(registration){
  if(!registration) return null;
  const key=normalizeRegistration(registration);
  return parkData.find(item=>normalizeRegistration(item.registration)===key)||null;
}

function homeAssignedRegistrations(){
  const assigned=new Set();

  affectations.forEach(item=>{
    [item.tractor,item.semi].forEach(registration=>{
      if(registration){
        assigned.add(normalizeRegistration(registration));
      }
    });
  });

  return assigned;
}

function homeAverageFuel(field){
  const values=fuelEntries
    .map(item=>fuelNumber(item[field]))
    .filter(value=>value!==null);

  if(!values.length) return null;

  return values.reduce((sum,value)=>sum+value,0)/values.length;
}

function refreshHomeDashboard(){
  if(!document.getElementById('homeVehicles')) return;
  initHomeCollapsiblePanels();

  const tractors=parkData.filter(item=>item.type==='Tracteur').length;
  const semis=parkData.filter(item=>item.type==='Semi').length;
  const assigned=homeAssignedRegistrations();

  const unassigned=parkData.filter(item=>
    !assigned.has(normalizeRegistration(item.registration))
  ).length;

  const openClaims=claimData.filter(item=>item.status!=='Clos').length;

  let lateMaintenance=0;
  let soonMaintenance=0;

  vidangeData.forEach(item=>{
    const remaining=calculateNextOil(item);

    if(remaining<=0) lateMaintenance++;
    else if(remaining<=5000) soonMaintenance++;
  });

  const finesTodo=adminFines.filter(item=>['À traiter','À prévenir'].includes(item.status)).length;

  const rungisOutside=adminRungis.filter(item=>
    item.vehicle && !homeRungisVehicleInfo(item.vehicle)
  ).length;

  const configuredSites=['dkv','ids','lumesia']
    .filter(key=>String(adminSites[key]||'').trim()).length;

  homeSetText('homeVehicles',parkData.length);
  homeSetText('homeVehiclesSub',`${tractors} tracteurs · ${semis} semis`);
  homeSetText('homeDrivers',driverProfiles.filter(driver=>!driverIsInactive(driver)).length);
  homeSetText('homeClaims',openClaims);
  homeSetText('homeOpenClaims',openClaims);
  homeSetText('homeMaintenance',lateMaintenance+soonMaintenance);

  homeSetText('homeTractors',tractors);
  homeSetText('homeSemis',semis);
  homeSetText('homeUnassigned',unassigned);

  homeSetText('homeLateMaintenance',lateMaintenance);
  homeSetText('homeSoonMaintenance',soonMaintenance);
  homeSetText('homeFinesTodo',finesTodo);
  homeSetText('homeRungisOutside',rungisOutside);

  homeSetText('homeFineTotal',adminFines.length);
  homeSetText('homeRungisTotal',adminRungis.length);
  homeSetText('homeSitesConfigured',`${configuredSites} / 3`);

  const diesel=homeAverageFuel('dieselPrice');
  const gnr=homeAverageFuel('gnrPrice');
  const adblue=homeAverageFuel('adbluePrice');

  const fuelEmpty=document.getElementById('homeFuelEmpty');
  const fuelContent=document.getElementById('homeFuelContent');

  if(fuelEntries.length){
    fuelEmpty.hidden=true;
    fuelContent.hidden=false;

    homeSetText('homeFuelDiesel',fuelFormatPrice(diesel));
    homeSetText('homeFuelGnr',fuelFormatPrice(gnr));
    homeSetText('homeFuelAdblue',fuelFormatPrice(adblue));

    const lastFuel=latestFuelEntry();

    homeSetText('homeFuelLastSupplier',lastFuel?.supplier||'—');
    homeSetText(
      'homeFuelLastDelivery',
      lastFuel ? fuelFormatDate(lastFuel.deliveryDate||lastFuel.orderDate) : '—'
    );
    homeSetText(
      'homeFuelLastDiesel',
      lastFuel ? fuelFormatPrice(lastFuel.dieselPrice) : '—'
    );
    homeSetText(
      'homeFuelLastGnr',
      lastFuel ? fuelFormatPrice(lastFuel.gnrPrice) : '—'
    );
    homeSetText(
      'homeFuelLastAdblue',
      lastFuel ? fuelFormatPrice(lastFuel.adbluePrice) : '—'
    );
  }else{
    fuelEmpty.hidden=false;
    fuelContent.hidden=true;
  }

  const now=new Date();
  homeSetText(
    'homeDate',
    now.toLocaleDateString('fr-FR',{
      weekday:'long',
      day:'2-digit',
      month:'long',
      year:'numeric'
    })
  );
}
