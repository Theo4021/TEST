
const FLEET_CONTROL_NAMES={tachy:'Tachygraphe',mines:'Mines',limiteur:'Limiteur',confinement:'Confinement',sanitaire:'Sanitaire / ATP'};
function fleetCurrentDrivers(plate){
  const key=normalizeRegistration(plate);if(!key)return '';
  return [...new Set(affectations.filter(a=>[a.tractor,a.semi].some(r=>normalizeRegistration(r)===key)).map(a=>String(a.name||'').trim()).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'fr')).join(' · ');
}
function fleetDays(value,today=new Date()){
  const text=String(value||'').trim();let m=text.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if(!m){const f=text.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);if(f)m=[f[0],f[3],f[2],f[1]];}
  if(!m)return null;
  const [y,mo,d]=m.slice(1).map(Number);const date=new Date(Date.UTC(y,mo-1,d));
  if(date.getUTCFullYear()!==y||date.getUTCMonth()!==mo-1||date.getUTCDate()!==d)return null;
  return Math.round((date.getTime()-Date.UTC(today.getFullYear(),today.getMonth(),today.getDate()))/86400000);
}
function fleetPriorityRows(today=new Date()){
  const rows=[];
  const assignedNames=new Set(affectations.filter(a=>normalizeRegistration(a.tractor)||normalizeRegistration(a.semi)).map(a=>normalizeAffText(a.name)));
  driverProfiles.filter(d=>!driverIsInactive(d)&&!assignedNames.has(normalizeAffText(driverDisplayName(d)))).forEach(d=>rows.push({kind:'assignment',id:d.id,plate:'',title:'Chauffeur sans affectation',driver:driverDisplayName(d),detail:'Affectation à vérifier',level:'open',rank:4}));
  const assignedPlates=new Set(affectations.flatMap(a=>[a.tractor,a.semi]).map(normalizeRegistration).filter(Boolean));
  parkData.filter(v=>!assignedPlates.has(normalizeRegistration(v.registration))).forEach(v=>rows.push({kind:'assignment',id:v.registration,plate:v.registration,title:'Véhicule non affecté',driver:'',detail:v.type||'Véhicule disponible',level:'open',rank:4}));
  technicalDeadlines.forEach(r=>{const days=fleetDays(r.nextControl,today);if(days===null)return;rows.push({kind:'control',id:r.id,plate:r.registration,title:FLEET_CONTROL_NAMES[r.category]||r.category,driver:fleetCurrentDrivers(r.registration),detail:r.label||'Contrôle réglementaire',due:r.nextControl,days,level:days<0?'late':days===0?'today':'soon',rank:days<0?0:days===0?1:3,category:r.category});});
  vidangeData.forEach(r=>{const km=calculateNextOil(r);if(typeof km!=='number'||!Number.isFinite(km)||km>5000)return;rows.push({kind:'oil',id:r.id,plate:r.registration,title:'Vidange',driver:fleetCurrentDrivers(r.registration),detail:'Entretien kilométrique',km,level:km<=0?'late':'soon',rank:km<=0?0:3});});
  adminFines.filter(r=>r.status==='À traiter').forEach(r=>rows.push({kind:'fine',id:r.id,plate:r.vehicle,title:r.reference||'Amende à traiter',driver:r.driver||'',detail:r.offense||'Dossier administratif',level:'open',rank:2}));
  claimData.filter(r=>r.status!=='Clos').forEach(r=>rows.push({kind:'claim',id:r.id,plate:r.vehicle,title:r.number||'Sinistre sans numéro',driver:r.driver||'',detail:r.status||'Dossier ouvert',level:'open',rank:2}));
  return rows.sort((a,b)=>a.rank-b.rank||((a.days??Infinity)-(b.days??Infinity))||((a.km??Infinity)-(b.km??Infinity))||String(a.plate||'').localeCompare(String(b.plate||''),'fr',{numeric:true}));
}
function fleetFilterRows(rows,state){
  const query=globalNormalize(state.query);
  return rows.filter(r=>(r.kind!=='control'||r.days<=Number(state.horizon))&&(state.kind==='all'||r.kind===state.kind)&&(state.level==='all'||(state.level==='late'?r.level==='late':r.level==='today'))&&(!query||globalNormalize([r.plate,r.driver,r.title,r.detail].join(' ')).includes(query)));
}
