
(()=>{
  if(window.__homeKpiDashboardApplied)return;window.__homeKpiDashboardApplied=true;
  const q=(selector,root=document)=>root.querySelector(selector);
  const head=q('#accueil .home-head'),kpis=q('#accueil .home-kpis');
  if(!head||!kpis)return;
  q('#accueil')?.classList.remove('home-rebuilt','simple-mode');
  const intro=q('#accueil .home-head p');
  if(intro)intro.textContent='Vue directe du parc, des chauffeurs et des points à surveiller.';
  if(!q('#homeDashboardStrip')){
    const strip=document.createElement('div');
    strip.id='homeDashboardStrip';
    strip.className='home-dashboard-strip';
    strip.innerHTML=`
      <button class="home-dashboard-shortcut" type="button" data-home-kpi-go="parc"><strong>Parc véhicules</strong><span>Liste, ajout et fiches véhicules</span></button>
      <button class="home-dashboard-shortcut" type="button" data-home-kpi-go="affectations"><strong>Affectations</strong><span>Chauffeurs, tracteurs et semis</span></button>
      <button class="home-dashboard-shortcut" type="button" data-home-kpi-go="chauffeur"><strong>Chauffeurs</strong><span>Fiches, statut et permis</span></button>
      <button class="home-dashboard-shortcut" type="button" data-home-kpi-go="search"><strong>Recherche</strong><span>Plaque, chauffeur ou dossier</span></button>`;
    kpis.insertAdjacentElement('afterend',strip);
  }
  function go(view){
    if(window.dashboardAllowLeave&&!window.dashboardAllowLeave())return;
    if(view==='search'){const input=q('#globalSearch');if(input){input.focus();input.select();}return;}
    const titles={parc:'Parc véhicules',affectations:'Affectations',chauffeur:'Chauffeurs'};
    showView(view,titles[view]||view,view==='affectations'?'parc':view);
  }
  q('#homeDashboardStrip')?.addEventListener('click',event=>{
    const button=event.target.closest('[data-home-kpi-go]');if(button)go(button.dataset.homeKpiGo);
  });
  const previous=refreshHomeDashboard;
  refreshHomeDashboard=function(){const result=previous.apply(this,arguments);q('#accueil')?.classList.remove('home-rebuilt','simple-mode');return result;};
})();
