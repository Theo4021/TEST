
(()=>{
  const groups=[];
  let currentView=document.querySelector('.view.active')?.id||'accueil';
  let technical='overview';
  let admin=typeof adminActiveTab==='string'?adminActiveTab:'fines';
  const definitions=[
    ['parc',[['parc','Parc véhicules'],['affectations','Affectations']]],
    ['suivi-technique',[['overview',"Vue d'ensemble"],['vidange','Vidanges'],['tachy','Tachygraphe'],['mines','Mines'],['limiteur','Limiteur de vitesse'],['confinement','Confinement'],['sanitaire','Sanitaire / ATP']]],
    ['gestion-administrative',[['fines','Amendes'],['rungis','Cartes Rungis'],['sites','Sites & outils']]]
  ];
  document.querySelector('#accueil .home-alerts')?.closest('.home-section-card')?.classList.add('home-alert-summary');
  const actionCenter=document.getElementById('homeActionCenter');
  const homeStack=document.querySelector('#accueil .home-stack');
  if(actionCenter&&homeStack)homeStack.append(actionCenter);
  function ensureAdminInlineTabs(){
    const head=document.querySelector('#gestion-administrative .admin-head');
    if(!head||document.getElementById('adminInlineTabs'))return;
    const eyebrow=head.querySelector('.parc-eyebrow');
    const tabs=document.createElement('div');
    tabs.className='admin-inline-tabs';
    tabs.id='adminInlineTabs';
    tabs.setAttribute('role','tablist');
    tabs.setAttribute('aria-label','Gestion administrative');
    [['fines','Amendes'],['rungis','Cartes Rungis'],['sites','Sites & outils']].forEach(([key,label])=>{
      const button=document.createElement('button');
      button.type='button';
      button.dataset.adminInlineTab=key;
      button.setAttribute('role','tab');
      button.textContent=label;
      button.addEventListener('click',()=>{
        admin=key;
        switchAdminTab(key);
        updateAdminHeading();
        sync();
      });
      tabs.append(button);
    });
    if(eyebrow)eyebrow.replaceWith(tabs);
    else head.prepend(tabs);
  }
  function syncAdminInlineTabs(){
    document.querySelectorAll('[data-admin-inline-tab]').forEach(button=>{
      const selected=button.dataset.adminInlineTab===admin;
      button.classList.toggle('active',selected);
      button.setAttribute('aria-selected',String(selected));
    });
  }
  function updateAdminHeading(){
    const headings={
      fines:['Amendes','Suivi des infractions à envoyer et contestations.'],
      rungis:['Cartes Rungis','Cartes et véhicules associés.'],
      sites:['Sites & outils','Accès à DKV, IDS et Lumesia.']
    };
    const [heading,description]=headings[admin]||headings.fines;
    const head=document.querySelector('#gestion-administrative .admin-head');
    if(head){head.querySelector('h1').textContent=heading;head.querySelector('p').textContent=description;}
    syncAdminInlineTabs();
  }
  function expand(group,open){
    group.wrapper.classList.toggle('open',open);
    group.parent.setAttribute('aria-expanded',String(open));
    group.children.hidden=!open;
  }
  function sync(){
    groups.forEach(group=>{
      const active=group.id===currentView||(group.id==='parc'&&currentView==='affectations');
      group.parent.classList.toggle('active',active);
      const selected=group.id==='parc'?currentView:group.id==='suivi-technique'?technical:admin;
      group.children.querySelectorAll('button').forEach(button=>{
        if(active&&button.dataset.key===selected)button.setAttribute('aria-current','page');
        else button.removeAttribute('aria-current');
      });
      if(active)expand(group,true);
    });
  }
  definitions.forEach(([id,items])=>{
    const parent=document.querySelector(`.nav-btn[data-view="${id}"]`);
    if(!parent)return;
    const wrapper=document.createElement('div');wrapper.className='nav-group';
    parent.before(wrapper);wrapper.append(parent);
    const children=document.createElement('div');children.className='nav-children';children.id=`nav-children-${id}`;
    wrapper.append(children);parent.setAttribute('aria-controls',children.id);
    parent.title=parent.textContent.trim();
    const group={id,parent,wrapper,children};groups.push(group);expand(group,false);
    parent.addEventListener('click',event=>{
      event.stopImmediatePropagation();event.preventDefault();
      const collapsed=document.querySelector('.app').classList.contains('sidebar-collapsed');
      if(collapsed&&typeof dashboardSetSidebarCollapsed==='function')dashboardSetSidebarCollapsed(false);
      expand(group,collapsed||parent.getAttribute('aria-expanded')!=='true');
    },true);
    items.forEach(([key,label])=>{
      const button=document.createElement('button');button.type='button';button.className='nav-child';button.dataset.key=key;button.textContent=label;
      children.append(button);
      button.addEventListener('click',()=>{
        showView(id==='parc'?key:id,label,id);
        if(id==='suivi-technique'){
          if(key==='overview')window.technicalShowHub();else window.technicalOpenPage(key);
        }
        if(id==='gestion-administrative')switchAdminTab(key);
        sync();
      });
    });
  });
  document.addEventListener('dashboard-navigation',event=>{
    if(event.detail.view)currentView=event.detail.view;
    if(event.detail.technical)technical=event.detail.technical;
    if(event.detail.admin)admin=event.detail.admin;
    updateAdminHeading();
    sync();
  });
  ensureAdminInlineTabs();
  updateAdminHeading();
  sync();
})();
