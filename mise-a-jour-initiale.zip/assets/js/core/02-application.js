const navButtons = document.querySelectorAll('.nav-btn');
const views = document.querySelectorAll('.view');
const title = document.getElementById('pageTitle');

function showView(id,pageTitle,activeNavId=id){
  navButtons.forEach(button=>button.classList.toggle('active',button.dataset.view === activeNavId));
  views.forEach(view=>view.classList.remove('active'));
  const targetView = document.getElementById(id);
  if(!targetView) return;
  targetView.classList.add('active');
  title.textContent = pageTitle;
  if(id === 'accueil' && typeof refreshHomeDashboard === 'function'){
    refreshHomeDashboard();
  }

  // Les canvas carburant n'ont pas de dimensions fiables tant que leur page est cachée.
  // On attend donc deux frames après l'affichage de l'onglet avant de les redessiner.
  if(id === 'carburant' && typeof renderFuelCharts === 'function'){
    requestAnimationFrame(()=>{
      requestAnimationFrame(renderFuelCharts);
    });
  }

  if(typeof administratorHandleViewChange === 'function'){
    administratorHandleViewChange(id);
  }
  window.scrollTo({top:0,behavior:'smooth'});
}

navButtons.forEach(btn=>{
  btn.addEventListener('click',async()=>{
    const id = btn.dataset.view;

    if(id==='administrateur' && typeof adminSecurityRequestAccess==='function'){
      const allowed=await adminSecurityRequestAccess();
      if(!allowed) return;
    }

    showView(id,id === 'accueil' ? 'Gestion de Parc' : btn.innerText.trim(),id);
  });
});



const PARK_STORAGE_KEY = 'hessers-parc-data-v3';
const AFFECT_STORAGE_KEY = 'hessers-affectations-data-v3';

// Préparé pour une future base partagée.
// Pour l'instant le dashboard reste autonome et utilise le stockage local du navigateur.
const DATA_BACKEND = {
  mode: 'local',
  apiBaseUrl: ''
};
let parkData = initialParkData.map(item=>({...item}));

try{
  const storedParkData = JSON.parse(localStorage.getItem(PARK_STORAGE_KEY));
  if(Array.isArray(storedParkData) && storedParkData.every(item=>
    item && typeof item.registration === 'string' && ['Tracteur','Semi'].includes(item.type)
  )){
    parkData = storedParkData;
  }
}catch(error){
  console.warn('Les données locales du parc sont indisponibles.',error);
}

let affectations = initialDrivers.map(item=>({...item}));

try{
  const storedAffectations = JSON.parse(localStorage.getItem(AFFECT_STORAGE_KEY));
  if(Array.isArray(storedAffectations) && storedAffectations.every(item=>item && typeof item.name === 'string')){
    affectations = storedAffectations;
  }
}catch(error){
  console.warn('Les données locales des affectations sont indisponibles.',error);
}

const parkTable = document.getElementById('parkTable');
const parkSearch = document.getElementById('parkSearch');
const parkTypeFilter = document.getElementById('parkTypeFilter');
const parkResultCount = document.getElementById('parkResultCount');
const rowActionsMenu = document.getElementById('rowActionsMenu');
const editVehicleOption = document.getElementById('editVehicleOption');
const deleteVehicleOption = document.getElementById('deleteVehicleOption');
const editVehicleModal = document.getElementById('editVehicleModal');
const editVehicleForm = document.getElementById('editVehicleForm');
const editVehicleRegistration = document.getElementById('editVehicleRegistration');
const editVehicleType = document.getElementById('editVehicleType');
const editVehicleParkNumber = document.getElementById('editVehicleParkNumber');
const editParkNumberField = document.getElementById('editParkNumberField');
const editVehicleError = document.getElementById('editVehicleError');
const addVehicleModal = document.getElementById('addVehicleModal');
const addVehicleForm = document.getElementById('addVehicleForm');
const newVehicleRegistration = document.getElementById('newVehicleRegistration');
const newVehicleType = document.getElementById('newVehicleType');
const newVehicleParkNumber = document.getElementById('newVehicleParkNumber');
const parkNumberField = document.getElementById('parkNumberField');
const addVehicleError = document.getElementById('addVehicleError');
const deleteVehicleModal = document.getElementById('deleteVehicleModal');
const deleteVehicleRegistration = document.getElementById('deleteVehicleRegistration');

let activeParkRegistration = null;
let activeActionButton = null;
let pendingDeleteRegistration = null;
let editingOriginalRegistration = null;

const parkTypeOrder = {Tracteur:0,Semi:1};
const normalizeParkText = value=>String(value).toLocaleLowerCase('fr').replace(/[^a-z0-9]/g,'');
const normalizeRegistration = value=>String(value).toUpperCase().replace(/[^A-Z0-9]/g,'');
const formatRegistration = value=>{
  const registration = normalizeRegistration(value);
  const parts = registration.match(/^([A-Z]{2})(\d{3})([A-Z]{0,2})$/);
  return parts ? [parts[1],parts[2],parts[3]].filter(Boolean).join('-') : registration;
};

function saveParkData(){
  try{
    localStorage.setItem(PARK_STORAGE_KEY,JSON.stringify(parkData));
    return true;
  }catch(error){
    console.warn('Impossible d’enregistrer les données du parc dans ce navigateur.',error);
    return false;
  }
}

function updateParkStats(){
  const tractors = parkData.filter(item=>item.type === 'Tracteur');
  const semis = parkData.filter(item=>item.type === 'Semi');
  const usedTractors = new Set(affectations.map(item=>normalizeRegistration(item.tractor)).filter(Boolean));
  const usedSemis = new Set(affectations.map(item=>normalizeRegistration(item.semi)).filter(Boolean));
  const unassignedTractors = tractors.filter(item=>!usedTractors.has(normalizeRegistration(item.registration))).length;
  const unassignedSemis = semis.filter(item=>!usedSemis.has(normalizeRegistration(item.registration))).length;

  document.getElementById('parkTotal').textContent = parkData.length;
  document.getElementById('parkTractors').textContent = tractors.length;
  document.getElementById('parkTrailers').textContent = semis.length;
  document.getElementById('parkUnassigned').textContent = unassignedTractors + unassignedSemis;
  document.getElementById('parkUnassignedBreakdown').textContent =
    `${unassignedTractors} tracteur${unassignedTractors > 1 ? 's' : ''} · ${unassignedSemis} semi${unassignedSemis > 1 ? 's' : ''}`;
}

function isVehicleAssigned(item){
  const registration = normalizeRegistration(item.registration);
  if(item.type === 'Tracteur'){
    return affectations.some(assignment=>normalizeRegistration(assignment.tractor) === registration);
  }
  return affectations.some(assignment=>normalizeRegistration(assignment.semi) === registration);
}

function renderParkTable(){
  const query = normalizeParkText(parkSearch.value);
  const selectedType = parkTypeFilter.value;
  const filteredData = parkData.filter(item=>{
    const searchableText = normalizeParkText(`${item.registration} ${item.type} ${item.parkNumber}`);
    return searchableText.includes(query) && (!selectedType || item.type === selectedType);
  }).sort((a,b)=>
    (parkTypeOrder[a.type] ?? 99) - (parkTypeOrder[b.type] ?? 99) ||
    normalizeRegistration(a.registration).localeCompare(
      normalizeRegistration(b.registration),'fr',{numeric:true,sensitivity:'base'}
    )
  );

  if(!filteredData.length){
    parkTable.innerHTML = '<tr><td colspan="6" class="empty-row">Aucun véhicule ne correspond à votre recherche.</td></tr>';
  }else{
    parkTable.innerHTML = filteredData.map(item=>{
      const displayedRegistration = formatRegistration(item.registration);
      return `
        <tr data-registration="${item.registration}">
          <td class="plate-cell" data-open-vehicle="${displayedRegistration}" title="Ouvrir la fiche véhicule">${displayedRegistration}</td>
          <td><span class="type-chip ${item.type === 'Tracteur' ? 'type-tractor' : 'type-semi'}">${item.type}</span></td>
          <td><span class="park-number ${item.parkNumber ? '' : 'empty'}">${item.parkNumber || '—'}</span></td>
          <td>
            <span class="assignment-status ${isVehicleAssigned(item) ? 'assigned' : 'unassigned'}">
              ${isVehicleAssigned(item) ? 'Affecté' : 'Non affecté'}
            </span>
          </td>
          <td>${dashboardModificationHtml(item)}</td>
          <td><button class="row-menu" type="button" data-registration="${item.registration}" aria-label="Actions pour ${displayedRegistration}" aria-haspopup="menu" aria-expanded="false">•••</button></td>
        </tr>
      `;
    }).join('');
  }

  updateParkStats();
  if(typeof populateVehicleSelects === 'function') populateVehicleSelects();
  parkResultCount.textContent = `${filteredData.length} véhicule${filteredData.length > 1 ? 's' : ''} affiché${filteredData.length > 1 ? 's' : ''}`;
}

function closeRowActionsMenu(){
  if(activeActionButton) activeActionButton.setAttribute('aria-expanded','false');
  rowActionsMenu.hidden = true;
  activeParkRegistration = null;
  activeActionButton = null;
}

function openRowActionsMenu(button,registration){
  closeRowActionsMenu();
  activeParkRegistration = registration;
  activeActionButton = button;
  button.setAttribute('aria-expanded','true');
  rowActionsMenu.hidden = false;

  const buttonRect = button.getBoundingClientRect();
  const menuRect = rowActionsMenu.getBoundingClientRect();
  const left = Math.max(10,Math.min(buttonRect.right - menuRect.width,window.innerWidth - menuRect.width - 10));
  let top = buttonRect.bottom + 6;
  if(top + menuRect.height > window.innerHeight - 10) top = buttonRect.top - menuRect.height - 6;
  rowActionsMenu.style.left = `${left}px`;
  rowActionsMenu.style.top = `${Math.max(10,top)}px`;
}

function syncModalState(){
  document.body.classList.toggle('modal-open',
    !addVehicleModal.hidden ||
    !editVehicleModal.hidden ||
    !deleteVehicleModal.hidden ||
    !addAssignmentModal.hidden ||
    !editAssignmentModal.hidden ||
    !deleteAssignmentModal.hidden
  );
}

function updateParkNumberField(){
  const isSemi = newVehicleType.value === 'Semi';
  newVehicleParkNumber.disabled = !isSemi;
  newVehicleParkNumber.required = isSemi;
  parkNumberField.classList.toggle('disabled',!isSemi);
  if(!isSemi) newVehicleParkNumber.value = '';
}

function openAddVehicleModal(){
  closeRowActionsMenu();
  addVehicleForm.reset();
  addVehicleError.textContent = '';
  updateParkNumberField();
  addVehicleModal.hidden = false;
  syncModalState();
  requestAnimationFrame(()=>newVehicleRegistration.focus());
}

function closeAddVehicleModal(){
  addVehicleModal.hidden = true;
  addVehicleError.textContent = '';
  syncModalState();
}


function updateEditParkNumberField(){
  const isSemi = editVehicleType.value === 'Semi';
  editVehicleParkNumber.disabled = !isSemi;
  editVehicleParkNumber.required = isSemi;
  editParkNumberField.classList.toggle('disabled',!isSemi);
  if(!isSemi) editVehicleParkNumber.value = '';
}

function openEditVehicleModal(registration){
  const normalized = normalizeRegistration(registration);
  const item = parkData.find(vehicle=>normalizeRegistration(vehicle.registration) === normalized);
  if(!item) return;

  editingOriginalRegistration = normalizeRegistration(item.registration);
  editVehicleError.textContent = '';
  editVehicleRegistration.value = formatRegistration(item.registration);
  editVehicleType.value = item.type;
  editVehicleParkNumber.value = item.parkNumber || '';
  updateEditParkNumberField();
  editVehicleModal.hidden = false;
  syncModalState();
  requestAnimationFrame(()=>editVehicleRegistration.focus());
}

function closeEditVehicleModal(){
  editVehicleModal.hidden = true;
  editVehicleError.textContent = '';
  editingOriginalRegistration = null;
  syncModalState();
}

function propagateVehicleChange(oldRegistration,newRegistration,newType,newParkNumber){
  const oldNormalized = normalizeRegistration(oldRegistration);
  const newFormatted = formatRegistration(newRegistration);

  affectations.forEach(item=>{
    if(normalizeRegistration(item.tractor) === oldNormalized){
      item.tractor = newType === 'Tracteur' ? newFormatted : item.tractor;
    }
    if(normalizeRegistration(item.semi) === oldNormalized){
      item.semi = newType === 'Semi' ? newFormatted : item.semi;
      if(newType === 'Semi') item.number = newParkNumber || item.number;
    }
  });
}

function openDeleteVehicleModal(registration){
  pendingDeleteRegistration = registration;
  deleteVehicleRegistration.textContent = formatRegistration(registration);
  deleteVehicleModal.hidden = false;
  syncModalState();
  requestAnimationFrame(()=>document.getElementById('confirmDeleteVehicle').focus());
}

function closeDeleteVehicleModal(){
  deleteVehicleModal.hidden = true;
  pendingDeleteRegistration = null;
  syncModalState();
}

parkSearch.addEventListener('input',renderParkTable);
parkTypeFilter.addEventListener('change',renderParkTable);

parkTable.addEventListener('click',event=>{
  const actionButton = event.target.closest('.row-menu');
  if(actionButton){
    event.stopPropagation();
    openRowActionsMenu(actionButton,actionButton.dataset.registration);
    return;
  }

  const row = event.target.closest('tr[data-registration]');
  if(!row) return;
  closeRowActionsMenu();
  parkTable.querySelectorAll('tr').forEach(item=>item.classList.remove('selected'));
  row.classList.add('selected');
});

editVehicleOption.addEventListener('click',()=>{
  if(!activeParkRegistration) return;
  const registration = activeParkRegistration;
  closeRowActionsMenu();
  openEditVehicleModal(registration);
});

deleteVehicleOption.addEventListener('click',()=>{
  if(!activeParkRegistration) return;
  const registration = activeParkRegistration;
  closeRowActionsMenu();
  openDeleteVehicleModal(registration);
});


editVehicleType.addEventListener('change',updateEditParkNumberField);

editVehicleRegistration.addEventListener('input',()=>{
  let value = editVehicleRegistration.value.toUpperCase().replace(/[^A-Z0-9-]/g,'').replace(/-{2,}/g,'-');
  const registration = normalizeRegistration(value);
  if(!value.includes('-') && registration.length >= 5) value = formatRegistration(registration);
  editVehicleRegistration.value = value;
});

editVehicleRegistration.addEventListener('blur',()=>{
  const registration = normalizeRegistration(editVehicleRegistration.value);
  if(registration.length >= 5) editVehicleRegistration.value = formatRegistration(registration);
});

editVehicleParkNumber.addEventListener('input',()=>{
  editVehicleParkNumber.value = editVehicleParkNumber.value.replace(/\D/g,'');
});

editVehicleForm.addEventListener('submit',event=>{
  event.preventDefault();
  if(!editingOriginalRegistration) return;

  const registration = normalizeRegistration(editVehicleRegistration.value);
  const type = editVehicleType.value;
  const parkNumber = type === 'Semi' ? editVehicleParkNumber.value.trim() : '';

  if(registration.length < 2){
    editVehicleError.textContent = 'Saisissez une immatriculation valide.';
    return;
  }

  if(parkData.some(item=>
    normalizeRegistration(item.registration) === registration &&
    normalizeRegistration(item.registration) !== editingOriginalRegistration
  )){
    editVehicleError.textContent = 'Cette immatriculation existe déjà dans le parc.';
    return;
  }

  if(type === 'Semi' && !parkNumber){
    editVehicleError.textContent = 'Le numéro de parc est obligatoire pour une semi-remorque.';
    return;
  }

  if(parkNumber && parkData.some(item=>
    String(item.parkNumber) === parkNumber &&
    normalizeRegistration(item.registration) !== editingOriginalRegistration
  )){
    editVehicleError.textContent = 'Ce numéro de parc est déjà utilisé.';
    return;
  }

  const item = parkData.find(vehicle=>normalizeRegistration(vehicle.registration) === editingOriginalRegistration);
  if(!item) return;

  const oldRegistration = item.registration;
  item.registration = registration;
  item.type = type;
  item.parkNumber = parkNumber;

  propagateVehicleChange(oldRegistration,registration,type,parkNumber);
  saveParkData();
  saveAffectations();

  closeEditVehicleModal();
  renderParkTable();
  renderAffectations();
});

document.getElementById('closeEditVehicle').addEventListener('click',closeEditVehicleModal);
document.getElementById('cancelEditVehicle').addEventListener('click',closeEditVehicleModal);
editVehicleModal.addEventListener('click',event=>{
  if(event.target === editVehicleModal) closeEditVehicleModal();
});

document.getElementById('confirmDeleteVehicle').addEventListener('click',()=>{
  if(!pendingDeleteRegistration) return;
  const index = parkData.findIndex(item=>item.registration === pendingDeleteRegistration);
  if(index !== -1){
    parkData.splice(index,1);
    saveParkData();
    renderParkTable();
    renderAffectations();
  }
  closeDeleteVehicleModal();
});

document.getElementById('openAffectations').addEventListener('click',()=>{
  closeRowActionsMenu();
  showView('affectations','Affectations','parc');
});
document.getElementById('backToPark').addEventListener('click',()=>{
  showView('parc','Parc','parc');
});
document.getElementById('addParkVehicle').addEventListener('click',openAddVehicleModal);
document.getElementById('closeAddVehicle').addEventListener('click',closeAddVehicleModal);
document.getElementById('cancelAddVehicle').addEventListener('click',closeAddVehicleModal);
document.getElementById('closeDeleteVehicle').addEventListener('click',closeDeleteVehicleModal);
document.getElementById('cancelDeleteVehicle').addEventListener('click',closeDeleteVehicleModal);
newVehicleType.addEventListener('change',updateParkNumberField);

newVehicleRegistration.addEventListener('input',()=>{
  let value = newVehicleRegistration.value.toUpperCase().replace(/[^A-Z0-9-]/g,'').replace(/-{2,}/g,'-');
  const registration = normalizeRegistration(value);
  if(!value.includes('-') && registration.length >= 5) value = formatRegistration(registration);
  newVehicleRegistration.value = value;
});

newVehicleRegistration.addEventListener('blur',()=>{
  const registration = normalizeRegistration(newVehicleRegistration.value);
  if(registration.length >= 5) newVehicleRegistration.value = formatRegistration(registration);
});

newVehicleParkNumber.addEventListener('input',()=>{
  newVehicleParkNumber.value = newVehicleParkNumber.value.replace(/\D/g,'');
});

addVehicleForm.addEventListener('submit',event=>{
  event.preventDefault();
  const registration = normalizeRegistration(newVehicleRegistration.value);
  const type = newVehicleType.value;
  const parkNumber = type === 'Semi' ? newVehicleParkNumber.value.trim() : '';

  if(registration.length < 2){
    addVehicleError.textContent = 'Saisissez une immatriculation valide.';
    newVehicleRegistration.focus();
    return;
  }
  if(parkData.some(item=>normalizeRegistration(item.registration) === registration)){
    addVehicleError.textContent = 'Cette immatriculation existe déjà dans le parc.';
    newVehicleRegistration.focus();
    return;
  }
  if(type === 'Semi' && !parkNumber){
    addVehicleError.textContent = 'Le numéro de parc est obligatoire pour une semi-remorque.';
    newVehicleParkNumber.focus();
    return;
  }
  if(parkNumber && parkData.some(item=>String(item.parkNumber) === parkNumber)){
    addVehicleError.textContent = 'Ce numéro de parc est déjà utilisé.';
    newVehicleParkNumber.focus();
    return;
  }

  parkData.push({registration,type,parkNumber});
  saveParkData();
  parkSearch.value = '';
  parkTypeFilter.value = '';
  closeAddVehicleModal();
  renderParkTable();
});

document.addEventListener('click',event=>{
  if(!rowActionsMenu.hidden && !rowActionsMenu.contains(event.target) && !event.target.closest('.row-menu')) closeRowActionsMenu();
});

window.addEventListener('resize',closeRowActionsMenu);
window.addEventListener('scroll',closeRowActionsMenu,true);
navButtons.forEach(button=>button.addEventListener('click',closeRowActionsMenu));

addVehicleModal.addEventListener('click',event=>{
  if(event.target === addVehicleModal) closeAddVehicleModal();
});
deleteVehicleModal.addEventListener('click',event=>{
  if(event.target === deleteVehicleModal) closeDeleteVehicleModal();
});

document.addEventListener('keydown',event=>{
  if(event.key !== 'Escape') return;
  if(!deleteAssignmentModal.hidden) closeDeleteAssignmentModal();
  else if(!editAssignmentModal.hidden) closeEditAssignmentModal();
  else if(!addAssignmentModal.hidden) closeAddAssignmentModal();
  else if(!deleteVehicleModal.hidden) closeDeleteVehicleModal();
  else if(!editVehicleModal.hidden) closeEditVehicleModal();
  else if(!addVehicleModal.hidden) closeAddVehicleModal();
  else{
    closeAffectationActionsMenu();
    closeRowActionsMenu();
  }
});



function csvEscape(value){
  const text = String(value ?? '').replace(/"/g,'""');
  return `"${text}"`;
}

function downloadCsv(filename,headers,rows){
  const content = '\uFEFF' + [
    headers.map(csvEscape).join(';'),
    ...rows.map(row=>row.map(csvEscape).join(';'))
  ].join('\r\n');

  const blob = new Blob([content],{type:'text/csv;charset=utf-8;'});
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

document.getElementById('exportParkCsv').addEventListener('click',()=>{
  const rows = [...parkData]
    .sort((a,b)=>
      (parkTypeOrder[a.type] ?? 99) - (parkTypeOrder[b.type] ?? 99) ||
      normalizeRegistration(a.registration).localeCompare(normalizeRegistration(b.registration),'fr',{numeric:true})
    )
    .map(item=>[formatRegistration(item.registration),item.type,item.parkNumber || '']);
  downloadCsv('Parc_vehicules.csv',['Immatriculation','Type','N° de parc'],rows);
});

document.getElementById('exportAssignmentsCsv').addEventListener('click',()=>{
  const rows = [...affectations]
    .sort((a,b)=>a.name.localeCompare(b.name,'fr',{sensitivity:'base'}))
    .map(item=>[
      item.name,
      item.tractor ? formatRegistration(item.tractor) : '',
      item.semi ? formatRegistration(item.semi) : '',
      item.number || '',
      item.phone || '',
      item.personal || ''
    ]);
  downloadCsv('Affectations.csv',['Chauffeur','Tracteur','Semi','N°','Téléphone pro','N° personnel'],rows);
});


const affTable = document.getElementById('affTable');
const affSearch = document.getElementById('affSearch');
const affCount = document.getElementById('affCount');
const affTotal = document.getElementById('affTotal');
const affAssigned = document.getElementById('affAssigned');
const affUnassigned = document.getElementById('affUnassigned');
const affIssues = document.getElementById('affIssues');
const affName = document.getElementById('affName');
const affTractor = document.getElementById('affTractor');
const affSemi = document.getElementById('affSemi');
const affNumber = document.getElementById('affNumber');
const affPhone = document.getElementById('affPhone');
const affPersonal = document.getElementById('affPersonal');
const affNotice = document.getElementById('affNotice');
const saveAssignment = document.getElementById('saveAssignment');
const selectedDriverName = document.getElementById('selectedDriverName');
const addAssignmentButton = document.getElementById('addAssignment');
const addAssignmentModal = document.getElementById('addAssignmentModal');
const addAssignmentForm = document.getElementById('addAssignmentForm');
const newAssignmentName = document.getElementById('newAssignmentName');
const newAssignmentTractor = document.getElementById('newAssignmentTractor');
const newAssignmentSemi = document.getElementById('newAssignmentSemi');
const newAssignmentNumber = document.getElementById('newAssignmentNumber');
const newAssignmentPhone = document.getElementById('newAssignmentPhone');
const newAssignmentPersonal = document.getElementById('newAssignmentPersonal');
const addAssignmentError = document.getElementById('addAssignmentError');
const affectationActionsMenu = document.getElementById('affectationActionsMenu');
const editAffectationOption = document.getElementById('editAffectationOption');
const deleteAffectationOption = document.getElementById('deleteAffectationOption');
const editAssignmentModal = document.getElementById('editAssignmentModal');
const deleteAssignmentModal = document.getElementById('deleteAssignmentModal');
const deleteAssignmentName = document.getElementById('deleteAssignmentName');

let selectedAffectationIndex = -1;
let activeAffectationIndex = -1;
let activeAffectationActionButton = null;
let pendingDeleteAffectationIndex = -1;

function normalizeAffText(value){
  return String(value ?? '')
    .toLocaleLowerCase('fr')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g,'')
    .replace(/[^a-z0-9]/g,'');
}

function saveAffectations(){
  try{
    localStorage.setItem(AFFECT_STORAGE_KEY,JSON.stringify(affectations));
    if(typeof renderVidTable==='function')renderVidTable();
    if(selectedVidangeId && typeof loadVidDetail==='function')loadVidDetail();
    return true;
  }catch(error){
    console.warn('Impossible d’enregistrer les affectations dans ce navigateur.',error);
    return false;
  }
}

function vehicleExistsInPark(value,type){
  const normalized = normalizeRegistration(value);
  if(!normalized) return true;
  return parkData.some(item=>item.type === type && normalizeRegistration(item.registration) === normalized);
}

function affectationHasIssue(item){
  return (
    (normalizeRegistration(item.tractor) && !vehicleExistsInPark(item.tractor,'Tracteur')) ||
    (normalizeRegistration(item.semi) && !vehicleExistsInPark(item.semi,'Semi'))
  );
}

function updateAffectationStats(){
  affTotal.textContent = affectations.length;
  affAssigned.textContent = affectations.filter(item=>normalizeRegistration(item.tractor)).length;
  affUnassigned.textContent = affectations.filter(item=>!normalizeRegistration(item.tractor)).length;
  affIssues.textContent = affectations.filter(affectationHasIssue).length;
}

function setAffectationFieldsDisabled(disabled){
  [affName,affTractor,affSemi,affNumber,affPhone,affPersonal,saveAssignment].forEach(element=>{
    element.disabled = disabled;
  });
}

function vehicleOptions(type){
  return parkData
    .filter(item=>item.type === type)
    .sort((a,b)=>normalizeRegistration(a.registration).localeCompare(
      normalizeRegistration(b.registration),'fr',{numeric:true,sensitivity:'base'}
    ));
}

function ensureSelectValue(select,value){
  const normalized = normalizeRegistration(value);
  if(!normalized){
    select.value = '';
    return;
  }
  const formatted = formatRegistration(normalized);
  const exists = [...select.options].some(option=>normalizeRegistration(option.value) === normalized);
  if(!exists){
    const option = document.createElement('option');
    option.value = formatted;
    option.textContent = `${formatted} · Hors Parc`;
    option.dataset.outsidePark = 'true';
    select.appendChild(option);
  }
  const match = [...select.options].find(option=>normalizeRegistration(option.value) === normalized);
  if(match) select.value = match.value;
}

function populateVehicleSelects(){
  if(!affTractor || !affSemi) return;
  const tractorValue = affTractor.value;
  const semiValue = affSemi.value;

  affTractor.innerHTML = '<option value="">—</option>' + vehicleOptions('Tracteur').map(item=>{
    const plate = formatRegistration(item.registration);
    return `<option value="${plate}">${plate}</option>`;
  }).join('');

  affSemi.innerHTML = '<option value="">—</option>' + vehicleOptions('Semi').map(item=>{
    const plate = formatRegistration(item.registration);
    return `<option value="${plate}">${plate}</option>`;
  }).join('');

  if(tractorValue) ensureSelectValue(affTractor,tractorValue);
  if(semiValue) ensureSelectValue(affSemi,semiValue);
}


function populateNewAssignmentSelects(){
  newAssignmentTractor.innerHTML = '<option value="">—</option>' + vehicleOptions('Tracteur').map(item=>{
    const plate = formatRegistration(item.registration);
    return `<option value="${plate}">${plate}</option>`;
  }).join('');

  newAssignmentSemi.innerHTML = '<option value="">—</option>' + vehicleOptions('Semi').map(item=>{
    const plate = formatRegistration(item.registration);
    return `<option value="${plate}">${plate}</option>`;
  }).join('');
}

function openAddAssignmentModal(){
  closeRowActionsMenu();
  addAssignmentForm.reset();
  addAssignmentError.textContent = '';
  populateNewAssignmentSelects();
  populateAssignmentDriverChoices(newAssignmentName);
  addAssignmentModal.hidden = false;
  syncModalState();
  requestAnimationFrame(()=>newAssignmentName.focus());
}

function closeAddAssignmentModal(){
  addAssignmentModal.hidden = true;
  addAssignmentError.textContent = '';
  syncModalState();
}


function openEditAssignmentModal(index){
  if(index < 0 || !affectations[index]) return;
  selectedAffectationIndex = index;
  loadSelectedAffectation();
  renderAffectations();
  editAssignmentModal.hidden = false;
  syncModalState();
  requestAnimationFrame(()=>affTractor.focus());
}

function closeEditAssignmentModal(){
  editAssignmentModal.hidden = true;
  affNotice.textContent = '';
  selectedAffectationIndex = -1;
  setAffectationFieldsDisabled(true);
  renderAffectations();
  syncModalState();
}

function closeAffectationActionsMenu(){
  if(activeAffectationActionButton) activeAffectationActionButton.setAttribute('aria-expanded','false');
  affectationActionsMenu.hidden = true;
  activeAffectationIndex = -1;
  activeAffectationActionButton = null;
}

function openAffectationActionsMenu(button,index){
  closeAffectationActionsMenu();
  activeAffectationIndex = index;
  activeAffectationActionButton = button;
  button.setAttribute('aria-expanded','true');
  affectationActionsMenu.hidden = false;

  const buttonRect = button.getBoundingClientRect();
  const menuRect = affectationActionsMenu.getBoundingClientRect();
  const left = Math.max(10,Math.min(buttonRect.right - menuRect.width,window.innerWidth - menuRect.width - 10));
  let top = buttonRect.bottom + 6;
  if(top + menuRect.height > window.innerHeight - 10) top = buttonRect.top - menuRect.height - 6;
  affectationActionsMenu.style.left = `${left}px`;
  affectationActionsMenu.style.top = `${Math.max(10,top)}px`;
}

function clearSelectedAffectation(){
  selectedAffectationIndex = -1;
  selectedDriverName.textContent = 'Aucun chauffeur sélectionné';
  affName.value = '';
  affTractor.value = '';
  affSemi.value = '';
  affNumber.value = '';
  affPhone.value = '';
  affPersonal.value = '';
  affNotice.textContent = '';
  setAffectationFieldsDisabled(true);
}

function openDeleteAssignmentModal(index){
  const item = affectations[index];
  if(!item) return;
  pendingDeleteAffectationIndex = index;
  deleteAssignmentName.textContent = item.name;
  deleteAssignmentModal.hidden = false;
  syncModalState();
  requestAnimationFrame(()=>document.getElementById('confirmDeleteAssignment').focus());
}

function closeDeleteAssignmentModal(){
  deleteAssignmentModal.hidden = true;
  pendingDeleteAffectationIndex = -1;
  syncModalState();
}

function renderAffectations(){
  const query = normalizeAffText(affSearch.value);
  const filtered = affectations
    .map((item,index)=>({item,index}))
    .filter(({item})=>normalizeAffText(
      `${item.name} ${item.tractor} ${item.semi} ${item.number} ${item.phone} ${item.personal}`
    ).includes(query));

  if(!filtered.length){
    affTable.innerHTML = '<tr><td colspan="8" class="empty-row">Aucune affectation ne correspond à votre recherche.</td></tr>';
  }else{
    affTable.innerHTML = filtered.map(({item,index})=>{
      const tractor = item.tractor ? formatRegistration(item.tractor) : '—';
      const semi = item.semi ? formatRegistration(item.semi) : '—';
      const tractorIssue = normalizeRegistration(item.tractor) && !vehicleExistsInPark(item.tractor,'Tracteur');
      const semiIssue = normalizeRegistration(item.semi) && !vehicleExistsInPark(item.semi,'Semi');
      return `
        <tr data-index="${index}" class="${index === selectedAffectationIndex ? 'selected' : ''}">
          <td><strong>${item.name}</strong></td>
          <td class="${item.tractor ? 'aff-plate' : 'aff-empty'}" ${item.tractor ? `data-open-vehicle="${tractor}" title="Ouvrir la fiche véhicule"` : ''}>${tractor}${tractorIssue ? '<span class="issue-badge">HORS PARC</span>' : ''}</td>
          <td class="${item.semi ? 'aff-plate' : 'aff-empty'}" ${item.semi ? `data-open-vehicle="${semi}" title="Ouvrir la fiche véhicule"` : ''}>${semi}${semiIssue ? '<span class="issue-badge">HORS PARC</span>' : ''}</td>
          <td class="${item.number ? '' : 'aff-empty'}">${item.number || '—'}</td>
          <td class="${item.phone ? '' : 'aff-empty'}">${item.phone || '—'}</td>
          <td class="${item.personal ? '' : 'aff-empty'}">${item.personal || '—'}</td>
          <td>${dashboardModificationHtml(item)}</td>
          <td>
            <button
              class="row-menu affectation-row-menu"
              type="button"
              data-index="${index}"
              aria-label="Actions pour ${item.name}"
              aria-haspopup="menu"
              aria-expanded="false"
            >•••</button>
          </td>
        </tr>
      `;
    }).join('');
  }

  updateAffectationStats();
  updateParkStats();
  affCount.textContent = `${filtered.length} chauffeur${filtered.length > 1 ? 's' : ''} affiché${filtered.length > 1 ? 's' : ''}`;
}

function loadSelectedAffectation(){
  const item = affectations[selectedAffectationIndex];
  if(!item) return;

  populateVehicleSelects();
  populateAssignmentDriverChoices(affName,item.name);
  selectedDriverName.textContent = item.name;
  affName.value = item.name;
  ensureSelectValue(affTractor,item.tractor);
  ensureSelectValue(affSemi,item.semi);
  affNumber.value = item.number || '';
  affPhone.value = item.phone || '';
  affPersonal.value = item.personal || '';
  affNotice.textContent = '';
  setAffectationFieldsDisabled(false);
}

affSearch.addEventListener('input',renderAffectations);

affName.addEventListener('change',()=>{
  selectedDriverName.textContent=affName.value || 'Aucun chauffeur sélectionné';
  affNotice.textContent='';
});

affTable.addEventListener('click',event=>{
  const actionButton = event.target.closest('.affectation-row-menu');
  if(actionButton){
    event.stopPropagation();
    openAffectationActionsMenu(actionButton,Number(actionButton.dataset.index));
    return;
  }

  if(event.target.closest('tr[data-index]')){
    closeAffectationActionsMenu();
  }
});

affSemi.addEventListener('change',()=>{
  const normalized = normalizeRegistration(affSemi.value);
  if(!normalized){
    affNumber.value = '';
    return;
  }
  const semi = parkData.find(item=>item.type === 'Semi' && normalizeRegistration(item.registration) === normalized);
  if(semi && semi.parkNumber) affNumber.value = semi.parkNumber;
});


addAssignmentButton.addEventListener('click',openAddAssignmentModal);
document.getElementById('closeAddAssignment').addEventListener('click',closeAddAssignmentModal);
document.getElementById('cancelAddAssignment').addEventListener('click',closeAddAssignmentModal);

newAssignmentSemi.addEventListener('change',()=>{
  const normalized = normalizeRegistration(newAssignmentSemi.value);
  if(!normalized){
    newAssignmentNumber.value = '';
    return;
  }
  const semi = parkData.find(item=>item.type === 'Semi' && normalizeRegistration(item.registration) === normalized);
  newAssignmentNumber.value = semi && semi.parkNumber ? semi.parkNumber : '';
});

newAssignmentNumber.addEventListener('input',()=>{
  newAssignmentNumber.value = newAssignmentNumber.value.replace(/\D/g,'');
});

addAssignmentForm.addEventListener('submit',event=>{
  event.preventDefault();
  const name = newAssignmentName.value.trim().replace(/\s+/g,' ');
  const normalizedName = normalizeAffText(name);

  if(!name){
    addAssignmentError.textContent = 'Sélectionnez un chauffeur.';
    newAssignmentName.focus();
    return;
  }
  if(!driverAllowsMultipleAssignments(name) && affectations.some(item=>normalizeAffText(item.name) === normalizedName)){
    addAssignmentError.textContent = 'Ce chauffeur possède déjà une affectation. Seuls les chauffeurs Régionaux peuvent avoir plusieurs affectations.';
    newAssignmentName.focus();
    return;
  }

  const newItem = {
    name,
    tractor: newAssignmentTractor.value ? formatRegistration(newAssignmentTractor.value) : '',
    semi: newAssignmentSemi.value ? formatRegistration(newAssignmentSemi.value) : '',
    number: newAssignmentNumber.value.trim(),
    phone: newAssignmentPhone.value.trim(),
    personal: newAssignmentPersonal.value.trim()
  };

  const assignmentError=dashboardValidateAssignment(newItem,-1);
  if(assignmentError){
    addAssignmentError.textContent=assignmentError;
    return;
  }

  affectations.push(newItem);
  affectations.sort((a,b)=>a.name.localeCompare(b.name,'fr',{sensitivity:'base'}));
  selectedAffectationIndex = -1;
  saveAffectations();

  affSearch.value = '';
  closeAddAssignmentModal();
  renderAffectations();
});

addAssignmentModal.addEventListener('click',event=>{
  if(event.target === addAssignmentModal) closeAddAssignmentModal();
});

editAffectationOption.addEventListener('click',()=>{
  if(activeAffectationIndex < 0) return;
  const index = activeAffectationIndex;
  closeAffectationActionsMenu();
  openEditAssignmentModal(index);
});

deleteAffectationOption.addEventListener('click',()=>{
  if(activeAffectationIndex < 0) return;
  const index = activeAffectationIndex;
  closeAffectationActionsMenu();
  openDeleteAssignmentModal(index);
});

document.getElementById('confirmDeleteAssignment').addEventListener('click',()=>{
  if(pendingDeleteAffectationIndex < 0 || !affectations[pendingDeleteAffectationIndex]) return;

  const deletedIndex = pendingDeleteAffectationIndex;
  affectations.splice(deletedIndex,1);
  const saved = saveAffectations();

  if(selectedAffectationIndex === deletedIndex){
    clearSelectedAffectation();
  }else if(selectedAffectationIndex > deletedIndex){
    selectedAffectationIndex -= 1;
  }

  selectedAffectationIndex = -1;
  closeDeleteAssignmentModal();
  renderAffectations();
});

document.getElementById('closeEditAssignment').addEventListener('click',closeEditAssignmentModal);
document.getElementById('cancelEditAssignment').addEventListener('click',closeEditAssignmentModal);
editAssignmentModal.addEventListener('click',event=>{
  if(event.target === editAssignmentModal) closeEditAssignmentModal();
});

document.getElementById('closeDeleteAssignment').addEventListener('click',closeDeleteAssignmentModal);
document.getElementById('cancelDeleteAssignment').addEventListener('click',closeDeleteAssignmentModal);
deleteAssignmentModal.addEventListener('click',event=>{
  if(event.target === deleteAssignmentModal) closeDeleteAssignmentModal();
});

document.addEventListener('click',event=>{
  if(!affectationActionsMenu.hidden &&
     !affectationActionsMenu.contains(event.target) &&
     !event.target.closest('.affectation-row-menu')){
    closeAffectationActionsMenu();
  }
});

window.addEventListener('resize',closeAffectationActionsMenu);
window.addEventListener('scroll',closeAffectationActionsMenu,true);
navButtons.forEach(button=>button.addEventListener('click',closeAffectationActionsMenu));

saveAssignment.addEventListener('click',()=>{
  const item = affectations[selectedAffectationIndex];
  if(!item) return;

  const selectedName=String(affName.value||'').trim();
  if(!selectedName){
    affNotice.style.color='#ff7373';
    affNotice.textContent='Sélectionnez un chauffeur.';
    affName.focus();
    return;
  }

  const duplicateDriver=!driverAllowsMultipleAssignments(selectedName) && affectations.some((other,index)=>
    index!==selectedAffectationIndex && normalizeAffText(other.name)===normalizeAffText(selectedName)
  );
  if(duplicateDriver){
    affNotice.style.color='#ff7373';
    affNotice.textContent='Ce chauffeur possède déjà une affectation. Seuls les chauffeurs Régionaux peuvent avoir plusieurs affectations.';
    affName.focus();
    return;
  }

  const candidate={
    ...item,
    name:selectedName,
    tractor:affTractor.value ? formatRegistration(affTractor.value) : '',
    semi:affSemi.value ? formatRegistration(affSemi.value) : '',
    number:affNumber.value.trim(),
    phone:affPhone.value.trim(),
    personal:affPersonal.value.trim()
  };

  const assignmentError=dashboardValidateAssignment(candidate,selectedAffectationIndex);
  if(assignmentError){
    alert(assignmentError);
    return;
  }

  Object.assign(item,candidate);
  affectations.sort((a,b)=>a.name.localeCompare(b.name,'fr',{sensitivity:'base'}));

  saveAffectations();
  closeEditAssignmentModal();
  renderAffectations();
});


renderParkTable();
populateVehicleSelects();
populateNewAssignmentSelects();
renderAffectations();
setAffectationFieldsDisabled(true);


/* ===== PAGE CHAUFFEUR ===== */
const DRIVER_STORAGE_KEY = 'hessers-driver-profiles-v1';

function splitDriverDisplayName(displayName){
  const parts = String(displayName || '').trim().split(/\s+/).filter(Boolean);
  if(!parts.length) return {lastName:'',firstName:''};
  if(parts.length === 1) return {lastName:parts[0],firstName:''};
  return {
    lastName: parts.slice(0,-1).join(' '),
    firstName: parts[parts.length-1]
  };
}

function createDriverFromName(displayName){
  const split = splitDriverDisplayName(displayName);
  return {
    id: 'drv_' + Math.random().toString(36).slice(2) + Date.now().toString(36),
    lastName: split.lastName,
    firstName: split.firstName,
    status: 'titulaire',
    birthDate: '',
    birthCity: '',
    birthPostalCode: '',
    phone: '',
    address: '',
    postalCode: '',
    city: '',
    licenseNumber: '',
    licenseIssueDate: '',
    licenseExpiry: ''
  };
}

function seedDriversFromAffectations(){
  const seen = new Set();
  return affectations
    .filter(item=>String(item.name || '').trim())
    .filter(item=>{
      const key = normalizeAffText(item.name);
      if(seen.has(key)) return false;
      seen.add(key);
      return true;
    })
    .map(item=>{
      const driver = createDriverFromName(item.name);
      driver.phone = String(item.phone || '').trim();
      return driver;
    })
    .sort((a,b)=>
      a.lastName.localeCompare(b.lastName,'fr',{sensitivity:'base'}) ||
      a.firstName.localeCompare(b.firstName,'fr',{sensitivity:'base'})
    );
}

let driverProfiles = [];
try{
  const storedDrivers = JSON.parse(localStorage.getItem(DRIVER_STORAGE_KEY));
  if(Array.isArray(storedDrivers)){
    driverProfiles = storedDrivers;
  }
}catch(error){
  console.warn('Impossible de lire les fiches chauffeurs.',error);
}
if(!driverProfiles.length){
  driverProfiles = seedDriversFromAffectations();
}

// Mise à niveau des fiches déjà enregistrées :
// - ajout de la ville de naissance
// - récupération du téléphone depuis Affectations lorsqu'il est vide
const affectationPhoneByName = new Map(
  affectations.map(item=>[
    normalizeAffText(item.name),
    String(item.phone || '').trim()
  ])
);
let driverProfilesMigrated = false;
const DRIVER_STATUSES={titulaire:'Titulaire',regional:'Régional',jockey:'Jockey'};
function normalizeDriverStatus(value){
  const raw=String(value||'').trim().toLowerCase();
  if(raw==='regional'||raw==='régional') return 'regional';
  if(raw==='jockey') return 'jockey';
  return 'titulaire';
}
function driverStatusLabel(driver){ return DRIVER_STATUSES[normalizeDriverStatus(driver?.status)]||'Titulaire'; }
function driverByDisplayName(name){
  const key=normalizeAffText(name);
  return driverProfiles.find(driver=>normalizeAffText(driverDisplayName(driver))===key)||null;
}
function driverAllowsMultipleAssignments(name){
  const driver=driverByDisplayName(name);
  return !!driver && normalizeDriverStatus(driver.status)==='regional';
}
driverProfiles.forEach(driver=>{
  const normalizedStatus=normalizeDriverStatus(driver.status);
  if(driver.status!==normalizedStatus){
    driver.status=normalizedStatus;
    driverProfilesMigrated=true;
  }
  if(typeof driver.birthCity !== 'string'){
    driver.birthCity = '';
    driverProfilesMigrated = true;
  }
  if(typeof driver.birthPostalCode !== 'string'){
    driver.birthPostalCode = '';
    driverProfilesMigrated = true;
  }
  if(!String(driver.phone || '').trim()){
    const key = normalizeAffText(`${driver.lastName} ${driver.firstName}`);
    const phone = affectationPhoneByName.get(key);
    if(phone){
      driver.phone = phone;
      driverProfilesMigrated = true;
    }
  }
  delete driver.fimoExpiry;
  delete driver.medicalExpiry;
  delete driver.adrExpiry;
});
if(driverProfilesMigrated){
  try{
    localStorage.setItem(DRIVER_STORAGE_KEY,JSON.stringify(driverProfiles));
  }catch(error){}
}

function saveDriverProfiles(){
  try{
    localStorage.setItem(DRIVER_STORAGE_KEY,JSON.stringify(driverProfiles));
    return true;
  }catch(error){
    console.warn('Impossible d’enregistrer les fiches chauffeurs.',error);
    return false;
  }
}

const driverList = document.getElementById('driverList');

function populateAssignmentDriverChoices(select,currentName=''){
  if(!select) return;

  const currentKey=normalizeAffText(currentName);
  const assignedNames=new Set(
    affectations
      .map(item=>normalizeAffText(item.name))
      .filter(Boolean)
  );

  const choices=(Array.isArray(driverProfiles)?driverProfiles:[])
    .map(driver=>({
      name:driverDisplayName(driver),
      lastName:String(driver.lastName||''),
      firstName:String(driver.firstName||''),
      status:normalizeDriverStatus(driver.status)
    }))
    .filter(item=>item.name)
    .sort((a,b)=>
      a.lastName.localeCompare(b.lastName,'fr',{sensitivity:'base'}) ||
      a.firstName.localeCompare(b.firstName,'fr',{sensitivity:'base'})
    );

  const seen=new Set();
  let options='<option value="">— Sélectionner un chauffeur —</option>';

  choices.forEach(item=>{
    const key=normalizeAffText(item.name);
    if(!key || seen.has(key)) return;
    seen.add(key);
    const allowsMultiple=item.status==='regional';
    const alreadyAssigned=assignedNames.has(key) && key!==currentKey && !allowsMultiple;
    const statusLabel=DRIVER_STATUSES[item.status]||'Titulaire';
    const suffix=alreadyAssigned?' · Déjà affecté':allowsMultiple?' · Régional · Multi-affectation':` · ${statusLabel}`;
    options += `<option value="${item.name.replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}" ${alreadyAssigned?'disabled':''}>${item.name}${suffix}</option>`;
  });

  if(currentName && !seen.has(currentKey)){
    const safe=String(currentName)
      .replace(/&/g,'&amp;')
      .replace(/"/g,'&quot;')
      .replace(/</g,'&lt;')
      .replace(/>/g,'&gt;');
    options += `<option value="${safe}">${safe}</option>`;
  }

  select.innerHTML=options;
  if(currentName) select.value=currentName;
}

const driverSearch = document.getElementById('driverSearch');
const driverListCount = document.getElementById('driverListCount');
const driverEmptyState = document.getElementById('driverEmptyState');
const driverDetailContent = document.getElementById('driverDetailContent');
const driverDetailName = document.getElementById('driverDetailName');
const driverBigAvatar = document.getElementById('driverBigAvatar');
const driverLastName = document.getElementById('driverLastName');
const driverFirstName = document.getElementById('driverFirstName');
const driverStatus = document.getElementById('driverStatus');
const driverBirthDate = document.getElementById('driverBirthDate');
const driverBirthCity = document.getElementById('driverBirthCity');
const driverBirthPostalCode = document.getElementById('driverBirthPostalCode');
const driverPhone = document.getElementById('driverPhone');
const driverAddress = document.getElementById('driverAddress');
const driverPostalCode = document.getElementById('driverPostalCode');
const driverCity = document.getElementById('driverCity');
const driverLicenseNumber = document.getElementById('driverLicenseNumber');
const driverLicenseIssueDate = document.getElementById('driverLicenseIssueDate');
const driverLicenseExpiry = document.getElementById('driverLicenseExpiry');
const driverSaveNotice = document.getElementById('driverSaveNotice');
const saveDriverButton = document.getElementById('saveDriver');

const driverActionsMenu = document.getElementById('driverActionsMenu');
const deleteDriverOption = document.getElementById('deleteDriverOption');
const addDriverModal = document.getElementById('addDriverModal');
const addDriverForm = document.getElementById('addDriverForm');
const newDriverLastName = document.getElementById('newDriverLastName');
const newDriverFirstName = document.getElementById('newDriverFirstName');
const newDriverStatus = document.getElementById('newDriverStatus');
const newDriverBirthDate = document.getElementById('newDriverBirthDate');
const newDriverBirthCity = document.getElementById('newDriverBirthCity');
const newDriverBirthPostalCode = document.getElementById('newDriverBirthPostalCode');
const newDriverPhone = document.getElementById('newDriverPhone');
const newDriverAddress = document.getElementById('newDriverAddress');
const newDriverPostalCode = document.getElementById('newDriverPostalCode');
const newDriverCity = document.getElementById('newDriverCity');
const newDriverLicenseNumber = document.getElementById('newDriverLicenseNumber');
const newDriverLicenseIssueDate = document.getElementById('newDriverLicenseIssueDate');
const newDriverLicenseExpiry = document.getElementById('newDriverLicenseExpiry');
const addDriverError = document.getElementById('addDriverError');
const deleteDriverModal = document.getElementById('deleteDriverModal');
const deleteDriverName = document.getElementById('deleteDriverName');

let selectedDriverId = null;
let activeDriverId = null;
let activeDriverMenuButton = null;
let pendingDeleteDriverId = null;

function driverDisplayName(item){
  return [item.lastName,item.firstName].filter(Boolean).join(' ').trim();
}
function driverInitials(item){
  const a = (item.lastName || '').trim().charAt(0);
  const b = (item.firstName || '').trim().charAt(0);
  return (a+b).toUpperCase() || '—';
}
function driverSecondaryLine(item){
  const parts = [];
  if(item.city) parts.push(item.city);
  if(item.phone) parts.push(item.phone);
  if(item.licenseNumber) parts.push('Permis ' + item.licenseNumber);
  return parts.join(' · ') || 'Informations à compléter';
}
function driverStatusBadge(item){
  const status=normalizeDriverStatus(item?.status);
  return `<span class="driver-status-badge ${status}">${DRIVER_STATUSES[status]}</span>`;
}

function renderDriverList(){
  const q = normalizeAffText(driverSearch.value);
  const visible = [...driverProfiles]
    .filter(item=>normalizeAffText(`${item.lastName} ${item.firstName} ${driverStatusLabel(item)} ${item.birthCity||''} ${item.birthPostalCode||''} ${item.city} ${item.phone} ${item.licenseNumber} ${item.licenseIssueDate||''}`).includes(q))
    .sort((a,b)=>
      a.lastName.localeCompare(b.lastName,'fr',{sensitivity:'base'}) ||
      a.firstName.localeCompare(b.firstName,'fr',{sensitivity:'base'})
    );

  if(!visible.length){
    driverList.innerHTML = '<div class="empty-row">Aucun chauffeur ne correspond à votre recherche.</div>';
  }else{
    driverList.innerHTML = visible.map(item=>`
      <div class="driver-item ${item.id === selectedDriverId ? 'selected' : ''}" data-driver-id="${item.id}">
        <div class="driver-avatar">${driverInitials(item)}</div>
        <div>
          <div class="driver-list-name">${driverDisplayName(item) || 'Sans nom'}${driverStatusBadge(item)}</div>
          <div class="driver-list-sub">${driverSecondaryLine(item)}</div>
        </div>
        <button class="driver-menu-btn" type="button" data-driver-menu="${item.id}" aria-label="Actions pour ${driverDisplayName(item)}">•••</button>
      </div>
    `).join('');
  }

  driverListCount.textContent = `${visible.length} chauffeur${visible.length > 1 ? 's' : ''} affiché${visible.length > 1 ? 's' : ''}`;
}

function getSelectedDriver(){
  return driverProfiles.find(item=>item.id === selectedDriverId) || null;
}

function fillDriverForm(){
  const item = getSelectedDriver();
  if(!item){
    driverEmptyState.hidden = false;
    driverDetailContent.hidden = true;
    return;
  }

  driverEmptyState.hidden = true;
  driverDetailContent.hidden = false;
  driverDetailName.textContent = driverDisplayName(item) || 'Fiche chauffeur';
  driverBigAvatar.textContent = driverInitials(item);

  driverLastName.value = item.lastName || '';
  driverFirstName.value = item.firstName || '';
  driverStatus.value = normalizeDriverStatus(item.status);
  driverBirthDate.value = item.birthDate || '';
  driverBirthCity.value = item.birthCity || '';
  driverBirthPostalCode.value = item.birthPostalCode || '';
  driverPhone.value = item.phone || '';
  driverAddress.value = item.address || '';
  driverPostalCode.value = item.postalCode || '';
  driverCity.value = item.city || '';
  driverLicenseNumber.value = item.licenseNumber || '';
  driverLicenseIssueDate.value = item.licenseIssueDate || '';
  driverLicenseExpiry.value = item.licenseExpiry || '';
  driverSaveNotice.textContent = '';
}

function closeDriverActionsMenu(){
  driverActionsMenu.hidden = true;
  activeDriverId = null;
  activeDriverMenuButton = null;
}

function openDriverActionsMenu(button,id){
  closeDriverActionsMenu();
  activeDriverId = id;
  activeDriverMenuButton = button;
  driverActionsMenu.hidden = false;

  const buttonRect = button.getBoundingClientRect();
  const menuRect = driverActionsMenu.getBoundingClientRect();
  const left = Math.max(10,Math.min(buttonRect.right-menuRect.width,window.innerWidth-menuRect.width-10));
  let top = buttonRect.bottom+6;
  if(top+menuRect.height > window.innerHeight-10) top = buttonRect.top-menuRect.height-6;
  driverActionsMenu.style.left = `${left}px`;
  driverActionsMenu.style.top = `${Math.max(10,top)}px`;
}

driverList.addEventListener('click',event=>{
  const menuButton = event.target.closest('[data-driver-menu]');
  if(menuButton){
    event.stopPropagation();
    openDriverActionsMenu(menuButton,menuButton.dataset.driverMenu);
    return;
  }

  const item = event.target.closest('[data-driver-id]');
  if(!item) return;
  closeDriverActionsMenu();
  selectedDriverId = item.dataset.driverId;
  renderDriverList();
  fillDriverForm();
});

driverSearch.addEventListener('input',renderDriverList);

driverPostalCode.addEventListener('input',()=>{
  driverPostalCode.value = driverPostalCode.value.replace(/\D/g,'').slice(0,5);
});

saveDriverButton.addEventListener('click',()=>{
  const item = getSelectedDriver();
  if(!item) return;

  const nextStatus=normalizeDriverStatus(driverStatus.value);
  const currentName=driverDisplayName(item);
  const assignmentCount=affectations.filter(assignment=>normalizeAffText(assignment.name)===normalizeAffText(currentName)).length;
  if(nextStatus!=='regional' && assignmentCount>1){
    driverSaveNotice.style.color='#ff7373';
    driverSaveNotice.textContent=`Ce chauffeur possède ${assignmentCount} affectations. Réduisez-les à une avant de passer en ${DRIVER_STATUSES[nextStatus]}.`;
    driverStatus.value=normalizeDriverStatus(item.status);
    return;
  }

  item.lastName = driverLastName.value.trim().toUpperCase();
  item.firstName = driverFirstName.value.trim();
  item.status = nextStatus;
  item.birthDate = driverBirthDate.value;
  item.birthCity = driverBirthCity.value.trim();
  item.birthPostalCode = driverBirthPostalCode.value.trim().toUpperCase();
  item.phone = driverPhone.value.trim();
  item.address = driverAddress.value.trim();
  item.postalCode = driverPostalCode.value.trim();
  item.city = driverCity.value.trim();
  item.licenseNumber = driverLicenseNumber.value.trim();
  item.licenseIssueDate = driverLicenseIssueDate.value;
  item.licenseExpiry = driverLicenseExpiry.value;

  const saved = saveDriverProfiles();
  driverDetailName.textContent = driverDisplayName(item);
  driverBigAvatar.textContent = driverInitials(item);
  driverSaveNotice.style.color = saved ? '#57d883' : '#ff7373';
  driverSaveNotice.textContent = saved ? 'Modifications enregistrées.' : 'Impossible d’enregistrer les modifications.';
  renderDriverList();
});

function syncDriverModalState(){
  const currentModalOpen =
    !addDriverModal.hidden ||
    !deleteDriverModal.hidden;
  if(currentModalOpen) document.body.classList.add('modal-open');
  else if(
    document.querySelectorAll('.modal-overlay:not([hidden])').length === 0
  ) document.body.classList.remove('modal-open');
}

function openAddDriverModal(){
  addDriverForm.reset();
  if(newDriverStatus) newDriverStatus.value='titulaire';
  addDriverError.textContent = '';
  addDriverModal.hidden = false;
  syncDriverModalState();
  requestAnimationFrame(()=>newDriverLastName.focus());
}
function closeAddDriverModal(){
  addDriverModal.hidden = true;
  addDriverError.textContent = '';
  syncDriverModalState();
}

newDriverPostalCode.addEventListener('input',()=>{
  newDriverPostalCode.value = newDriverPostalCode.value.replace(/\D/g,'').slice(0,5);
});

document.getElementById('addDriver').addEventListener('click',openAddDriverModal);
document.getElementById('closeAddDriver').addEventListener('click',closeAddDriverModal);
document.getElementById('cancelAddDriver').addEventListener('click',closeAddDriverModal);
addDriverModal.addEventListener('click',event=>{
  if(event.target === addDriverModal) closeAddDriverModal();
});

addDriverForm.addEventListener('submit',event=>{
  event.preventDefault();
  const lastName = newDriverLastName.value.trim().toUpperCase();
  const firstName = newDriverFirstName.value.trim();

  if(!lastName || !firstName){
    addDriverError.textContent = 'Le nom et le prénom sont obligatoires.';
    return;
  }

  const exists = driverProfiles.some(item=>
    normalizeAffText(`${item.lastName} ${item.firstName}`) === normalizeAffText(`${lastName} ${firstName}`)
  );
  if(exists){
    addDriverError.textContent = 'Ce chauffeur existe déjà dans la liste.';
    return;
  }

  const item = createDriverFromName(`${lastName} ${firstName}`);
  item.lastName = lastName;
  item.firstName = firstName;
  item.status = normalizeDriverStatus(newDriverStatus.value);
  item.birthDate = newDriverBirthDate.value;
  item.birthCity = newDriverBirthCity.value.trim();
  item.birthPostalCode = newDriverBirthPostalCode.value.trim().toUpperCase();
  item.phone = newDriverPhone.value.trim();
  item.address = newDriverAddress.value.trim();
  item.postalCode = newDriverPostalCode.value.trim();
  item.city = newDriverCity.value.trim();
  item.licenseNumber = newDriverLicenseNumber.value.trim();
  item.licenseIssueDate = newDriverLicenseIssueDate.value;
  item.licenseExpiry = newDriverLicenseExpiry.value;
  driverProfiles.push(item);
  saveDriverProfiles();
  selectedDriverId = item.id;
  closeAddDriverModal();
  driverSearch.value = '';
  renderDriverList();
  fillDriverForm();
});

deleteDriverOption.addEventListener('click',()=>{
  if(!activeDriverId) return;
  pendingDeleteDriverId = activeDriverId;
  const item = driverProfiles.find(driver=>driver.id === activeDriverId);
  deleteDriverName.textContent = item ? driverDisplayName(item) : '';
  closeDriverActionsMenu();
  deleteDriverModal.hidden = false;
  syncDriverModalState();
});

function closeDeleteDriverModal(){
  deleteDriverModal.hidden = true;
  pendingDeleteDriverId = null;
  syncDriverModalState();
}
document.getElementById('closeDeleteDriver').addEventListener('click',closeDeleteDriverModal);
document.getElementById('cancelDeleteDriver').addEventListener('click',closeDeleteDriverModal);
deleteDriverModal.addEventListener('click',event=>{
  if(event.target === deleteDriverModal) closeDeleteDriverModal();
});
document.getElementById('confirmDeleteDriver').addEventListener('click',()=>{
  if(!pendingDeleteDriverId) return;
  driverProfiles = driverProfiles.filter(item=>item.id !== pendingDeleteDriverId);
  if(selectedDriverId === pendingDeleteDriverId) selectedDriverId = null;
  saveDriverProfiles();
  closeDeleteDriverModal();
  renderDriverList();
  fillDriverForm();
});

document.addEventListener('click',event=>{
  if(!driverActionsMenu.hidden &&
     !driverActionsMenu.contains(event.target) &&
     !event.target.closest('[data-driver-menu]')){
    closeDriverActionsMenu();
  }
});
window.addEventListener('resize',closeDriverActionsMenu);
window.addEventListener('scroll',closeDriverActionsMenu,true);

function driverCsvEscape(value){
  return `"${String(value ?? '').replace(/"/g,'""')}"`;
}
document.getElementById('exportDriversCsv').addEventListener('click',()=>{
  const headers = [
    'Nom','Prénom','Type de chauffeur','Date de naissance','Ville de naissance','Code postal ville de naissance','Téléphone','Adresse','Code postal','Ville',
    'N° permis','Délivrance permis','Expiration permis'
  ];
  const rows = [...driverProfiles]
    .sort((a,b)=>a.lastName.localeCompare(b.lastName,'fr',{sensitivity:'base'}))
    .map(item=>[
      item.lastName,item.firstName,driverStatusLabel(item),item.birthDate,item.birthCity,item.birthPostalCode,item.phone,item.address,item.postalCode,item.city,
      item.licenseNumber,item.licenseIssueDate,item.licenseExpiry
    ]);

  const csv = '\uFEFF' + [
    headers.map(driverCsvEscape).join(';'),
    ...rows.map(row=>row.map(driverCsvEscape).join(';'))
  ].join('\r\n');

  const blob = new Blob([csv],{type:'text/csv;charset=utf-8;'});
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = 'Chauffeurs.csv';
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
});

document.addEventListener('keydown',event=>{
  if(event.key !== 'Escape') return;
  if(!deleteDriverModal.hidden) closeDeleteDriverModal();
  else if(!addDriverModal.hidden) closeAddDriverModal();
  else closeDriverActionsMenu();
});

renderDriverList();
fillDriverForm();



/* ===== PAGE SINISTRE ===== */
const CLAIM_STORAGE_KEY = 'hessers-claims-v2';
const CLAIM_EVENTS_KEY = 'hessers-claim-events-v2';
const CLAIM_FILE_DB = 'hessers-claim-files-v1';
const CLAIM_FILE_STORE = 'files';

let claimData = [];
let claimEventsData = [];
let selectedClaimId = null;
let claimDraftSnapshot = null;

try{
  const storedClaims = JSON.parse(localStorage.getItem(CLAIM_STORAGE_KEY));
  if(Array.isArray(storedClaims)) claimData = storedClaims;
}catch(error){
  console.warn('Impossible de lire les sinistres enregistrés.',error);
}

try{
  const storedEvents = JSON.parse(localStorage.getItem(CLAIM_EVENTS_KEY));
  if(Array.isArray(storedEvents)) claimEventsData = storedEvents;
}catch(error){
  console.warn('Impossible de lire l’historique des sinistres.',error);
}

const claimTable = document.getElementById('claimTable');
const claimTableWrap = document.querySelector('.claim-table-wrap');
const claimSearch = document.getElementById('claimSearch');
const claimCountLabel = document.getElementById('claimCountLabel');
const claimDetailEmpty = document.getElementById('claimDetailEmpty');
const claimDetailContent = document.getElementById('claimDetailContent');
const claimAttachmentInput = document.getElementById('claimAttachmentInput');
const claimAttachmentList = document.getElementById('claimAttachmentList');
const claimTimeline = document.getElementById('claimTimeline');

const claimActionsMenu = document.getElementById('claimActionsMenu');
const deleteClaimOption = document.getElementById('deleteClaimOption');
const deleteClaimModal = document.getElementById('deleteClaimModal');
const deleteClaimNumber = document.getElementById('deleteClaimNumber');

let activeClaimMenuId = null;
let activeClaimMenuButton = null;
let pendingDeleteClaimId = null;



function closeClaimActionsMenu(){
  claimActionsMenu.hidden = true;
  activeClaimMenuId = null;
  activeClaimMenuButton = null;
}

function openClaimActionsMenu(button,id){
  closeClaimActionsMenu();
  activeClaimMenuId = id;
  activeClaimMenuButton = button;
  claimActionsMenu.hidden = false;

  const rect = button.getBoundingClientRect();
  const menuRect = claimActionsMenu.getBoundingClientRect();
  const left = Math.max(10,Math.min(rect.right-menuRect.width,window.innerWidth-menuRect.width-10));
  let top = rect.bottom+6;
  if(top+menuRect.height > window.innerHeight-10){
    top = rect.top-menuRect.height-6;
  }

  claimActionsMenu.style.left = `${left}px`;
  claimActionsMenu.style.top = `${Math.max(10,top)}px`;
}

function openDeleteClaimModal(id){
  const item = claimData.find(claim=>claim.id === id);
  if(!item) return;

  pendingDeleteClaimId = id;
  deleteClaimNumber.textContent = item.number || 'sans n° de dossier';
  deleteClaimModal.hidden = false;
  document.body.classList.add('modal-open');
  requestAnimationFrame(()=>document.getElementById('confirmDeleteClaim').focus());
}

function closeDeleteClaimModal(){
  deleteClaimModal.hidden = true;
  pendingDeleteClaimId = null;

  if(document.querySelectorAll('.modal-overlay:not([hidden])').length === 0){
    document.body.classList.remove('modal-open');
  }
}

async function deleteAllClaimFiles(claimId){
  try{
    const files = await getClaimFiles(claimId);
    for(const file of files){
      await deleteClaimFile(file.key);
    }
  }catch(error){
    console.warn('Impossible de supprimer toutes les pièces jointes du sinistre.',error);
  }
}

function saveClaims(){
  try{
    localStorage.setItem(CLAIM_STORAGE_KEY,JSON.stringify(claimData));
    return true;
  }catch(error){
    console.warn('Impossible d’enregistrer les sinistres.',error);
    return false;
  }
}

function saveClaimEvents(){
  try{
    localStorage.setItem(CLAIM_EVENTS_KEY,JSON.stringify(claimEventsData.slice(0,30)));
  }catch(error){
    console.warn('Impossible d’enregistrer l’historique des sinistres.',error);
  }
}

function addClaimEvent(message){
  claimEventsData.unshift({
    id:'evt_'+Date.now()+'_'+Math.random().toString(36).slice(2),
    message,
    date:new Date().toISOString()
  });
  claimEventsData = claimEventsData.slice(0,30);
  saveClaimEvents();
  renderClaimEvents();
}

function getSelectedClaim(){
  return claimData.find(item=>item.id === selectedClaimId) || null;
}

function claimStatusClass(status){
  if(status === 'Clos') return 'closed';
  if(status === 'En attente') return 'wait';
  if(status === 'Urgent') return 'urgent';
  return 'open';
}

function formatClaimDate(value){
  if(!value) return '—';
  const d = new Date(value+'T00:00:00');
  return Number.isNaN(d.getTime()) ? value : d.toLocaleDateString('fr-FR');
}

function formatMoney(value){
  const number = Number(String(value ?? '').replace(',','.'));
  if(!Number.isFinite(number)) return 0;
  return number;
}



function normalizeClaimSearch(value){
  return String(value || '')
    .toLocaleLowerCase('fr')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g,'');
}

function updateClaimKpis(){
  const opened = claimData.filter(item=>item.status === 'Ouvert' || item.status === 'Urgent').length;
  const waiting = claimData.filter(item=>item.status === 'En attente').length;
  const closed = claimData.filter(item=>item.status === 'Clos').length;
  const cost = claimData
    .filter(item=>item.status !== 'Clos')
    .reduce((sum,item)=>sum+formatMoney(item.cost),0);

  document.getElementById('claimOpenCount').textContent = opened;
  document.getElementById('claimWaitingCount').textContent = waiting;
  document.getElementById('claimClosedCount').textContent = closed;
  document.getElementById('claimCostTotal').textContent =
    cost.toLocaleString('fr-FR',{maximumFractionDigits:2})+' €';
}

function renderClaims(){
  const q = normalizeClaimSearch(claimSearch.value);
  const rows = [...claimData]
    .sort((a,b)=>String(b.date || '').localeCompare(String(a.date || '')))
    .filter(item=>{
      const searchable = normalizeClaimSearch(
        `${item.number} ${item.date} ${item.driver} ${item.vehicle} ${item.type} ${item.status} AXA France`
      );
      return searchable.includes(q);
    });

  if(!rows.length){
    claimTable.innerHTML = `
      <tr>
        <td colspan="7" class="claim-empty-table">
          ${claimData.length ? 'Aucun sinistre ne correspond à votre recherche.' : 'Aucun sinistre enregistré.'}
        </td>
      </tr>
    `;
  }else{
    claimTable.innerHTML = rows.map(item=>`
      <tr data-claim-id="${item.id}" class="${item.id === selectedClaimId ? 'selected' : ''}">
        <td>${formatClaimDate(item.date)}</td>
        <td>${item.driver || '—'}</td>
        <td class="plate-cell">${item.vehicle || '—'}</td>
        <td>${item.type || '—'}</td>
        <td><span class="claim-status ${claimStatusClass(item.status)}">${item.status || 'Ouvert'}</span></td>
        <td>AXA France</td>
        <td><button class="claim-row-menu" type="button" data-claim-menu="${item.id}" aria-label="Actions pour ${item.number}">•••</button></td>
      </tr>
    `).join('');
  }

  claimCountLabel.textContent =
    `${rows.length} sinistre${rows.length > 1 ? 's' : ''} affiché${rows.length > 1 ? 's' : ''}`;

  // Jusqu'à 11 sinistres : la liste s'affiche entièrement.
  // À partir du 12e : hauteur fixe + défilement interne.
  claimTableWrap.classList.toggle('claim-scroll', rows.length > 11);

  updateClaimKpis();
  renderClaimTypeSummary();
}

function claimDriverOptions(){
  const names = [];
  const seen = new Set();

  if(typeof driverProfiles !== 'undefined' && Array.isArray(driverProfiles)){
    driverProfiles.forEach(item=>{
      const name = [item.lastName,item.firstName].filter(Boolean).join(' ').trim();
      const key = normalizeClaimSearch(name);
      if(name && !seen.has(key)){
        seen.add(key);
        names.push(name);
      }
    });
  }

  if(typeof affectations !== 'undefined' && Array.isArray(affectations)){
    affectations.forEach(item=>{
      const name = String(item.name || '').trim();
      const key = normalizeClaimSearch(name);
      if(name && !seen.has(key)){
        seen.add(key);
        names.push(name);
      }
    });
  }

  return names.sort((a,b)=>a.localeCompare(b,'fr',{sensitivity:'base'}));
}

function claimVehicleOptions(){
  if(typeof parkData === 'undefined' || !Array.isArray(parkData)) return [];
  return [...parkData]
    .sort((a,b)=>{
      const order = {Tracteur:0,Semi:1};
      return (order[a.type]??9)-(order[b.type]??9) ||
        String(a.registration).localeCompare(String(b.registration),'fr',{numeric:true});
    })
    .map(item=>({
      value:formatRegistration(item.registration),
      label:`${formatRegistration(item.registration)} · ${item.type}${item.parkNumber ? ' · '+item.parkNumber : ''}`
    }));
}

function fillClaimSelectors(item){
  const driverSelect = document.getElementById('claimDetailDriver');
  const vehicleSelect = document.getElementById('claimDetailVehicle');

  const drivers = claimDriverOptions();
  driverSelect.innerHTML =
    '<option value="">— Sélectionner —</option>' +
    drivers.map(name=>`<option value="${name.replace(/"/g,'&quot;')}">${name}</option>`).join('');

  const vehicles = claimVehicleOptions();
  vehicleSelect.innerHTML =
    '<option value="">— Sélectionner —</option>' +
    vehicles.map(vehicle=>`<option value="${vehicle.value}">${vehicle.label}</option>`).join('');

  if(item.driver && ![...driverSelect.options].some(option=>option.value === item.driver)){
    const option = document.createElement('option');
    option.value = item.driver;
    option.textContent = item.driver;
    driverSelect.appendChild(option);
  }
  if(item.vehicle && ![...vehicleSelect.options].some(option=>option.value === item.vehicle)){
    const option = document.createElement('option');
    option.value = item.vehicle;
    option.textContent = item.vehicle;
    vehicleSelect.appendChild(option);
  }

  driverSelect.value = item.driver || '';
  vehicleSelect.value = item.vehicle || '';
}

function loadClaimDetail(){
  const item = getSelectedClaim();

  if(!item){
    claimDetailEmpty.hidden = false;
    claimDetailContent.hidden = true;
    return;
  }

  claimDetailEmpty.hidden = true;
  claimDetailContent.hidden = false;
  claimDraftSnapshot = JSON.parse(JSON.stringify(item));

  document.getElementById('claimDetailNumber').value = item.number || '';
  document.getElementById('claimDetailDate').value = item.date || '';
  fillClaimSelectors(item);
  document.getElementById('claimDetailThirdParty').value = item.thirdParty || '';
  document.getElementById('claimDetailType').value = item.type || '';
  document.getElementById('claimDetailCost').value = item.cost || '';
  document.getElementById('claimDetailStatus').value = item.status || 'Ouvert';
  document.getElementById('claimDetailDescription').value = item.description || '';

  renderClaimTimeline();
  renderClaimAttachments();
}

function readClaimFormInto(item){
  item.number = document.getElementById('claimDetailNumber').value.trim();
  item.date = document.getElementById('claimDetailDate').value;
  item.driver = document.getElementById('claimDetailDriver').value;
  item.vehicle = document.getElementById('claimDetailVehicle').value;
  item.thirdParty = document.getElementById('claimDetailThirdParty').value.trim();
  item.type = document.getElementById('claimDetailType').value.trim();
  item.cost = document.getElementById('claimDetailCost').value.trim();
  item.status = document.getElementById('claimDetailStatus').value;
  item.description = document.getElementById('claimDetailDescription').value.trim();
  item.insurance = 'AXA France';
}

claimTable.addEventListener('click',event=>{
  const menuButton = event.target.closest('[data-claim-menu]');
  if(menuButton){
    event.stopPropagation();
    openClaimActionsMenu(menuButton,menuButton.dataset.claimMenu);
    return;
  }

  const row = event.target.closest('tr[data-claim-id]');
  if(!row) return;

  closeClaimActionsMenu();
  selectedClaimId = row.dataset.claimId;
  renderClaims();
  loadClaimDetail();
});

claimSearch.addEventListener('input',renderClaims);

deleteClaimOption.addEventListener('click',()=>{
  if(!activeClaimMenuId) return;
  const id = activeClaimMenuId;
  closeClaimActionsMenu();
  openDeleteClaimModal(id);
});

document.getElementById('confirmDeleteClaim').addEventListener('click',async()=>{
  if(!pendingDeleteClaimId) return;

  const id = pendingDeleteClaimId;
  const item = claimData.find(claim=>claim.id === id);
  const number = item?.number ? `Dossier ${item.number}` : 'Sinistre sans n° de dossier';

  await deleteAllClaimFiles(id);

  claimData = claimData.filter(claim=>claim.id !== id);

  if(selectedClaimId === id){
    selectedClaimId = null;
    claimDraftSnapshot = null;
  }

  saveClaims();
  addClaimEvent(`${number} supprimé`);
  closeDeleteClaimModal();
  renderClaims();
  loadClaimDetail();
});

document.getElementById('closeDeleteClaim').addEventListener('click',closeDeleteClaimModal);
document.getElementById('cancelDeleteClaim').addEventListener('click',closeDeleteClaimModal);

deleteClaimModal.addEventListener('click',event=>{
  if(event.target === deleteClaimModal){
    closeDeleteClaimModal();
  }
});

document.addEventListener('click',event=>{
  if(
    !claimActionsMenu.hidden &&
    !claimActionsMenu.contains(event.target) &&
    !event.target.closest('[data-claim-menu]')
  ){
    closeClaimActionsMenu();
  }
});

window.addEventListener('resize',closeClaimActionsMenu);
window.addEventListener('scroll',closeClaimActionsMenu,true);



document.getElementById('addClaim').addEventListener('click',()=>{
  const item = {
    id:'claim_'+Date.now()+'_'+Math.random().toString(36).slice(2),
    number:'',
    date:new Date().toISOString().slice(0,10),
    driver:'',
    vehicle:'',
    type:'',
    status:'Ouvert',
    insurance:'AXA France',
    thirdParty:'',
    cost:'',
    description:'',
    progress:0
  };

  claimData.push(item);
  selectedClaimId = item.id;
  saveClaims();
  addClaimEvent('Nouveau sinistre créé');
  claimSearch.value = '';
  renderClaims();
  loadClaimDetail();
});

document.getElementById('saveClaim').addEventListener('click',()=>{
  const item = getSelectedClaim();
  if(!item) return;

  readClaimFormInto(item);
  saveClaims();
  addClaimEvent(`${item.number ? 'Dossier '+item.number : 'Sinistre sans n° de dossier'} enregistré`);
  renderClaims();
  loadClaimDetail();
});

document.getElementById('cancelClaimChanges').addEventListener('click',()=>{
  const item = getSelectedClaim();
  if(!item || !claimDraftSnapshot) return;

  Object.keys(item).forEach(key=>delete item[key]);
  Object.assign(item,JSON.parse(JSON.stringify(claimDraftSnapshot)));

  renderClaims();
  loadClaimDetail();
});

/* ----- Suivi manuel ----- */
function renderClaimTimeline(){
  const item = getSelectedClaim();
  const progress = item ? Math.max(0,Math.min(3,Number(item.progress) || 0)) : 0;

  claimTimeline.querySelectorAll('.claim-step').forEach(step=>{
    const stage = Number(step.dataset.stage);
    step.classList.toggle('done',stage <= progress);
    step.classList.toggle('current',stage === progress);
  });
}

claimTimeline.addEventListener('click',event=>{
  const step = event.target.closest('.claim-step[data-stage]');
  const item = getSelectedClaim();
  if(!step || !item) return;

  item.progress = Number(step.dataset.stage);
  saveClaims();

  const labels = ['Déclaré','Envoyé à l’assurance','Expertise','Clôturé'];
  addClaimEvent(`${item.number ? 'Dossier '+item.number : 'Sinistre sans n° de dossier'} : suivi → ${labels[item.progress]}`);
  renderClaimTimeline();
});

/* ----- Pièces jointes réelles via IndexedDB ----- */
function openClaimFileDb(){
  return new Promise((resolve,reject)=>{
    const request = indexedDB.open(CLAIM_FILE_DB,1);

    request.onupgradeneeded = ()=>{
      const db = request.result;
      if(!db.objectStoreNames.contains(CLAIM_FILE_STORE)){
        const store = db.createObjectStore(CLAIM_FILE_STORE,{keyPath:'key'});
        store.createIndex('claimId','claimId',{unique:false});
      }
    };

    request.onsuccess = ()=>resolve(request.result);
    request.onerror = ()=>reject(request.error);
  });
}

async function putClaimFile(claimId,file){
  const db = await openClaimFileDb();
  const id = 'file_'+Date.now()+'_'+Math.random().toString(36).slice(2);
  const record = {
    key:`${claimId}::${id}`,
    claimId,
    id,
    name:file.name,
    type:file.type,
    size:file.size,
    blob:file,
    addedAt:new Date().toISOString()
  };

  await new Promise((resolve,reject)=>{
    const tx = db.transaction(CLAIM_FILE_STORE,'readwrite');
    tx.objectStore(CLAIM_FILE_STORE).put(record);
    tx.oncomplete = resolve;
    tx.onerror = ()=>reject(tx.error);
  });
  db.close();
  return record;
}

async function getClaimFiles(claimId){
  if(!claimId) return [];
  const db = await openClaimFileDb();

  const records = await new Promise((resolve,reject)=>{
    const tx = db.transaction(CLAIM_FILE_STORE,'readonly');
    const index = tx.objectStore(CLAIM_FILE_STORE).index('claimId');
    const request = index.getAll(claimId);
    request.onsuccess = ()=>resolve(request.result || []);
    request.onerror = ()=>reject(request.error);
  });

  db.close();
  return records.sort((a,b)=>String(a.addedAt).localeCompare(String(b.addedAt)));
}

async function deleteClaimFile(key){
  const db = await openClaimFileDb();
  await new Promise((resolve,reject)=>{
    const tx = db.transaction(CLAIM_FILE_STORE,'readwrite');
    tx.objectStore(CLAIM_FILE_STORE).delete(key);
    tx.oncomplete = resolve;
    tx.onerror = ()=>reject(tx.error);
  });
  db.close();
}

function formatFileSize(bytes){
  if(bytes < 1024) return bytes+' o';
  if(bytes < 1024*1024) return (bytes/1024).toFixed(1).replace('.',',')+' Ko';
  return (bytes/(1024*1024)).toFixed(1).replace('.',',')+' Mo';
}

async function renderClaimAttachments(){
  const item = getSelectedClaim();
  if(!item){
    claimAttachmentList.innerHTML = '';
    return;
  }

  try{
    const files = await getClaimFiles(item.id);

    claimAttachmentList.innerHTML = files.map(file=>`
      <div class="claim-file" data-file-key="${file.key}">
        <span>▤</span>
        <span class="claim-file-name" title="${file.name.replace(/"/g,'&quot;')}">${file.name}</span>
        <span class="claim-file-meta">${formatFileSize(file.size)}</span>
        <button class="claim-file-remove" type="button" data-delete-file="${file.key}" aria-label="Supprimer ${file.name.replace(/"/g,'&quot;')}">✕</button>
      </div>
    `).join('') + `
      <button class="claim-file add" type="button" id="addClaimAttachment"><span class="button-icon"><svg class="app-icon" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v14M5 12h14"/></svg></span>Ajouter</button>
    `;

    document.getElementById('addClaimAttachment').addEventListener('click',()=>{
      claimAttachmentInput.click();
    });
  }catch(error){
    console.warn('Impossible de charger les pièces jointes.',error);
    claimAttachmentList.innerHTML = `
      <button class="claim-file add" type="button" id="addClaimAttachment"><span class="button-icon"><svg class="app-icon" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v14M5 12h14"/></svg></span>Ajouter</button>
    `;
    document.getElementById('addClaimAttachment').addEventListener('click',()=>{
      claimAttachmentInput.click();
    });
  }
}

claimAttachmentInput.addEventListener('change',async()=>{
  const item = getSelectedClaim();
  if(!item || !claimAttachmentInput.files.length) return;

  const files = [...claimAttachmentInput.files];

  try{
    for(const file of files){
      await putClaimFile(item.id,file);
    }
    addClaimEvent(
      `${files.length} pièce${files.length > 1 ? 's' : ''} jointe${files.length > 1 ? 's' : ''} ajoutée${files.length > 1 ? 's' : ''} à ${item.number || 'un sinistre sans n° de dossier'}`
    );
  }catch(error){
    console.warn('Impossible d’ajouter une pièce jointe.',error);
    alert('Impossible d’enregistrer la pièce jointe dans ce navigateur.');
  }

  claimAttachmentInput.value = '';
  renderClaimAttachments();
});

claimAttachmentList.addEventListener('click',async event=>{
  const button = event.target.closest('[data-delete-file]');
  const item = getSelectedClaim();
  if(!button || !item) return;

  try{
    await deleteClaimFile(button.dataset.deleteFile);
    addClaimEvent(`${item.number ? 'Pièce jointe supprimée de '+item.number : 'Pièce jointe supprimée d’un sinistre sans n° de dossier'}`);
    renderClaimAttachments();
  }catch(error){
    console.warn('Impossible de supprimer la pièce jointe.',error);
  }
});

/* ----- Cartes du bas ----- */
function renderClaimTypeSummary(){
  const container = document.getElementById('claimTypeSummary');

  if(!claimData.length){
    container.innerHTML = '<div class="claim-empty-summary">Aucun sinistre enregistré.</div>';
    return;
  }

  const counts = new Map();
  claimData.forEach(item=>{
    const type = String(item.type || '').trim() || 'Non renseigné';
    counts.set(type,(counts.get(type) || 0)+1);
  });

  const entries = [...counts.entries()].sort((a,b)=>b[1]-a[1]).slice(0,5);
  const colors = ['#db3333','#f39b2f','#5ba7ff','#7b61d1','#6b747e'];
  const total = claimData.length;

  let current = 0;
  const gradientParts = entries.map(([type,count],index)=>{
    const start = current;
    current += count/total*100;
    return `${colors[index]} ${start}% ${current}%`;
  });

  container.innerHTML = `
    <div class="claim-donut-wrap">
      <div class="claim-donut" style="background:conic-gradient(${gradientParts.join(',')})">
        <div class="claim-donut-center">${total}<small>Sinistre${total > 1 ? 's' : ''}</small></div>
      </div>
      <div class="claim-legend">
        ${entries.map(([type,count],index)=>`
          <div class="claim-legend-row">
            <span class="claim-dot" style="background:${colors[index]}"></span>
            ${type} · ${count}
          </div>
        `).join('')}
      </div>
    </div>
  `;
}

function renderClaimEvents(){
  const container = document.getElementById('claimEvents');

  if(!claimEventsData.length){
    container.innerHTML = '<div class="claim-empty-summary">Aucun événement pour le moment.</div>';
    return;
  }

  container.innerHTML = claimEventsData.slice(0,5).map(event=>{
    const date = new Date(event.date);
    const formatted = Number.isNaN(date.getTime())
      ? ''
      : date.toLocaleString('fr-FR',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'});

    return `
      <div class="claim-event">
        <span class="claim-event-dot"></span>
        <span>${event.message}</span>
        <span class="claim-event-time">${formatted}</span>
      </div>
    `;
  }).join('');
}


document.addEventListener('keydown',event=>{
  if(event.key !== 'Escape') return;
  if(!deleteClaimModal.hidden) closeDeleteClaimModal();
  else closeClaimActionsMenu();
});

renderClaims();
renderClaimEvents();
loadClaimDetail();





/* ===== VIDANGE TFMO + IMPORT JEF ===== */
const TECH_DEADLINE_STORAGE_KEY='hessers-technical-deadlines-v1';
let technicalDeadlines=INITIAL_TECH_DEADLINES.map(item=>({...item}));
try{
  const storedTechnicalDeadlines=JSON.parse(localStorage.getItem(TECH_DEADLINE_STORAGE_KEY));
  if(Array.isArray(storedTechnicalDeadlines) && storedTechnicalDeadlines.length) technicalDeadlines=storedTechnicalDeadlines.filter(item=>item.category!=='hayon');
}catch(error){console.warn('Lecture des échéances techniques impossible.',error)}
function saveTechnicalDeadlines(){
  try{localStorage.setItem(TECH_DEADLINE_STORAGE_KEY,JSON.stringify(technicalDeadlines));return true}
  catch(error){console.warn('Sauvegarde des échéances techniques impossible.',error);return false}
}

const VIDANGE_STORAGE_KEY = 'hessers-vidange-tfmo-v4';

let vidangeData = INITIAL_VIDANGE_DATA.map(item=>({...item}));
try{
  const stored = JSON.parse(localStorage.getItem(VIDANGE_STORAGE_KEY));
  if(Array.isArray(stored) && stored.length){
    const storedByRegistration = new Map(stored.map(item=>[normalizeRegistration(item.registration),item]));
    vidangeData = INITIAL_VIDANGE_DATA.map(source=>({
      ...source,
      ...(storedByRegistration.get(normalizeRegistration(source.registration))||{}),
      sameInterval:source.sameInterval ?? 50000,
      differentInterval:source.differentInterval ?? 100000
    }));
  }
}catch(error){console.warn('Impossible de lire les données Vidange TFMO.',error)}

const vidTable=document.getElementById('vidTable');
const vidTableWrap=document.getElementById('vidTableWrap');
const vidSearch=document.getElementById('vidSearch');
const vidCountLabel=document.getElementById('vidCountLabel');
const vidDetailEmpty=document.getElementById('vidDetailEmpty');
const vidDetailContent=document.getElementById('vidDetailContent');

let selectedVidangeId=null;
let vidangeDraft=null;

function saveVidangeData(){
  try{localStorage.setItem(VIDANGE_STORAGE_KEY,JSON.stringify(vidangeData));return true}
  catch(error){console.warn('Impossible d’enregistrer le suivi des vidanges.',error);return false}
}
function kmNumber(value){
  if(value===null || value===undefined || value==='') return null;
  const n=Number(String(value).replace(/\s/g,'').replace(',','.'));
  return Number.isFinite(n)?n:null;
}
function excelNumeric(value){const n=kmNumber(value);return n===null?0:n}
function calculateNextOil(record){
  if(record?.needsData || kmNumber(record?.currentKm)===null)return NaN;
  const E=excelNumeric(record.currentKm),F=excelNumeric(record.lastMajorKm),G=excelNumeric(record.lastGarageKm);
  return F===G ? G+Number(record.sameInterval||0)-E : F+Number(record.differentInterval||0)-E;
}
function vidStatus(record){
  const next=calculateNextOil(record);
  if(!Number.isFinite(next))return{label:'À renseigner',className:'pending'};
  if(next<=0)return{label:'À faire',className:'late'};
  if(next<=5000)return{label:'À prévoir',className:'soon'};
  return{label:'À jour',className:'ok'};
}
function formatKm(value){const n=kmNumber(value);return n===null?'—':`${n.toLocaleString('fr-FR')} km`}
function formatRemaining(value){return Number.isFinite(Number(value))?`${Number(value).toLocaleString('fr-FR')} km`:'À renseigner'}
function vidSearchText(value){
  return String(value||'').toLocaleLowerCase('fr').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9]/g,'');
}
function sortedVidangeData(){
  return [...vidangeData].sort((a,b)=>{
    const nextA=calculateNextOil(a),nextB=calculateNextOil(b);
    if(!Number.isFinite(nextA))return Number.isFinite(nextB)?1:0;
    if(!Number.isFinite(nextB))return -1;
    return nextA-nextB||normalizeRegistration(a.registration).localeCompare(normalizeRegistration(b.registration),'fr',{numeric:true});
  });
}
function vidangeAssignedDriver(registration){
  const plate=normalizeRegistration(registration),seen=new Set();
  const names=(Array.isArray(affectations)?affectations:[])
    .filter(item=>normalizeRegistration(item.tractor)===plate)
    .map(item=>String(item.name||'').trim())
    .filter(name=>{const key=vidSearchText(name);if(!key||seen.has(key))return false;seen.add(key);return true})
    .sort((a,b)=>a.localeCompare(b,'fr',{numeric:true,sensitivity:'base'}));
  return names.join(' · ')||'Non affecté';
}
function updateVidKpis(){
  let late=0,soon=0,ok=0,pending=0;
  vidangeData.forEach(r=>{const s=vidStatus(r);if(s.className==='late')late++;else if(s.className==='soon')soon++;else if(s.className==='pending')pending++;else ok++});
  document.getElementById('vidTotal').textContent=vidangeData.length;
  document.getElementById('vidLate').textContent=late;
  document.getElementById('vidSoon').textContent=soon;
  document.getElementById('vidOk').textContent=ok;
  const pendingLabel=document.getElementById('vidPendingLabel');
  if(pendingLabel)pendingLabel.textContent=pending?`${pending} véhicule${pending>1?'s':''} à renseigner`:'Parc et feuille Excel réunis';
}
function renderVidTable(){
  const q=vidSearchText(vidSearch.value);
  const visible=sortedVidangeData().filter(r=>vidSearchText(`${r.registration} ${vidangeAssignedDriver(r.registration)} ${r.lastName} ${r.firstName} ${r.currentKm??''}`).includes(q));
  if(!visible.length){
    vidTable.innerHTML='<tr><td colspan="7" class="empty-row">Aucun véhicule ne correspond à votre recherche.</td></tr>';
  }else{
    vidTable.innerHTML=visible.map(r=>{
      const next=calculateNextOil(r),status=vidStatus(r),driver=vidangeAssignedDriver(r.registration);
      return `<tr data-vid-id="${r.id}" class="${r.id===selectedVidangeId?'selected':''}">
        <td class="plate-cell">${formatRegistration(r.registration)}</td>
        <td>${driver||'—'}</td>
        <td><span class="vid-next ${status.className}">${formatRemaining(next)}</span></td>
        <td class="vid-km">${formatKm(r.currentKm)}</td>
        <td class="vid-km ${r.lastMajorKm===null?'vid-empty':''}">${formatKm(r.lastMajorKm)}</td>
        <td class="vid-km ${r.lastGarageKm===null?'vid-empty':''}">${formatKm(r.lastGarageKm)}</td>
        <td><span class="vid-status ${status.className}">${status.label}</span></td>
      </tr>`;
    }).join('');
  }
  vidCountLabel.textContent=`${visible.length} véhicule${visible.length>1?'s':''} affiché${visible.length>1?'s':''}`;
  vidTableWrap.classList.toggle('scroll',visible.length>11);
  updateVidKpis();
}
function selectedVidRecord(){return vidangeData.find(r=>r.id===selectedVidangeId)||null}
function refreshVidDetailComputed(r){
  const s=vidStatus(r),next=calculateNextOil(r);
  const badge=document.getElementById('vidDetailStatus');
  const value=document.getElementById('vidDetailNext');
  badge.className=`vid-status ${s.className}`;badge.textContent=s.label;
  value.className=`vid-calc-value vid-next ${s.className}`;value.textContent=formatRemaining(next);
  document.getElementById('vidDetailRule').innerHTML=
    `Règle issue de la formule Excel de ce véhicule :<br>`+
    `si <strong>KM dernière grosse vidange = dernier passage garage</strong> → +${Number(r.sameInterval).toLocaleString('fr-FR')} km ; `+
    `sinon → +${Number(r.differentInterval).toLocaleString('fr-FR')} km.`;
}
function loadVidDetail(){
  const r=selectedVidRecord();
  if(!r){vidDetailEmpty.hidden=false;vidDetailContent.hidden=true;return}
  vidDetailEmpty.hidden=true;vidDetailContent.hidden=false;vidangeDraft=JSON.parse(JSON.stringify(r));
  document.getElementById('vidDetailPlate').textContent=formatRegistration(r.registration);
  document.getElementById('vidDetailDriver').textContent=vidangeAssignedDriver(r.registration);
  document.getElementById('vidCurrentKm').value=r.currentKm??'';
  document.getElementById('vidLastMajorKm').value=r.lastMajorKm??'';
  document.getElementById('vidLastGarageKm').value=r.lastGarageKm??'';
  document.getElementById('vidNotice').textContent='';
  refreshVidDetailComputed(r);
}
['vidCurrentKm','vidLastMajorKm','vidLastGarageKm'].forEach(id=>{
  document.getElementById(id).addEventListener('input',e=>{
    e.target.value=e.target.value.replace(/[^\d]/g,'');
    const r=selectedVidRecord();if(!r)return;
    const temp={...r,
      currentKm:kmNumber(document.getElementById('vidCurrentKm').value),
      lastMajorKm:kmNumber(document.getElementById('vidLastMajorKm').value),
      lastGarageKm:kmNumber(document.getElementById('vidLastGarageKm').value)
    };
    refreshVidDetailComputed(temp);
  });
});
vidTable.addEventListener('click',e=>{
  const row=e.target.closest('tr[data-vid-id]');if(!row)return;
  selectedVidangeId=row.dataset.vidId;renderVidTable();loadVidDetail();
});
vidSearch.addEventListener('input',renderVidTable);
document.getElementById('saveVidRecord').addEventListener('click',()=>{
  const r=selectedVidRecord();if(!r)return;
  r.currentKm=kmNumber(document.getElementById('vidCurrentKm').value);
  r.lastMajorKm=kmNumber(document.getElementById('vidLastMajorKm').value);
  r.lastGarageKm=kmNumber(document.getElementById('vidLastGarageKm').value);
  const saved=saveVidangeData();renderVidTable();loadVidDetail();
  const n=document.getElementById('vidNotice');n.style.color=saved?'#57d883':'#ff7373';n.textContent=saved?'Modifications enregistrées.':'Impossible d’enregistrer les modifications.';
});
document.getElementById('cancelVidChanges').addEventListener('click',()=>{
  const r=selectedVidRecord();if(!r||!vidangeDraft)return;
  Object.keys(r).forEach(k=>delete r[k]);Object.assign(r,JSON.parse(JSON.stringify(vidangeDraft)));renderVidTable();loadVidDetail();
});

function printVidangeSimple(){
  const q=vidSearchText(vidSearch.value);
  const rows=sortedVidangeData().filter(r=>
    vidSearchText(`${r.registration} ${vidangeAssignedDriver(r.registration)} ${r.lastName} ${r.firstName} ${r.currentKm??''}`).includes(q)
  );

  const escapePrint=value=>String(value??'')
    .replace(/&/g,'&amp;')
    .replace(/</g,'&lt;')
    .replace(/>/g,'&gt;')
    .replace(/"/g,'&quot;')
    .replace(/'/g,'&#039;');

  const body=rows.map(r=>{
    const driver=vidangeAssignedDriver(r.registration);
    const next=calculateNextOil(r);
    const status=vidStatus(r);

    return `
      <tr>
        <td class="plate">${escapePrint(formatRegistration(r.registration))}</td>
        <td>${escapePrint(driver)}</td>
        <td class="number ${status.className}">${escapePrint(formatRemaining(next))}</td>
        <td class="number">${escapePrint(formatKm(r.currentKm))}</td>
        <td class="number">${escapePrint(formatKm(r.lastMajorKm))}</td>
        <td class="number">${escapePrint(formatKm(r.lastGarageKm))}</td>
      </tr>
    `;
  }).join('');

  const printFrame=document.createElement('iframe');
  printFrame.style.position='fixed';
  printFrame.style.right='0';
  printFrame.style.bottom='0';
  printFrame.style.width='0';
  printFrame.style.height='0';
  printFrame.style.border='0';
  printFrame.style.visibility='hidden';
  document.body.appendChild(printFrame);

  const doc=printFrame.contentDocument || printFrame.contentWindow.document;
  doc.open();
  doc.write(`<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<title>Liste des vidanges</title>
<style>
  @page{
    size:A4 landscape;
    margin:10mm;
  }

  *{
    box-sizing:border-box;
  }

  body{
    margin:0;
    background:#fff;
    color:#000;
    font-family:Arial,Helvetica,sans-serif;
    font-size:8.5pt;
  }

  h1{
    margin:0 0 3mm;
    font-size:14pt;
    font-weight:700;
  }

  .print-meta{
    margin-bottom:4mm;
    color:#444;
    font-size:8pt;
  }

  table{
    width:88%;
    margin-right:auto;
    border-collapse:collapse;
    table-layout:fixed;
  }

  thead{
    display:table-header-group;
  }

  tr{
    page-break-inside:avoid;
  }

  th,
  td{
    border:1px solid #555;
    padding:2.1mm 1.4mm;
    vertical-align:middle;
  }

  th{
    background:#eee;
    font-size:7.5pt;
    font-weight:700;
    text-align:left;
  }

  td{
    line-height:1.2;
  }

  .plate{
    font-weight:700;
    white-space:nowrap;
  }

  .number{
    text-align:right;
    white-space:nowrap;
  }

  .status{
    text-align:center;
    font-weight:700;
    white-space:nowrap;
  }

  .late{
    font-weight:700;
  }

  .soon{
    font-weight:700;
  }

  th:nth-child(1){width:15%}
  th:nth-child(2){width:25%}
  th:nth-child(3){width:15%}
  th:nth-child(4){width:15%}
  th:nth-child(5){width:15%}
  th:nth-child(6){width:15%}
  
</style>
</head>
<body>
  <h1>Suivi des vidanges</h1>
  <div class="print-meta">
    ${rows.length} véhicule${rows.length>1?'s':''} · Impression du ${new Date().toLocaleDateString('fr-FR')}
  </div>

  <table>
    <thead>
      <tr>
        <th>Immatriculation</th>
        <th>Chauffeur</th>
        <th>Prochaine vidange</th>
        <th>Km actuel</th>
        <th>Dernière grosse vidange</th>
        <th>Dernier passage garage</th>
      </tr>
    </thead>
    <tbody>
      ${body || '<tr><td colspan="6">Aucune ligne à imprimer.</td></tr>'}
    </tbody>
  </table>
<style>
/* ===== POPUPS PLUS CARRES ===== */
.modal-card,
.confirm-card,
.jef-card,
.admin-modal-card,
.fuel-modal-card,
.user-id-modal-card,
.shared-storage-modal-card,
.adminsec-modal-card{
  border-radius:6px !important;
  overflow:hidden;
}

.modal-head,
.modal-body,
.modal-actions{
  border-radius:0 !important;
}

.modal-close-btn,
.modal-btn,
.tool-btn,
.modal-card .btn,
.confirm-card .btn,
.jef-card .btn,
.admin-modal-card .btn,
.fuel-modal-card .btn,
.user-id-modal-card .btn,
.shared-storage-modal-card .btn,
.adminsec-modal-card .btn{
  border-radius:4px !important;
}

.form-field input,
.form-field select,
.claim-select,
.claim-input,
.claim-textarea,
.jef-textarea,
.jef-preview input,
.user-id-field input,
.adminsec-field input,
.shared-storage-simple input,
.shared-storage-simple select,
.shared-storage-simple textarea{
  border-radius:4px !important;
}

.confirm-warning,
.jef-instructions,
.shared-storage-hero,
.shared-storage-message,
.adminsec-error{
  border-radius:4px !important;
}

.modal-icon,
.adminsec-icon{
  border-radius:6px !important;
}
</style>

</body>
</html>`);
  doc.close();

  setTimeout(()=>{
    printFrame.contentWindow.focus();
    printFrame.contentWindow.print();

    setTimeout(()=>{
      printFrame.remove();
    },1000);
  },250);
}

document.getElementById('printVidangeList').addEventListener('click',printVidangeSimple);


/* IMPORT JEF — fichier XLSX uniquement */
const jefModal=document.getElementById('jefModal');
const jefPreviewBody=document.getElementById('jefPreviewBody');
const jefSummary=document.getElementById('jefSummary');
const jefError=document.getElementById('jefError');
const jefFileName=document.getElementById('jefFileName');
const applyJef=document.getElementById('applyJef');
const jefXlsxInput=document.getElementById('jefXlsxInput');

let jefMatches=[];
let jefDetectedSheet='';

function openJefPreview(fileName){
  jefError.textContent='';
  jefFileName.textContent=fileName || '—';
  jefPreviewBody.innerHTML='';
  jefSummary.classList.add('loading');
  jefSummary.textContent='Lecture du fichier Excel…';
  applyJef.disabled=true;
  jefMatches=[];
  jefModal.hidden=false;
  document.body.classList.add('modal-open');
}

function closeJefModal(){
  jefModal.hidden=true;
  jefError.textContent='';
  jefSummary.classList.remove('loading');
  if(document.querySelectorAll('.modal-overlay:not([hidden])').length===0){
    document.body.classList.remove('modal-open');
  }
}

document.getElementById('importJef').addEventListener('click',()=>{
  jefXlsxInput.click();
});

document.getElementById('closeJefModal').addEventListener('click',closeJefModal);
document.getElementById('cancelJef').addEventListener('click',closeJefModal);
jefModal.addEventListener('click',event=>{
  if(event.target===jefModal) closeJefModal();
});

function xmlDocument(xmlText){
  const doc=new DOMParser().parseFromString(xmlText,'application/xml');
  if(doc.getElementsByTagName('parsererror').length){
    throw new Error('Le fichier Excel contient un XML illisible.');
  }
  return doc;
}

function columnIndexFromCellRef(ref){
  const letters=String(ref||'').match(/[A-Z]+/i)?.[0]?.toUpperCase() || '';
  let value=0;
  for(const char of letters){
    value=value*26+(char.charCodeAt(0)-64);
  }
  return Math.max(0,value-1);
}

function normalizeXlsxPath(target){
  let path=String(target||'').replace(/\\/g,'/');
  if(path.startsWith('/')) path=path.slice(1);
  if(path.startsWith('xl/')) return path;
  while(path.startsWith('../')) path=path.slice(3);
  return 'xl/'+path.replace(/^\/+/,'');
}

async function readSharedStrings(zip){
  const entry=zip.file('xl/sharedStrings.xml');
  if(!entry) return [];

  const doc=xmlDocument(await entry.async('string'));
  return [...doc.getElementsByTagName('si')].map(si=>
    [...si.getElementsByTagName('t')].map(node=>node.textContent||'').join('')
  );
}

function cellValue(cell,sharedStrings){
  const type=cell.getAttribute('t') || '';

  if(type==='inlineStr'){
    return [...cell.getElementsByTagName('t')].map(node=>node.textContent||'').join('');
  }

  const valueNode=cell.getElementsByTagName('v')[0];
  if(!valueNode) return '';

  const raw=valueNode.textContent ?? '';

  if(type==='s'){
    return sharedStrings[Number(raw)] ?? '';
  }
  if(type==='b'){
    return raw==='1';
  }
  if(type==='str'){
    return raw;
  }

  const number=Number(raw);
  return Number.isFinite(number) ? number : raw;
}

async function readWorksheetRows(zip,path,sharedStrings){
  const entry=zip.file(path);
  if(!entry) return [];

  const doc=xmlDocument(await entry.async('string'));
  const result=[];

  for(const rowNode of [...doc.getElementsByTagName('row')]){
    const rowIndex=Math.max(0,Number(rowNode.getAttribute('r')||1)-1);
    const row=[];

    for(const cell of [...rowNode.getElementsByTagName('c')]){
      const col=columnIndexFromCellRef(cell.getAttribute('r'));
      row[col]=cellValue(cell,sharedStrings);
    }

    result[rowIndex]=row;
  }

  return result;
}

async function readXlsxSheets(file){
  if(typeof JSZip==='undefined'){
    throw new Error('Le lecteur Excel intégré n’est pas disponible.');
  }

  const zip=await JSZip.loadAsync(file);
  const workbookEntry=zip.file('xl/workbook.xml');
  const relsEntry=zip.file('xl/_rels/workbook.xml.rels');

  if(!workbookEntry || !relsEntry){
    throw new Error('Ce fichier ne semble pas être un classeur .xlsx valide.');
  }

  const [workbookXml,relsXml,sharedStrings]=await Promise.all([
    workbookEntry.async('string'),
    relsEntry.async('string'),
    readSharedStrings(zip)
  ]);

  const workbookDoc=xmlDocument(workbookXml);
  const relsDoc=xmlDocument(relsXml);

  const relMap=new Map(
    [...relsDoc.getElementsByTagName('Relationship')].map(rel=>[
      rel.getAttribute('Id'),
      rel.getAttribute('Target')
    ])
  );

  const sheets=[];

  for(const sheetNode of [...workbookDoc.getElementsByTagName('sheet')]){
    const name=sheetNode.getAttribute('name') || 'Feuille';
    const relationId=
      sheetNode.getAttribute('r:id') ||
      sheetNode.getAttributeNS(
        'http://schemas.openxmlformats.org/officeDocument/2006/relationships',
        'id'
      );

    const target=relMap.get(relationId);
    if(!target) continue;

    const path=normalizeXlsxPath(target);
    const rows=await readWorksheetRows(zip,path,sharedStrings);
    sheets.push({name,rows});
  }

  return sheets;
}

function normalizedHeader(value){
  return String(value??'')
    .toLocaleLowerCase('fr')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g,'')
    .replace(/[^a-z0-9]/g,'');
}

function plateFromCell(value,trackedByPlate){
  const text=String(value??'').trim().toUpperCase();
  const normalized=normalizeRegistration(text);

  if(trackedByPlate.has(normalized)){
    return trackedByPlate.get(normalized).registration;
  }

  const compact=text.replace(/[^A-Z0-9]/g,'');
  const match=compact.match(/^([A-Z]{2})(\d{3})([A-Z]{2})$/);
  if(!match) return null;

  const formatted=`${match[1]}-${match[2]}-${match[3]}`;
  const known=trackedByPlate.get(normalizeRegistration(formatted));
  return known ? known.registration : formatted;
}

function mileageFromCell(value){
  if(typeof value==='number'){
    if(Number.isFinite(value) && value>=0 && value<=3000000) return Math.round(value);
    return null;
  }

  const cleaned=String(value??'')
    .replace(/\u00a0/g,' ')
    .replace(/\s/g,'')
    .replace(/[^\d.,-]/g,'');

  if(!cleaned) return null;

  const normalized=cleaned
    .replace(/[.,](?=\d{3}(?:\D|$))/g,'')
    .replace(',','.');

  const number=Number(normalized);
  if(!Number.isFinite(number) || number<0 || number>3000000) return null;
  return Math.round(number);
}

function mileageHeaderScore(value){
  const h=normalizedHeader(value);
  if(!h) return 0;

  if(
    h.includes('kilometrageactuel') ||
    h.includes('kilometragecourant') ||
    h.includes('kmactuel') ||
    h.includes('currentkm') ||
    h.includes('currentmileage') ||
    h.includes('odometer') ||
    h.includes('compteurkilometrique')
  ) return 160;

  if(
    h.includes('kilometrage') ||
    h.includes('mileage') ||
    h==='km' ||
    h.includes('odometre')
  ) return 80;

  if(
    h.includes('vidange') ||
    h.includes('garage') ||
    h.includes('derniere') ||
    h.includes('dernier') ||
    h.includes('prochaine')
  ) return -120;

  return 0;
}

function plateHeaderScore(value){
  const h=normalizedHeader(value);
  if(!h) return 0;

  if(h.includes('immatriculation') || h.includes('immat')) return 160;
  if(h.includes('plaque') || h.includes('registration') || h.includes('licenseplate')) return 120;
  if(h==='vehicule' || h==='vehicle') return 50;
  return 0;
}

function extractJefFromSheet(sheet,trackedByPlate){
  const rows=sheet.rows || [];
  const maxCols=Math.max(0,...rows.map(row=>Array.isArray(row)?row.length:0));

  if(!maxCols) return {sheetName:sheet.name,items:[],score:0};

  const plateCounts=new Array(maxCols).fill(0);
  let firstPlateRow=Infinity;

  rows.forEach((row,rowIndex)=>{
    if(!Array.isArray(row)) return;

    for(let col=0;col<row.length;col++){
      const plate=plateFromCell(row[col],trackedByPlate);
      if(plate && trackedByPlate.has(normalizeRegistration(plate))){
        plateCounts[col]++;
        firstPlateRow=Math.min(firstPlateRow,rowIndex);
      }
    }
  });

  let plateCol=plateCounts.indexOf(Math.max(...plateCounts));
  const plateCount=plateCounts[plateCol] || 0;

  if(!plateCount){
    return {sheetName:sheet.name,items:[],score:0};
  }

  const headerLimit=Number.isFinite(firstPlateRow)
    ? Math.min(firstPlateRow+1,30)
    : Math.min(rows.length,30);

  let bestHeaderRow=-1;
  let bestPlateHeader=-Infinity;

  for(let r=0;r<headerLimit;r++){
    const score=plateHeaderScore(rows[r]?.[plateCol]);
    if(score>bestPlateHeader){
      bestPlateHeader=score;
      bestHeaderRow=r;
    }
  }

  let kmCol=-1;
  let kmScore=-Infinity;

  for(let col=0;col<maxCols;col++){
    if(col===plateCol) continue;

    let headerScore=0;
    for(let r=0;r<headerLimit;r++){
      headerScore=Math.max(headerScore,mileageHeaderScore(rows[r]?.[col]));
    }

    let numericOnPlateRows=0;
    let plausibleChanges=0;

    rows.forEach(row=>{
      if(!Array.isArray(row)) return;
      const plate=plateFromCell(row[plateCol],trackedByPlate);
      if(!plate || !trackedByPlate.has(normalizeRegistration(plate))) return;

      const km=mileageFromCell(row[col]);
      if(km!==null){
        numericOnPlateRows++;
        if(km>=1000) plausibleChanges++;
      }
    });

    const score=headerScore + numericOnPlateRows*3 + plausibleChanges;
    if(score>kmScore){
      kmScore=score;
      kmCol=col;
    }
  }

  if(kmCol<0){
    return {sheetName:sheet.name,items:[],score:0};
  }

  const byPlate=new Map();

  rows.forEach((row,rowIndex)=>{
    if(!Array.isArray(row)) return;

    const plate=plateFromCell(row[plateCol],trackedByPlate);
    if(!plate) return;

    const normalized=normalizeRegistration(plate);
    const km=mileageFromCell(row[kmCol]);

    if(km===null) return;

    byPlate.set(normalized,{
      registration:plate,
      normalized,
      km,
      row:rowIndex+1
    });
  });

  const knownCount=[...byPlate.keys()].filter(key=>trackedByPlate.has(key)).length;
  const score=knownCount*100 + Math.max(0,kmScore) + plateCount;

  return {
    sheetName:sheet.name,
    items:[...byPlate.values()],
    score,
    plateCol,
    kmCol
  };
}

async function parseJefXlsx(file){
  const sheets=await readXlsxSheets(file);
  if(!sheets.length){
    throw new Error('Aucune feuille exploitable n’a été trouvée dans ce fichier Excel.');
  }

  const trackedByPlate=new Map(
    vidangeData.map(record=>[
      normalizeRegistration(record.registration),
      record
    ])
  );

  const candidates=sheets
    .map(sheet=>extractJefFromSheet(sheet,trackedByPlate))
    .sort((a,b)=>b.score-a.score);

  const best=candidates[0];

  if(!best || !best.items.length){
    throw new Error(
      'Aucune immatriculation et aucun kilométrage exploitable n’ont été détectés dans ce fichier.'
    );
  }

  jefDetectedSheet=best.sheetName;

  return best.items.map(item=>{
    const record=trackedByPlate.get(item.normalized);

    return {
      ...item,
      recordId:record?.id || null,
      currentKm:record?.currentKm ?? null
    };
  });
}

function renderJefPreview(){
  const matched=jefMatches.filter(item=>item.recordId).length;
  const unmatched=jefMatches.length-matched;

  jefPreviewBody.innerHTML=jefMatches.map((item,index)=>`
    <tr>
      <td class="plate-cell">${formatRegistration(item.registration)}</td>
      <td>
        <input
          type="text"
          inputmode="numeric"
          value="${item.km}"
          data-jef-km="${index}"
          ${item.recordId?'':'disabled'}
        >
      </td>
      <td>
        ${item.currentKm===null
          ? '—'
          : Number(item.currentKm).toLocaleString('fr-FR')+' km'}
      </td>
      <td>
        <span class="jef-match ${item.recordId?'ok':'bad'}">
          ${item.recordId?'✓ Véhicule trouvé':'✕ Absent du suivi'}
        </span>
      </td>
    </tr>
  `).join('');

  jefSummary.classList.remove('loading');
  jefSummary.textContent=
    `Feuille détectée : ${jefDetectedSheet} · `+
    `${matched} véhicule${matched>1?'s':''} rapproché${matched>1?'s':''}`+
    (unmatched
      ? ` · ${unmatched} immatriculation${unmatched>1?'s':''} non trouvée${unmatched>1?'s':''}`
      : '');

  applyJef.disabled=matched===0;

  jefPreviewBody.querySelectorAll('[data-jef-km]').forEach(input=>{
    input.addEventListener('input',()=>{
      input.value=input.value.replace(/\D/g,'');
      const index=Number(input.dataset.jefKm);
      if(jefMatches[index]){
        jefMatches[index].km=Number(input.value||0);
      }
    });
  });
}

jefXlsxInput.addEventListener('change',async()=>{
  const file=jefXlsxInput.files?.[0];
  if(!file) return;

  if(!file.name.toLocaleLowerCase('fr').endsWith('.xlsx')){
    alert('Sélectionnez uniquement un fichier Excel au format .xlsx.');
    jefXlsxInput.value='';
    return;
  }

  openJefPreview(file.name);

  try{
    jefMatches=await parseJefXlsx(file);
    renderJefPreview();
  }catch(error){
    console.warn('Erreur pendant l’import JEF XLSX.',error);
    jefMatches=[];
    jefPreviewBody.innerHTML='';
    jefSummary.classList.remove('loading');
    jefSummary.textContent='Import impossible.';
    jefError.textContent=error?.message || 'Impossible de lire ce fichier Excel.';
    applyJef.disabled=true;
  }finally{
    // Permet de sélectionner à nouveau le même fichier si nécessaire.
    jefXlsxInput.value='';
  }
});

applyJef.addEventListener('click',()=>{
  const byId=new Map(vidangeData.map(record=>[record.id,record]));
  let updated=0;

  jefMatches.forEach(match=>{
    if(!match.recordId) return;

    const record=byId.get(match.recordId);
    const km=Number(match.km);

    if(!record || !Number.isFinite(km) || km<0) return;

    record.currentKm=Math.round(km);
    updated++;
  });

  saveVidangeData();
  renderVidTable();

  if(selectedVidangeId){
    loadVidDetail();
  }

  closeJefModal();

  alert(
    `${updated} kilométrage${updated>1?'s':''} `+
    `mis à jour depuis le fichier JEF.`
  );
});

document.addEventListener('keydown',event=>{
  if(event.key==='Escape' && !jefModal.hidden){
    closeJefModal();
  }
});
renderVidTable();
loadVidDetail();



/* ===== GESTION ADMINISTRATIVE ===== */
const ADMIN_FINE_KEY='hessers-admin-fines-v1';
const ADMIN_RUNGIS_KEY='hessers-admin-rungis-v2';
const ADMIN_SITES_KEY='hessers-admin-sites-v1';


let adminFines=[];
let adminRungis=INITIAL_RUNGIS_CARDS.map(item=>({...item}));
let adminSites={dkv:'',ids:'',lumesia:''};

try{
  const saved=JSON.parse(localStorage.getItem(ADMIN_FINE_KEY));
  if(Array.isArray(saved)) adminFines=saved;
}catch(error){console.warn(error)}
try{
  const saved=JSON.parse(localStorage.getItem(ADMIN_RUNGIS_KEY));
  if(Array.isArray(saved)) adminRungis=saved;
}catch(error){console.warn(error)}
try{
  const saved=JSON.parse(localStorage.getItem(ADMIN_SITES_KEY));
  if(saved && typeof saved==='object'){
    adminSites={...adminSites,...saved};
    if(!adminSites.ids && saved.ils) adminSites.ids=saved.ils;
    delete adminSites.ils;
  }
}catch(error){console.warn(error)}

let adminActiveTab='fines';
let adminActionType=null;
let adminActionId=null;
let editingFineId=null;
let editingRungisId=null;
let editingSiteKey=null;

const adminActionsMenu=document.getElementById('adminActionsMenu');
const fineTable=document.getElementById('fineTable');
const fineTableWrap=document.getElementById('fineTableWrap');
const rungisTable=document.getElementById('rungisTable');
const rungisTableWrap=document.getElementById('rungisTableWrap');

function saveAdminFines(){localStorage.setItem(ADMIN_FINE_KEY,JSON.stringify(adminFines))}
function saveAdminRungis(){localStorage.setItem(ADMIN_RUNGIS_KEY,JSON.stringify(adminRungis))}
function saveAdminSites(){localStorage.setItem(ADMIN_SITES_KEY,JSON.stringify(adminSites))}

function adminNorm(value){
  return String(value||'').toLocaleLowerCase('fr').normalize('NFD').replace(/[\u0300-\u036f]/g,'');
}

function switchAdminTab(tab){
  adminActiveTab=tab;
  document.querySelectorAll('[data-admin-tab]').forEach(card=>card.classList.toggle('active',card.dataset.adminTab===tab));
  document.getElementById('adminSectionFines').classList.toggle('active',tab==='fines');
  document.getElementById('adminSectionRungis').classList.toggle('active',tab==='rungis');
  document.getElementById('adminSectionSites').classList.toggle('active',tab==='sites');
}
document.querySelectorAll('[data-admin-tab]').forEach(card=>card.addEventListener('click',()=>switchAdminTab(card.dataset.adminTab)));

function fineStatusClass(status){
  if(status==='Clos') return 'done';
  if(status==='Désigné'||status==='Contesté') return 'pending';
  return 'todo';
}

function updateFineKpis(){
  document.getElementById('fineTotal').textContent=adminFines.length;
  document.getElementById('fineTodo').textContent=adminFines.filter(x=>x.status==='À traiter').length;
  document.getElementById('finePending').textContent=adminFines.filter(x=>x.status==='Désigné'||x.status==='Contesté').length;
  document.getElementById('fineClosed').textContent=adminFines.filter(x=>x.status==='Clos').length;
  document.getElementById('adminHubFineCount').textContent=adminFines.length;
}

function renderFines(){
  const q=adminNorm(document.getElementById('fineSearch').value);
  const visible=[...adminFines]
    .sort((a,b)=>String(b.date||'').localeCompare(String(a.date||'')))
    .filter(item=>adminNorm(`${item.date} ${item.vehicle} ${item.driver} ${item.offense} ${item.reference} ${item.status}`).includes(q));

  if(!visible.length){
    fineTable.innerHTML=`<tr><td colspan="8" class="admin-empty">${adminFines.length?'Aucune amende ne correspond à votre recherche.':'Aucune amende enregistrée.'}</td></tr>`;
  }else{
    fineTable.innerHTML=visible.map(item=>`
      <tr data-fine-row="${item.id}" title="Ouvrir l’amende">
        <td>${item.date?new Date(item.date+'T00:00:00').toLocaleDateString('fr-FR'):'—'}</td>
        <td class="plate-cell">${item.vehicle||'—'}</td>
        <td>${item.driver||'—'}</td>
        <td>${item.offense||'—'}</td>
        <td>${item.amount?Number(String(item.amount).replace(',','.')).toLocaleString('fr-FR',{minimumFractionDigits:2,maximumFractionDigits:2})+' €':'—'}</td>
        <td>
          ${item.reference||'—'}
          ${Number(item.attachmentCount||0)>0 ? `<span class="fine-file-count">📎 ${Number(item.attachmentCount||0)}</span>` : ''}
        </td>
        <td><span class="admin-status ${fineStatusClass(item.status)}">${item.status||'À traiter'}</span></td>
        <td><button class="admin-row-menu" type="button" data-admin-menu-type="fine" data-admin-menu-id="${item.id}">•••</button></td>
      </tr>
    `).join('');
  }

  document.getElementById('fineCountLabel').textContent=`${visible.length} amende${visible.length>1?'s':''} affichée${visible.length>1?'s':''}`;
  fineTableWrap.classList.toggle('scroll',visible.length>11);
  updateFineKpis();
}

document.getElementById('fineSearch').addEventListener('input',renderFines);

fineTable.addEventListener('click',event=>{
  // Le menu ••• garde son propre comportement.
  if(event.target.closest('[data-admin-menu-type]')) return;

  const row=event.target.closest('[data-fine-row]');
  if(!row) return;

  closeAdminActions();
  openFineModal(row.dataset.fineRow);
});


function rungisVehicleInfo(registration){
  if(!registration) return null;
  const key=normalizeRegistration(registration);
  return parkData.find(v=>normalizeRegistration(v.registration)===key)||null;
}

function updateRungisKpis(){
  const assigned=adminRungis.filter(item=>String(item.vehicle||'').trim()).length;
  const free=adminRungis.length-assigned;
  const outside=adminRungis.filter(item=>item.vehicle && !rungisVehicleInfo(item.vehicle)).length;

  document.getElementById('rungisTotal').textContent=adminRungis.length;
  document.getElementById('rungisAssigned').textContent=assigned;
  document.getElementById('rungisFree').textContent=free;
  document.getElementById('rungisOutsidePark').textContent=outside;
  document.getElementById('adminHubRungisCount').textContent=adminRungis.length;
}

function renderRungis(){
  const q=adminNorm(document.getElementById('rungisSearch').value);

  const visible=[...adminRungis]
    .sort((a,b)=>String(a.cardNumber||'').localeCompare(String(b.cardNumber||''),'fr',{numeric:true}))
    .filter(item=>{
      const vehicle=rungisVehicleInfo(item.vehicle);
      const parkNumber=vehicle?.parkNumber||'';
      return adminNorm(`${item.cardNumber} ${item.vehicle} ${parkNumber}`).includes(q);
    });

  if(!visible.length){
    rungisTable.innerHTML=`<tr><td colspan="4" class="admin-empty">${adminRungis.length?'Aucune carte ne correspond à votre recherche.':'Aucune carte Rungis enregistrée.'}</td></tr>`;
  }else{
    rungisTable.innerHTML=visible.map(item=>{
      const vehicle=rungisVehicleInfo(item.vehicle);
      const parkNumber=vehicle?.parkNumber||'—';

      return `<tr>
        <td><strong>${item.cardNumber||'—'}</strong></td>
        <td class="plate-cell">${item.vehicle?formatRegistration(item.vehicle):'—'}</td>
        <td>${parkNumber}</td>
        <td><button class="admin-row-menu" type="button" data-admin-menu-type="rungis" data-admin-menu-id="${item.id}">•••</button></td>
      </tr>`;
    }).join('');
  }

  document.getElementById('rungisCountLabel').textContent=
    `${visible.length} carte${visible.length>1?'s':''} affichée${visible.length>1?'s':''}`;

  rungisTableWrap.classList.toggle('scroll',visible.length>11);
  updateRungisKpis();
}

document.getElementById('rungisSearch').addEventListener('input',renderRungis);

function driverOptionsForAdmin(){
  const names=[];
  const seen=new Set();
  if(Array.isArray(driverProfiles)){
    driverProfiles.forEach(x=>{
      const name=[x.lastName,x.firstName].filter(Boolean).join(' ').trim();
      const key=adminNorm(name);
      if(name&&!seen.has(key)){seen.add(key);names.push(name)}
    });
  }
  if(Array.isArray(affectations)){
    affectations.forEach(x=>{
      const name=String(x.name||'').trim();
      const key=adminNorm(name);
      if(name&&!seen.has(key)){seen.add(key);names.push(name)}
    });
  }
  return names.sort((a,b)=>a.localeCompare(b,'fr',{sensitivity:'base'}));
}

function vehicleOptionsForAdmin(){
  return [...parkData]
    .sort((a,b)=>{
      const order={Tracteur:0,Semi:1};
      return (order[a.type]??9)-(order[b.type]??9)||normalizeRegistration(a.registration).localeCompare(normalizeRegistration(b.registration),'fr',{numeric:true});
    })
    .map(v=>({value:formatRegistration(v.registration),label:`${formatRegistration(v.registration)} · ${v.type}${v.parkNumber?' · '+v.parkNumber:''}`}));
}

/* Amende modal */
const fineModal=document.getElementById('fineModal');
const fineForm=document.getElementById('fineForm');
const fineDriverSelect=document.getElementById('fineDriver');
const openFineDriverProfileButton=document.getElementById('openFineDriverProfile');
const fineDriverPreview=document.getElementById('fineDriverPreview');
const closeFineDriverPreviewButton=document.getElementById('closeFineDriverPreview');


/* ===== PIÈCES JOINTES AMENDES ===== */
const FINE_FILES_FOLDER='pieces_jointes_amendes';
let pendingFineFiles=[];

const fineAttachmentInput=document.getElementById('fineAttachmentInput');
const fineAttachmentList=document.getElementById('fineAttachmentList');
const fineAttachmentWarning=document.getElementById('fineAttachmentWarning');
const addFineAttachmentButton=document.getElementById('addFineAttachment');

function fineSafeFilePart(value){
  return String(value||'')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g,'')
    .replace(/[<>:"/\\|?*\x00-\x1F]/g,'_')
    .replace(/\s+/g,' ')
    .trim()
    .slice(0,120) || 'fichier';
}

async function fineFilesDirectory(create=false){
  if(!sharedConnected || !sharedDirectoryHandle) return null;
  return await sharedDirectoryHandle.getDirectoryHandle(FINE_FILES_FOLDER,{create});
}

async function putFineFile(fineId,file){
  if(!sharedConnected || !sharedDirectoryHandle){
    throw new Error('Stockage partagé non connecté.');
  }

  const dir=await fineFilesDirectory(true);
  const id='file_'+Date.now()+'_'+Math.random().toString(36).slice(2);
  const storedName=
    `${fineSafeFilePart(fineId)}__${id}__${fineSafeFilePart(file.name)}`;

  const handle=await dir.getFileHandle(storedName,{create:true});
  const writable=await handle.createWritable();
  await writable.write(file);
  await writable.close();

  return {
    key:'fine-shared::'+storedName,
    fineId,
    id,
    name:file.name,
    type:file.type,
    size:file.size,
    addedAt:new Date().toISOString()
  };
}

async function getFineFiles(fineId){
  if(!fineId || !sharedConnected || !sharedDirectoryHandle) return [];

  let dir;
  try{
    dir=await fineFilesDirectory(false);
  }catch(error){
    if(error?.name==='NotFoundError') return [];
    throw error;
  }
  if(!dir) return [];

  const prefix=fineSafeFilePart(fineId)+'__';
  const records=[];

  for await(const [storedName,handle] of dir.entries()){
    if(handle.kind!=='file' || !storedName.startsWith(prefix)) continue;

    const file=await handle.getFile();
    const first=storedName.indexOf('__');
    const second=storedName.indexOf('__',first+2);
    const id=second>first ? storedName.slice(first+2,second) : storedName;
    const displayName=second>=0 ? storedName.slice(second+2) : storedName;

    records.push({
      key:'fine-shared::'+storedName,
      fineId,
      id,
      name:displayName,
      type:file.type,
      size:file.size,
      addedAt:new Date(file.lastModified).toISOString()
    });
  }

  return records.sort((a,b)=>String(a.addedAt).localeCompare(String(b.addedAt)));
}

async function deleteFineFile(key){
  if(!sharedConnected || !sharedDirectoryHandle) return;
  if(!String(key||'').startsWith('fine-shared::')) return;

  const dir=await fineFilesDirectory(false);
  if(!dir) return;

  await dir.removeEntry(String(key).slice('fine-shared::'.length));
}

async function deleteAllFineFiles(fineId){
  if(!fineId || !sharedConnected || !sharedDirectoryHandle) return;

  let dir;
  try{
    dir=await fineFilesDirectory(false);
  }catch(error){
    if(error?.name==='NotFoundError') return;
    throw error;
  }
  if(!dir) return;

  const prefix=fineSafeFilePart(fineId)+'__';
  const toDelete=[];

  for await(const [name,handle] of dir.entries()){
    if(handle.kind==='file' && name.startsWith(prefix)) toDelete.push(name);
  }

  for(const name of toDelete){
    await dir.removeEntry(name);
  }
}

async function openFineFile(key){
  if(!sharedConnected || !sharedDirectoryHandle) return;
  if(!String(key||'').startsWith('fine-shared::')) return;

  try{
    const dir=await fineFilesDirectory(false);
    const storedName=String(key).slice('fine-shared::'.length);
    const handle=await dir.getFileHandle(storedName);
    const file=await handle.getFile();
    const url=URL.createObjectURL(file);

    const link=document.createElement('a');
    link.href=url;
    link.target='_blank';
    link.rel='noopener';
    link.click();

    setTimeout(()=>URL.revokeObjectURL(url),15000);
  }catch(error){
    dashboardToast('Fichier impossible à ouvrir',String(error),'error',4000);
  }
}

function fineFormatSize(bytes){
  if(bytes<1024) return bytes+' o';
  if(bytes<1024*1024) return (bytes/1024).toFixed(1).replace('.',',')+' Ko';
  return (bytes/(1024*1024)).toFixed(1).replace('.',',')+' Mo';
}

async function renderFineAttachments(){
  if(!fineAttachmentList) return;

  fineAttachmentWarning.hidden=sharedConnected;

  const savedFiles=editingFineId
    ? await getFineFiles(editingFineId).catch(error=>{
        console.warn('Impossible de lire les pièces jointes Amende.',error);
        return [];
      })
    : [];

  const savedHtml=savedFiles.map(file=>`
    <div class="fine-file">
      <span>▤</span>
      <span class="fine-file-name saved"
            data-open-fine-file="${dashboardEsc(file.key)}"
            title="Ouvrir ${dashboardEsc(file.name)}">${dashboardEsc(file.name)}</span>
      <span class="fine-file-meta">${fineFormatSize(file.size)}</span>
      <button class="fine-file-remove"
              type="button"
              data-delete-fine-file="${dashboardEsc(file.key)}"
              aria-label="Supprimer ${dashboardEsc(file.name)}">✕</button>
    </div>
  `).join('');

  const pendingHtml=pendingFineFiles.map((file,index)=>`
    <div class="fine-file pending">
      <span>▤</span>
      <span class="fine-file-name" title="${dashboardEsc(file.name)}">${dashboardEsc(file.name)}</span>
      <span class="fine-file-meta">${fineFormatSize(file.size)} · à enregistrer</span>
      <button class="fine-file-remove"
              type="button"
              data-remove-pending-fine-file="${index}"
              aria-label="Retirer ${dashboardEsc(file.name)}">✕</button>
    </div>
  `).join('');

  fineAttachmentList.innerHTML=(savedHtml+pendingHtml) ||
    '<span class="vehicle-none">Aucune pièce jointe.</span>';
}

async function updateFineAttachmentCount(fineId){
  const item=adminFines.find(x=>x.id===fineId);
  if(!item) return;

  const files=await getFineFiles(fineId).catch(()=>[]);
  item.attachmentCount=files.length;
  saveAdminFines();
  renderFines();
}

addFineAttachmentButton?.addEventListener('click',()=>{
  if(!sharedConnected){
    fineAttachmentWarning.hidden=false;
    dashboardToast(
      'Stockage partagé requis',
      'Connecte le dossier data avant d’ajouter une pièce jointe.',
      'warn',
      3500
    );
    return;
  }
  fineAttachmentInput.click();
});

fineAttachmentInput?.addEventListener('change',()=>{
  if(!fineAttachmentInput.files?.length) return;

  pendingFineFiles.push(...fineAttachmentInput.files);
  fineAttachmentInput.value='';
  renderFineAttachments();
});

fineAttachmentList?.addEventListener('click',async event=>{
  const pendingButton=event.target.closest('[data-remove-pending-fine-file]');
  if(pendingButton){
    pendingFineFiles.splice(Number(pendingButton.dataset.removePendingFineFile),1);
    renderFineAttachments();
    return;
  }

  const deleteButton=event.target.closest('[data-delete-fine-file]');
  if(deleteButton && editingFineId){
    if(!confirm('Supprimer cette pièce jointe ?')) return;

    try{
      await deleteFineFile(deleteButton.dataset.deleteFineFile);
      await updateFineAttachmentCount(editingFineId);

      administratorWriteHistory({
        action:'Pièce jointe',
        section:'Amendes',
        entity:adminFines.find(x=>x.id===editingFineId)?.reference || editingFineId,
        detail:'Suppression d’une pièce jointe'
      });

      await renderFineAttachments();
    }catch(error){
      dashboardToast('Suppression impossible',String(error),'error',4000);
    }
    return;
  }

  const openButton=event.target.closest('[data-open-fine-file]');
  if(openButton){
    await openFineFile(openButton.dataset.openFineFile);
  }
});


function fineDriverKey(value){
  return adminNorm(value).replace(/\s+/g,' ').trim();
}

function findFineDriverProfile(name){
  const key=fineDriverKey(name);
  if(!key || !Array.isArray(driverProfiles)) return null;
  return driverProfiles.find(driver=>fineDriverKey(driverDisplayName(driver))===key) || null;
}

function updateFineDriverProfileButton(){
  if(!openFineDriverProfileButton || !fineDriverSelect) return;
  const name=String(fineDriverSelect.value||'').trim();
  const profile=findFineDriverProfile(name);
  openFineDriverProfileButton.disabled=!profile;
  openFineDriverProfileButton.title=profile
    ? `Ouvrir la fiche chauffeur de ${driverDisplayName(profile)}`
    : (name ? 'Aucune fiche chauffeur correspondante trouvée' : 'Sélectionnez un chauffeur');
}

function fineDriverPreviewDate(value){
  const raw=String(value||'').trim();
  if(!raw) return '—';
  const match=raw.match(/^(\d{4})-(\d{2})-(\d{2})/);
  return match ? `${match[3]}/${match[2]}/${match[1]}` : raw;
}

function fineDriverPreviewSet(id,value){
  const element=document.getElementById(id);
  if(element) element.textContent=String(value||'').trim() || '—';
}

function closeFineDriverPreview(){
  if(fineDriverPreview) fineDriverPreview.hidden=true;
}

function renderFineDriverPreview(profile){
  if(!profile || !fineDriverPreview) return;
  const fullName=driverDisplayName(profile);
  const initials=`${String(profile.firstName||'').trim().charAt(0)}${String(profile.lastName||'').trim().charAt(0)}`.toUpperCase() || '—';
  fineDriverPreviewSet('fineDriverPreviewTitle',fullName);
  fineDriverPreviewSet('fineDriverPreviewName',fullName);
  fineDriverPreviewSet('fineDriverPreviewAvatar',initials);
  fineDriverPreviewSet('fineDriverPreviewBirthDate',fineDriverPreviewDate(profile.birthDate));
  fineDriverPreviewSet('fineDriverPreviewBirthCity',profile.birthCity);
  fineDriverPreviewSet('fineDriverPreviewBirthPostalCode',profile.birthPostalCode);
  fineDriverPreviewSet('fineDriverPreviewPhone',profile.phone);
  fineDriverPreviewSet('fineDriverPreviewAddress',profile.address);
  fineDriverPreviewSet('fineDriverPreviewPostalCode',profile.postalCode);
  fineDriverPreviewSet('fineDriverPreviewCity',profile.city);
  fineDriverPreviewSet('fineDriverPreviewLicense',profile.licenseNumber);
  fineDriverPreviewSet('fineDriverPreviewLicenseIssue',fineDriverPreviewDate(profile.licenseIssueDate));
  fineDriverPreviewSet('fineDriverPreviewLicenseExpiry',fineDriverPreviewDate(profile.licenseExpiry));
  fineDriverPreview.hidden=false;
}

function openFineSelectedDriverProfile(){
  const name=String(fineDriverSelect?.value||'').trim();
  const profile=findFineDriverProfile(name);
  if(!profile){
    dashboardToast(
      'Fiche chauffeur introuvable',
      name ? `Aucune fiche chauffeur ne correspond à ${name}.` : 'Sélectionnez d’abord un chauffeur.',
      'warn',
      3500
    );
    return;
  }
  renderFineDriverPreview(profile);
}

fineDriverSelect?.addEventListener('change',()=>{
  updateFineDriverProfileButton();
  if(fineDriverPreview && !fineDriverPreview.hidden){
    const profile=findFineDriverProfile(String(fineDriverSelect.value||'').trim());
    if(profile) renderFineDriverPreview(profile);
    else closeFineDriverPreview();
  }
});
openFineDriverProfileButton?.addEventListener('click',openFineSelectedDriverProfile);
closeFineDriverPreviewButton?.addEventListener('click',closeFineDriverPreview);

function fillFineSelectors(){
  const vehicle=document.getElementById('fineVehicle');
  vehicle.innerHTML='<option value="">— Sélectionner —</option>'+vehicleOptionsForAdmin().map(x=>`<option value="${x.value}">${x.label}</option>`).join('');
  const driver=fineDriverSelect;
  driver.innerHTML='<option value="">— Sélectionner —</option>'+driverOptionsForAdmin().map(x=>`<option value="${x}">${x}</option>`).join('');
  updateFineDriverProfileButton();
}
function openFineModal(id=null){
  editingFineId=id;
  pendingFineFiles=[];
  closeFineDriverPreview();
  fineForm.reset();
  fillFineSelectors();
  document.getElementById('fineModalTitle').textContent=id?'Modifier l’amende':'Ajouter une amende';
  const item=adminFines.find(x=>x.id===id);
  if(item){
    document.getElementById('fineDate').value=item.date||'';
    document.getElementById('fineVehicle').value=item.vehicle||'';
    document.getElementById('fineDriver').value=item.driver||'';
    document.getElementById('fineAmount').value=item.amount||'';
    document.getElementById('fineOffense').value=item.offense||'';
    document.getElementById('fineReference').value=item.reference||'';
    document.getElementById('fineStatus').value=item.status||'À traiter';
    document.getElementById('fineNotes').value=item.notes||'';
  }else{
    document.getElementById('fineStatus').value='À traiter';
  }
  updateFineDriverProfileButton();
  fineModal.hidden=false;
  document.body.classList.add('modal-open');
  renderFineAttachments();
}
function closeFineModal(){
  closeFineDriverPreview();
  fineModal.hidden=true;
  editingFineId=null;
  pendingFineFiles=[];
  if(fineAttachmentInput) fineAttachmentInput.value='';
  if(document.querySelectorAll('.modal-overlay:not([hidden])').length===0)document.body.classList.remove('modal-open')
}
document.getElementById('addFine').addEventListener('click',()=>openFineModal());
document.getElementById('closeFineModal').addEventListener('click',closeFineModal);
document.getElementById('cancelFineModal').addEventListener('click',closeFineModal);
fineModal.addEventListener('click',e=>{if(e.target===fineModal)closeFineModal()});
fineForm.addEventListener('submit',async e=>{
  e.preventDefault();

  const data={
    date:document.getElementById('fineDate').value,
    vehicle:document.getElementById('fineVehicle').value,
    driver:document.getElementById('fineDriver').value,
    amount:document.getElementById('fineAmount').value.trim(),
    offense:document.getElementById('fineOffense').value.trim(),
    reference:document.getElementById('fineReference').value.trim(),
    status:document.getElementById('fineStatus').value,
    notes:document.getElementById('fineNotes').value.trim()
  };

  let fineId=editingFineId;

  if(editingFineId){
    const item=adminFines.find(x=>x.id===editingFineId);
    if(item) Object.assign(item,data);
  }else{
    fineId='fine_'+Date.now()+'_'+Math.random().toString(36).slice(2);
    adminFines.push({id:fineId,attachmentCount:0,...data});
  }

  saveAdminFines();

  const filesToSave=[...pendingFineFiles];

  if(filesToSave.length){
    if(!sharedConnected){
      dashboardToast(
        'Amende enregistrée sans les fichiers',
        'Le stockage partagé n’est pas connecté.',
        'warn',
        4000
      );
    }else{
      try{
        for(const file of filesToSave){
          await putFineFile(fineId,file);
        }

        const item=adminFines.find(x=>x.id===fineId);
        if(item){
          const files=await getFineFiles(fineId);
          item.attachmentCount=files.length;
          saveAdminFines();
        }

        administratorWriteHistory({
          action:'Pièce jointe',
          section:'Amendes',
          entity:data.reference || fineId,
          detail:`${filesToSave.length} fichier${filesToSave.length>1?'s':''} ajouté${filesToSave.length>1?'s':''}`
        });
      }catch(error){
        dashboardToast(
          'Fichier(s) non enregistré(s)',
          String(error),
          'error',
          4500
        );
      }
    }
  }

  closeFineModal();
  renderFines();
});

/* Rungis modal */
const rungisModal=document.getElementById('rungisModal');
const rungisForm=document.getElementById('rungisForm');
const rungisError=document.getElementById('rungisError');

function fillRungisVehicles(){
  const select=document.getElementById('rungisVehicle');
  select.innerHTML=
    '<option value="">— Aucune immatriculation —</option>'+
    vehicleOptionsForAdmin().map(x=>`<option value="${x.value}">${x.label}</option>`).join('');
}

function updateRungisParkPreview(){
  const registration=document.getElementById('rungisVehicle').value;
  const vehicle=rungisVehicleInfo(registration);
  document.getElementById('rungisParkNumberPreview').value=vehicle?.parkNumber||'—';
}

function openRungisModal(id=null){
  editingRungisId=id;
  rungisForm.reset();
  rungisError.textContent='';
  fillRungisVehicles();

  document.getElementById('rungisModalTitle').textContent=
    id?'Modifier la carte Rungis':'Ajouter une carte Rungis';

  const item=adminRungis.find(x=>x.id===id);

  if(item){
    document.getElementById('rungisCardNumber').value=item.cardNumber||'';

    const select=document.getElementById('rungisVehicle');
    const registration=item.vehicle?formatRegistration(item.vehicle):'';

    if(registration && ![...select.options].some(option=>option.value===registration)){
      const option=document.createElement('option');
      option.value=registration;
      option.textContent=`${registration} · HORS PARC`;
      select.appendChild(option);
    }

    select.value=registration;
  }

  updateRungisParkPreview();
  rungisModal.hidden=false;
  document.body.classList.add('modal-open');
}

function closeRungisModal(){
  rungisModal.hidden=true;
  editingRungisId=null;
  rungisError.textContent='';
  if(document.querySelectorAll('.modal-overlay:not([hidden])').length===0){
    document.body.classList.remove('modal-open');
  }
}

document.getElementById('rungisVehicle').addEventListener('change',updateRungisParkPreview);
document.getElementById('addRungis').addEventListener('click',()=>openRungisModal());
document.getElementById('closeRungisModal').addEventListener('click',closeRungisModal);
document.getElementById('cancelRungisModal').addEventListener('click',closeRungisModal);
rungisModal.addEventListener('click',e=>{if(e.target===rungisModal)closeRungisModal()});

rungisForm.addEventListener('submit',e=>{
  e.preventDefault();

  const cardNumber=document.getElementById('rungisCardNumber').value.trim();
  const vehicle=document.getElementById('rungisVehicle').value;

  if(!cardNumber){
    rungisError.textContent='Renseignez le n° de carte.';
    return;
  }

  const duplicate=adminRungis.some(item=>
    item.id!==editingRungisId &&
    String(item.cardNumber||'').trim().toLocaleLowerCase('fr')===cardNumber.toLocaleLowerCase('fr')
  );

  if(duplicate){
    rungisError.textContent='Ce n° de carte existe déjà.';
    return;
  }

  const data={cardNumber,vehicle};

  if(editingRungisId){
    const item=adminRungis.find(x=>x.id===editingRungisId);
    if(item) Object.assign(item,data);
  }else{
    adminRungis.push({
      id:'rungis_'+Date.now()+'_'+Math.random().toString(36).slice(2),
      ...data
    });
  }

  saveAdminRungis();
  closeRungisModal();
  renderRungis();
});

/* Context menu */
function closeAdminActions(){adminActionsMenu.hidden=true;adminActionType=null;adminActionId=null}
document.addEventListener('click',e=>{
  const button=e.target.closest('[data-admin-menu-type]');
  if(button){
    e.stopPropagation();
    adminActionType=button.dataset.adminMenuType;adminActionId=button.dataset.adminMenuId;
    adminActionsMenu.hidden=false;
    const r=button.getBoundingClientRect(),m=adminActionsMenu.getBoundingClientRect();
    adminActionsMenu.style.left=Math.max(10,Math.min(r.right-m.width,window.innerWidth-m.width-10))+'px';
    let top=r.bottom+6;if(top+m.height>window.innerHeight-10)top=r.top-m.height-6;
    adminActionsMenu.style.top=Math.max(10,top)+'px';
    return;
  }
  if(!adminActionsMenu.hidden&&!adminActionsMenu.contains(e.target))closeAdminActions();
});
document.getElementById('adminEditAction').addEventListener('click',()=>{
  const type=adminActionType,id=adminActionId;closeAdminActions();
  if(type==='fine')openFineModal(id);else if(type==='rungis')openRungisModal(id);
});

/* Delete */
const adminDeleteModal=document.getElementById('adminDeleteModal');
let deleteAdminType=null,deleteAdminId=null;
function openAdminDelete(type,id){
  deleteAdminType=type;deleteAdminId=id;
  const item=type==='fine'?adminFines.find(x=>x.id===id):adminRungis.find(x=>x.id===id);
  document.getElementById('adminDeleteText').textContent=type==='fine'
    ? `L’amende ${item?.reference?item.reference:'sélectionnée'} sera supprimée.`
    : `La carte Rungis ${item?.cardNumber||'sélectionnée'} sera supprimée.`;
  adminDeleteModal.hidden=false;document.body.classList.add('modal-open');
}
function closeAdminDelete(){adminDeleteModal.hidden=true;deleteAdminType=null;deleteAdminId=null;if(document.querySelectorAll('.modal-overlay:not([hidden])').length===0)document.body.classList.remove('modal-open')}
document.getElementById('adminDeleteAction').addEventListener('click',()=>{
  const t=adminActionType,i=adminActionId;closeAdminActions();openAdminDelete(t,i);
});
document.getElementById('confirmAdminDelete').addEventListener('click',async()=>{
  if(deleteAdminType==='fine'){
    const fineId=deleteAdminId;

    try{
      await deleteAllFineFiles(fineId);
    }catch(error){
      console.warn('Impossible de supprimer les pièces jointes de l’amende.',error);
    }

    adminFines=adminFines.filter(x=>x.id!==fineId);
    saveAdminFines();
    renderFines();
  }
  else if(deleteAdminType==='rungis'){
    adminRungis=adminRungis.filter(x=>x.id!==deleteAdminId);
    saveAdminRungis();
    renderRungis();
  }
  closeAdminDelete();
});
document.getElementById('closeAdminDelete').addEventListener('click',closeAdminDelete);
document.getElementById('cancelAdminDelete').addEventListener('click',closeAdminDelete);
adminDeleteModal.addEventListener('click',e=>{if(e.target===adminDeleteModal)closeAdminDelete()});

/* Sites */
function renderAdminSites(){
  ['dkv','ids','lumesia'].forEach(key=>{
    const url=String(adminSites[key]||'').trim();
    document.getElementById('siteUrl_'+key).textContent=url||'Adresse non configurée';
    const button=document.querySelector(`[data-open-site="${key}"]`);
    button.classList.toggle('disabled',!url);
  });
}
function openSiteUrlModal(key){
  editingSiteKey=key;
  document.getElementById('siteUrlModalTitle').textContent=`Configurer ${key==='dkv'?'DKV':key==='ids'?'IDS':'Lumesia'}`;
  document.getElementById('siteUrlInput').value=adminSites[key]||'';
  document.getElementById('siteUrlError').textContent='';
  document.getElementById('siteUrlModal').hidden=false;document.body.classList.add('modal-open');
}
function closeSiteUrlModal(){document.getElementById('siteUrlModal').hidden=true;editingSiteKey=null;if(document.querySelectorAll('.modal-overlay:not([hidden])').length===0)document.body.classList.remove('modal-open')}
document.querySelectorAll('[data-edit-site]').forEach(btn=>btn.addEventListener('click',()=>openSiteUrlModal(btn.dataset.editSite)));
document.querySelectorAll('[data-open-site]').forEach(btn=>btn.addEventListener('click',()=>{
  const url=String(adminSites[btn.dataset.openSite]||'').trim();if(url)window.open(url,'_blank','noopener,noreferrer');
}));
document.getElementById('closeSiteUrlModal').addEventListener('click',closeSiteUrlModal);
document.getElementById('cancelSiteUrlModal').addEventListener('click',closeSiteUrlModal);
document.getElementById('siteUrlModal').addEventListener('click',e=>{if(e.target===document.getElementById('siteUrlModal'))closeSiteUrlModal()});
document.getElementById('siteUrlForm').addEventListener('submit',e=>{
  e.preventDefault();
  let url=document.getElementById('siteUrlInput').value.trim();
  if(url&&!/^https?:\/\//i.test(url))url='https://'+url;
  if(url){
    try{new URL(url)}catch(error){document.getElementById('siteUrlError').textContent='Adresse invalide.';return}
  }
  adminSites[editingSiteKey]=url;saveAdminSites();renderAdminSites();closeSiteUrlModal();
});

window.addEventListener('resize',closeAdminActions);
window.addEventListener('scroll',closeAdminActions,true);
document.addEventListener('keydown',e=>{
  if(e.key!=='Escape')return;
  if(!adminDeleteModal.hidden)closeAdminDelete();
  else if(!fineModal.hidden)closeFineModal();
  else if(!rungisModal.hidden)closeRungisModal();
  else if(!document.getElementById('siteUrlModal').hidden)closeSiteUrlModal();
  else closeAdminActions();
});

renderFines();
renderRungis();
renderAdminSites();
switchAdminTab('fines');



/* ===== PAGE CARBURANT ===== */
const FUEL_STORAGE_KEY='hessers-fuel-tracking-v1';

let fuelEntries=[];
try{
  const stored=JSON.parse(localStorage.getItem(FUEL_STORAGE_KEY));
  if(Array.isArray(stored)) fuelEntries=stored;
}catch(error){
  console.warn('Impossible de lire le suivi carburant.',error);
}

let editingFuelId=null;
let activeFuelMenuId=null;
let pendingDeleteFuelId=null;

const fuelTable=document.getElementById('fuelTable');
const fuelTableWrap=document.getElementById('fuelTableWrap');
const fuelSearch=document.getElementById('fuelSearch');
const fuelActionsMenu=document.getElementById('fuelActionsMenu');
const fuelModal=document.getElementById('fuelModal');
const deleteFuelModal=document.getElementById('deleteFuelModal');

function saveFuelEntries(){
  try{
    localStorage.setItem(FUEL_STORAGE_KEY,JSON.stringify(fuelEntries));
    return true;
  }catch(error){
    console.warn('Impossible d’enregistrer le suivi carburant.',error);
    return false;
  }
}

function fuelNorm(value){
  return String(value||'')
    .toLocaleLowerCase('fr')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g,'');
}

function fuelNumber(value){
  if(value===null || value===undefined || value==='') return null;

  const cleaned=String(value)
    .trim()
    .replace(/\s/g,'')
    .replace(',','.');

  const number=Number(cleaned);
  return Number.isFinite(number)?number:null;
}

function fuelFormatPrice(value){
  const number=fuelNumber(value);
  return number===null
    ? '—'
    : number.toLocaleString('fr-FR',{
        minimumFractionDigits:3,
        maximumFractionDigits:3
      })+' €';
}

function fuelFormatDate(value){
  if(!value) return '—';
  const date=new Date(value+'T00:00:00');
  return Number.isNaN(date.getTime())
    ? value
    : date.toLocaleDateString('fr-FR');
}

function averageFuelField(field){
  const values=fuelEntries
    .map(item=>fuelNumber(item[field]))
    .filter(value=>value!==null);

  if(!values.length) return null;

  return values.reduce((sum,value)=>sum+value,0)/values.length;
}

function updateFuelKpis(){
  document.getElementById('fuelAvgDiesel').textContent=
    fuelFormatPrice(averageFuelField('dieselPrice'));

  document.getElementById('fuelAvgGnr').textContent=
    fuelFormatPrice(averageFuelField('gnrPrice'));

  document.getElementById('fuelAvgAdblue').textContent=
    fuelFormatPrice(averageFuelField('adbluePrice'));
}

function latestFuelEntry(){
  return [...fuelEntries]
    .sort((a,b)=>
      String(b.deliveryDate||b.orderDate||'')
        .localeCompare(String(a.deliveryDate||a.orderDate||''))
    )[0] || null;
}

function updateFuelLastCard(){
  const item=latestFuelEntry();

  document.getElementById('fuelLastSupplier').textContent=item?.supplier||'—';
  document.getElementById('fuelLastDelivery').textContent=
    item ? fuelFormatDate(item.deliveryDate||item.orderDate) : '—';
  document.getElementById('fuelLastDiesel').textContent=
    item ? fuelFormatPrice(item.dieselPrice) : '—';
  document.getElementById('fuelLastGnr').textContent=
    item ? fuelFormatPrice(item.gnrPrice) : '—';
}

function renderFuelTable(){
  const q=fuelNorm(fuelSearch.value);

  const visible=[...fuelEntries]
    .sort((a,b)=>
      String(b.orderDate||'').localeCompare(String(a.orderDate||''))
    )
    .filter(item=>
      fuelNorm(
        `${item.supplier} ${item.orderDate} ${item.deliveryDate} `+
        `${item.dieselPrice} ${item.gnrPrice} ${item.adbluePrice}`
      ).includes(q)
    );

  if(!visible.length){
    fuelTable.innerHTML=`
      <tr>
        <td colspan="7" class="fuel-empty">
          ${fuelEntries.length
            ? 'Aucune commande ne correspond à votre recherche.'
            : 'Aucune commande carburant enregistrée.'}
        </td>
      </tr>
    `;
  }else{
    fuelTable.innerHTML=visible.map(item=>`
      <tr>
        <td><strong>${item.supplier||'—'}</strong></td>
        <td>${fuelFormatDate(item.orderDate)}</td>
        <td>${fuelFormatDate(item.deliveryDate)}</td>
        <td class="fuel-price">${fuelFormatPrice(item.dieselPrice)}</td>
        <td class="fuel-price">${fuelFormatPrice(item.gnrPrice)}</td>
        <td class="fuel-price">${fuelFormatPrice(item.adbluePrice)}</td>
        <td>
          <button
            class="fuel-row-menu"
            type="button"
            data-fuel-menu="${item.id}"
            aria-label="Actions"
          >•••</button>
        </td>
      </tr>
    `).join('');
  }

  document.getElementById('fuelCountLabel').textContent=
    `${visible.length} commande${visible.length>1?'s':''} affichée${visible.length>1?'s':''}`;

  fuelTableWrap.classList.toggle('scroll',visible.length>11);

  updateFuelKpis();
  updateFuelLastCard();

  requestAnimationFrame(renderFuelCharts);
}

fuelSearch.addEventListener('input',renderFuelTable);

/* ----- Ajout / modification ----- */
const fuelForm=document.getElementById('fuelForm');
const fuelError=document.getElementById('fuelError');

function openFuelModal(id=null){
  editingFuelId=id;
  fuelForm.reset();
  fuelError.textContent='';

  const item=fuelEntries.find(entry=>entry.id===id);

  document.getElementById('fuelModalTitle').textContent=
    item ? 'Modifier la commande' : 'Ajouter une commande';

  if(item){
    document.getElementById('fuelSupplier').value=item.supplier||'';
    document.getElementById('fuelOrderDate').value=item.orderDate||'';
    document.getElementById('fuelDeliveryDate').value=item.deliveryDate||'';
    document.getElementById('fuelDieselPrice').value=item.dieselPrice??'';
    document.getElementById('fuelGnrPrice').value=item.gnrPrice??'';
    document.getElementById('fuelAdbluePrice').value=item.adbluePrice??'';
  }

  fuelModal.hidden=false;
  document.body.classList.add('modal-open');
}

function closeFuelModal(){
  fuelModal.hidden=true;
  editingFuelId=null;
  fuelError.textContent='';

  if(document.querySelectorAll('.modal-overlay:not([hidden])').length===0){
    document.body.classList.remove('modal-open');
  }
}

document.getElementById('addFuelEntry').addEventListener('click',()=>openFuelModal());
document.getElementById('closeFuelModal').addEventListener('click',closeFuelModal);
document.getElementById('cancelFuelModal').addEventListener('click',closeFuelModal);
fuelModal.addEventListener('click',event=>{
  if(event.target===fuelModal) closeFuelModal();
});

fuelForm.addEventListener('submit',event=>{
  event.preventDefault();

  const supplier=document.getElementById('fuelSupplier').value.trim();

  if(!supplier){
    fuelError.textContent='Renseignez le fournisseur.';
    return;
  }

  const data={
    supplier,
    orderDate:document.getElementById('fuelOrderDate').value,
    deliveryDate:document.getElementById('fuelDeliveryDate').value,
    dieselPrice:document.getElementById('fuelDieselPrice').value.trim(),
    gnrPrice:document.getElementById('fuelGnrPrice').value.trim(),
    adbluePrice:document.getElementById('fuelAdbluePrice').value.trim()
  };

  if(editingFuelId){
    const item=fuelEntries.find(entry=>entry.id===editingFuelId);
    if(item) Object.assign(item,data);
  }else{
    fuelEntries.push({
      id:'fuel_'+Date.now()+'_'+Math.random().toString(36).slice(2),
      ...data
    });
  }

  saveFuelEntries();
  closeFuelModal();
  renderFuelTable();
});

/* ----- Menu actions ----- */
function closeFuelActionsMenu(){
  fuelActionsMenu.hidden=true;
  activeFuelMenuId=null;
}

function openFuelActionsMenu(button,id){
  closeFuelActionsMenu();

  activeFuelMenuId=id;
  fuelActionsMenu.hidden=false;

  const rect=button.getBoundingClientRect();
  const menuRect=fuelActionsMenu.getBoundingClientRect();

  const left=Math.max(
    10,
    Math.min(
      rect.right-menuRect.width,
      window.innerWidth-menuRect.width-10
    )
  );

  let top=rect.bottom+6;

  if(top+menuRect.height>window.innerHeight-10){
    top=rect.top-menuRect.height-6;
  }

  fuelActionsMenu.style.left=left+'px';
  fuelActionsMenu.style.top=Math.max(10,top)+'px';
}

fuelTable.addEventListener('click',event=>{
  const button=event.target.closest('[data-fuel-menu]');
  if(!button) return;

  event.stopPropagation();
  openFuelActionsMenu(button,button.dataset.fuelMenu);
});

document.getElementById('editFuelAction').addEventListener('click',()=>{
  const id=activeFuelMenuId;
  closeFuelActionsMenu();

  if(id) openFuelModal(id);
});

/* ----- Suppression ----- */
function openDeleteFuelModal(id){
  const item=fuelEntries.find(entry=>entry.id===id);
  if(!item) return;

  pendingDeleteFuelId=id;

  document.getElementById('deleteFuelText').textContent=
    `La commande ${item.supplier||''} du ${fuelFormatDate(item.orderDate)} sera supprimée.`;

  deleteFuelModal.hidden=false;
  document.body.classList.add('modal-open');
}

function closeDeleteFuelModal(){
  deleteFuelModal.hidden=true;
  pendingDeleteFuelId=null;

  if(document.querySelectorAll('.modal-overlay:not([hidden])').length===0){
    document.body.classList.remove('modal-open');
  }
}

document.getElementById('deleteFuelAction').addEventListener('click',()=>{
  const id=activeFuelMenuId;
  closeFuelActionsMenu();

  if(id) openDeleteFuelModal(id);
});

document.getElementById('confirmDeleteFuel').addEventListener('click',()=>{
  if(!pendingDeleteFuelId) return;

  fuelEntries=fuelEntries.filter(item=>item.id!==pendingDeleteFuelId);

  saveFuelEntries();
  closeDeleteFuelModal();
  renderFuelTable();
});

document.getElementById('closeDeleteFuel').addEventListener('click',closeDeleteFuelModal);
document.getElementById('cancelDeleteFuel').addEventListener('click',closeDeleteFuelModal);
deleteFuelModal.addEventListener('click',event=>{
  if(event.target===deleteFuelModal){
    closeDeleteFuelModal();
  }
});

/* ----- Graphiques sans librairie externe ----- */
function fuelChartData(field){
  return [...fuelEntries]
    .filter(item=>fuelNumber(item[field])!==null && (item.deliveryDate||item.orderDate))
    .sort((a,b)=>
      String(a.deliveryDate||a.orderDate)
        .localeCompare(String(b.deliveryDate||b.orderDate))
    )
    .map(item=>({
      date:item.deliveryDate||item.orderDate,
      value:fuelNumber(item[field])
    }));
}

function drawFuelChart(canvas,emptyElement,data){
  if(!canvas || !emptyElement) return;

  const rect=canvas.getBoundingClientRect();

  // Si la page Carburant est masquée, le canvas peut mesurer 0 x 0.
  // Ne surtout pas le redimensionner à 1 px : le navigateur étirerait ensuite
  // cette image minuscule sur toute la carte, ce qui créait le gros bloc rouge.
  if(rect.width < 10 || rect.height < 10) return;

  const dpr=Math.max(1,window.devicePixelRatio||1);
  const pixelWidth=Math.max(1,Math.round(rect.width*dpr));
  const pixelHeight=Math.max(1,Math.round(rect.height*dpr));

  // On ne redimensionne réellement le buffer que lorsque c'est nécessaire.
  if(canvas.width!==pixelWidth) canvas.width=pixelWidth;
  if(canvas.height!==pixelHeight) canvas.height=pixelHeight;

  const ctx=canvas.getContext('2d');
  if(!ctx) return;

  // Remise à zéro systématique : évite toute accumulation de scale()
  // lors des redessins, changements de thème ou redimensionnements.
  ctx.setTransform(1,0,0,1,0,0);
  ctx.clearRect(0,0,canvas.width,canvas.height);
  ctx.setTransform(dpr,0,0,dpr,0,0);

  const width=rect.width;
  const height=rect.height;

  if(!data.length){
    emptyElement.hidden=false;
    return;
  }

  emptyElement.hidden=true;

  const padding={left:42,right:15,top:16,bottom:31};
  const plotWidth=width-padding.left-padding.right;
  const plotHeight=height-padding.top-padding.bottom;

  const values=data.map(point=>point.value);

  let min=Math.min(...values);
  let max=Math.max(...values);

  if(min===max){
    min-=0.02;
    max+=0.02;
  }else{
    const extra=(max-min)*0.15;
    min-=extra;
    max+=extra;
  }

  const x=index=>
    data.length===1
      ? padding.left+plotWidth/2
      : padding.left+(index/(data.length-1))*plotWidth;

  const y=value=>
    padding.top+(max-value)/(max-min)*plotHeight;

  ctx.lineWidth=1;
  ctx.strokeStyle='rgba(255,255,255,.08)';
  ctx.fillStyle='#808a94';
  ctx.font='10px Inter, Segoe UI, Arial';

  for(let i=0;i<=4;i++){
    const yy=padding.top+(i/4)*plotHeight;

    ctx.beginPath();
    ctx.moveTo(padding.left,yy);
    ctx.lineTo(width-padding.right,yy);
    ctx.stroke();

    const value=max-(i/4)*(max-min);
    ctx.fillText(
      value.toLocaleString('fr-FR',{
        minimumFractionDigits:3,
        maximumFractionDigits:3
      }),
      2,
      yy+3
    );
  }

  ctx.strokeStyle='#db3333';
  ctx.lineWidth=2;

  ctx.beginPath();
  data.forEach((point,index)=>{
    const xx=x(index);
    const yy=y(point.value);

    if(index===0) ctx.moveTo(xx,yy);
    else ctx.lineTo(xx,yy);
  });
  ctx.stroke();

  data.forEach((point,index)=>{
    const xx=x(index);
    const yy=y(point.value);

    ctx.fillStyle='#db3333';
    ctx.beginPath();
    ctx.arc(xx,yy,3.5,0,Math.PI*2);
    ctx.fill();
  });

  const dateIndices=data.length<=4
    ? data.map((_,index)=>index)
    : [0,Math.floor((data.length-1)/2),data.length-1];

  ctx.fillStyle='#808a94';
  ctx.textAlign='center';

  dateIndices.forEach(index=>{
    const date=new Date(data[index].date+'T00:00:00');

    ctx.fillText(
      date.toLocaleDateString('fr-FR',{
        day:'2-digit',
        month:'2-digit'
      }),
      x(index),
      height-8
    );
  });

  ctx.textAlign='start';
}

function renderFuelCharts(){
  drawFuelChart(
    document.getElementById('fuelDieselChart'),
    document.getElementById('fuelDieselChartEmpty'),
    fuelChartData('dieselPrice')
  );

  drawFuelChart(
    document.getElementById('fuelGnrChart'),
    document.getElementById('fuelGnrChartEmpty'),
    fuelChartData('gnrPrice')
  );
}

document.addEventListener('click',event=>{
  if(
    !fuelActionsMenu.hidden &&
    !fuelActionsMenu.contains(event.target) &&
    !event.target.closest('[data-fuel-menu]')
  ){
    closeFuelActionsMenu();
  }
});

let fuelResizeFrame=null;
window.addEventListener('resize',()=>{
  closeFuelActionsMenu();

  if(fuelResizeFrame) cancelAnimationFrame(fuelResizeFrame);
  fuelResizeFrame=requestAnimationFrame(()=>{
    requestAnimationFrame(()=>{
      fuelResizeFrame=null;
      renderFuelCharts();
    });
  });
});

window.addEventListener('scroll',closeFuelActionsMenu,true);

document.addEventListener('keydown',event=>{
  if(event.key!=='Escape') return;

  if(!deleteFuelModal.hidden) closeDeleteFuelModal();
  else if(!fuelModal.hidden) closeFuelModal();
  else closeFuelActionsMenu();
});

renderFuelTable();



/* ===== ACCUEIL DYNAMIQUE ===== */
function homeSetText(id,value){
  const element=document.getElementById(id);
  if(element) element.textContent=value;
}

function homeRungisVehicleInfo(registration){
  if(!registration) return null;
  const key=normalizeRegistration(registration);
  return parkData.find(item=>normalizeRegistration(item.registration)===key)||null;
}

function homeAssignedRegistrations(){
  const assigned=new Set();

  affectations.forEach(item=>{
    [item.tractor,item.semi].forEach(registration=>{
      if(registration){
        assigned.add(normalizeRegistration(registration));
      }
    });
  });

  return assigned;
}

function homeAverageFuel(field){
  const values=fuelEntries
    .map(item=>fuelNumber(item[field]))
    .filter(value=>value!==null);

  if(!values.length) return null;

  return values.reduce((sum,value)=>sum+value,0)/values.length;
}

function refreshHomeDashboard(){
  if(!document.getElementById('homeVehicles')) return;

  const tractors=parkData.filter(item=>item.type==='Tracteur').length;
  const semis=parkData.filter(item=>item.type==='Semi').length;
  const assigned=homeAssignedRegistrations();

  const unassigned=parkData.filter(item=>
    !assigned.has(normalizeRegistration(item.registration))
  ).length;

  const openClaims=claimData.filter(item=>item.status!=='Clos').length;

  let lateMaintenance=0;
  let soonMaintenance=0;

  vidangeData.forEach(item=>{
    const remaining=calculateNextOil(item);

    if(remaining<=0) lateMaintenance++;
    else if(remaining<=5000) soonMaintenance++;
  });

  const finesTodo=adminFines.filter(item=>item.status==='À traiter').length;

  const rungisOutside=adminRungis.filter(item=>
    item.vehicle && !homeRungisVehicleInfo(item.vehicle)
  ).length;

  const configuredSites=['dkv','ids','lumesia']
    .filter(key=>String(adminSites[key]||'').trim()).length;

  homeSetText('homeVehicles',parkData.length);
  homeSetText('homeVehiclesSub',`${tractors} tracteurs · ${semis} semis`);
  homeSetText('homeDrivers',driverProfiles.length);
  homeSetText('homeClaims',openClaims);
  homeSetText('homeMaintenance',lateMaintenance+soonMaintenance);

  homeSetText('homeTractors',tractors);
  homeSetText('homeSemis',semis);
  homeSetText('homeUnassigned',unassigned);

  homeSetText('homeLateMaintenance',lateMaintenance);
  homeSetText('homeSoonMaintenance',soonMaintenance);
  homeSetText('homeFinesTodo',finesTodo);
  homeSetText('homeRungisOutside',rungisOutside);

  homeSetText('homeFineTotal',adminFines.length);
  homeSetText('homeRungisTotal',adminRungis.length);
  homeSetText('homeSitesConfigured',`${configuredSites} / 3`);

  const diesel=homeAverageFuel('dieselPrice');
  const gnr=homeAverageFuel('gnrPrice');
  const adblue=homeAverageFuel('adbluePrice');

  const fuelEmpty=document.getElementById('homeFuelEmpty');
  const fuelContent=document.getElementById('homeFuelContent');

  if(fuelEntries.length){
    fuelEmpty.hidden=true;
    fuelContent.hidden=false;

    homeSetText('homeFuelDiesel',fuelFormatPrice(diesel));
    homeSetText('homeFuelGnr',fuelFormatPrice(gnr));
    homeSetText('homeFuelAdblue',fuelFormatPrice(adblue));

    const lastFuel=latestFuelEntry();

    homeSetText('homeFuelLastSupplier',lastFuel?.supplier||'—');
    homeSetText(
      'homeFuelLastDelivery',
      lastFuel ? fuelFormatDate(lastFuel.deliveryDate||lastFuel.orderDate) : '—'
    );
    homeSetText(
      'homeFuelLastDiesel',
      lastFuel ? fuelFormatPrice(lastFuel.dieselPrice) : '—'
    );
    homeSetText(
      'homeFuelLastGnr',
      lastFuel ? fuelFormatPrice(lastFuel.gnrPrice) : '—'
    );
    homeSetText(
      'homeFuelLastAdblue',
      lastFuel ? fuelFormatPrice(lastFuel.adbluePrice) : '—'
    );
  }else{
    fuelEmpty.hidden=false;
    fuelContent.hidden=true;
  }

  const now=new Date();
  homeSetText(
    'homeDate',
    now.toLocaleDateString('fr-FR',{
      weekday:'long',
      day:'2-digit',
      month:'long',
      year:'numeric'
    })
  );
}

document.querySelectorAll('[data-home-view]').forEach(element=>{
  element.addEventListener('click',()=>{
    const target=element.dataset.homeView;
    const navButton=[...navButtons].find(button=>button.dataset.view===target);

    if(!navButton) return;

    showView(
      target,
      target==='accueil'?'Gestion de Parc':navButton.innerText.trim(),
      target
    );

    if(target==='gestion-administrative'){
      const tab=element.dataset.homeAdminTab;

      if(tab && typeof switchAdminTab==='function'){
        switchAdminTab(tab);
      }
    }
  });
});

refreshHomeDashboard();



/* ===== RECHERCHE GLOBALE ===== */
const globalSearch=document.getElementById('globalSearch');
const globalSearchResults=document.getElementById('globalSearchResults');
const globalSearchClear=document.getElementById('globalSearchClear');

let globalSearchMatches=[];
let globalSearchActiveIndex=-1;

function globalNormalize(value){
  return String(value??'')
    .toLocaleLowerCase('fr')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g,'')
    .replace(/[^a-z0-9]/g,'');
}

function globalEscape(value){
  return String(value??'')
    .replace(/&/g,'&amp;')
    .replace(/</g,'&lt;')
    .replace(/>/g,'&gt;')
    .replace(/"/g,'&quot;')
    .replace(/'/g,'&#039;');
}


function globalResultIconSvg(icon){
  const icons={
    '▣': `<svg class="app-icon" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h11v10H3z"/><path d="M14 10h4l3 3v3h-7z"/><circle cx="7" cy="18" r="2"/><circle cx="18" cy="18" r="2"/></svg>`,
    '♙': `<svg class="app-icon" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="4"/><path d="M4.5 21a7.5 7.5 0 0 1 15 0"/></svg>`,
    '⚠': `<svg class="app-icon" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3 2.5 20h19z"/><path d="M12 9v4"/><path d="M12 17h.01"/></svg>`,
    '🔧': `<svg class="app-icon" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14.7 6.3a4 4 0 0 0-5-5l2.1 2.1-2.8 2.8-2.1-2.1a4 4 0 0 0 5 5L20 17.2 17.2 20z"/></svg>`,
    '⛽': `<svg class="app-icon" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 22V4a2 2 0 0 1 2-2h7a2 2 0 0 1 2 2v18"/><path d="M3 22h15"/><path d="M8 6h5v5H8z"/><path d="M16 7h2l3 3v7a2 2 0 0 1-4 0v-4"/></svg>`,
    '▰': `<svg class="app-icon" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 5h16v14H4z"/><path d="M8 9h8"/><path d="M8 13h8"/><path d="M8 17h5"/></svg>`,
    '↗': `<svg class="app-icon" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 4h6v6"/><path d="M10 14 20 4"/><path d="M20 13v6a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1h6"/></svg>`
  };
  return icons[icon] || `<svg class="app-icon" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/></svg>`;
}

function globalPageTitle(view){
  const names={
    accueil:'Gestion de Parc',
    parc:'Parc',
    chauffeur:'Chauffeur',
    sinistre:'Sinistre',
    'suivi-technique':'Suivi technique',
    carburant:'Carburant',
    'gestion-administrative':'Gestion administrative'
  };
  return names[view]||view;
}

function buildGlobalSearchMatches(rawQuery){
  const query=globalNormalize(rawQuery);
  if(query.length<2) return [];

  const results=[];
  const push=(item)=>{
    if(results.length<60) results.push(item);
  };

  /* Véhicules */
  parkData.forEach(vehicle=>{
    const plate=formatRegistration(vehicle.registration);
    const searchable=globalNormalize(
      `${plate} ${vehicle.registration} ${vehicle.type} ${vehicle.parkNumber||''}`
    );

    if(searchable.includes(query)){
      push({
        icon:'▣',
        title:plate,
        meta:`${vehicle.type}${vehicle.parkNumber?' · N° parc '+vehicle.parkNumber:''}`,
        page:'Parc',
        view:'parc',
        searchId:'parkSearch',
        searchValue:plate,
        priority:searchable.startsWith(query)?0:2
      });
    }
  });

  /* Chauffeurs */
  driverProfiles.forEach(driver=>{
    const name=[driver.lastName,driver.firstName].filter(Boolean).join(' ').trim();
    if(!name) return;

    const searchable=globalNormalize(
      `${name} ${driver.phone||''} ${driver.city||''} ${driver.licenseNumber||''}`
    );

    if(searchable.includes(query)){
      push({
        icon:'♙',
        title:name,
        meta:[driver.phone,driver.city].filter(Boolean).join(' · ')||'Fiche chauffeur',
        page:'Chauffeur',
        view:'chauffeur',
        searchId:'driverSearch',
        searchValue:name,
        priority:globalNormalize(name).startsWith(query)?0:2
      });
    }
  });

  /* Sinistres */
  claimData.forEach(claim=>{
    const searchable=globalNormalize(
      `${claim.number||''} ${claim.driver||''} ${claim.vehicle||''} ${claim.type||''} ${claim.status||''}`
    );

    if(searchable.includes(query)){
      push({
        icon:'⚠',
        title:claim.number||claim.type||'Sinistre',
        meta:[claim.vehicle,claim.driver,claim.status].filter(Boolean).join(' · '),
        page:'Sinistre',
        view:'sinistre',
        searchId:'claimSearch',
        searchValue:claim.number||claim.vehicle||claim.driver||claim.type||'',
        priority:0
      });
    }
  });

  /* Vidanges */
  vidangeData.forEach(record=>{
    const plate=formatRegistration(record.registration);
    const driver=[record.lastName,record.firstName].filter(Boolean).join(' ');
    const searchable=globalNormalize(`${plate} ${driver} ${record.currentKm??''}`);

    if(searchable.includes(query)){
      const remaining=calculateNextOil(record);
      push({
        icon:'🔧',
        title:plate,
        meta:`${driver||'Sans chauffeur'} · ${Number(remaining).toLocaleString('fr-FR')} km`,
        page:'Suivi technique',
        view:'suivi-technique',
        searchId:'vidSearch',
        searchValue:plate,
        priority:1
      });
    }
  });

  /* Amendes */
  adminFines.forEach(fine=>{
    const searchable=globalNormalize(
      `${fine.reference||''} ${fine.vehicle||''} ${fine.driver||''} ${fine.offense||''} ${fine.status||''}`
    );

    if(searchable.includes(query)){
      push({
        icon:'⚠',
        title:fine.reference||fine.offense||'Amende',
        meta:[fine.vehicle,fine.driver,fine.status].filter(Boolean).join(' · '),
        page:'Amendes',
        view:'gestion-administrative',
        adminTab:'fines',
        searchId:'fineSearch',
        searchValue:fine.reference||fine.vehicle||fine.driver||fine.offense||'',
        priority:1
      });
    }
  });

  /* Cartes Rungis */
  adminRungis.forEach(card=>{
    const vehicle=homeRungisVehicleInfo(card.vehicle);
    const searchable=globalNormalize(
      `${card.cardNumber||''} ${card.vehicle||''} ${vehicle?.parkNumber||''}`
    );

    if(searchable.includes(query)){
      push({
        icon:'▣',
        title:`Carte ${card.cardNumber||'—'}`,
        meta:[card.vehicle,vehicle?.parkNumber?`N° parc ${vehicle.parkNumber}`:''].filter(Boolean).join(' · '),
        page:'Cartes Rungis',
        view:'gestion-administrative',
        adminTab:'rungis',
        searchId:'rungisSearch',
        searchValue:card.cardNumber||card.vehicle||vehicle?.parkNumber||'',
        priority:1
      });
    }
  });

  /* Carburant */
  fuelEntries.forEach(entry=>{
    const searchable=globalNormalize(
      `${entry.supplier||''} ${entry.orderDate||''} ${entry.deliveryDate||''}`
    );

    if(searchable.includes(query)){
      push({
        icon:'⛽',
        title:entry.supplier||'Commande carburant',
        meta:[
          entry.orderDate?fuelFormatDate(entry.orderDate):'',
          entry.dieselPrice?`Gasoil ${fuelFormatPrice(entry.dieselPrice)}`:''
        ].filter(Boolean).join(' · '),
        page:'Carburant',
        view:'carburant',
        searchId:'fuelSearch',
        searchValue:entry.supplier||entry.orderDate||'',
        priority:1
      });
    }
  });

  /* Accès directs aux pages */
  [
    ['parc','Parc','▣','Véhicules et affectations'],
    ['chauffeur','Chauffeur','♙','Fiches chauffeurs'],
    ['sinistre','Sinistre','⚠','Déclaration et suivi des sinistres'],
    ['suivi-technique','Suivi technique','🔧','Vidanges et import JEF'],
    ['carburant','Carburant','⛽','Commandes et prix carburant'],
    ['gestion-administrative','Gestion administrative','▰','Amendes, Rungis et outils']
  ].forEach(([view,title,icon,meta])=>{
    if(globalNormalize(`${title} ${meta}`).includes(query)){
      push({
        icon,
        title:`Ouvrir ${title}`,
        meta,
        page:'Navigation',
        view,
        priority:3
      });
    }
  });

  /* DKV / IDS / Lumesia */
  [
    ['DKV','dkv'],
    ['IDS','ids'],
    ['Lumesia','lumesia']
  ].forEach(([name,key])=>{
    if(globalNormalize(name).includes(query)){
      push({
        icon:'↗',
        title:name,
        meta:'Site & outil',
        page:'Administratif',
        view:'gestion-administrative',
        adminTab:'sites',
        priority:2
      });
    }
  });

  return results
    .sort((a,b)=>
      (a.priority??9)-(b.priority??9) ||
      a.title.localeCompare(b.title,'fr',{sensitivity:'base'})
    )
    .slice(0,14);
}

function renderGlobalSearch(){
  const query=globalSearch.value.trim();

  globalSearchClear.hidden=!query;
  globalSearchActiveIndex=-1;

  if(query.length<2){
    globalSearchMatches=[];
    globalSearchResults.innerHTML=`
      <div class="global-search-help">
        Tapez au moins 2 caractères.<br>
        Vous pouvez rechercher une plaque, un chauffeur, un sinistre, une amende,
        une carte Rungis, une commande carburant ou une page.
      </div>
    `;
    globalSearchResults.hidden=!document.activeElement.isSameNode(globalSearch);
    return;
  }

  globalSearchMatches=buildGlobalSearchMatches(query);

  if(!globalSearchMatches.length){
    globalSearchResults.innerHTML=`
      <div class="global-search-empty">
        Aucun résultat pour « ${globalEscape(query)} »
      </div>
    `;
    globalSearchResults.hidden=false;
    return;
  }

  globalSearchResults.innerHTML=globalSearchMatches.map((result,index)=>`
    <button class="global-result" type="button" data-global-result="${index}">
      <span class="global-result-icon">${globalResultIconSvg(result.icon)}</span>
      <span>
        <div class="global-result-title">${globalEscape(result.title)}</div>
        <div class="global-result-meta">${globalEscape(result.meta||'')}</div>
      </span>
      <span class="global-result-page">${globalEscape(result.page||'')}</span>
    </button>
  `).join('');

  globalSearchResults.hidden=false;
}

function closeGlobalSearch(){
  globalSearchResults.hidden=true;
  globalSearchActiveIndex=-1;
}

function activateGlobalSearchResult(index){
  const result=globalSearchMatches[index];
  if(!result) return;

  showView(
    result.view,
    globalPageTitle(result.view),
    result.view
  );

  if(result.view==='gestion-administrative' && result.adminTab){
    switchAdminTab(result.adminTab);
  }

  if(result.searchId){
    const targetSearch=document.getElementById(result.searchId);

    if(targetSearch){
      targetSearch.value=result.searchValue||'';
      targetSearch.dispatchEvent(new Event('input',{bubbles:true}));
    }
  }

  globalSearch.value='';
  globalSearchClear.hidden=true;
  closeGlobalSearch();
}

globalSearch.addEventListener('focus',renderGlobalSearch);
globalSearch.addEventListener('input',renderGlobalSearch);

globalSearchClear.addEventListener('click',()=>{
  globalSearch.value='';
  globalSearchClear.hidden=true;
  globalSearch.focus();
  renderGlobalSearch();
});

globalSearchResults.addEventListener('click',event=>{
  const button=event.target.closest('[data-global-result]');
  if(!button) return;
  activateGlobalSearchResult(Number(button.dataset.globalResult));
});

globalSearch.addEventListener('keydown',event=>{
  if(globalSearchResults.hidden) return;

  const buttons=[...globalSearchResults.querySelectorAll('[data-global-result]')];
  if(!buttons.length) return;

  if(event.key==='ArrowDown'){
    event.preventDefault();
    globalSearchActiveIndex=(globalSearchActiveIndex+1)%buttons.length;
  }else if(event.key==='ArrowUp'){
    event.preventDefault();
    globalSearchActiveIndex=(globalSearchActiveIndex-1+buttons.length)%buttons.length;
  }else if(event.key==='Enter' && globalSearchActiveIndex>=0){
    event.preventDefault();
    activateGlobalSearchResult(globalSearchActiveIndex);
    return;
  }else if(event.key==='Escape'){
    closeGlobalSearch();
    return;
  }else{
    return;
  }

  buttons.forEach((button,index)=>{
    button.classList.toggle('active',index===globalSearchActiveIndex);
  });

  buttons[globalSearchActiveIndex]?.scrollIntoView({block:'nearest'});
});

document.addEventListener('click',event=>{
  if(
    !globalSearchResults.hidden &&
    !event.target.closest('.global-search-wrap')
  ){
    closeGlobalSearch();
  }
});





/* ===== IDENTIFIANT UTILISATEUR ===== */
const DASHBOARD_USER_KEY='hessers-dashboard-user-v1';
let dashboardUser=(localStorage.getItem(DASHBOARD_USER_KEY)||'').trim().toUpperCase();

const dashboardUserBadge=document.getElementById('dashboardUserBadge');
const dashboardUserLabel=document.getElementById('dashboardUserLabel');
const dashboardUserModal=document.getElementById('dashboardUserModal');
const dashboardUserInput=document.getElementById('dashboardUserInput');
const dashboardUserError=document.getElementById('dashboardUserError');
const saveDashboardUserButton=document.getElementById('saveDashboardUser');
const closeDashboardUserModal=document.getElementById('closeDashboardUserModal');

function normalizeDashboardUser(value){
  return String(value||'')
    .trim()
    .toUpperCase()
    .replace(/\s+/g,'')
    .replace(/[^A-Z0-9._-]/g,'')
    .slice(0,30);
}

function refreshDashboardUserBadge(){
  dashboardUserLabel.textContent=dashboardUser || 'Utilisateur';
  dashboardUserBadge.title=dashboardUser
    ? 'Utilisateur : '+dashboardUser+' — cliquer pour changer'
    : 'Définir l’identifiant utilisateur';
}

function openDashboardUserModal(force=false){
  dashboardUserInput.value=dashboardUser || '';
  dashboardUserError.classList.remove('show');
  dashboardUserModal.hidden=false;
  document.body.classList.add('modal-open');
  setTimeout(()=>dashboardUserInput.focus(),40);

  if(force){
    closeDashboardUserModal.hidden=true;
  }else{
    closeDashboardUserModal.hidden=false;
  }
}

function closeDashboardUserDialog(){
  if(!dashboardUser) return;
  dashboardUserModal.hidden=true;
  if(document.querySelectorAll('.modal-overlay:not([hidden])').length===0){
    document.body.classList.remove('modal-open');
  }
}

function saveDashboardUser(){
  const previousDashboardUser=dashboardUser;
  const value=normalizeDashboardUser(dashboardUserInput.value);
  if(!value){
    dashboardUserError.classList.add('show');
    dashboardUserInput.focus();
    return false;
  }

  dashboardUser=value;
  localStorage.setItem(DASHBOARD_USER_KEY,dashboardUser);
  refreshDashboardUserBadge();
  dashboardUserModal.hidden=true;

  if(typeof administratorUserChanged === 'function'){
    administratorUserChanged(previousDashboardUser,dashboardUser);
  }

  if(document.querySelectorAll('.modal-overlay:not([hidden])').length===0){
    document.body.classList.remove('modal-open');
  }

  return true;
}

dashboardUserBadge.addEventListener('click',()=>openDashboardUserModal(false));
saveDashboardUserButton.addEventListener('click',saveDashboardUser);
closeDashboardUserModal.addEventListener('click',closeDashboardUserDialog);
dashboardUserModal.addEventListener('click',event=>{
  if(event.target===dashboardUserModal) closeDashboardUserDialog();
});
dashboardUserInput.addEventListener('keydown',event=>{
  if(event.key==='Enter'){
    event.preventDefault();
    saveDashboardUser();
  }
});
dashboardUserInput.addEventListener('input',()=>{
  dashboardUserInput.value=normalizeDashboardUser(dashboardUserInput.value);
  dashboardUserError.classList.remove('show');
});

refreshDashboardUserBadge();
if(!dashboardUser){
  setTimeout(()=>openDashboardUserModal(true),180);
}



/* ===== SUPERVISION ADMINISTRATEUR : CORE ===== */
const ADMINISTRATOR_USER='THEMIA';
const ADMIN_PRESENCE_FOLDER='presence';
const ADMIN_HISTORY_FOLDER='historique';
const ADMIN_PRESENCE_INTERVAL=30000;
const ADMIN_ONLINE_MAX_AGE=120000;
const ADMIN_HISTORY_MAX_RECORDS=400;

let administratorPresenceTimer=null;
let administratorPresenceUser='';
let administratorSessionStartedAt=new Date().toISOString();
let administratorConnectionLoggedUser='';
let administratorLastPresenceWrite=0;
let administratorLastKnownPage='accueil';

function administratorIsAdmin(){
  return String(dashboardUser||'').toUpperCase()===ADMINISTRATOR_USER;
}

function administratorSafePart(value){
  return String(value||'')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g,'')
    .replace(/[<>:"/\\|?*\x00-\x1F]/g,'_')
    .replace(/\s+/g,'_')
    .replace(/[^A-Za-z0-9._-]/g,'_')
    .slice(0,80) || 'inconnu';
}

function administratorLocalDateKey(value=new Date()){
  const date=value instanceof Date ? value : new Date(value);
  const y=date.getFullYear();
  const m=String(date.getMonth()+1).padStart(2,'0');
  const d=String(date.getDate()).padStart(2,'0');
  return `${y}-${m}-${d}`;
}

function administratorPageLabel(id){
  return ({
    accueil:'Accueil',
    parc:'Parc',
    affectations:'Affectations',
    chauffeur:'Chauffeur',
    sinistre:'Sinistre',
    'suivi-technique':'Suivi technique',
    carburant:'Carburant',
    'gestion-administrative':'Gestion administrative',
    administrateur:'Administrateur'
  })[id] || String(id||'—');
}

async function administratorGetDirectory(name,create=false){
  if(!sharedConnected || !sharedDirectoryHandle) return null;
  return await sharedDirectoryHandle.getDirectoryHandle(name,{create});
}

async function administratorWriteJsonFile(directory,fileName,payload){
  const handle=await directory.getFileHandle(fileName,{create:true});
  const writable=await handle.createWritable();
  await writable.write(JSON.stringify(payload,null,2));
  await writable.close();
}

async function administratorWriteHistory(event){
  if(!sharedConnected || !sharedDirectoryHandle || !dashboardUser) return;

  try{
    const root=await administratorGetDirectory(ADMIN_HISTORY_FOLDER,true);
    if(!root) return;

    const now=new Date();
    const day=administratorLocalDateKey(now);
    const dayDir=await root.getDirectoryHandle(day,{create:true});

    const payload={
      id:'evt_'+Date.now()+'_'+Math.random().toString(36).slice(2,8),
      timestamp:now.toISOString(),
      user:dashboardUser,
      action:event.action || 'Activité',
      section:event.section || administratorPageLabel(administratorLastKnownPage),
      entity:event.entity || '',
      detail:event.detail || '',
      session:sharedClientId
    };

    const stamp=
      String(now.getHours()).padStart(2,'0')+
      String(now.getMinutes()).padStart(2,'0')+
      String(now.getSeconds()).padStart(2,'0')+
      '_'+String(now.getMilliseconds()).padStart(3,'0');

    const fileName=
      `${stamp}_${administratorSafePart(dashboardUser)}_${Math.random().toString(36).slice(2,7)}.json`;

    await administratorWriteJsonFile(dayDir,fileName,payload);
  }catch(error){
    console.warn('Historique administrateur indisponible.',error);
  }
}

async function administratorWritePresence(){
  if(!sharedConnected || !sharedDirectoryHandle || !dashboardUser) return;

  try{
    const dir=await administratorGetDirectory(ADMIN_PRESENCE_FOLDER,true);
    if(!dir) return;

    const now=new Date();
    const activeView=document.querySelector('.view.active')?.id || administratorLastKnownPage || 'accueil';
    administratorLastKnownPage=activeView;

    const payload={
      user:dashboardUser,
      session:sharedClientId,
      connectedAt:administratorSessionStartedAt,
      heartbeatAt:now.toISOString(),
      page:activeView,
      pageLabel:administratorPageLabel(activeView),
      online:true
    };

    await administratorWriteJsonFile(
      dir,
      administratorSafePart(dashboardUser)+'.json',
      payload
    );

    administratorLastPresenceWrite=Date.now();
  }catch(error){
    console.warn('Présence utilisateur indisponible.',error);
  }
}

async function administratorStartPresence(force=false){
  if(!sharedConnected || !dashboardUser) return;

  const currentUser=dashboardUser;

  if(administratorPresenceUser && administratorPresenceUser!==currentUser){
    try{
      const dir=await administratorGetDirectory(ADMIN_PRESENCE_FOLDER,false);
      if(dir){
        await dir.removeEntry(administratorSafePart(administratorPresenceUser)+'.json');
      }
    }catch(error){}
    administratorConnectionLoggedUser='';
  }

  administratorPresenceUser=currentUser;

  if(administratorPresenceTimer){
    clearInterval(administratorPresenceTimer);
    administratorPresenceTimer=null;
  }

  await administratorWritePresence();

  administratorPresenceTimer=setInterval(()=>{
    administratorWritePresence();
  },ADMIN_PRESENCE_INTERVAL);

  if(force || administratorConnectionLoggedUser!==currentUser){
    administratorConnectionLoggedUser=currentUser;
    administratorSessionStartedAt=new Date().toISOString();
    await administratorWriteHistory({
      action:'Connexion',
      section:'Dashboard',
      entity:currentUser,
      detail:'Ouverture du dashboard'
    });
  }
}

async function administratorStopPresence(removeFile=false){
  if(administratorPresenceTimer){
    clearInterval(administratorPresenceTimer);
    administratorPresenceTimer=null;
  }

  if(removeFile && sharedConnected && sharedDirectoryHandle && administratorPresenceUser){
    try{
      const dir=await administratorGetDirectory(ADMIN_PRESENCE_FOLDER,false);
      if(dir){
        await dir.removeEntry(administratorSafePart(administratorPresenceUser)+'.json');
      }
    }catch(error){}
  }
}

function administratorEntityLabel(descriptor,item){
  if(!item) return '';

  if(descriptor.key===PARK_STORAGE_KEY) return formatRegistration(item.registration||'');
  if(descriptor.key===AFFECT_STORAGE_KEY) return item.name||'';
  if(descriptor.key===DRIVER_STORAGE_KEY) return `${item.lastName||''} ${item.firstName||''}`.trim();
  if(descriptor.key===CLAIM_STORAGE_KEY) return item.number ? `Dossier ${item.number}` : (item.vehicle||'Sinistre');
  if(descriptor.key===VIDANGE_STORAGE_KEY) return formatRegistration(item.registration||'');
  if(descriptor.key===TECH_DEADLINE_STORAGE_KEY) return `${String(item.control||item.category||'Échéance').trim()} · ${formatRegistration(item.registration||'')}`;
  if(descriptor.key===ADMIN_FINE_KEY) return item.reference || item.vehicle || 'Amende';
  if(descriptor.key===ADMIN_RUNGIS_KEY) return item.cardNumber ? `Carte ${item.cardNumber}` : 'Carte Rungis';
  if(descriptor.key===FUEL_STORAGE_KEY) return item.supplier || 'Commande carburant';

  return item.id||'';
}

function administratorSectionLabel(descriptor){
  if(descriptor.key===PARK_STORAGE_KEY) return 'Parc';
  if(descriptor.key===AFFECT_STORAGE_KEY) return 'Affectations';
  if(descriptor.key===DRIVER_STORAGE_KEY) return 'Chauffeur';
  if(descriptor.key===CLAIM_STORAGE_KEY) return 'Sinistre';
  if(descriptor.key===VIDANGE_STORAGE_KEY) return 'Suivi technique';
  if(descriptor.key===TECH_DEADLINE_STORAGE_KEY) return 'Échéances techniques';
  if(descriptor.key===ADMIN_FINE_KEY) return 'Amendes';
  if(descriptor.key===ADMIN_RUNGIS_KEY) return 'Cartes Rungis';
  if(descriptor.key===ADMIN_SITES_KEY) return 'Sites & outils';
  if(descriptor.key===FUEL_STORAGE_KEY) return 'Carburant';
  return 'Dashboard';
}

function administratorDiffDataset(descriptor,previous,next){
  if(descriptor.key===CLAIM_EVENTS_KEY) return [];

  if(descriptor.kind==='object'){
    const prev=previous||{};
    const after=next||{};
    const changes=dashboardDescribeObjectChanges(prev,after,descriptor);
    if(!changes.length) return [];
    return [{
      action:'Modification',
      section:administratorSectionLabel(descriptor),
      entity:'Paramètres',
      detail:changes.join(' · ')
    }];
  }

  const prevArray=Array.isArray(previous)?previous:[];
  const nextArray=Array.isArray(next)?next:[];
  const prevMap=sharedRecordMap(descriptor,prevArray);
  const nextMap=sharedRecordMap(descriptor,nextArray);

  const created=[];
  const modified=[];
  const deleted=[];

  for(const [id,item] of nextMap.entries()){
    if(!prevMap.has(id)){
      created.push(item);
    }else if(JSON.stringify(prevMap.get(id))!==JSON.stringify(item)){
      modified.push({before:prevMap.get(id),after:item});
    }
  }

  for(const [id,item] of prevMap.entries()){
    if(!nextMap.has(id)) deleted.push(item);
  }

  const total=created.length+modified.length+deleted.length;
  if(!total) return [];

  if(total>12){
    return [{
      action:'Mise à jour en lot',
      section:administratorSectionLabel(descriptor),
      entity:`${total} éléments`,
      detail:`${created.length} ajout(s), ${modified.length} modification(s), ${deleted.length} suppression(s)`
    }];
  }

  const events=[];
  created.forEach(item=>events.push({
    action:'Ajout',
    section:administratorSectionLabel(descriptor),
    entity:administratorEntityLabel(descriptor,item),
    detail:dashboardDescribeCreatedItem(item,descriptor)
  }));
  modified.forEach(change=>events.push({
    action:'Modification',
    section:administratorSectionLabel(descriptor),
    entity:administratorEntityLabel(descriptor,change.after),
    detail:dashboardDescribeObjectChanges(change.before,change.after,descriptor).join(' · ') || 'Élément modifié'
  }));
  deleted.forEach(item=>events.push({
    action:'Suppression',
    section:administratorSectionLabel(descriptor),
    entity:administratorEntityLabel(descriptor,item),
    detail:'Élément supprimé'
  }));

  return events;
}

async function administratorLogDatasetChanges(descriptor,previous,next){
  const events=administratorDiffDataset(descriptor,previous,next);
  for(const event of events){
    await administratorWriteHistory(event);
  }

  if(events.length){
    administratorWritePresence();
  }
}

function refreshAdministratorAccess(){
  const button=document.getElementById('administratorNavButton');
  if(!button) return;

  const allowed=administratorIsAdmin();
  button.hidden=!allowed;

  const current=document.querySelector('.view.active')?.id;
  if(!allowed && current==='administrateur' && typeof showView==='function'){
    showView('accueil','Gestion de Parc','accueil');
  }
}

function administratorUserChanged(previousUser,newUser){
  if(typeof adminSecurityLock==='function'){
    adminSecurityLock(true);
  }

  refreshAdministratorAccess();

  if(typeof sharedConnected!=='undefined' && sharedConnected){
    administratorStartPresence(previousUser!==newUser);
  }
}

/* ===== STOCKAGE PARTAGÉ GROUPDRIVE =====
   - Le localStorage reste un cache local pour conserver l'architecture existante.
   - Les données métier sont synchronisées avec des JSON du dossier Groupdrive.
   - Chaque sauvegarde est fusionnée au niveau des enregistrements afin de limiter
     les écrasements lorsque deux utilisateurs modifient des éléments différents.
*/
const SHARED_DB_NAME='hessers-shared-folder-v1';
const SHARED_DB_STORE='handles';
const SHARED_HANDLE_KEY='groupdrive-data-folder';
const SHARED_POLL_MS=5000;

const SHARED_DATASETS=[
  {key:PARK_STORAGE_KEY,file:'parc.json',kind:'array',id:item=>normalizeRegistration(item?.registration)},
  {key:AFFECT_STORAGE_KEY,file:'affectations.json',kind:'array',id:item=>normalizeAffText(item?.name)},
  {key:DRIVER_STORAGE_KEY,file:'chauffeurs.json',kind:'array',id:item=>String(item?.id||'')},
  {key:CLAIM_STORAGE_KEY,file:'sinistres.json',kind:'array',id:item=>String(item?.id||'')},
  {key:CLAIM_EVENTS_KEY,file:'sinistres_historique.json',kind:'array',id:item=>String(item?.id||'')},
  {key:VIDANGE_STORAGE_KEY,file:'vidanges.json',kind:'array',id:item=>String(item?.id||normalizeRegistration(item?.registration)||'')},
  {key:TECH_DEADLINE_STORAGE_KEY,file:'echeances_techniques.json',kind:'array',id:item=>String(item?.id||'')},
  {key:ADMIN_FINE_KEY,file:'amendes.json',kind:'array',id:item=>String(item?.id||'')},
  {key:ADMIN_RUNGIS_KEY,file:'cartes_rungis.json',kind:'array',id:item=>String(item?.id||item?.cardNumber||'')},
  {key:ADMIN_SITES_KEY,file:'sites.json',kind:'object'},
  {key:FUEL_STORAGE_KEY,file:'carburant.json',kind:'array',id:item=>String(item?.id||'')}
];

const SHARED_DESCRIPTOR_BY_KEY=new Map(SHARED_DATASETS.map(item=>[item.key,item]));
const SHARED_ORIGINAL_SET_ITEM=Storage.prototype.setItem;
const SHARED_ORIGINAL_REMOVE_ITEM=Storage.prototype.removeItem;

let sharedDirectoryHandle=null;
let sharedConnected=false;
let sharedPollTimer=null;
let sharedWriteQueues=new Map();
let sharedLastLocalByKey=new Map();
let sharedRemoteSignatureByKey=new Map();
let sharedPendingRemote=new Map();
let sharedClientId='client_'+Math.random().toString(36).slice(2)+'_'+Date.now().toString(36);
let sharedLastSyncAt=null;
let sharedFilesReady=0;
let sharedSuppressLocalHook=false;

const sharedStorageButton=document.getElementById('sharedStorageButton');
const sharedStorageLabel=document.getElementById('sharedStorageLabel');
const sharedStorageHeroDot=document.getElementById('sharedStorageHeroDot');
const sharedStorageModal=document.getElementById('sharedStorageModal');
const closeSharedStorageModal=document.getElementById('closeSharedStorageModal');
const connectSharedStorageButton=document.getElementById('connectSharedStorage');
const syncSharedStorageButton=document.getElementById('syncSharedStorage');
const disconnectSharedStorageButton=document.getElementById('disconnectSharedStorage');
const sharedStorageState=document.getElementById('sharedStorageState');
const sharedStorageFolder=document.getElementById('sharedStorageFolder');
const sharedStorageLastSync=document.getElementById('sharedStorageLastSync');
const sharedStorageFileCount=document.getElementById('sharedStorageFileCount');
const sharedStorageMessage=document.getElementById('sharedStorageMessage');

function sharedDeepClone(value){
  return value === undefined ? undefined : JSON.parse(JSON.stringify(value));
}

function sharedFormatTime(date){
  if(!date) return '—';
  return new Intl.DateTimeFormat('fr-FR',{hour:'2-digit',minute:'2-digit',second:'2-digit'}).format(date);
}

function sharedSetUiState(mode,message){
  sharedStorageButton.classList.remove('connected','syncing','error');
  sharedStorageHeroDot.className='shared-storage-hero-dot';
  closeSharedStorageModal.hidden=!sharedConnected;

  if(mode==='connected'){
    sharedStorageButton.classList.add('connected');
    sharedStorageHeroDot.classList.add('connected');
    sharedStorageButton.title='Stockage partagé connecté';
    sharedStorageLabel.textContent='Partagé';
    sharedStorageState.textContent='Stockage partagé actif';
    sharedStorageFolder.textContent='Dossier '+(sharedDirectoryHandle?.name || 'data')+' connecté automatiquement.';
    sharedStorageMessage.className='shared-storage-message ok';
    sharedStorageMessage.innerHTML=message || 'Les données sont partagées entre les utilisateurs du Groupdrive.';
    connectSharedStorageButton.hidden=true;
    syncSharedStorageButton.hidden=false;
    syncSharedStorageButton.disabled=false;
    disconnectSharedStorageButton.hidden=false;
    disconnectSharedStorageButton.disabled=false;
    disconnectSharedStorageButton.textContent='Changer de dossier';
  }else if(mode==='syncing'){
    sharedStorageButton.classList.add('syncing');
    sharedStorageButton.title='Synchronisation en cours';
    sharedStorageLabel.textContent='Synchro…';
    sharedStorageState.textContent='Synchronisation…';
    sharedStorageFolder.textContent='Mise à jour des données partagées.';
    sharedStorageMessage.className='shared-storage-message warn';
    sharedStorageMessage.innerHTML=message || 'Synchronisation avec le Groupdrive…';
  }else if(mode==='error'){
    sharedStorageButton.classList.add('error');
    sharedStorageHeroDot.classList.add('error');
    sharedStorageButton.title='Erreur du stockage partagé';
    sharedStorageLabel.textContent='Erreur';
    sharedStorageState.textContent='Connexion impossible';
    sharedStorageFolder.textContent=sharedDirectoryHandle?.name
      ? 'Dossier '+sharedDirectoryHandle.name
      : 'Dossier data non connecté';
    sharedStorageMessage.className='shared-storage-message error';
    sharedStorageMessage.innerHTML=message || 'Impossible d’accéder au stockage partagé.';
    connectSharedStorageButton.hidden=false;
    connectSharedStorageButton.textContent=sharedDirectoryHandle
      ? 'Réessayer l’autorisation'
      : 'Activer le stockage partagé';
    syncSharedStorageButton.hidden=true;
    disconnectSharedStorageButton.hidden=true;
  }else{
    sharedStorageButton.title='Stockage partagé à activer';
    sharedStorageLabel.textContent='À activer';
    sharedStorageState.textContent=sharedDirectoryHandle ? 'Autorisation requise' : 'À activer';
    sharedStorageFolder.textContent=sharedDirectoryHandle
      ? 'Le dossier '+sharedDirectoryHandle.name+' est déjà mémorisé.'
      : 'Sélectionne une fois le dossier data du Groupdrive.';
    sharedStorageMessage.className='shared-storage-message warn';
    sharedStorageMessage.innerHTML=message || (
      sharedDirectoryHandle
        ? 'Clique sur <b>Autoriser</b>. Tu n’auras normalement pas à rechercher le dossier de nouveau.'
        : 'Première utilisation uniquement : sélectionne le dossier <b>data</b> du Groupdrive.'
    );
    connectSharedStorageButton.hidden=false;
    connectSharedStorageButton.textContent=sharedDirectoryHandle
      ? 'Autoriser'
      : 'Activer le stockage partagé';
    syncSharedStorageButton.hidden=true;
    disconnectSharedStorageButton.hidden=true;
  }

  sharedStorageLastSync.textContent=sharedFormatTime(sharedLastSyncAt);
  sharedStorageFileCount.textContent=`${sharedFilesReady} / ${SHARED_DATASETS.length}`;
}
function openSharedStorageModal(){
  sharedStorageModal.hidden=false;
  closeSharedStorageModal.hidden=!sharedConnected;
  document.body.classList.add('modal-open');
  sharedSetUiState(sharedConnected?'connected':'local');
}
function closeSharedStorageDialog(){
  if(!sharedConnected) return;
  sharedStorageModal.hidden=true;
  if(document.querySelectorAll('.modal-overlay:not([hidden])').length===0){
    document.body.classList.remove('modal-open');
  }
}

function openSharedHandleDb(){
  return new Promise((resolve,reject)=>{
    const request=indexedDB.open(SHARED_DB_NAME,1);
    request.onupgradeneeded=()=>{
      const db=request.result;
      if(!db.objectStoreNames.contains(SHARED_DB_STORE)){
        db.createObjectStore(SHARED_DB_STORE);
      }
    };
    request.onsuccess=()=>resolve(request.result);
    request.onerror=()=>reject(request.error);
  });
}

async function saveSharedDirectoryHandle(handle){
  try{
    const db=await openSharedHandleDb();
    await new Promise((resolve,reject)=>{
      const tx=db.transaction(SHARED_DB_STORE,'readwrite');
      tx.objectStore(SHARED_DB_STORE).put(handle,SHARED_HANDLE_KEY);
      tx.oncomplete=resolve;
      tx.onerror=()=>reject(tx.error);
    });
    db.close();
  }catch(error){
    console.warn('Impossible de mémoriser le dossier Groupdrive.',error);
  }
}

async function loadSharedDirectoryHandle(){
  try{
    const db=await openSharedHandleDb();
    const handle=await new Promise((resolve,reject)=>{
      const tx=db.transaction(SHARED_DB_STORE,'readonly');
      const request=tx.objectStore(SHARED_DB_STORE).get(SHARED_HANDLE_KEY);
      request.onsuccess=()=>resolve(request.result||null);
      request.onerror=()=>reject(request.error);
    });
    db.close();
    return handle;
  }catch(error){
    console.warn('Impossible de relire le dossier Groupdrive mémorisé.',error);
    return null;
  }
}

async function forgetSharedDirectoryHandle(){
  try{
    const db=await openSharedHandleDb();
    await new Promise((resolve,reject)=>{
      const tx=db.transaction(SHARED_DB_STORE,'readwrite');
      tx.objectStore(SHARED_DB_STORE).delete(SHARED_HANDLE_KEY);
      tx.oncomplete=resolve;
      tx.onerror=()=>reject(tx.error);
    });
    db.close();
  }catch(error){
    console.warn(error);
  }
}

async function sharedHasPermission(handle,request=false){
  if(!handle) return false;
  const options={mode:'readwrite'};
  try{
    if(await handle.queryPermission(options)==='granted') return true;
    if(request && await handle.requestPermission(options)==='granted') return true;
  }catch(error){
    console.warn('Vérification permission Groupdrive impossible.',error);
  }
  return false;
}

async function sharedReadDocument(descriptor){
  if(!sharedDirectoryHandle) return null;
  try{
    const fileHandle=await sharedDirectoryHandle.getFileHandle(descriptor.file);
    const file=await fileHandle.getFile();
    const raw=await file.text();
    const doc=JSON.parse(raw);
    if(doc && Object.prototype.hasOwnProperty.call(doc,'data')){
      return {
        ...doc,
        _lastModified:file.lastModified
      };
    }
    return {
      version:1,
      updatedAt:new Date(file.lastModified).toISOString(),
      updatedBy:'ancien-format',
      data:doc,
      _lastModified:file.lastModified
    };
  }catch(error){
    if(error?.name==='NotFoundError') return null;
    throw error;
  }
}

async function sharedWriteDocument(descriptor,data){
  if(!sharedDirectoryHandle) throw new Error('Dossier Groupdrive non connecté.');

  const fileHandle=await sharedDirectoryHandle.getFileHandle(descriptor.file,{create:true});
  const writable=await fileHandle.createWritable();
  const doc={
    version:1,
    updatedAt:new Date().toISOString(),
    updatedBy:dashboardUser || sharedClientId,
    data
  };
  await writable.write(JSON.stringify(doc,null,2));
  await writable.close();

  const file=await fileHandle.getFile();
  const signature=`${file.lastModified}|${doc.updatedAt}|${doc.updatedBy}`;
  sharedRemoteSignatureByKey.set(descriptor.key,signature);
  sharedLastSyncAt=new Date();
  return doc;
}

function sharedCurrentData(key){
  if(key===PARK_STORAGE_KEY) return sharedDeepClone(parkData);
  if(key===AFFECT_STORAGE_KEY) return sharedDeepClone(affectations);
  if(key===DRIVER_STORAGE_KEY) return sharedDeepClone(driverProfiles);
  if(key===CLAIM_STORAGE_KEY) return sharedDeepClone(claimData);
  if(key===CLAIM_EVENTS_KEY) return sharedDeepClone(claimEventsData);
  if(key===VIDANGE_STORAGE_KEY) return sharedDeepClone(vidangeData);
  if(key===TECH_DEADLINE_STORAGE_KEY) return sharedDeepClone(technicalDeadlines);
  if(key===ADMIN_FINE_KEY) return sharedDeepClone(adminFines);
  if(key===ADMIN_RUNGIS_KEY) return sharedDeepClone(adminRungis);
  if(key===ADMIN_SITES_KEY) return sharedDeepClone(adminSites);
  if(key===FUEL_STORAGE_KEY) return sharedDeepClone(fuelEntries);
  return null;
}

function sharedWriteLocalCache(key,data){
  try{
    sharedSuppressLocalHook=true;
    SHARED_ORIGINAL_SET_ITEM.call(localStorage,key,JSON.stringify(data));
  }catch(error){
    console.warn('Impossible de mettre à jour le cache local.',error);
  }finally{
    sharedSuppressLocalHook=false;
  }
  sharedLastLocalByKey.set(key,sharedDeepClone(data));
}

function sharedRefreshUiForKey(key){
  try{
    if(key===PARK_STORAGE_KEY){
      renderParkTable();
      renderAffectations();
    }
    if(key===AFFECT_STORAGE_KEY){
      renderAffectations();
      renderParkTable();
    }
    if(key===DRIVER_STORAGE_KEY){
      if(selectedDriverId && !driverProfiles.some(item=>item.id===selectedDriverId)) selectedDriverId=null;
      renderDriverList();
      fillDriverForm();
    }
    if(key===CLAIM_STORAGE_KEY){
      if(selectedClaimId && !claimData.some(item=>item.id===selectedClaimId)) selectedClaimId=null;
      renderClaims();
      loadClaimDetail();
      renderClaimTimeline();
      renderClaimAttachments();
    }
    if(key===CLAIM_EVENTS_KEY){
      renderClaimEvents();
    }
    if(key===VIDANGE_STORAGE_KEY){
      if(selectedVidangeId && !vidangeData.some(item=>item.id===selectedVidangeId)) selectedVidangeId=null;
      renderVidTable();
      loadVidDetail();
    }
    if(key===TECH_DEADLINE_STORAGE_KEY && typeof window.technicalRefreshAll==='function') window.technicalRefreshAll();
    if(key===ADMIN_FINE_KEY) renderFines();
    if(key===ADMIN_RUNGIS_KEY) renderRungis();
    if(key===ADMIN_SITES_KEY) renderAdminSites();
    if(key===FUEL_STORAGE_KEY){
      renderFuelTable();
      renderFuelCharts();
    }
    refreshHomeDashboard();
  }catch(error){
    console.warn('Rafraîchissement interface après synchro impossible.',key,error);
  }
}

function sharedApplyData(key,data,refresh=true){
  const cloned=sharedDeepClone(data);

  if(key===PARK_STORAGE_KEY && Array.isArray(cloned)) parkData=cloned;
  else if(key===AFFECT_STORAGE_KEY && Array.isArray(cloned)){
    affectations=cloned;
    if(typeof renderVidTable==='function')renderVidTable();
    if(selectedVidangeId && typeof loadVidDetail==='function')loadVidDetail();
  }
  else if(key===DRIVER_STORAGE_KEY && Array.isArray(cloned)){
    let driverMigrationNeeded=false;
    driverProfiles=cloned.map(driver=>{
      const next={...driver};
      if(typeof next.birthPostalCode!=='string'){
        next.birthPostalCode='';
        driverMigrationNeeded=true;
      }
      const normalizedStatus=normalizeDriverStatus(next.status);
      if(next.status!==normalizedStatus){
        next.status=normalizedStatus;
        driverMigrationNeeded=true;
      }
      return next;
    });
    if(driverMigrationNeeded){
      setTimeout(()=>saveDriverProfiles(),0);
    }
  }
  else if(key===CLAIM_STORAGE_KEY && Array.isArray(cloned)) claimData=cloned;
  else if(key===CLAIM_EVENTS_KEY && Array.isArray(cloned)) claimEventsData=cloned.slice(0,30);
  else if(key===VIDANGE_STORAGE_KEY && Array.isArray(cloned)) vidangeData=cloned;
  else if(key===TECH_DEADLINE_STORAGE_KEY && Array.isArray(cloned)) technicalDeadlines=cloned.filter(item=>item.category!=='hayon');
  else if(key===ADMIN_FINE_KEY && Array.isArray(cloned)) adminFines=cloned;
  else if(key===ADMIN_RUNGIS_KEY && Array.isArray(cloned)) adminRungis=cloned;
  else if(key===ADMIN_SITES_KEY && cloned && typeof cloned==='object'){
    adminSites={dkv:'',ids:'',lumesia:'',...cloned};
    if(!adminSites.ids && cloned.ils) adminSites.ids=cloned.ils;
    delete adminSites.ils;
  }
  else if(key===FUEL_STORAGE_KEY && Array.isArray(cloned)) fuelEntries=cloned;
  else return;

  sharedWriteLocalCache(key,sharedCurrentData(key));
  if(refresh) sharedRefreshUiForKey(key);
}

function sharedRecordMap(descriptor,array){
  const map=new Map();
  (Array.isArray(array)?array:[]).forEach((item,index)=>{
    const id=descriptor.id?.(item);
    const safeId=id || `__index_${index}`;
    map.set(String(safeId),item);
  });
  return map;
}

function sharedMergeDelta(descriptor,previous,next,remote){
  if(descriptor.kind==='object'){
    const prev=previous && typeof previous==='object' ? previous : {};
    const after=next && typeof next==='object' ? next : {};
    const latest=remote && typeof remote==='object' ? {...remote} : {};

    const keys=new Set([...Object.keys(prev),...Object.keys(after)]);
    let objectChanged=false;
    keys.forEach(key=>{
      if(!(key in after)){
        if(key in prev){
          delete latest[key];
          objectChanged=true;
        }
      }else if(JSON.stringify(prev[key])!==JSON.stringify(after[key])){
        latest[key]=sharedDeepClone(after[key]);
        objectChanged=true;
      }
    });
    if(objectChanged){
      latest._modifiedBy=dashboardUser || sharedClientId;
      latest._modifiedAt=new Date().toISOString();
    }
    return latest;
  }

  const prevArray=Array.isArray(previous)?previous:[];
  const nextArray=Array.isArray(next)?next:[];
  const remoteArray=Array.isArray(remote)?remote:[];

  const prevMap=sharedRecordMap(descriptor,prevArray);
  const nextMap=sharedRecordMap(descriptor,nextArray);
  const remoteMap=sharedRecordMap(descriptor,remoteArray);

  // suppressions locales
  for(const id of prevMap.keys()){
    if(!nextMap.has(id)) remoteMap.delete(id);
  }

  // ajouts / modifications locales
  for(const [id,item] of nextMap.entries()){
    const before=prevMap.get(id);
    if(!prevMap.has(id) || JSON.stringify(before)!==JSON.stringify(item)){
      const stamped=sharedDeepClone(item);
      const now=new Date().toISOString();

      if(stamped && typeof stamped==='object'){
        stamped._modifiedBy=dashboardUser || sharedClientId;
        stamped._modifiedAt=now;

        if(!prevMap.has(id)){
          stamped._createdBy=stamped._createdBy || dashboardUser || sharedClientId;
          stamped._createdAt=stamped._createdAt || now;
        }else if(before && typeof before==='object'){
          stamped._createdBy=stamped._createdBy || before._createdBy;
          stamped._createdAt=stamped._createdAt || before._createdAt;
        }
      }

      remoteMap.set(id,stamped);
    }
  }

  // On conserve l'ordre distant autant que possible, puis les nouveaux éléments.
  const result=[];
  const used=new Set();

  for(const item of remoteArray){
    const id=String(descriptor.id?.(item)||'');
    if(!id || used.has(id) || !remoteMap.has(id)) continue;
    result.push(remoteMap.get(id));
    used.add(id);
  }

  for(const [id,item] of remoteMap.entries()){
    if(!used.has(id)){
      result.push(item);
      used.add(id);
    }
  }

  return result;
}

async function sharedQueueSave(key,previous,next){
  const descriptor=SHARED_DESCRIPTOR_BY_KEY.get(key);
  if(!descriptor || !sharedConnected) return;

  const oldQueue=sharedWriteQueues.get(key)||Promise.resolve();

  const newQueue=oldQueue.then(async()=>{
    sharedSetUiState('syncing','Enregistrement des modifications dans le Groupdrive…');

    try{
      await dashboardEnsureDailyBackup().catch(error=>console.warn('Sauvegarde quotidienne indisponible.',error));

      const remoteDoc=await sharedReadDocument(descriptor);
      const remoteData=remoteDoc ? remoteDoc.data : previous;

      const conflict=dashboardDetectSharedConflict(descriptor,previous,next,remoteData);
      if(conflict){
        const keepLocal=await dashboardAskSharedConflict(descriptor,conflict,remoteDoc);
        if(!keepLocal){
          sharedApplyData(key,remoteData,true);
          sharedLastLocalByKey.set(key,sharedDeepClone(remoteData));
          sharedSetUiState('connected','Version partagée rechargée.');
          dashboardToast('Version partagée rechargée','Votre modification locale a été abandonnée.','warn');
          return;
        }

        administratorWriteHistory({
          action:'Conflit',
          section:administratorSectionLabel(descriptor),
          entity:conflict.labels.join(', '),
          detail:'Version locale conservée après conflit multi-utilisateurs'
        });
      }

      const merged=sharedMergeDelta(descriptor,previous,next,remoteData);

      await sharedWriteDocument(descriptor,merged);

      // Journal administrateur : uniquement l'action locale qui vient d'être validée.
      administratorLogDatasetChanges(descriptor,previous,next).catch(error=>
        console.warn('Journalisation de la modification impossible.',error)
      );

      // On ne réinjecte le résultat fusionné dans l'interface que si aucune
      // sauvegarde plus récente du même jeu de données n'a déjà été demandée.
      // Cela évite qu'une écriture réseau un peu lente fasse revenir l'écran
      // à l'état précédent pendant que l'utilisateur continue de modifier.
      const currentLocal=sharedLastLocalByKey.get(key);
      if(JSON.stringify(currentLocal)===JSON.stringify(next)){
        sharedApplyData(key,merged,false);
        sharedLastLocalByKey.set(key,sharedDeepClone(merged));
      }

      sharedSetUiState('connected','Modifications enregistrées dans le Groupdrive.');
      dashboardToastSharedSave();
      dashboardRefreshNotifications();
    }catch(error){
      console.error('Échec sauvegarde Groupdrive.',key,error);
      sharedSetUiState(
        'error',
        'La modification reste visible sur ce poste, mais son enregistrement dans le Groupdrive a échoué.<br><b>'+String(error)+'</b>'
      );
    }
  }).finally(()=>{
    if(sharedWriteQueues.get(key)===newQueue){
      sharedWriteQueues.delete(key);
    }
  });

  sharedWriteQueues.set(key,newQueue);
}

Storage.prototype.setItem=function(key,value){
  const isShared=
    this===localStorage &&
    !sharedSuppressLocalHook &&
    sharedConnected &&
    SHARED_DESCRIPTOR_BY_KEY.has(key);

  let previous=null;
  let next=null;

  if(isShared){
    previous=sharedDeepClone(
      sharedLastLocalByKey.has(key)
        ? sharedLastLocalByKey.get(key)
        : sharedCurrentData(key)
    );
    try{next=JSON.parse(value)}catch(error){next=null}
  }

  const result=SHARED_ORIGINAL_SET_ITEM.call(this,key,value);

  if(isShared && next!==null){
    sharedLastLocalByKey.set(key,sharedDeepClone(next));
    sharedQueueSave(key,previous,next);
  }

  return result;
};

Storage.prototype.removeItem=function(key){
  const result=SHARED_ORIGINAL_REMOVE_ITEM.call(this,key);
  if(
    this===localStorage &&
    !sharedSuppressLocalHook &&
    sharedConnected &&
    SHARED_DESCRIPTOR_BY_KEY.has(key)
  ){
    const previous=sharedDeepClone(sharedLastLocalByKey.get(key));
    sharedLastLocalByKey.set(key,null);
    sharedQueueSave(key,previous,SHARED_DESCRIPTOR_BY_KEY.get(key).kind==='array'?[]:{});
  }
  return result;
};

function sharedUserIsEditing(){
  if(document.querySelector('.modal-overlay:not([hidden])')) return true;

  const active=document.activeElement;
  if(!active) return false;

  if(active.matches('textarea,select,[contenteditable="true"]')) return true;

  if(active.matches('input')){
    const type=(active.getAttribute('type')||'text').toLowerCase();
    return type!=='search';
  }

  return false;
}

async function sharedSyncFromDisk(force=false){
  if(!sharedConnected || !sharedDirectoryHandle) return;

  try{
    if(!(await sharedHasPermission(sharedDirectoryHandle,false))){
      sharedConnected=false;
      sharedSetUiState('local','Edge doit de nouveau autoriser l’accès au dossier <b>data</b>.');
      return;
    }

    const editing=sharedUserIsEditing();

    for(const descriptor of SHARED_DATASETS){
      if(sharedWriteQueues.has(descriptor.key)) continue;

      const doc=await sharedReadDocument(descriptor);
      if(!doc) continue;

      const signature=`${doc._lastModified||0}|${doc.updatedAt||''}|${doc.updatedBy||''}`;
      const previousSignature=sharedRemoteSignatureByKey.get(descriptor.key);

      if(force || (previousSignature && signature!==previousSignature)){
        if(editing && !force){
          sharedPendingRemote.set(descriptor.key,{doc,signature});
          continue;
        }
        sharedApplyData(descriptor.key,doc.data,true);
      }

      sharedRemoteSignatureByKey.set(descriptor.key,signature);
    }

    if(!editing && sharedPendingRemote.size){
      for(const [key,pending] of sharedPendingRemote.entries()){
        sharedApplyData(key,pending.doc.data,true);
        sharedRemoteSignatureByKey.set(key,pending.signature);
      }
      sharedPendingRemote.clear();
    }

    sharedLastSyncAt=new Date();
    sharedSetUiState(
      'connected',
      sharedPendingRemote.size
        ? 'Une mise à jour distante est en attente pendant ta saisie.'
        : 'Les données sont synchronisées avec le Groupdrive.'
    );
    dashboardRefreshNotifications();
    if(document.querySelector('.view.active')?.id==='administrateur'){
      dashboardRenderQuality();
      dashboardRefreshBackupList();
    }
  }catch(error){
    console.error('Synchronisation Groupdrive impossible.',error);
    sharedSetUiState('error','Impossible de lire le Groupdrive.<br><b>'+String(error)+'</b>');
  }
}

async function sharedInitializeFiles(){
  sharedFilesReady=0;
  sharedSetUiState('syncing','Initialisation des fichiers partagés…');

  for(const descriptor of SHARED_DATASETS){
    let doc=await sharedReadDocument(descriptor);

    if(!doc){
      const current=sharedCurrentData(descriptor.key);
      await sharedWriteDocument(descriptor,current);
      doc=await sharedReadDocument(descriptor);
    }else{
      sharedApplyData(descriptor.key,doc.data,false);
    }

    if(doc){
      const signature=`${doc._lastModified||0}|${doc.updatedAt||''}|${doc.updatedBy||''}`;
      sharedRemoteSignatureByKey.set(descriptor.key,signature);
      sharedLastLocalByKey.set(descriptor.key,sharedCurrentData(descriptor.key));
      sharedFilesReady++;
      sharedSetUiState('syncing','Préparation des données partagées…');
    }
  }

  // Une seule remise à jour globale après le chargement des 10 fichiers.
  renderParkTable();
  renderAffectations();
  renderDriverList();
  fillDriverForm();
  renderClaims();
  loadClaimDetail();
  renderClaimEvents();
  renderClaimTimeline();
  renderClaimAttachments();
  renderVidTable();
  loadVidDetail();
  renderFines();
  renderRungis();
  renderAdminSites();
  renderFuelTable();
  renderFuelCharts();
  refreshHomeDashboard();

  sharedLastSyncAt=new Date();
}

async function sharedConnect(handle,{requestPermission=false}={}){
  if(!handle) return false;

  sharedDirectoryHandle=handle;
  sharedSetUiState('syncing','Vérification de l’accès au dossier…');

  const allowed=await sharedHasPermission(handle,requestPermission);
  if(!allowed){
    sharedConnected=false;
    sharedSetUiState(
      'local',
      'Le dossier <b>'+String(handle.name||'data')+'</b> est mémorisé, mais Edge attend ton autorisation.'
    );
    return false;
  }

  try{
    // Test lecture/écriture réel
    const testHandle=await handle.getFileHandle('.dashboard-access-test.json',{create:true});
    const writable=await testHandle.createWritable();
    await writable.write(JSON.stringify({checkedAt:new Date().toISOString(),user:dashboardUser || sharedClientId}));
    await writable.close();

    sharedConnected=true;
    await saveSharedDirectoryHandle(handle);
    await sharedInitializeFiles();
    await dashboardEnsureDailyBackup().catch(error=>console.warn('Sauvegarde automatique indisponible.',error));
    await administratorStartPresence(false);
    dashboardRefreshNotifications();

    if(sharedPollTimer) clearInterval(sharedPollTimer);
    sharedPollTimer=setInterval(()=>sharedSyncFromDisk(false),SHARED_POLL_MS);

    sharedSetUiState(
      'connected',
      'Connexion réussie. Les données sont maintenant partagées automatiquement.'
    );
    if(!sharedStorageModal.hidden){
      setTimeout(closeSharedStorageDialog,550);
    }
    return true;
  }catch(error){
    sharedConnected=false;
    sharedSetUiState(
      'error',
      'Le dossier a été sélectionné mais l’accès lecture/écriture a échoué.<br><b>'+String(error)+'</b>'
    );
    return false;
  }
}

async function sharedChooseDirectory(){
  if(window.__dashboardSharedPickerActive) return;
  window.__dashboardSharedPickerActive=true;

  if(typeof window.showDirectoryPicker!=='function'){
    sharedSetUiState(
      'error',
      'Cette version d’Edge ne fournit pas l’API nécessaire pour accéder au dossier partagé.'
    );
    window.__dashboardSharedPickerActive=false;
    return;
  }

  try{
    // Si un handle est déjà mémorisé, on tente d'abord de réautoriser celui-ci.
    if(sharedDirectoryHandle && !sharedConnected){
      const reconnected=await sharedConnect(sharedDirectoryHandle,{requestPermission:true});
      if(reconnected) return;
    }

    const handle=await window.showDirectoryPicker({mode:'readwrite'});
    await sharedConnect(handle,{requestPermission:true});
  }catch(error){
    if(error?.name==='AbortError') return;
    sharedSetUiState('error','Connexion au dossier impossible.<br><b>'+String(error)+'</b>');
  }finally{
    window.__dashboardSharedPickerActive=false;
  }
}

async function sharedDisconnect(){
  await administratorStopPresence(true);

  if(sharedPollTimer){
    clearInterval(sharedPollTimer);
    sharedPollTimer=null;
  }

  await Promise.allSettled([...sharedWriteQueues.values()]);
  sharedWriteQueues.clear();
  sharedPendingRemote.clear();

  sharedConnected=false;
  sharedDirectoryHandle=null;
  sharedFilesReady=0;
  sharedRemoteSignatureByKey.clear();
  sharedLastLocalByKey.clear();
  await forgetSharedDirectoryHandle();

  sharedSetUiState(
    'local',
    'Ce navigateur est déconnecté du Groupdrive. Le dashboard utilise temporairement son cache local.'
  );
}

sharedStorageButton.addEventListener('click',async()=>{
  if(sharedConnected){
    await sharedSyncFromDisk(true);
    return;
  }
  openSharedStorageModal();
});
closeSharedStorageModal.addEventListener('click',closeSharedStorageDialog);
sharedStorageModal.addEventListener('click',event=>{
  if(event.target===sharedStorageModal) closeSharedStorageDialog();
});
connectSharedStorageButton.addEventListener('click',sharedChooseDirectory);
syncSharedStorageButton.addEventListener('click',()=>sharedSyncFromDisk(true));
disconnectSharedStorageButton.addEventListener('click',async()=>{
  await sharedDisconnect();
  await sharedChooseDirectory();
});

window.addEventListener('focus',()=>{
  if(sharedConnected) sharedSyncFromDisk(false);
});
document.addEventListener('visibilitychange',()=>{
  if(!document.hidden && sharedConnected) sharedSyncFromDisk(false);
});

// Tentative de reconnexion automatique au lancement.
// Si Edge ne conserve pas l'autorisation, l'utilisateur clique simplement
// sur le bouton dossier dans la barre du haut pour la redonner.
(async()=>{
  if(typeof window.showDirectoryPicker!=='function'){
    sharedSetUiState('error','API d’accès au dossier indisponible dans ce navigateur.');
    return;
  }

  const savedHandle=await loadSharedDirectoryHandle();
  if(savedHandle){
    sharedDirectoryHandle=savedHandle;
    const connected=await sharedConnect(savedHandle,{requestPermission:false});
    if(!connected){
      sharedSetUiState(
        'local',
        'Le dossier <b>'+String(savedHandle.name||'data')+'</b> est mémorisé. Clique sur le bouton dossier pour autoriser l’accès.'
      );
    }
  }else{
    sharedSetUiState(
      'local',
      'Première utilisation uniquement : sélectionne le dossier <b>data</b> du Groupdrive.'
    );
    setTimeout(openSharedStorageModal,450);
  }
})();


/* ===== PIÈCES JOINTES SINISTRES DANS LE GROUPDRIVE ===== */
const SHARED_CLAIM_FILES_FOLDER='pieces_jointes_sinistres';

function sharedSafeFilePart(value){
  return String(value||'')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g,'')
    .replace(/[<>:"/\\|?*\x00-\x1F]/g,'_')
    .replace(/\s+/g,' ')
    .trim()
    .slice(0,120) || 'fichier';
}

async function sharedClaimFilesDirectory(create=false){
  if(!sharedConnected || !sharedDirectoryHandle) return null;
  return await sharedDirectoryHandle.getDirectoryHandle(
    SHARED_CLAIM_FILES_FOLDER,
    {create}
  );
}

const localPutClaimFile=putClaimFile;
const localGetClaimFiles=getClaimFiles;
const localDeleteClaimFile=deleteClaimFile;

putClaimFile=async function(claimId,file){
  if(!sharedConnected) return localPutClaimFile(claimId,file);

  const dir=await sharedClaimFilesDirectory(true);
  const id='file_'+Date.now()+'_'+Math.random().toString(36).slice(2);
  const cleanClaim=sharedSafeFilePart(claimId);
  const cleanName=sharedSafeFilePart(file.name);
  const storedName=`${cleanClaim}__${id}__${cleanName}`;

  const handle=await dir.getFileHandle(storedName,{create:true});
  const writable=await handle.createWritable();
  await writable.write(file);
  await writable.close();

  return {
    key:'shared::'+storedName,
    claimId,
    id,
    name:file.name,
    type:file.type,
    size:file.size,
    blob:null,
    addedAt:new Date().toISOString()
  };
};

getClaimFiles=async function(claimId){
  if(!sharedConnected) return localGetClaimFiles(claimId);
  if(!claimId) return [];

  let dir;
  try{
    dir=await sharedClaimFilesDirectory(false);
  }catch(error){
    if(error?.name==='NotFoundError') return [];
    throw error;
  }

  const prefix=sharedSafeFilePart(claimId)+'__';
  const records=[];

  for await (const [storedName,handle] of dir.entries()){
    if(handle.kind!=='file' || !storedName.startsWith(prefix)) continue;
    const file=await handle.getFile();

    const firstSep=storedName.indexOf('__');
    const secondSep=storedName.indexOf('__',firstSep+2);
    const id=secondSep>firstSep ? storedName.slice(firstSep+2,secondSep) : storedName;
    const displayName=secondSep>=0 ? storedName.slice(secondSep+2) : storedName;

    records.push({
      key:'shared::'+storedName,
      claimId,
      id,
      name:displayName,
      type:file.type,
      size:file.size,
      blob:null,
      addedAt:new Date(file.lastModified).toISOString()
    });
  }

  return records.sort((a,b)=>String(a.addedAt).localeCompare(String(b.addedAt)));
};

deleteClaimFile=async function(key){
  if(!sharedConnected || !String(key||'').startsWith('shared::')){
    return localDeleteClaimFile(key);
  }

  const dir=await sharedClaimFilesDirectory(false);
  const storedName=String(key).slice('shared::'.length);
  await dir.removeEntry(storedName);
};





/* ===== SÉCURITÉ ADMINISTRATEUR =====
   Le fichier data/admin_security.json ne contient jamais le mot de passe.
   Il contient seulement un sel aléatoire et un hash PBKDF2-SHA256.
*/
const ADMIN_SECURITY_FILE='admin_security.json';
const ADMIN_SECURITY_ITERATIONS=310000;
const ADMIN_SECURITY_TIMEOUT=15*60*1000;
const ADMIN_SECURITY_MIN_LENGTH=8;

let adminSecurityUnlocked=false;
let adminSecurityUnlockedUntil=0;
let adminSecurityMode='login';
let adminSecurityResolver=null;
let adminSecurityFailures=0;
let adminSecurityBlockedUntil=0;

const adminSecurityModal=document.getElementById('adminSecurityModal');
const adminSecurityIntro=document.getElementById('adminSecurityIntro');
const adminSecurityPassword=document.getElementById('adminSecurityPassword');
const adminSecurityConfirm=document.getElementById('adminSecurityConfirm');
const adminSecurityConfirmWrap=document.getElementById('adminSecurityConfirmWrap');
const adminSecurityError=document.getElementById('adminSecurityError');
const adminSecuritySubmit=document.getElementById('adminSecuritySubmit');
const adminSecurityCancel=document.getElementById('adminSecurityCancel');
const adminSecurityClose=document.getElementById('adminSecurityClose');
const adminSecurityChip=document.getElementById('adminSecurityChip');
const adminSecurityChipText=document.getElementById('adminSecurityChipText');
const adminSecurityLockButton=document.getElementById('adminSecurityLockButton');
const adminSecurityChangeButton=document.getElementById('adminSecurityChangeButton');

function adminSecurityToB64(bytes){
  let value='';
  bytes.forEach(byte=>value+=String.fromCharCode(byte));
  return btoa(value);
}
function adminSecurityFromB64(value){
  const raw=atob(value);
  const bytes=new Uint8Array(raw.length);
  for(let i=0;i<raw.length;i++) bytes[i]=raw.charCodeAt(i);
  return bytes;
}
async function adminSecurityDerive(password,salt,iterations){
  const source=await crypto.subtle.importKey(
    'raw',new TextEncoder().encode(password),'PBKDF2',false,['deriveBits']
  );
  const result=await crypto.subtle.deriveBits(
    {name:'PBKDF2',hash:'SHA-256',salt,iterations},
    source,256
  );
  return new Uint8Array(result);
}
function adminSecurityEqual(a,b){
  if(a.length!==b.length) return false;
  let diff=0;
  for(let i=0;i<a.length;i++) diff|=a[i]^b[i];
  return diff===0;
}

async function adminSecurityReadConfig(){
  if(!sharedConnected || !sharedDirectoryHandle) return null;
  try{
    const handle=await sharedDirectoryHandle.getFileHandle(ADMIN_SECURITY_FILE);
    const file=await handle.getFile();
    const config=JSON.parse(await file.text());
    return config?.salt && config?.hash ? config : null;
  }catch(error){
    if(error?.name==='NotFoundError') return null;
    throw error;
  }
}

async function adminSecurityCreateConfig(password){
  if(!sharedConnected || !sharedDirectoryHandle){
    throw new Error('Le stockage partagé Groupdrive doit être connecté.');
  }

  const salt=crypto.getRandomValues(new Uint8Array(16));
  const hash=await adminSecurityDerive(password,salt,ADMIN_SECURITY_ITERATIONS);
  const config={
    version:1,
    algorithm:'PBKDF2-SHA256',
    iterations:ADMIN_SECURITY_ITERATIONS,
    salt:adminSecurityToB64(salt),
    hash:adminSecurityToB64(hash),
    adminUser:ADMINISTRATOR_USER,
    updatedAt:new Date().toISOString(),
    updatedBy:dashboardUser
  };

  const handle=await sharedDirectoryHandle.getFileHandle(ADMIN_SECURITY_FILE,{create:true});
  const writable=await handle.createWritable();
  await writable.write(JSON.stringify(config,null,2));
  await writable.close();
}

async function adminSecurityVerify(password,config){
  const salt=adminSecurityFromB64(config.salt);
  const expected=adminSecurityFromB64(config.hash);
  const actual=await adminSecurityDerive(
    password,
    salt,
    Number(config.iterations)||ADMIN_SECURITY_ITERATIONS
  );
  return adminSecurityEqual(actual,expected);
}

function adminSecurityIsUnlocked(){
  if(!adminSecurityUnlocked) return false;
  if(Date.now()>adminSecurityUnlockedUntil){
    adminSecurityLock(true);
    return false;
  }
  return true;
}
function adminSecurityTouch(){
  if(adminSecurityUnlocked){
    adminSecurityUnlockedUntil=Date.now()+ADMIN_SECURITY_TIMEOUT;
  }
}
function adminSecurityUpdateUi(){
  const open=adminSecurityUnlocked && Date.now()<=adminSecurityUnlockedUntil;
  adminSecurityChip?.classList.toggle('unlocked',open);
  if(adminSecurityChipText) adminSecurityChipText.textContent=open?'Déverrouillé':'Verrouillé';
  if(adminSecurityLockButton) adminSecurityLockButton.disabled=!open;
}

function adminSecurityShowError(text){
  adminSecurityError.textContent=text;
  adminSecurityError.classList.add('show');
}
function adminSecurityClearError(){
  adminSecurityError.textContent='';
  adminSecurityError.classList.remove('show');
}

function adminSecurityOpen(mode){
  adminSecurityMode=mode;
  adminSecurityClearError();
  adminSecurityPassword.value='';
  adminSecurityConfirm.value='';
  adminSecurityModal.hidden=false;
  document.body.classList.add('modal-open');

  if(mode==='setup'){
    adminSecurityIntro.innerHTML='Première utilisation : crée le mot de passe de l’espace <b>Administrateur</b>.';
    adminSecurityConfirmWrap.hidden=false;
    adminSecuritySubmit.textContent='Créer le mot de passe';
  }else if(mode==='change'){
    adminSecurityIntro.textContent='Choisis un nouveau mot de passe administrateur.';
    adminSecurityConfirmWrap.hidden=false;
    adminSecuritySubmit.textContent='Changer le mot de passe';
  }else{
    adminSecurityIntro.textContent='Saisis le mot de passe administrateur pour accéder à la supervision.';
    adminSecurityConfirmWrap.hidden=true;
    adminSecuritySubmit.textContent='Déverrouiller';
  }

  setTimeout(()=>adminSecurityPassword.focus(),50);
}

function adminSecurityCloseModal(result=false){
  adminSecurityModal.hidden=true;
  adminSecurityPassword.value='';
  adminSecurityConfirm.value='';
  adminSecurityClearError();

  if(document.querySelectorAll('.modal-overlay:not([hidden])').length===0){
    document.body.classList.remove('modal-open');
  }

  if(adminSecurityResolver){
    const resolve=adminSecurityResolver;
    adminSecurityResolver=null;
    resolve(result);
  }
}

function adminSecurityLock(returnHome=true){
  adminSecurityUnlocked=false;
  adminSecurityUnlockedUntil=0;
  adminSecurityUpdateUi();

  if(returnHome && document.querySelector('.view.active')?.id==='administrateur'){
    showView('accueil','Gestion de Parc','accueil');
  }
}

async function adminSecurityRequestAccess(){
  if(!administratorIsAdmin()) return false;

  if(!sharedConnected || !sharedDirectoryHandle){
    alert('Connecte d’abord le stockage partagé Groupdrive.');
    return false;
  }

  if(adminSecurityIsUnlocked()){
    adminSecurityTouch();
    return true;
  }

  let config;
  try{
    config=await adminSecurityReadConfig();
  }catch(error){
    alert('Impossible de lire la sécurité Administrateur : '+String(error));
    return false;
  }

  adminSecurityOpen(config?'login':'setup');

  return await new Promise(resolve=>{
    adminSecurityResolver=resolve;
  });
}

async function adminSecuritySubmitForm(){
  adminSecurityClearError();

  if(Date.now()<adminSecurityBlockedUntil){
    const sec=Math.ceil((adminSecurityBlockedUntil-Date.now())/1000);
    adminSecurityShowError(`Trop de tentatives. Réessaie dans ${sec} seconde(s).`);
    return;
  }

  const password=String(adminSecurityPassword.value||'');

  if(adminSecurityMode==='setup' || adminSecurityMode==='change'){
    if(password.length<ADMIN_SECURITY_MIN_LENGTH){
      adminSecurityShowError(`Utilise au moins ${ADMIN_SECURITY_MIN_LENGTH} caractères.`);
      return;
    }
    if(password!==String(adminSecurityConfirm.value||'')){
      adminSecurityShowError('Les deux mots de passe ne correspondent pas.');
      return;
    }

    try{
      adminSecuritySubmit.disabled=true;
      await adminSecurityCreateConfig(password);
      adminSecurityUnlocked=true;
      adminSecurityUnlockedUntil=Date.now()+ADMIN_SECURITY_TIMEOUT;
      adminSecurityFailures=0;
      adminSecurityUpdateUi();

      administratorWriteHistory({
        action:'Sécurité',
        section:'Administrateur',
        entity:'Mot de passe',
        detail:adminSecurityMode==='setup'
          ? 'Protection administrateur activée'
          : 'Mot de passe administrateur modifié'
      });

      adminSecurityCloseModal(adminSecurityMode==='setup');
    }catch(error){
      adminSecurityShowError('Impossible d’enregistrer le mot de passe : '+String(error));
    }finally{
      adminSecuritySubmit.disabled=false;
    }
    return;
  }

  try{
    adminSecuritySubmit.disabled=true;
    const config=await adminSecurityReadConfig();

    if(!config){
      adminSecurityOpen('setup');
      return;
    }

    const valid=await adminSecurityVerify(password,config);

    if(!valid){
      adminSecurityFailures++;
      if(adminSecurityFailures>=5){
        adminSecurityFailures=0;
        adminSecurityBlockedUntil=Date.now()+30000;
        adminSecurityShowError('5 tentatives incorrectes. Accès bloqué 30 secondes.');
      }else{
        adminSecurityShowError(`Mot de passe incorrect (${adminSecurityFailures}/5).`);
      }
      return;
    }

    adminSecurityUnlocked=true;
    adminSecurityUnlockedUntil=Date.now()+ADMIN_SECURITY_TIMEOUT;
    adminSecurityFailures=0;
    adminSecurityUpdateUi();

    administratorWriteHistory({
      action:'Connexion Admin',
      section:'Administrateur',
      entity:dashboardUser,
      detail:'Espace administrateur déverrouillé'
    });

    adminSecurityCloseModal(true);
  }catch(error){
    adminSecurityShowError('Erreur de vérification : '+String(error));
  }finally{
    adminSecuritySubmit.disabled=false;
    if(adminSecurityMode==='login') adminSecuritySubmit.textContent='Déverrouiller';
  }
}

async function adminSecurityChangePasswordFlow(){
  if(!administratorIsAdmin()) return;

  if(!adminSecurityIsUnlocked()){
    const allowed=await adminSecurityRequestAccess();
    if(!allowed) return;
  }

  adminSecurityOpen('change');
}

adminSecuritySubmit.addEventListener('click',adminSecuritySubmitForm);
adminSecurityCancel.addEventListener('click',()=>adminSecurityCloseModal(false));
adminSecurityClose.addEventListener('click',()=>adminSecurityCloseModal(false));
adminSecurityModal.addEventListener('click',event=>{
  if(event.target===adminSecurityModal) adminSecurityCloseModal(false);
});

adminSecurityPassword.addEventListener('keydown',event=>{
  if(event.key!=='Enter') return;
  event.preventDefault();
  if(adminSecurityMode==='login') adminSecuritySubmitForm();
  else adminSecurityConfirm.focus();
});
adminSecurityConfirm.addEventListener('keydown',event=>{
  if(event.key==='Enter'){
    event.preventDefault();
    adminSecuritySubmitForm();
  }
});

adminSecurityLockButton.addEventListener('click',()=>adminSecurityLock(true));
adminSecurityChangeButton.addEventListener('click',adminSecurityChangePasswordFlow);

['click','keydown','touchstart'].forEach(type=>{
  document.addEventListener(type,()=>{
    if(
      adminSecurityUnlocked &&
      document.querySelector('.view.active')?.id==='administrateur'
    ){
      adminSecurityTouch();
    }
  },{passive:true});
});

setInterval(()=>{
  if(adminSecurityUnlocked) adminSecurityIsUnlocked();
  adminSecurityUpdateUi();
},15000);

adminSecurityUpdateUi();


/* ===== PAGE ADMINISTRATEUR : INTERFACE ===== */
let administratorPresenceRecords=[];
let administratorHistoryRecords=[];
let administratorRefreshTimer=null;
let administratorRefreshRunning=false;

const superadminState=document.getElementById('superadminState');
const superadminStateText=document.getElementById('superadminStateText');
const superadminOnlineCount=document.getElementById('superadminOnlineCount');
const superadminLoginToday=document.getElementById('superadminLoginToday');
const superadminActionsToday=document.getElementById('superadminActionsToday');
const superadminLastActivity=document.getElementById('superadminLastActivity');
const superadminLastActivityUser=document.getElementById('superadminLastActivityUser');
const superadminOnlineBadge=document.getElementById('superadminOnlineBadge');
const superadminOnlineTable=document.getElementById('superadminOnlineTable');
const superadminOnlineEmpty=document.getElementById('superadminOnlineEmpty');
const superadminLoginTable=document.getElementById('superadminLoginTable');
const superadminLoginEmpty=document.getElementById('superadminLoginEmpty');
const superadminHistoryTable=document.getElementById('superadminHistoryTable');
const superadminHistoryEmpty=document.getElementById('superadminHistoryEmpty');
const superadminHistoryCount=document.getElementById('superadminHistoryCount');
const superadminHistorySearch=document.getElementById('superadminHistorySearch');
const superadminUserFilter=document.getElementById('superadminUserFilter');
const superadminActionFilter=document.getElementById('superadminActionFilter');
const superadminRefreshButton=document.getElementById('superadminRefresh');
const superadminExportButton=document.getElementById('superadminExport');

function administratorEscape(value){
  return String(value??'')
    .replace(/&/g,'&amp;')
    .replace(/</g,'&lt;')
    .replace(/>/g,'&gt;')
    .replace(/"/g,'&quot;')
    .replace(/'/g,'&#039;');
}

function administratorInitials(user){
  const text=String(user||'?').trim();
  return text.slice(0,2).toUpperCase();
}

function administratorFormatDateTime(value){
  const date=new Date(value);
  if(Number.isNaN(date.getTime())) return {date:'—',time:'—',full:'—'};

  return {
    date:new Intl.DateTimeFormat('fr-FR',{day:'2-digit',month:'2-digit',year:'numeric'}).format(date),
    time:new Intl.DateTimeFormat('fr-FR',{hour:'2-digit',minute:'2-digit',second:'2-digit'}).format(date),
    full:new Intl.DateTimeFormat('fr-FR',{
      day:'2-digit',month:'2-digit',year:'numeric',
      hour:'2-digit',minute:'2-digit',second:'2-digit'
    }).format(date)
  };
}

function administratorRelativeTime(value){
  const ms=Date.now()-new Date(value).getTime();
  if(!Number.isFinite(ms)) return '—';
  if(ms<15000) return 'À l’instant';
  if(ms<60000) return `Il y a ${Math.max(1,Math.floor(ms/1000))} s`;
  if(ms<3600000) return `Il y a ${Math.floor(ms/60000)} min`;
  return administratorFormatDateTime(value).time;
}

function administratorActionClass(action){
  if(action==='Connexion') return 'login';
  if(action==='Ajout') return 'add';
  if(action==='Suppression') return 'delete';
  if(action==='Modification' || action==='Mise à jour en lot' || action==='Pièce jointe') return 'edit';
  return '';
}

async function administratorReadPresence(){
  if(!sharedConnected || !sharedDirectoryHandle) return [];

  let dir;
  try{
    dir=await administratorGetDirectory(ADMIN_PRESENCE_FOLDER,false);
  }catch(error){
    if(error?.name==='NotFoundError') return [];
    throw error;
  }
  if(!dir) return [];

  const records=[];

  for await(const [name,handle] of dir.entries()){
    if(handle.kind!=='file' || !name.toLowerCase().endsWith('.json')) continue;

    try{
      const file=await handle.getFile();
      const data=JSON.parse(await file.text());
      if(!data?.user || !data?.heartbeatAt) continue;

      const age=Date.now()-new Date(data.heartbeatAt).getTime();
      if(data.online!==false && age<=ADMIN_ONLINE_MAX_AGE){
        records.push(data);
      }
    }catch(error){}
  }

  // Une ligne maximum par utilisateur.
  const byUser=new Map();
  records.forEach(item=>{
    const key=String(item.user).toUpperCase();
    const previous=byUser.get(key);
    if(!previous || new Date(item.heartbeatAt)>new Date(previous.heartbeatAt)){
      byUser.set(key,item);
    }
  });

  return [...byUser.values()].sort((a,b)=>
    String(a.user).localeCompare(String(b.user),'fr',{sensitivity:'base'})
  );
}

async function administratorReadHistory(){
  if(!sharedConnected || !sharedDirectoryHandle) return [];

  let root;
  try{
    root=await administratorGetDirectory(ADMIN_HISTORY_FOLDER,false);
  }catch(error){
    if(error?.name==='NotFoundError') return [];
    throw error;
  }
  if(!root) return [];

  const dayNames=[];
  for await(const [name,handle] of root.entries()){
    if(handle.kind==='directory' && /^\d{4}-\d{2}-\d{2}$/.test(name)){
      dayNames.push(name);
    }
  }

  dayNames.sort().reverse();

  const records=[];

  for(const dayName of dayNames.slice(0,7)){
    if(records.length>=ADMIN_HISTORY_MAX_RECORDS) break;

    let dayDir;
    try{
      dayDir=await root.getDirectoryHandle(dayName);
    }catch(error){continue}

    const files=[];
    for await(const [name,handle] of dayDir.entries()){
      if(handle.kind==='file' && name.toLowerCase().endsWith('.json')){
        files.push({name,handle});
      }
    }

    files.sort((a,b)=>b.name.localeCompare(a.name));

    for(const entry of files){
      if(records.length>=ADMIN_HISTORY_MAX_RECORDS) break;

      try{
        const file=await entry.handle.getFile();
        const data=JSON.parse(await file.text());
        if(data?.timestamp && data?.user) records.push(data);
      }catch(error){}
    }
  }

  return records.sort((a,b)=>new Date(b.timestamp)-new Date(a.timestamp));
}

function administratorRenderOnline(){
  const rows=administratorPresenceRecords;
  superadminOnlineCount.textContent=rows.length;
  superadminOnlineBadge.textContent=rows.length;
  superadminOnlineEmpty.hidden=rows.length>0;
  superadminOnlineTable.innerHTML=rows.map(item=>`
    <tr>
      <td>
        <div class="superadmin-user">
          <span class="superadmin-user-avatar">${administratorEscape(administratorInitials(item.user))}</span>
          <span>${administratorEscape(item.user)}</span>
        </div>
      </td>
      <td><span class="superadmin-online">En ligne</span></td>
      <td>${administratorEscape(item.pageLabel||administratorPageLabel(item.page))}</td>
      <td title="${administratorEscape(administratorFormatDateTime(item.heartbeatAt).full)}">${administratorEscape(administratorRelativeTime(item.heartbeatAt))}</td>
    </tr>
  `).join('');
}

function administratorRenderLogins(){
  const logins=administratorHistoryRecords
    .filter(item=>item.action==='Connexion')
    .slice(0,10);

  superadminLoginEmpty.hidden=logins.length>0;
  superadminLoginTable.innerHTML=logins.map(item=>{
    const stamp=administratorFormatDateTime(item.timestamp);
    return `
      <tr>
        <td>
          <div class="superadmin-user">
            <span class="superadmin-user-avatar">${administratorEscape(administratorInitials(item.user))}</span>
            <span>${administratorEscape(item.user)}</span>
          </div>
        </td>
        <td>${administratorEscape(stamp.date)}</td>
        <td>${administratorEscape(stamp.time)}</td>
      </tr>
    `;
  }).join('');
}

function administratorFilteredHistory(){
  const search=String(superadminHistorySearch.value||'').trim().toLocaleLowerCase('fr');
  const user=superadminUserFilter.value;
  const action=superadminActionFilter.value;

  return administratorHistoryRecords.filter(item=>{
    if(user && item.user!==user) return false;
    if(action && item.action!==action) return false;

    if(search){
      const haystack=[
        item.user,item.action,item.section,item.entity,item.detail
      ].join(' ').toLocaleLowerCase('fr');
      if(!haystack.includes(search)) return false;
    }

    return true;
  });
}

function administratorRefreshUserFilter(){
  const current=superadminUserFilter.value;
  const users=[...new Set(administratorHistoryRecords.map(item=>item.user).filter(Boolean))]
    .sort((a,b)=>a.localeCompare(b,'fr',{sensitivity:'base'}));

  superadminUserFilter.innerHTML=
    '<option value="">Tous les utilisateurs</option>'+
    users.map(user=>`<option value="${administratorEscape(user)}">${administratorEscape(user)}</option>`).join('');

  if(users.includes(current)) superadminUserFilter.value=current;
}

function administratorRenderHistory(){
  const rows=administratorFilteredHistory();
  superadminHistoryEmpty.hidden=rows.length>0;
  superadminHistoryCount.textContent=
    `${rows.length} événement${rows.length>1?'s':''} affiché${rows.length>1?'s':''}`;

  superadminHistoryTable.innerHTML=rows.map(item=>{
    const stamp=administratorFormatDateTime(item.timestamp);
    return `
      <tr>
        <td title="${administratorEscape(stamp.full)}">${administratorEscape(stamp.date)} · ${administratorEscape(stamp.time)}</td>
        <td><strong>${administratorEscape(item.user)}</strong></td>
        <td><span class="superadmin-action-badge ${administratorActionClass(item.action)}">${administratorEscape(item.action)}</span></td>
        <td>${administratorEscape(item.section||'—')}</td>
        <td>${administratorEscape(item.entity||'—')}</td>
        <td>${administratorEscape(item.detail||'—')}</td>
      </tr>
    `;
  }).join('');
}

function administratorRenderKpis(){
  const today=administratorLocalDateKey(new Date());

  const todayRows=administratorHistoryRecords.filter(item=>
    administratorLocalDateKey(item.timestamp)===today
  );

  const logins=todayRows.filter(item=>item.action==='Connexion').length;
  const actions=todayRows.filter(item=>item.action!=='Connexion').length;

  superadminLoginToday.textContent=logins;
  superadminActionsToday.textContent=actions;

  const latest=administratorHistoryRecords[0];
  if(latest){
    superadminLastActivity.textContent=administratorFormatDateTime(latest.timestamp).time;
    superadminLastActivityUser.textContent=`${latest.user} · ${latest.action}`;
  }else{
    superadminLastActivity.textContent='—';
    superadminLastActivityUser.textContent='Aucune activité';
  }
}

function administratorRenderAll(){
  administratorRenderOnline();
  administratorRenderLogins();
  administratorRefreshUserFilter();
  administratorRenderHistory();
  administratorRenderKpis();
}

function administratorSetState(mode,text){
  superadminState.classList.remove('ok','error');
  if(mode==='ok') superadminState.classList.add('ok');
  if(mode==='error') superadminState.classList.add('error');
  superadminStateText.textContent=text;
}

async function administratorRefreshDashboard(){
  if(administratorRefreshRunning || !administratorIsAdmin()) return;
  administratorRefreshRunning=true;
  superadminRefreshButton.disabled=true;

  try{
    if(!sharedConnected || !sharedDirectoryHandle){
      administratorPresenceRecords=[];
      administratorHistoryRecords=[];
      administratorRenderAll();
      administratorSetState('error','Groupdrive non connecté');
      return;
    }

    administratorSetState('','Actualisation…');

    await administratorWritePresence();

    const [presence,history]=await Promise.all([
      administratorReadPresence(),
      administratorReadHistory()
    ]);

    administratorPresenceRecords=presence;
    administratorHistoryRecords=history;
    administratorRenderAll();
    administratorSetState('ok','À jour');
  }catch(error){
    console.warn('Page Administrateur indisponible.',error);
    administratorSetState('error','Erreur de lecture');
  }finally{
    administratorRefreshRunning=false;
    superadminRefreshButton.disabled=false;
  }
}

function administratorHandleViewChange(id){
  administratorLastKnownPage=id || administratorLastKnownPage;

  if(sharedConnected && dashboardUser){
    administratorWritePresence();
  }

  if(id==='administrateur' && administratorIsAdmin()){
    administratorRefreshDashboard();

    if(administratorRefreshTimer) clearInterval(administratorRefreshTimer);
    administratorRefreshTimer=setInterval(()=>{
      if(document.querySelector('.view.active')?.id==='administrateur'){
        administratorRefreshDashboard();
      }
    },10000);
  }else if(administratorRefreshTimer){
    clearInterval(administratorRefreshTimer);
    administratorRefreshTimer=null;
  }
}

function administratorCsvEscape(value){
  const text=String(value??'');
  if(/[;"\n\r]/.test(text)){
    return '"'+text.replace(/"/g,'""')+'"';
  }
  return text;
}

function administratorExportCsv(){
  const rows=administratorFilteredHistory();
  const header=['Date / heure','Utilisateur','Action','Section','Élément','Détail'];
  const lines=[header.map(administratorCsvEscape).join(';')];

  rows.forEach(item=>{
    const stamp=administratorFormatDateTime(item.timestamp).full;
    lines.push([
      stamp,item.user,item.action,item.section,item.entity,item.detail
    ].map(administratorCsvEscape).join(';'));
  });

  const blob=new Blob(['\ufeff'+lines.join('\r\n')],{type:'text/csv;charset=utf-8'});
  const url=URL.createObjectURL(blob);
  const link=document.createElement('a');
  link.href=url;
  link.download='historique_dashboard_'+administratorLocalDateKey(new Date())+'.csv';
  document.body.appendChild(link);
  link.click();
  link.remove();
  setTimeout(()=>URL.revokeObjectURL(url),1000);
}

superadminRefreshButton.addEventListener('click',administratorRefreshDashboard);
superadminHistorySearch.addEventListener('input',administratorRenderHistory);
superadminUserFilter.addEventListener('change',administratorRenderHistory);
superadminActionFilter.addEventListener('change',administratorRenderHistory);
superadminExportButton.addEventListener('click',administratorExportCsv);

refreshAdministratorAccess();

/* Historique des pièces jointes sinistres */
const administratorBasePutClaimFile=putClaimFile;
const administratorBaseDeleteClaimFile=deleteClaimFile;

putClaimFile=async function(claimId,file){
  const result=await administratorBasePutClaimFile(claimId,file);

  if(sharedConnected){
    administratorWriteHistory({
      action:'Pièce jointe',
      section:'Sinistre',
      entity:String(claimId||''),
      detail:'Ajout du fichier '+String(file?.name||'')
    });
  }

  return result;
};

deleteClaimFile=async function(key){
  const result=await administratorBaseDeleteClaimFile(key);

  if(sharedConnected){
    administratorWriteHistory({
      action:'Pièce jointe',
      section:'Sinistre',
      entity:'Pièce jointe',
      detail:'Suppression d’un fichier'
    });
  }

  return result;
};



/* =========================================================
   V2 PRODUCTION
   ========================================================= */

/* ---------- Helpers ---------- */
function dashboardEsc(value){
  return String(value??'')
    .replace(/&/g,'&amp;')
    .replace(/</g,'&lt;')
    .replace(/>/g,'&gt;')
    .replace(/"/g,'&quot;')
    .replace(/'/g,'&#039;');
}
function dashboardDateTime(value){
  if(!value) return '—';
  const d=new Date(value);
  if(Number.isNaN(d.getTime())) return '—';
  return d.toLocaleString('fr-FR',{
    day:'2-digit',month:'2-digit',year:'numeric',
    hour:'2-digit',minute:'2-digit'
  });
}
function dashboardModificationHtml(item){
  if(!item?._modifiedAt && !item?._modifiedBy){
    return '<span class="last-modification">—</span>';
  }
  return `<span class="last-modification"><strong>${dashboardEsc(item._modifiedBy||'—')}</strong><br>${dashboardEsc(dashboardDateTime(item._modifiedAt))}</span>`;
}
function dashboardVisibleValue(value){
  if(value===null || value===undefined || value==='') return '—';
  if(typeof value==='boolean') return value?'Oui':'Non';
  return String(value);
}
function dashboardDatasetFieldLabels(descriptor){
  const key=descriptor?.key;
  const maps={
    [PARK_STORAGE_KEY]:{registration:'Immatriculation',type:'Type',parkNumber:'N° parc'},
    [AFFECT_STORAGE_KEY]:{name:'Chauffeur',tractor:'Tracteur',semi:'Semi',number:'N° parc',phone:'Téléphone pro',personal:'N° personnel'},
    [DRIVER_STORAGE_KEY]:{lastName:'Nom',firstName:'Prénom',status:'Type de chauffeur',birthDate:'Date de naissance',birthCity:'Ville de naissance',birthPostalCode:'Code postal ville de naissance',phone:'Téléphone',address:'Adresse',postalCode:'Code postal',city:'Ville',licenseNumber:'N° permis',licenseIssueDate:'Délivrance permis',licenseExpiry:'Expiration permis'},
    [CLAIM_STORAGE_KEY]:{number:'N° dossier',date:'Date',driver:'Chauffeur',vehicle:'Véhicule',thirdParty:'Tiers',type:'Type',cost:'Coût',status:'Statut',description:'Description'},
    [VIDANGE_STORAGE_KEY]:{registration:'Immatriculation',driver:'Chauffeur',currentKm:'Km actuel',lastMajorKm:'Dernière grosse vidange',lastGarageKm:'Dernier passage garage'},
    [TECH_DEADLINE_STORAGE_KEY]:{category:'Catégorie',registration:'Immatriculation',driver:'Chauffeur',genre:'Genre',model:'Marque / Modèle',control:'Contrôle',label:'Libellé',lastControl:'Dernier contrôle',nextControl:'Prochain contrôle',company:'Société',operator:'Exploitant',sourceState:'État source',appointment:'Renseignements RDV'},
    [ADMIN_FINE_KEY]:{date:'Date',vehicle:'Véhicule',driver:'Chauffeur',offense:'Infraction',amount:'Montant',reference:'Référence',status:'Statut',notes:'Notes'},
    [ADMIN_RUNGIS_KEY]:{cardNumber:'N° carte',vehicle:'Immatriculation'},
    [ADMIN_SITES_KEY]:{dkv:'DKV',ids:'IDS',lumesia:'Lumesia'},
    [FUEL_STORAGE_KEY]:{supplier:'Fournisseur',orderDate:'Date commande',deliveryDate:'Date livraison',dieselPrice:'Prix gasoil',gnrPrice:'Prix GNR',adbluePrice:'Prix AdBlue'}
  };
  return maps[key]||{};
}
function dashboardDescribeObjectChanges(before,after,descriptor){
  const labels=dashboardDatasetFieldLabels(descriptor);
  const keys=new Set([...Object.keys(before||{}),...Object.keys(after||{})]);
  const changes=[];

  for(const key of keys){
    if(key==='id' || key.startsWith('_')) continue;
    const a=before?.[key];
    const b=after?.[key];
    if(JSON.stringify(a)===JSON.stringify(b)) continue;

    const label=labels[key]||key;
    changes.push(`${label}: ${dashboardVisibleValue(a)} → ${dashboardVisibleValue(b)}`);
    if(changes.length>=5) break;
  }

  return changes;
}
function dashboardDescribeCreatedItem(item,descriptor){
  const labels=dashboardDatasetFieldLabels(descriptor);
  const parts=[];
  for(const [key,value] of Object.entries(item||{})){
    if(key==='id'||key.startsWith('_')||value===null||value===undefined||value==='') continue;
    parts.push(`${labels[key]||key}: ${dashboardVisibleValue(value)}`);
    if(parts.length>=4) break;
  }
  return parts.length?parts.join(' · '):'Nouvel élément enregistré';
}

/* ---------- Toasts ---------- */
const dashboardToastStack=document.getElementById('dashboardToastStack');
let dashboardLastSaveToast=0;
function dashboardToast(title,text='',type='success',duration=2600){
  if(!dashboardToastStack) return;
  const node=document.createElement('div');
  node.className=`dashboard-toast ${type}`;
  node.innerHTML=`<strong>${dashboardEsc(title)}</strong>${text?dashboardEsc(text):''}`;
  dashboardToastStack.appendChild(node);
  setTimeout(()=>{
    node.style.opacity='0';
    node.style.transform='translateY(7px)';
    setTimeout(()=>node.remove(),180);
  },duration);
}
function dashboardToastSharedSave(){
  const now=Date.now();
  if(now-dashboardLastSaveToast<1200) return;
  dashboardLastSaveToast=now;
  dashboardToast('Enregistré','Modification synchronisée avec le Groupdrive.','success',2000);
}

/* ---------- Validation ---------- */
function dashboardValidateAssignment(candidate,currentIndex=-1){
  const tractor=normalizeRegistration(candidate?.tractor);
  const semi=normalizeRegistration(candidate?.semi);
  const candidateRegional=typeof driverAllowsMultipleAssignments==='function' && driverAllowsMultipleAssignments(candidate?.name);

  if(tractor){
    const duplicates=affectations
      .map((item,index)=>({item,index}))
      .filter(({item,index})=>index!==currentIndex && normalizeRegistration(item.tractor)===tractor);
    const blocking=duplicates.find(({item})=>!(candidateRegional && driverAllowsMultipleAssignments(item.name)));
    if(blocking){
      return `Le tracteur ${formatRegistration(tractor)} est déjà affecté à ${blocking.item.name}. Le partage d'un véhicule est réservé aux chauffeurs Régionaux.`;
    }
  }

  if(semi){
    const duplicates=affectations
      .map((item,index)=>({item,index}))
      .filter(({item,index})=>index!==currentIndex && normalizeRegistration(item.semi)===semi);
    const blocking=duplicates.find(({item})=>!(candidateRegional && driverAllowsMultipleAssignments(item.name)));
    if(blocking){
      return `La semi ${formatRegistration(semi)} est déjà affectée à ${blocking.item.name}. Le partage d'un véhicule est réservé aux chauffeurs Régionaux.`;
    }
  }

  return '';
}

function dashboardDataIssues(){
  const issues=[];

  const duplicateGroups=(values)=>{
    const counts=new Map();
    values.filter(Boolean).forEach(value=>counts.set(value,(counts.get(value)||0)+1));
    return [...counts.entries()].filter(([,count])=>count>1);
  };

  duplicateGroups(parkData.map(v=>normalizeRegistration(v.registration))).forEach(([reg,count])=>{
    issues.push({level:'high',section:'Parc',text:`Immatriculation ${formatRegistration(reg)} présente ${count} fois.`});
  });

  duplicateGroups(parkData.map(v=>String(v.parkNumber||'').trim())).forEach(([n,count])=>{
    issues.push({level:'high',section:'Parc',text:`N° de parc ${n} utilisé ${count} fois.`});
  });

  duplicateGroups(affectations.map(a=>normalizeAffText(a.name))).forEach(([name,count])=>{
    const sample=affectations.find(a=>normalizeAffText(a.name)===name);
    if(sample && driverAllowsMultipleAssignments(sample.name)) return;
    issues.push({level:'high',section:'Affectations',text:`Chauffeur ${sample?.name||name} présent ${count} fois.`});
  });

  duplicateGroups(affectations.map(a=>normalizeRegistration(a.tractor))).forEach(([reg,count])=>{
    const rows=affectations.filter(a=>normalizeRegistration(a.tractor)===reg);
    if(rows.length>1 && rows.every(a=>driverAllowsMultipleAssignments(a.name))) return;
    issues.push({level:'high',section:'Affectations',text:`Tracteur ${formatRegistration(reg)} affecté à ${count} chauffeurs.`});
  });

  duplicateGroups(affectations.map(a=>normalizeRegistration(a.semi))).forEach(([reg,count])=>{
    const rows=affectations.filter(a=>normalizeRegistration(a.semi)===reg);
    if(rows.length>1 && rows.every(a=>driverAllowsMultipleAssignments(a.name))) return;
    issues.push({level:'high',section:'Affectations',text:`Semi ${formatRegistration(reg)} affectée à ${count} chauffeurs.`});
  });

  affectations.forEach(a=>{
    const t=normalizeRegistration(a.tractor);
    const s=normalizeRegistration(a.semi);
    if(t && !vehicleExistsInPark(t,'Tracteur')){
      issues.push({level:'warn',section:'Affectations',text:`${a.name} : tracteur ${formatRegistration(t)} hors parc.`});
    }
    if(s && !vehicleExistsInPark(s,'Semi')){
      issues.push({level:'warn',section:'Affectations',text:`${a.name} : semi ${formatRegistration(s)} hors parc.`});
    }
  });

  duplicateGroups(driverProfiles.map(d=>String(d.licenseNumber||'').trim().toUpperCase())).forEach(([license,count])=>{
    issues.push({level:'high',section:'Chauffeurs',text:`N° de permis ${license} utilisé sur ${count} fiches.`});
  });

  vidangeData.forEach(v=>{
    const current=kmNumber(v.currentKm);
    const major=kmNumber(v.lastMajorKm);
    const garage=kmNumber(v.lastGarageKm);
    if(current!==null && major!==null && current<major){
      issues.push({level:'high',section:'Suivi technique',text:`${formatRegistration(v.registration)} : km actuel inférieur à la dernière grosse vidange.`});
    }
    if(current!==null && garage!==null && current<garage){
      issues.push({level:'high',section:'Suivi technique',text:`${formatRegistration(v.registration)} : km actuel inférieur au dernier passage garage.`});
    }
  });

  duplicateGroups(adminRungis.map(r=>String(r.cardNumber||'').trim().toLocaleLowerCase('fr'))).forEach(([card,count])=>{
    issues.push({level:'high',section:'Cartes Rungis',text:`Carte ${card} présente ${count} fois.`});
  });

  return issues.slice(0,100);
}

/* Validation active avant enregistrement de certains formulaires */
document.getElementById('saveVidRecord')?.addEventListener('click',event=>{
  const current=kmNumber(document.getElementById('vidCurrentKm')?.value);
  const major=kmNumber(document.getElementById('vidLastMajorKm')?.value);
  const garage=kmNumber(document.getElementById('vidLastGarageKm')?.value);
  if(current!==null && ((major!==null && current<major)||(garage!==null && current<garage))){
    event.preventDefault();
    event.stopImmediatePropagation();
    const notice=document.getElementById('vidNotice');
    if(notice){
      notice.style.color='#ff7373';
      notice.textContent='Le kilométrage actuel ne peut pas être inférieur à un kilométrage d’entretien déjà enregistré.';
    }
  }
},true);

saveDriverButton?.addEventListener('click',event=>{
  const license=String(driverLicenseNumber?.value||'').trim().toUpperCase();
  if(!license) return;
  const selected=getSelectedDriver();
  const duplicate=driverProfiles.find(d=>d.id!==selected?.id && String(d.licenseNumber||'').trim().toUpperCase()===license);
  if(duplicate){
    event.preventDefault();
    event.stopImmediatePropagation();
    driverSaveNotice.style.color='#ff7373';
    driverSaveNotice.textContent=`Ce n° de permis est déjà utilisé par ${driverDisplayName(duplicate)}.`;
  }
},true);

addDriverForm?.addEventListener('submit',event=>{
  const license=String(newDriverLicenseNumber?.value||'').trim().toUpperCase();
  if(!license) return;
  const duplicate=driverProfiles.find(d=>String(d.licenseNumber||'').trim().toUpperCase()===license);
  if(duplicate){
    event.preventDefault();
    event.stopImmediatePropagation();
    addDriverError.textContent=`Ce n° de permis est déjà utilisé par ${driverDisplayName(duplicate)}.`;
  }
},true);

fuelForm?.addEventListener('submit',event=>{
  const ids=['fuelDieselPrice','fuelGnrPrice','fuelAdbluePrice'];
  for(const id of ids){
    const value=document.getElementById(id)?.value?.trim();
    if(!value) continue;
    const n=Number(value.replace(',','.'));
    if(!Number.isFinite(n)||n<0){
      event.preventDefault();
      event.stopImmediatePropagation();
      fuelError.textContent='Les prix carburant doivent être des nombres positifs.';
      return;
    }
  }
},true);

fineForm?.addEventListener('submit',event=>{
  const input=document.getElementById('fineAmount');
  if(!input?.value?.trim()) return;
  const n=Number(input.value.replace(',','.'));
  if(!Number.isFinite(n)||n<0){
    event.preventDefault();
    event.stopImmediatePropagation();
    fineError.textContent='Le montant doit être un nombre positif.';
  }
},true);

/* ---------- Qualité Admin ---------- */
const qualityScore=document.getElementById('qualityScore');
const qualityTitle=document.getElementById('qualityTitle');
const qualitySubtitle=document.getElementById('qualitySubtitle');
const qualityList=document.getElementById('qualityList');
document.getElementById('qualityRefresh')?.addEventListener('click',dashboardRenderQuality);

function dashboardRenderQuality(){
  if(!qualityScore) return;
  const issues=dashboardDataIssues();
  const high=issues.filter(x=>x.level==='high').length;
  const warn=issues.length-high;
  const score=Math.max(0,100-high*8-warn*3);

  qualityScore.textContent=score;
  qualityScore.className='quality-score '+(score>=90?'good':score>=70?'warn':'bad');

  if(!issues.length){
    qualityTitle.textContent='Données cohérentes';
    qualitySubtitle.textContent='Aucune anomalie détectée.';
    qualityList.innerHTML='<div class="vehicle-none">Aucune anomalie détectée.</div>';
    return;
  }

  qualityTitle.textContent=`${issues.length} anomalie${issues.length>1?'s':''} détectée${issues.length>1?'s':''}`;
  qualitySubtitle.textContent=`${high} critique${high>1?'s':''} · ${warn} à vérifier`;
  qualityList.innerHTML=issues.slice(0,30).map(issue=>
    `<div class="quality-item"><strong>${dashboardEsc(issue.section)}</strong> · ${dashboardEsc(issue.text)}</div>`
  ).join('');
}

/* ---------- Notifications ---------- */
const notificationBell=document.getElementById('notificationBell');
const notificationBadge=document.getElementById('notificationBadge');
const notificationPanel=document.getElementById('notificationPanel');
const notificationList=document.getElementById('notificationList');
const notificationClose=document.getElementById('notificationClose');
const notificationSubtitle=document.getElementById('notificationSubtitle');
const notificationQuickVehicles=document.getElementById('notificationQuickVehicles');

const DASHBOARD_RECENTS_KEY='hessers-recent-vehicles-v1';
const DASHBOARD_FAVORITES_KEY='hessers-favorite-vehicles-v1';

function dashboardReadLocalList(key){
  try{
    const value=JSON.parse(localStorage.getItem(key));
    return Array.isArray(value)?value:[];
  }catch(error){return []}
}
function dashboardWriteLocalList(key,value){
  localStorage.setItem(key,JSON.stringify(value));
}
function dashboardRecentVehicles(){
  return dashboardReadLocalList(DASHBOARD_RECENTS_KEY);
}
function dashboardFavoriteVehicles(){
  return dashboardReadLocalList(DASHBOARD_FAVORITES_KEY);
}
function dashboardRememberVehicle(registration){
  const plate=formatRegistration(registration);
  let recents=dashboardRecentVehicles().filter(x=>normalizeRegistration(x)!==normalizeRegistration(plate));
  recents.unshift(plate);
  recents=recents.slice(0,6);
  dashboardWriteLocalList(DASHBOARD_RECENTS_KEY,recents);
  dashboardRenderQuickVehicles();
}
function dashboardToggleFavorite(registration){
  const plate=formatRegistration(registration);
  let favs=dashboardFavoriteVehicles();
  const exists=favs.some(x=>normalizeRegistration(x)===normalizeRegistration(plate));
  if(exists) favs=favs.filter(x=>normalizeRegistration(x)!==normalizeRegistration(plate));
  else favs.unshift(plate);
  dashboardWriteLocalList(DASHBOARD_FAVORITES_KEY,favs.slice(0,10));
  dashboardRenderQuickVehicles();
  return !exists;
}
function dashboardBuildNotifications(){
  const items=[];

  const late=[...vidangeData]
    .map(v=>({v,remaining:calculateNextOil(v)}))
    .filter(x=>x.remaining<=0)
    .sort((a,b)=>a.remaining-b.remaining);

  late.slice(0,5).forEach(({v,remaining})=>{
    items.push({
      level:'high',icon:'!',title:`Vidange à faire · ${formatRegistration(v.registration)}`,
      text:`Échéance dépassée de ${Math.abs(Math.round(remaining)).toLocaleString('fr-FR')} km.`,
      view:'suivi-technique',searchId:'vidSearch',searchValue:formatRegistration(v.registration)
    });
  });
  if(late.length>5){
    items.push({level:'high',icon:'!',title:`${late.length-5} autres vidanges dépassées`,text:'Ouvrir le suivi technique.',view:'suivi-technique'});
  }

  const soon=vidangeData.filter(v=>{
    const remaining=calculateNextOil(v);
    return remaining>0 && remaining<=5000;
  }).length;
  if(soon){
    items.push({level:'warn',icon:'~',title:`${soon} vidange${soon>1?'s':''} à prévoir`,text:'Échéance dans moins de 5 000 km.',view:'suivi-technique'});
  }

  const assigned=new Set();
  affectations.forEach(a=>{
    if(a.tractor) assigned.add(normalizeRegistration(a.tractor));
    if(a.semi) assigned.add(normalizeRegistration(a.semi));
  });
  const unassigned=parkData.filter(v=>!assigned.has(normalizeRegistration(v.registration))).length;
  if(unassigned){
    items.push({level:'info',icon:'i',title:`${unassigned} véhicule${unassigned>1?'s':''} non affecté${unassigned>1?'s':''}`,text:'Consulter le Parc.',view:'parc'});
  }

  const fines=adminFines.filter(f=>f.status==='À traiter').length;
  if(fines){
    items.push({level:'warn',icon:'€',title:`${fines} amende${fines>1?'s':''} à traiter`,text:'Gestion administrative.',view:'gestion-administrative',adminTab:'fines'});
  }

  const staleClaims=claimData.filter(c=>{
    if(c.status==='Clos'||!c.date) return false;
    const d=new Date(c.date+'T00:00:00');
    return Number.isFinite(d.getTime()) && Date.now()-d.getTime()>14*24*60*60*1000;
  }).length;
  if(staleClaims){
    items.push({level:'warn',icon:'⚠',title:`${staleClaims} sinistre${staleClaims>1?'s':''} ouvert${staleClaims>1?'s':''} depuis +14 jours`,text:'Vérifier leur avancement.',view:'sinistre'});
  }

  const issues=dashboardDataIssues();
  if(issues.length){
    items.push({
      level:issues.some(x=>x.level==='high')?'high':'warn',
      icon:'!',title:`${issues.length} anomalie${issues.length>1?'s':''} de données`,
      text:administratorIsAdmin()?'Voir le contrôle qualité dans Administrateur.':'Certaines données nécessitent une vérification.',
      view:administratorIsAdmin()?'administrateur':'parc',
      requiresAdmin:administratorIsAdmin()
    });
  }

  return items;
}
async function dashboardOpenNotification(item){
  notificationPanel.hidden=true;

  if(item.requiresAdmin && typeof adminSecurityRequestAccess==='function'){
    const allowed=await adminSecurityRequestAccess();
    if(!allowed) return;
  }

  const nav=[...navButtons].find(b=>b.dataset.view===item.view);
  if(nav){
    showView(item.view,item.view==='accueil'?'Gestion de Parc':nav.innerText.trim(),item.view);
  }

  if(item.adminTab && typeof switchAdminTab==='function') switchAdminTab(item.adminTab);
  if(item.view==='suivi-technique' && item.searchId==='vidSearch' && typeof window.technicalOpenPage==='function') window.technicalOpenPage('vidange');
  if(item.searchId && item.searchValue){
    const input=document.getElementById(item.searchId);
    if(input){
      input.value=item.searchValue;
      input.dispatchEvent(new Event('input',{bubbles:true}));
    }
  }
}
function dashboardRenderQuickVehicles(){
  if(!notificationQuickVehicles) return;
  const favs=dashboardFavoriteVehicles();
  const recents=dashboardRecentVehicles().filter(r=>!favs.some(f=>normalizeRegistration(f)===normalizeRegistration(r)));
  const chips=[
    ...favs.map(reg=>({reg,label:'★ '+reg})),
    ...recents.slice(0,5).map(reg=>({reg,label:reg}))
  ];
  notificationQuickVehicles.innerHTML=chips.length
    ? chips.map(x=>`<button class="notification-chip" type="button" data-quick-vehicle="${dashboardEsc(x.reg)}">${dashboardEsc(x.label)}</button>`).join('')
    : '<span class="vehicle-none">Aucun véhicule consulté.</span>';
}
function dashboardRefreshNotifications(){
  if(!notificationList) return;
  const items=dashboardBuildNotifications();
  const levelOrder={high:0,warn:1,info:2};
  const viewOrder={'suivi-technique':0,'gestion-administrative':1,'sinistre':2,'parc':3,'affectations':4,'chauffeur':5,'administrateur':6};
  const sortedItems=items
    .map((item,index)=>({...item,_originalIndex:index}))
    .sort((a,b)=>{
      const levelDiff=(levelOrder[a.level]??9)-(levelOrder[b.level]??9);
      if(levelDiff!==0) return levelDiff;
      const viewDiff=(viewOrder[a.view]??9)-(viewOrder[b.view]??9);
      if(viewDiff!==0) return viewDiff;
      const aDetail=a.searchValue?0:1;
      const bDetail=b.searchValue?0:1;
      if(aDetail!==bDetail) return aDetail-bDetail;
      return String(a.title).localeCompare(String(b.title),'fr',{numeric:true,sensitivity:'base'});
    });

  notificationBadge.textContent=sortedItems.length>99?'99+':sortedItems.length;
  notificationBadge.hidden=!sortedItems.length;
  notificationSubtitle.textContent=sortedItems.length
    ? `${sortedItems.length} élément${sortedItems.length>1?'s':''} à surveiller`
    : 'Aucun élément urgent';

  if(sortedItems.length){
    let currentLevel='';
    notificationList.innerHTML=sortedItems.map((item,index)=>{
      const label=item.level==='high'?'URGENT':item.level==='warn'?'À VOIR':'INFO';
      const section=currentLevel!==label ? `<div class="notification-section-label">${label}</div>` : '';
      currentLevel=label;
      return `${section}
        <button class="notification-item ${item.level==='warn'?'warn':item.level==='info'?'info':''}" type="button" data-notification-index="${index}">
          <span class="notification-icon">${dashboardEsc(item.icon)}</span>
          <span><span class="notification-item-title">${dashboardEsc(item.title)}</span><span class="notification-item-text">${dashboardEsc(item.text)}</span></span>
          <span class="notification-priority">${label}</span>
        </button>`;
    }).join('');
  }else{
    notificationList.innerHTML='<div class="notification-empty">Tout est calme pour le moment.</div>';
  }

  notificationList._dashboardItems=sortedItems;
  dashboardRenderQuickVehicles();
  dashboardRenderQuality();
}
notificationBell?.addEventListener('click',event=>{
  event.stopPropagation();
  dashboardRefreshNotifications();
  notificationPanel.hidden=!notificationPanel.hidden;
});
notificationClose?.addEventListener('click',()=>notificationPanel.hidden=true);
notificationList?.addEventListener('click',event=>{
  const row=event.target.closest('[data-notification-index]');
  if(!row) return;
  const item=notificationList._dashboardItems?.[Number(row.dataset.notificationIndex)];
  if(item) dashboardOpenNotification(item);
});
notificationQuickVehicles?.addEventListener('click',event=>{
  const btn=event.target.closest('[data-quick-vehicle]');
  if(btn) dashboardOpenVehicleDossier(btn.dataset.quickVehicle);
});
document.addEventListener('click',event=>{
  if(!notificationPanel?.hidden && !notificationPanel.contains(event.target) && !notificationBell.contains(event.target)){
    notificationPanel.hidden=true;
  }
});

/* ---------- Fiche véhicule ---------- */
const vehicleDossierModal=document.getElementById('vehicleDossierModal');
const vehicleDossierBody=document.getElementById('vehicleDossierBody');
const vehicleDossierTitle=document.getElementById('vehicleDossierTitle');
const vehicleDossierClose=document.getElementById('vehicleDossierClose');
let dashboardCurrentVehicleDossier='';

function dashboardFindVehicleLinks(registration){
  const reg=normalizeRegistration(registration);
  const vehicle=parkData.find(v=>normalizeRegistration(v.registration)===reg)||null;
  const assignment=affectations.find(a=>
    normalizeRegistration(a.tractor)===reg || normalizeRegistration(a.semi)===reg
  )||null;
  const driver=assignment
    ? driverProfiles.find(d=>normalizeAffText(`${d.lastName} ${d.firstName}`)===normalizeAffText(assignment.name))||null
    : null;
  const maintenance=vidangeData.find(v=>normalizeRegistration(v.registration)===reg)||null;
  const claims=claimData.filter(c=>normalizeRegistration(c.vehicle)===reg);
  const fines=adminFines.filter(f=>normalizeRegistration(f.vehicle)===reg);
  const rungis=adminRungis.filter(r=>normalizeRegistration(r.vehicle)===reg);
  return {vehicle,assignment,driver,maintenance,claims,fines,rungis};
}
function dashboardVehicleLinkedItems(items,renderer){
  if(!items.length) return '<div class="vehicle-none">Aucun élément lié.</div>';
  return `<div class="vehicle-linked-list">${items.slice(0,6).map(renderer).join('')}</div>`;
}
function dashboardOpenVehicleDossier(registration){
  const links=dashboardFindVehicleLinks(registration);
  if(!links.vehicle){
    dashboardToast('Véhicule introuvable',formatRegistration(registration),'warn');
    return;
  }

  const {vehicle,assignment,driver,maintenance,claims,fines,rungis}=links;
  const plate=formatRegistration(vehicle.registration);
  dashboardCurrentVehicleDossier=plate;
  dashboardRememberVehicle(plate);

  const counterpart=assignment
    ? (vehicle.type==='Tracteur'?assignment.semi:assignment.tractor)
    : '';
  const remaining=maintenance?calculateNextOil(maintenance):null;
  const favorite=dashboardFavoriteVehicles().some(x=>normalizeRegistration(x)===normalizeRegistration(plate));

  vehicleDossierTitle.textContent=`Fiche véhicule · ${plate}`;
  vehicleDossierBody.innerHTML=`
    <div class="vehicle-dossier-top">
      <div>
        <div class="vehicle-dossier-plate">${dashboardEsc(plate)}</div>
        <div class="vehicle-dossier-meta">${dashboardEsc(vehicle.type)}${vehicle.parkNumber?' · Parc '+dashboardEsc(vehicle.parkNumber):''}</div>
      </div>
      <button class="vehicle-favorite-btn ${favorite?'active':''}" id="vehicleFavoriteButton" type="button">${favorite?'★ Favori':'☆ Ajouter aux favoris'}</button>
    </div>

    <div class="vehicle-summary-grid">
      <div class="vehicle-summary-cell"><div class="vehicle-summary-label">AFFECTATION</div><div class="vehicle-summary-value">${assignment?'Affecté':'Non affecté'}</div></div>
      <div class="vehicle-summary-cell"><div class="vehicle-summary-label">CHAUFFEUR</div><div class="vehicle-summary-value">${dashboardEsc(assignment?.name||'—')}</div></div>
      <div class="vehicle-summary-cell"><div class="vehicle-summary-label">PROCHAINE VIDANGE</div><div class="vehicle-summary-value">${remaining===null?'—':remaining<=0?`${Math.abs(Math.round(remaining)).toLocaleString('fr-FR')} km dépassés`:`${Math.round(remaining).toLocaleString('fr-FR')} km`}</div></div>
      <div class="vehicle-summary-cell"><div class="vehicle-summary-label">SINISTRES</div><div class="vehicle-summary-value">${claims.length}</div></div>
    </div>

    <div class="vehicle-dossier-grid">
      <div class="vehicle-section">
        <div class="vehicle-section-head">AFFECTATION & CHAUFFEUR</div>
        <div class="vehicle-section-content">
          <div class="vehicle-line"><span class="vehicle-line-label">Chauffeur</span><span class="vehicle-line-value">${dashboardEsc(assignment?.name||'—')}</span></div>
          <div class="vehicle-line"><span class="vehicle-line-label">${vehicle.type==='Tracteur'?'Semi':'Tracteur'} associé${vehicle.type==='Tracteur'?'e':''}</span><span class="vehicle-line-value">${dashboardEsc(counterpart?formatRegistration(counterpart):'—')}</span></div>
          <div class="vehicle-line"><span class="vehicle-line-label">Téléphone pro</span><span class="vehicle-line-value">${dashboardEsc(assignment?.phone||'—')}</span></div>
          <div class="vehicle-line"><span class="vehicle-line-label">N° personnel</span><span class="vehicle-line-value">${dashboardEsc(assignment?.personal||'—')}</span></div>
          <div class="vehicle-line"><span class="vehicle-line-label">Permis</span><span class="vehicle-line-value">${dashboardEsc(driver?.licenseNumber||'—')}</span></div>
          <div class="vehicle-line"><span class="vehicle-line-label">Délivré le</span><span class="vehicle-line-value">${dashboardEsc(driver?.licenseIssueDate||'—')}</span></div>
        </div>
      </div>

      <div class="vehicle-section">
        <div class="vehicle-section-head">SUIVI TECHNIQUE</div>
        <div class="vehicle-section-content">
          <div class="vehicle-line"><span class="vehicle-line-label">Km actuel</span><span class="vehicle-line-value">${maintenance?.currentKm!=null?Number(maintenance.currentKm).toLocaleString('fr-FR')+' km':'—'}</span></div>
          <div class="vehicle-line"><span class="vehicle-line-label">Dernière grosse vidange</span><span class="vehicle-line-value">${maintenance?.lastMajorKm!=null?Number(maintenance.lastMajorKm).toLocaleString('fr-FR')+' km':'—'}</span></div>
          <div class="vehicle-line"><span class="vehicle-line-label">Dernier passage garage</span><span class="vehicle-line-value">${maintenance?.lastGarageKm!=null?Number(maintenance.lastGarageKm).toLocaleString('fr-FR')+' km':'—'}</span></div>
          <div class="vehicle-line"><span class="vehicle-line-label">État vidange</span><span class="vehicle-line-value">${remaining===null?'Non suivi':remaining<=0?'À faire':remaining<=5000?'À prévoir':'À jour'}</span></div>
        </div>
      </div>

      <div class="vehicle-section">
        <div class="vehicle-section-head">SINISTRES</div>
        <div class="vehicle-section-content">
          ${dashboardVehicleLinkedItems(claims,c=>`<div class="vehicle-linked-item"><strong>${dashboardEsc(c.number||'Sans n° dossier')}</strong> · ${dashboardEsc(c.status||'—')}<br>${dashboardEsc(c.date||'—')} · ${dashboardEsc(c.type||'Sinistre')}</div>`)}
        </div>
      </div>

      <div class="vehicle-section">
        <div class="vehicle-section-head">AMENDES & CARTE RUNGIS</div>
        <div class="vehicle-section-content">
          ${dashboardVehicleLinkedItems(fines,f=>`<div class="vehicle-linked-item"><strong>${dashboardEsc(f.reference||'Amende')}</strong> · ${dashboardEsc(f.status||'—')}${Number(f.attachmentCount||0)>0?` · 📎 ${Number(f.attachmentCount||0)}`:''}<br>${dashboardEsc(f.date||'—')} · ${dashboardEsc(f.offense||'—')}</div>`)}
          <div style="height:8px"></div>
          ${dashboardVehicleLinkedItems(rungis,r=>`<div class="vehicle-linked-item"><strong>Carte Rungis ${dashboardEsc(r.cardNumber||'—')}</strong></div>`)}
        </div>
      </div>

      <div class="vehicle-section full">
        <div class="vehicle-section-head">TRAÇABILITÉ</div>
        <div class="vehicle-section-content">
          <div class="vehicle-line"><span class="vehicle-line-label">Créé par</span><span class="vehicle-line-value">${dashboardEsc(vehicle._createdBy||'Donnée initiale')}</span></div>
          <div class="vehicle-line"><span class="vehicle-line-label">Création</span><span class="vehicle-line-value">${dashboardEsc(dashboardDateTime(vehicle._createdAt))}</span></div>
          <div class="vehicle-line"><span class="vehicle-line-label">Dernière modification</span><span class="vehicle-line-value">${dashboardEsc(vehicle._modifiedBy||'—')} · ${dashboardEsc(dashboardDateTime(vehicle._modifiedAt))}</span></div>
        </div>
      </div>
    </div>

    <div class="vehicle-dossier-actions">
      <button class="tool-btn" type="button" data-vehicle-go="parc">Ouvrir dans Parc</button>
      <button class="tool-btn" type="button" data-vehicle-go="affectations">Ouvrir Affectations</button>
      ${maintenance?'<button class="tool-btn" type="button" data-vehicle-go="suivi-technique">Ouvrir Suivi technique</button>':''}
      ${claims.length?'<button class="tool-btn" type="button" data-vehicle-go="sinistre">Voir les sinistres</button>':''}
    </div>
  `;

  document.getElementById('vehicleFavoriteButton')?.addEventListener('click',event=>{
    const active=dashboardToggleFavorite(plate);
    event.currentTarget.classList.toggle('active',active);
    event.currentTarget.textContent=active?'★ Favori':'☆ Ajouter aux favoris';
  });

  vehicleDossierModal.hidden=false;
  document.body.classList.add('modal-open');
}
function dashboardCloseVehicleDossier(){
  vehicleDossierModal.hidden=true;
  dashboardCurrentVehicleDossier='';
  if(document.querySelectorAll('.modal-overlay:not([hidden])').length===0) document.body.classList.remove('modal-open');
}
vehicleDossierClose?.addEventListener('click',dashboardCloseVehicleDossier);
vehicleDossierModal?.addEventListener('click',event=>{
  if(event.target===vehicleDossierModal) dashboardCloseVehicleDossier();
});
vehicleDossierBody?.addEventListener('click',event=>{
  const go=event.target.closest('[data-vehicle-go]');
  if(!go) return;
  const view=go.dataset.vehicleGo;
  const plate=dashboardCurrentVehicleDossier;
  dashboardCloseVehicleDossier();
  const nav=[...navButtons].find(b=>b.dataset.view===view);
  if(nav) showView(view,nav.innerText.trim(),view);
  if(view==='suivi-technique'&&plate){
    vidSearch.value=plate;renderVidTable();
  }
  if(view==='sinistre'&&plate){
    claimSearch.value=plate;renderClaims();
  }
});
parkTable?.addEventListener('click',event=>{
  const cell=event.target.closest('[data-open-vehicle]');
  if(cell && !event.target.closest('.row-menu')) dashboardOpenVehicleDossier(cell.dataset.openVehicle);
});
affTable?.addEventListener('click',event=>{
  const cell=event.target.closest('[data-open-vehicle]');
  if(cell && !event.target.closest('.row-menu')) dashboardOpenVehicleDossier(cell.dataset.openVehicle);
});

/* ---------- Conflits multi-utilisateurs ---------- */
const sharedConflictModal=document.getElementById('sharedConflictModal');
const sharedConflictItems=document.getElementById('sharedConflictItems');
const sharedConflictBanner=document.getElementById('sharedConflictBanner');
let sharedConflictResolver=null;

function dashboardCompareRecord(a,b){
  return JSON.stringify(a??null)===JSON.stringify(b??null);
}
function dashboardDetectSharedConflict(descriptor,previous,next,remote){
  if(!remote) return null;

  if(descriptor.kind==='object'){
    const keys=new Set([
      ...Object.keys(previous||{}),
      ...Object.keys(next||{}),
      ...Object.keys(remote||{})
    ]);
    const conflicts=[];
    for(const key of keys){
      if(key.startsWith('_')) continue;
      const localChanged=!dashboardCompareRecord(previous?.[key],next?.[key]);
      const remoteChanged=!dashboardCompareRecord(previous?.[key],remote?.[key]);
      if(localChanged && remoteChanged && !dashboardCompareRecord(next?.[key],remote?.[key])){
        conflicts.push(key);
      }
    }
    if(!conflicts.length) return null;
    const labels=dashboardDatasetFieldLabels(descriptor);
    return {ids:conflicts,labels:conflicts.map(k=>labels[k]||k),items:[]};
  }

  const p=sharedRecordMap(descriptor,Array.isArray(previous)?previous:[]);
  const n=sharedRecordMap(descriptor,Array.isArray(next)?next:[]);
  const r=sharedRecordMap(descriptor,Array.isArray(remote)?remote:[]);
  const ids=new Set([...p.keys(),...n.keys(),...r.keys()]);
  const conflicts=[];

  for(const id of ids){
    const pv=p.get(id);
    const nv=n.get(id);
    const rv=r.get(id);
    const localChanged=!dashboardCompareRecord(pv,nv);
    const remoteChanged=!dashboardCompareRecord(pv,rv);
    if(localChanged && remoteChanged && !dashboardCompareRecord(nv,rv)){
      conflicts.push({id,local:nv,remote:rv,before:pv});
    }
  }

  if(!conflicts.length) return null;
  return {
    ids:conflicts.map(x=>x.id),
    labels:conflicts.map(x=>administratorEntityLabel(descriptor,x.local||x.remote||x.before)||x.id),
    items:conflicts
  };
}
function dashboardAskSharedConflict(descriptor,conflict,remoteDoc){
  const remoteUser=conflict.items
    .map(x=>x.remote?._modifiedBy)
    .filter(Boolean)[0] || remoteDoc?.updatedBy || 'un autre utilisateur';

  sharedConflictBanner.innerHTML=
    `La même donnée a été modifiée par <b>${dashboardEsc(remoteUser)}</b> pendant votre saisie.`;

  sharedConflictItems.innerHTML=conflict.labels.map((label,index)=>{
    const item=conflict.items[index];
    const changes=item
      ? dashboardDescribeObjectChanges(item.before||{},item.remote||{},descriptor).join(' · ')
      : 'Modification distante détectée';
    return `<div class="conflict-item"><strong>${dashboardEsc(label)}</strong><br>${dashboardEsc(changes||'Modification distante détectée')}</div>`;
  }).join('');

  sharedConflictModal.hidden=false;
  document.body.classList.add('modal-open');

  return new Promise(resolve=>{sharedConflictResolver=resolve});
}
function dashboardResolveConflictChoice(keep){
  sharedConflictModal.hidden=true;
  if(document.querySelectorAll('.modal-overlay:not([hidden])').length===0) document.body.classList.remove('modal-open');
  if(sharedConflictResolver){
    const resolve=sharedConflictResolver;
    sharedConflictResolver=null;
    resolve(keep);
  }
}
document.getElementById('sharedConflictReload')?.addEventListener('click',()=>dashboardResolveConflictChoice(false));
document.getElementById('sharedConflictKeep')?.addEventListener('click',()=>dashboardResolveConflictChoice(true));

/* ---------- Sauvegardes / restauration ---------- */
const DASHBOARD_BACKUP_FOLDER='sauvegardes';
let dashboardBackupInProgress=false;
let dashboardBackupReadyForDay='';

async function dashboardGetBackupRoot(create=false){
  if(!sharedConnected||!sharedDirectoryHandle) return null;
  return await sharedDirectoryHandle.getDirectoryHandle(DASHBOARD_BACKUP_FOLDER,{create});
}
async function dashboardFileExists(dir,name){
  try{
    await dir.getFileHandle(name);
    return true;
  }catch(error){
    if(error?.name==='NotFoundError') return false;
    throw error;
  }
}
async function dashboardWriteRawJson(dir,name,payload){
  const handle=await dir.getFileHandle(name,{create:true});
  const writable=await handle.createWritable();
  await writable.write(JSON.stringify(payload,null,2));
  await writable.close();
}
async function dashboardReadRawJson(dir,name){
  const handle=await dir.getFileHandle(name);
  const file=await handle.getFile();
  return JSON.parse(await file.text());
}
function dashboardBackupTimestampName(prefix='manuel'){
  const d=new Date();
  const pad=n=>String(n).padStart(2,'0');
  return `${prefix}_${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}_${pad(d.getHours())}-${pad(d.getMinutes())}-${pad(d.getSeconds())}`;
}
async function dashboardCreateBackup(name,reason='Sauvegarde manuelle'){
  if(!sharedConnected||!sharedDirectoryHandle) throw new Error('Groupdrive non connecté.');
  if(dashboardBackupInProgress) return false;

  dashboardBackupInProgress=true;
  try{
    const root=await dashboardGetBackupRoot(true);
    const dir=await root.getDirectoryHandle(name,{create:true});
    let files=0;

    for(const descriptor of SHARED_DATASETS){
      const doc=await sharedReadDocument(descriptor);
      if(!doc) continue;
      const clean={...doc};
      delete clean._lastModified;
      await dashboardWriteRawJson(dir,descriptor.file,clean);
      files++;
    }

    const security=await adminSecurityReadConfig().catch(()=>null);
    if(security){
      await dashboardWriteRawJson(dir,ADMIN_SECURITY_FILE,security);
    }

    await dashboardWriteRawJson(dir,'manifest.json',{
      version:1,
      createdAt:new Date().toISOString(),
      createdBy:dashboardUser||'inconnu',
      reason,
      files
    });

    administratorWriteHistory({
      action:'Sauvegarde',
      section:'Administrateur',
      entity:name,
      detail:`${files} fichiers de données sauvegardés`
    });

    return true;
  }finally{
    dashboardBackupInProgress=false;
  }
}
async function dashboardEnsureDailyBackup(){
  if(!sharedConnected||!sharedDirectoryHandle) return;
  const day=administratorLocalDateKey(new Date());
  if(dashboardBackupReadyForDay===day) return;

  const root=await dashboardGetBackupRoot(true);
  const dir=await root.getDirectoryHandle(day,{create:true});
  const exists=await dashboardFileExists(dir,'manifest.json');
  if(!exists){
    await dashboardCreateBackup(day,'Sauvegarde automatique quotidienne');
  }
  dashboardBackupReadyForDay=day;
  dashboardRefreshBackupList();
}
async function dashboardListBackups(){
  if(!sharedConnected||!sharedDirectoryHandle) return [];
  let root;
  try{
    root=await dashboardGetBackupRoot(false);
  }catch(error){
    if(error?.name==='NotFoundError') return [];
    throw error;
  }
  const result=[];
  for await(const [name,handle] of root.entries()){
    if(handle.kind!=='directory') continue;
    try{
      const manifest=await dashboardReadRawJson(handle,'manifest.json');
      result.push({name,manifest});
    }catch(error){}
  }
  return result.sort((a,b)=>String(b.manifest?.createdAt||b.name).localeCompare(String(a.manifest?.createdAt||a.name)));
}
async function dashboardRefreshBackupList(){
  const list=document.getElementById('backupList');
  const count=document.getElementById('backupCount');
  if(!list||!count) return;

  if(!sharedConnected){
    count.textContent='0';
    list.innerHTML='<div class="vehicle-none">Groupdrive non connecté.</div>';
    return;
  }

  try{
    const backups=await dashboardListBackups();
    count.textContent=backups.length;
    list.innerHTML=backups.length
      ? backups.slice(0,14).map(b=>`
          <div class="backup-row">
            <div>
              <div class="backup-name">${dashboardEsc(b.name)}</div>
              <div class="backup-meta">${dashboardEsc(dashboardDateTime(b.manifest?.createdAt))} · ${dashboardEsc(b.manifest?.createdBy||'—')} · ${dashboardEsc(b.manifest?.reason||'Sauvegarde')}</div>
            </div>
            <button type="button" data-restore-backup="${dashboardEsc(b.name)}">Restaurer</button>
          </div>
        `).join('')
      : '<div class="vehicle-none">Aucune sauvegarde détectée.</div>';
  }catch(error){
    list.innerHTML=`<div class="vehicle-none">Impossible de lire les sauvegardes : ${dashboardEsc(error)}</div>`;
  }
}
async function dashboardRestoreBackup(name){
  if(!administratorIsAdmin()) return;
  if(typeof adminSecurityIsUnlocked==='function' && !adminSecurityIsUnlocked()){
    const allowed=await adminSecurityRequestAccess();
    if(!allowed) return;
  }
  if(!confirm(`Restaurer la sauvegarde "${name}" ?\n\nLes données actuelles seront remplacées. Une sauvegarde de sécurité sera créée avant la restauration.`)) return;

  try{
    dashboardToast('Restauration','Création d’une sauvegarde de sécurité…','warn',3500);
    await dashboardCreateBackup(dashboardBackupTimestampName('avant-restauration'),'Sauvegarde avant restauration');

    const root=await dashboardGetBackupRoot(false);
    const dir=await root.getDirectoryHandle(name);

    for(const descriptor of SHARED_DATASETS){
      try{
        const doc=await dashboardReadRawJson(dir,descriptor.file);
        const handle=await sharedDirectoryHandle.getFileHandle(descriptor.file,{create:true});
        const writable=await handle.createWritable();
        await writable.write(JSON.stringify(doc,null,2));
        await writable.close();
      }catch(error){
        if(error?.name!=='NotFoundError') throw error;
      }
    }

    administratorWriteHistory({
      action:'Restauration',
      section:'Administrateur',
      entity:name,
      detail:'Sauvegarde restaurée'
    });

    await sharedSyncFromDisk(true);
    dashboardRefreshNotifications();
    dashboardRenderQuality();
    dashboardToast('Restauration terminée',`Sauvegarde ${name} restaurée.`,'success',3500);
  }catch(error){
    dashboardToast('Échec de restauration',String(error),'error',5000);
  }
}
document.getElementById('backupNow')?.addEventListener('click',async event=>{
  event.currentTarget.disabled=true;
  try{
    const name=dashboardBackupTimestampName('manuel');
    await dashboardCreateBackup(name,'Sauvegarde manuelle');
    dashboardToast('Sauvegarde créée',name,'success');
    await dashboardRefreshBackupList();
  }catch(error){
    dashboardToast('Sauvegarde impossible',String(error),'error',4500);
  }finally{
    event.currentTarget.disabled=false;
  }
});
document.getElementById('backupRefresh')?.addEventListener('click',dashboardRefreshBackupList);
document.getElementById('backupList')?.addEventListener('click',event=>{
  const button=event.target.closest('[data-restore-backup]');
  if(button) dashboardRestoreBackup(button.dataset.restoreBackup);
});

/* ---------- Admin refresh enrichi ---------- */
const dashboardOriginalAdminRefresh=administratorRefreshDashboard;
administratorRefreshDashboard=async function(){
  await dashboardOriginalAdminRefresh();
  dashboardRenderQuality();
  await dashboardRefreshBackupList();
  if(typeof dashboardRefreshUpdateUi==='function'){
    await dashboardRefreshUpdateUi();
  }
};

/* ---------- Raccourcis ---------- */
const shortcutHelp=document.getElementById('shortcutHelp');
let shortcutHelpTimer=null;
function dashboardFlashShortcutHelp(){
  if(!shortcutHelp) return;
  shortcutHelp.classList.add('show');
  clearTimeout(shortcutHelpTimer);
  shortcutHelpTimer=setTimeout(()=>shortcutHelp.classList.remove('show'),2200);
}
document.addEventListener('keydown',event=>{
  const tag=document.activeElement?.tagName?.toLowerCase();
  const typing=['input','textarea','select'].includes(tag);

  if((event.ctrlKey||event.metaKey) && event.key.toLowerCase()==='k'){
    event.preventDefault();
    globalSearch.focus();
    globalSearch.select();
    dashboardFlashShortcutHelp();
    return;
  }

  if(event.key==='Escape'){
    notificationPanel.hidden=true;
    if(!vehicleDossierModal.hidden) dashboardCloseVehicleDossier();
  }

  if(!typing && event.altKey && event.key.toLowerCase()==='p'){
    event.preventDefault();
    showView('parc','Parc','parc');
    dashboardFlashShortcutHelp();
  }
  if(!typing && event.altKey && event.key.toLowerCase()==='a'){
    event.preventDefault();
    showView('affectations','Affectations','affectations');
    dashboardFlashShortcutHelp();
  }
  if(!typing && event.key==='?'){
    dashboardFlashShortcutHelp();
  }
});

/* ---------- Final refresh ---------- */
setTimeout(()=>{
  dashboardRefreshNotifications();
  dashboardRenderQuality();
  dashboardRefreshBackupList();
},700);



/* ===== MENU LATÉRAL RÉDUCTIBLE ===== */
const SIDEBAR_COLLAPSED_KEY='hessers-sidebar-collapsed-v1';
const appShell=document.querySelector('.app');
const sidebarCollapseButton=document.getElementById('sidebarCollapseButton');
const sidebarCollapseLabel=document.getElementById('sidebarCollapseLabel');
const sidebarHamburger=document.getElementById('sidebarHamburger');

function dashboardSetSidebarCollapsed(collapsed,save=true){
  const state=Boolean(collapsed);
  appShell?.classList.toggle('sidebar-collapsed',state);

  if(sidebarCollapseButton){
    sidebarCollapseButton.title=state?'Agrandir le menu':'Réduire le menu';
    sidebarCollapseButton.setAttribute('aria-label',state?'Agrandir le menu':'Réduire le menu');
  }
  if(sidebarCollapseLabel){
    sidebarCollapseLabel.textContent=state?'Agrandir le menu':'Réduire le menu';
  }

  if(save){
    localStorage.setItem(SIDEBAR_COLLAPSED_KEY,state?'1':'0');
  }

  // Le changement de largeur peut modifier les dimensions des graphiques.
  if(typeof renderFuelCharts==='function'){
    requestAnimationFrame(()=>{
      requestAnimationFrame(renderFuelCharts);
    });
  }
}

function dashboardToggleSidebar(){
  dashboardSetSidebarCollapsed(!appShell?.classList.contains('sidebar-collapsed'));
}

sidebarCollapseButton?.addEventListener('click',dashboardToggleSidebar);

dashboardSetSidebarCollapsed(
  localStorage.getItem(SIDEBAR_COLLAPSED_KEY)==='1',
  false
);




/* ===== MISE À JOUR DU DASHBOARD DEPUIS ADMIN ===== */
const DASHBOARD_ROOT_DB='hessers-dashboard-root-v1';
const DASHBOARD_ROOT_STORE='handles';
const DASHBOARD_ROOT_HANDLE_KEY='dashboard-root-folder';
const DASHBOARD_HTML_BACKUP_FOLDER='Sauvegardes_dashboard';
const DASHBOARD_UPDATE_META_FILE='dashboard_update.json';
const DASHBOARD_FIXED_HTML_NAME='Dashboard.html';
const DASHBOARD_UPDATE_POLL_MS=15000;
const DASHBOARD_LOADED_AT=Date.now();

let dashboardRootHandle=null;
let dashboardRootAuthorized=false;
let dashboardUpdatePollTimer=null;
let dashboardUpdateLastSeenStamp=0;

const dashboardAuthorizeRootButton=document.getElementById('dashboardAuthorizeRoot');
const dashboardUpdateButton=document.getElementById('dashboardUpdateButton');
const dashboardRestorePreviousButton=document.getElementById('dashboardRestorePrevious');
const dashboardUpdateRootChip=document.getElementById('dashboardUpdateRootChip');
const dashboardUpdateCurrentFileChip=document.getElementById('dashboardUpdateCurrentFileChip');
const dashboardUpdateBackupCount=document.getElementById('dashboardUpdateBackupCount');

const dashboardUpdateModal=document.getElementById('dashboardUpdateModal');
const dashboardUpdateModalClose=document.getElementById('dashboardUpdateModalClose');
const dashboardUpdateModalCancel=document.getElementById('dashboardUpdateModalCancel');
const dashboardUpdateSelectFile=document.getElementById('dashboardUpdateSelectFile');

const dashboardVersionBanner=document.getElementById('dashboardVersionBanner');
const dashboardVersionLater=document.getElementById('dashboardVersionLater');
const dashboardVersionReload=document.getElementById('dashboardVersionReload');

function dashboardLoadedHtmlFilename(){
  try{
    const path=decodeURIComponent(location.pathname||'');
    const name=path.split('/').filter(Boolean).pop()||DASHBOARD_FIXED_HTML_NAME;
    return name.toLowerCase().endsWith('.html') ? name : DASHBOARD_FIXED_HTML_NAME;
  }catch(error){
    return DASHBOARD_FIXED_HTML_NAME;
  }
}

function dashboardCurrentHtmlFilename(){
  // Toutes les nouvelles versions utilisent volontairement le même nom.
  return DASHBOARD_FIXED_HTML_NAME;
}

function dashboardFixedHtmlUrl(){
  try{
    const url=new URL(location.href);
    const parts=url.pathname.split('/');
    parts[parts.length-1]=encodeURIComponent(DASHBOARD_FIXED_HTML_NAME);
    url.pathname=parts.join('/');
    url.search='';
    url.hash='';
    return url.href;
  }catch(error){
    return DASHBOARD_FIXED_HTML_NAME;
  }
}

function dashboardOpenRootDb(){
  return new Promise((resolve,reject)=>{
    const req=indexedDB.open(DASHBOARD_ROOT_DB,1);
    req.onupgradeneeded=()=>{
      const db=req.result;
      if(!db.objectStoreNames.contains(DASHBOARD_ROOT_STORE)){
        db.createObjectStore(DASHBOARD_ROOT_STORE);
      }
    };
    req.onsuccess=()=>resolve(req.result);
    req.onerror=()=>reject(req.error);
  });
}

async function dashboardSaveRootHandle(handle){
  try{
    const db=await dashboardOpenRootDb();
    await new Promise((resolve,reject)=>{
      const tx=db.transaction(DASHBOARD_ROOT_STORE,'readwrite');
      tx.objectStore(DASHBOARD_ROOT_STORE).put(handle,DASHBOARD_ROOT_HANDLE_KEY);
      tx.oncomplete=resolve;
      tx.onerror=()=>reject(tx.error);
    });
    db.close();
  }catch(error){
    console.warn('Impossible de mémoriser le dossier principal.',error);
  }
}

async function dashboardLoadRootHandle(){
  try{
    const db=await dashboardOpenRootDb();
    const handle=await new Promise((resolve,reject)=>{
      const tx=db.transaction(DASHBOARD_ROOT_STORE,'readonly');
      const req=tx.objectStore(DASHBOARD_ROOT_STORE).get(DASHBOARD_ROOT_HANDLE_KEY);
      req.onsuccess=()=>resolve(req.result||null);
      req.onerror=()=>reject(req.error);
    });
    db.close();
    return handle;
  }catch(error){
    console.warn('Impossible de relire le dossier principal.',error);
    return null;
  }
}

async function dashboardRootHasPermission(handle,request=false){
  if(!handle) return false;
  try{
    const options={mode:'readwrite'};
    if(await handle.queryPermission(options)==='granted') return true;
    if(request && await handle.requestPermission(options)==='granted') return true;
  }catch(error){
    console.warn(error);
  }
  return false;
}

async function dashboardCountHtmlBackups(){
  if(!dashboardRootHandle || !dashboardRootAuthorized) return 0;
  try{
    const dir=await dashboardRootHandle.getDirectoryHandle(DASHBOARD_HTML_BACKUP_FOLDER);
    let count=0;
    for await(const [,handle] of dir.entries()){
      if(handle.kind==='file') count++;
    }
    return count;
  }catch(error){
    if(error?.name==='NotFoundError') return 0;
    throw error;
  }
}

async function dashboardRefreshUpdateUi(){
  const filename=dashboardCurrentHtmlFilename();
  dashboardUpdateCurrentFileChip.textContent='Fichier : '+filename;

  if(dashboardRootAuthorized){
    dashboardUpdateRootChip.textContent='Dossier principal autorisé';
    dashboardUpdateRootChip.className='dashboard-update-chip ok';
    dashboardAuthorizeRootButton.textContent='Changer de dossier';
  }else if(dashboardRootHandle){
    dashboardUpdateRootChip.textContent='Autorisation à renouveler';
    dashboardUpdateRootChip.className='dashboard-update-chip warn';
    dashboardAuthorizeRootButton.textContent='Autoriser le dossier';
  }else{
    dashboardUpdateRootChip.textContent='Dossier principal non autorisé';
    dashboardUpdateRootChip.className='dashboard-update-chip warn';
    dashboardAuthorizeRootButton.textContent='Autoriser le dossier';
  }

  dashboardUpdateButton.disabled=!dashboardRootHandle;
  dashboardRestorePreviousButton.disabled=!dashboardRootAuthorized;

  try{
    dashboardUpdateBackupCount.textContent=await dashboardCountHtmlBackups();
  }catch(error){
    dashboardUpdateBackupCount.textContent='—';
  }
}

async function dashboardAuthorizeRoot(forcePicker=false){
  if(typeof window.showDirectoryPicker!=='function'){
    dashboardToast('Impossible','Cette version d’Edge ne permet pas l’accès au dossier.','error',4000);
    return false;
  }

  try{
    if(dashboardRootHandle && !forcePicker){
      const allowed=await dashboardRootHasPermission(dashboardRootHandle,true);
      if(allowed){
        dashboardRootAuthorized=true;
        await dashboardRefreshUpdateUi();
        return true;
      }
    }

    const handle=await window.showDirectoryPicker({mode:'readwrite'});
    const allowed=await dashboardRootHasPermission(handle,true);
    if(!allowed) return false;

    // On vérifie que c'est bien le dossier principal du dashboard.
    // Pendant la migration vers le nom fixe Dashboard.html, l'ancienne page
    // peut encore être ouverte sous son ancien nom : les deux cas sont acceptés.
    const candidates=[DASHBOARD_FIXED_HTML_NAME,dashboardLoadedHtmlFilename()]
      .filter((name,index,array)=>name && array.indexOf(name)===index);
    let rootLooksValid=false;

    for(const name of candidates){
      try{
        await handle.getFileHandle(name);
        rootLooksValid=true;
        break;
      }catch(error){
        if(error?.name!=='NotFoundError') throw error;
      }
    }

    if(!rootLooksValid){
      try{
        await handle.getDirectoryHandle('Data');
        rootLooksValid=true;
      }catch(error){
        if(error?.name!=='NotFoundError') throw error;
      }
    }

    if(!rootLooksValid){
      dashboardToast(
        'Mauvais dossier',
        'Sélectionne le dossier principal qui contient Dashboard.html ou le dossier Data.',
        'warn',
        5000
      );
      return false;
    }

    dashboardRootHandle=handle;
    dashboardRootAuthorized=true;
    await dashboardSaveRootHandle(handle);
    await dashboardRefreshUpdateUi();

    dashboardToast(
      'Dossier autorisé',
      'Les prochaines mises à jour pourront remplacer automatiquement le HTML.',
      'success'
    );
    return true;
  }catch(error){
    if(error?.name!=='AbortError'){
      dashboardToast('Autorisation impossible',String(error),'error',4500);
    }
    return false;
  }
}

async function dashboardReadFileBytes(fileHandle){
  const file=await fileHandle.getFile();
  return await file.arrayBuffer();
}

function dashboardBackupHtmlName(originalName){
  const dot=originalName.toLowerCase().lastIndexOf('.html');
  const base=dot>=0?originalName.slice(0,dot):originalName;
  const d=new Date();
  const pad=n=>String(n).padStart(2,'0');
  const stamp=
    `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}_`+
    `${pad(d.getHours())}-${pad(d.getMinutes())}-${pad(d.getSeconds())}`;
  return `${base}_${stamp}.html`;
}

async function dashboardBackupCurrentHtml(){
  if(!dashboardRootHandle || !dashboardRootAuthorized){
    throw new Error('Dossier principal non autorisé.');
  }

  const candidates=[DASHBOARD_FIXED_HTML_NAME,dashboardLoadedHtmlFilename()]
    .filter((name,index,array)=>name && array.indexOf(name)===index);

  let sourceName='';
  let currentHandle=null;
  for(const name of candidates){
    try{
      currentHandle=await dashboardRootHandle.getFileHandle(name);
      sourceName=name;
      break;
    }catch(error){
      if(error?.name!=='NotFoundError') throw error;
    }
  }

  // Première migration : si aucun ancien HTML n'existe plus dans le dossier,
  // on autorise quand même la création du nouveau Dashboard.html.
  if(!currentHandle) return null;

  const bytes=await dashboardReadFileBytes(currentHandle);
  const backupDir=await dashboardRootHandle.getDirectoryHandle(
    DASHBOARD_HTML_BACKUP_FOLDER,
    {create:true}
  );

  const backupName=dashboardBackupHtmlName(sourceName);
  const backupHandle=await backupDir.getFileHandle(backupName,{create:true});
  const writable=await backupHandle.createWritable();
  await writable.write(bytes);
  await writable.close();

  return backupName;
}

async function dashboardWriteUpdateMeta(data){
  if(!dashboardRootHandle || !dashboardRootAuthorized) return;

  try{
    const handle=await dashboardRootHandle.getFileHandle(
      DASHBOARD_UPDATE_META_FILE,
      {create:true}
    );
    const writable=await handle.createWritable();
    await writable.write(JSON.stringify(data,null,2));
    await writable.close();
  }catch(error){
    console.warn('Impossible d’écrire dashboard_update.json',error);
  }
}

async function dashboardReadUpdateMeta(){
  if(!dashboardRootHandle || !dashboardRootAuthorized) return null;
  try{
    const handle=await dashboardRootHandle.getFileHandle(DASHBOARD_UPDATE_META_FILE);
    const file=await handle.getFile();
    return JSON.parse(await file.text());
  }catch(error){
    if(error?.name==='NotFoundError') return null;
    throw error;
  }
}

async function dashboardReplaceCurrentHtml(newFile){
  if(!dashboardRootHandle || !dashboardRootAuthorized){
    throw new Error('Dossier principal non autorisé.');
  }

  if(!newFile || !newFile.name.toLowerCase().endsWith('.html')){
    throw new Error('Sélectionne un fichier HTML.');
  }

  // Protection : le nouveau fichier doit ressembler à notre dashboard.
  const preview=await newFile.slice(0,300000).text();
  const signatures=[
    'Gestion de Parc',
    'hessers',
    'data-view="parc"',
    'sharedStorageButton'
  ];
  const matches=signatures.filter(token=>preview.toLowerCase().includes(token.toLowerCase())).length;
  if(matches<3){
    throw new Error('Le fichier sélectionné ne semble pas être une version du dashboard H.ESSERS.');
  }

  const currentName=dashboardCurrentHtmlFilename();

  // 1. Sauvegarde de l'ancienne version
  const backupName=await dashboardBackupCurrentHtml();

  // 2. Lecture du nouveau HTML
  const bytes=await newFile.arrayBuffer();

  // 3. Écriture dans le fichier principal
  const currentHandle=await dashboardRootHandle.getFileHandle(currentName,{create:true});
  const writable=await currentHandle.createWritable();
  await writable.write(bytes);
  await writable.close();

  // 4. Métadonnées pour prévenir les autres sessions
  const meta={
    version:1,
    updatedAt:new Date().toISOString(),
    updatedAtMs:Date.now(),
    updatedBy:dashboardUser||'inconnu',
    currentFile:currentName,
    sourceFile:newFile.name,
    backupFile:backupName
  };
  await dashboardWriteUpdateMeta(meta);
  dashboardUpdateLastSeenStamp=meta.updatedAtMs;

  administratorWriteHistory({
    action:'Mise à jour',
    section:'Administrateur',
    entity:currentName,
    detail:`Dashboard remplacé par ${newFile.name}${backupName ? ` · sauvegarde ${backupName}` : ' · aucune ancienne version trouvée'}`
  });

  await dashboardRefreshUpdateUi();

  return {backupName,currentName,sourceName:newFile.name};
}

async function dashboardPickUpdateFile(){
  if(!dashboardRootAuthorized){
    const allowed=await dashboardAuthorizeRoot(false);
    if(!allowed) return;
  }

  try{
    const handles=await window.showOpenFilePicker({
      multiple:false,
      types:[{
        description:'Fichier HTML',
        accept:{'text/html':['.html','.htm']}
      }]
    });
    const file=await handles[0].getFile();

    dashboardUpdateSelectFile.disabled=true;
    dashboardUpdateSelectFile.textContent='Mise à jour…';

    const result=await dashboardReplaceCurrentHtml(file);

    dashboardUpdateModal.hidden=true;
    if(document.querySelectorAll('.modal-overlay:not([hidden])').length===0){
      document.body.classList.remove('modal-open');
    }

    dashboardToast(
      'Dashboard mis à jour',
      result.backupName
        ? `Ancienne version sauvegardée : ${result.backupName}`
        : 'Dashboard.html a été créé. Aucune ancienne version n’était disponible à sauvegarder.',
      'success',
      4500
    );

    dashboardVersionBanner.hidden=false;
  }catch(error){
    if(error?.name!=='AbortError'){
      if(error?.name==='NotFoundError'){
        dashboardRootAuthorized=false;
        await dashboardRefreshUpdateUi();
        dashboardToast(
          'Dossier à réautoriser',
          'Le dossier mémorisé n’est plus accessible. Clique sur « Autoriser le dossier » puis sélectionne le dossier principal du Dashboard.',
          'warn',
          6500
        );
      }else{
        dashboardToast('Mise à jour impossible',String(error),'error',5500);
      }
    }
  }finally{
    dashboardUpdateSelectFile.disabled=false;
    dashboardUpdateSelectFile.textContent='Choisir le nouveau HTML';
  }
}

async function dashboardListHtmlBackups(){
  if(!dashboardRootHandle || !dashboardRootAuthorized) return [];
  try{
    const dir=await dashboardRootHandle.getDirectoryHandle(DASHBOARD_HTML_BACKUP_FOLDER);
    const files=[];
    for await(const [name,handle] of dir.entries()){
      if(handle.kind!=='file' || !name.toLowerCase().endsWith('.html')) continue;
      const file=await handle.getFile();
      files.push({name,handle,lastModified:file.lastModified,size:file.size});
    }
    return files.sort((a,b)=>b.lastModified-a.lastModified);
  }catch(error){
    if(error?.name==='NotFoundError') return [];
    throw error;
  }
}

async function dashboardRestorePreviousHtml(){
  if(!dashboardRootAuthorized){
    const allowed=await dashboardAuthorizeRoot(false);
    if(!allowed) return;
  }

  if(typeof adminSecurityIsUnlocked==='function' && !adminSecurityIsUnlocked()){
    const allowed=await adminSecurityRequestAccess();
    if(!allowed) return;
  }

  try{
    const backups=await dashboardListHtmlBackups();
    if(!backups.length){
      dashboardToast('Aucune sauvegarde','Aucune ancienne version HTML disponible.','warn');
      return;
    }

    const latest=backups[0];
    if(!confirm(`Restaurer la dernière version sauvegardée ?\n\n${latest.name}`)) return;

    // Sauvegarder d'abord la version actuelle pour permettre un retour en arrière.
    const safetyBackup=await dashboardBackupCurrentHtml();

    const bytes=await dashboardReadFileBytes(latest.handle);
    const currentName=dashboardCurrentHtmlFilename();
    const currentHandle=await dashboardRootHandle.getFileHandle(currentName,{create:true});
    const writable=await currentHandle.createWritable();
    await writable.write(bytes);
    await writable.close();

    const meta={
      version:1,
      updatedAt:new Date().toISOString(),
      updatedAtMs:Date.now(),
      updatedBy:dashboardUser||'inconnu',
      currentFile:currentName,
      sourceFile:latest.name,
      backupFile:safetyBackup,
      restored:true
    };
    await dashboardWriteUpdateMeta(meta);
    dashboardUpdateLastSeenStamp=meta.updatedAtMs;

    administratorWriteHistory({
      action:'Restauration',
      section:'Administrateur',
      entity:currentName,
      detail:`Version HTML restaurée depuis ${latest.name}`
    });

    await dashboardRefreshUpdateUi();

    dashboardToast(
      'Version restaurée',
      'Recharge la page pour utiliser la version restaurée.',
      'success',
      4000
    );
    dashboardVersionBanner.hidden=false;
  }catch(error){
    dashboardToast('Restauration impossible',String(error),'error',5000);
  }
}

function dashboardOpenUpdateModal(){
  dashboardUpdateModal.hidden=false;
  document.body.classList.add('modal-open');
}
function dashboardCloseUpdateModal(){
  dashboardUpdateModal.hidden=true;
  if(document.querySelectorAll('.modal-overlay:not([hidden])').length===0){
    document.body.classList.remove('modal-open');
  }
}

async function dashboardCheckForNewHtmlVersion(){
  if(!dashboardRootAuthorized) return;

  try{
    const meta=await dashboardReadUpdateMeta();
    if(!meta?.updatedAtMs) return;

    const stamp=Number(meta.updatedAtMs)||0;
    if(!dashboardUpdateLastSeenStamp){
      dashboardUpdateLastSeenStamp=stamp;
      return;
    }

    // Si une autre session a publié une version plus récente depuis le chargement de cette page.
    if(
      stamp>dashboardUpdateLastSeenStamp &&
      stamp>DASHBOARD_LOADED_AT+1500
    ){
      dashboardUpdateLastSeenStamp=stamp;
      dashboardVersionBanner.hidden=false;
    }
  }catch(error){
    console.warn('Vérification version dashboard impossible.',error);
  }
}

dashboardAuthorizeRootButton?.addEventListener('click',()=>dashboardAuthorizeRoot(Boolean(dashboardRootAuthorized)));
dashboardUpdateButton?.addEventListener('click',async()=>{
  if(typeof adminSecurityIsUnlocked==='function' && !adminSecurityIsUnlocked()){
    const allowed=await adminSecurityRequestAccess();
    if(!allowed) return;
  }

  if(!dashboardRootAuthorized){
    const allowed=await dashboardAuthorizeRoot(false);
    if(!allowed) return;
  }

  dashboardOpenUpdateModal();
});
dashboardRestorePreviousButton?.addEventListener('click',dashboardRestorePreviousHtml);

dashboardUpdateModalClose?.addEventListener('click',dashboardCloseUpdateModal);
dashboardUpdateModalCancel?.addEventListener('click',dashboardCloseUpdateModal);
dashboardUpdateModal?.addEventListener('click',event=>{
  if(event.target===dashboardUpdateModal) dashboardCloseUpdateModal();
});
dashboardUpdateSelectFile?.addEventListener('click',dashboardPickUpdateFile);

dashboardVersionReload?.addEventListener('click',()=>{ location.href=dashboardFixedHtmlUrl(); });
dashboardVersionLater?.addEventListener('click',()=>dashboardVersionBanner.hidden=true);

(async()=>{
  dashboardUpdateCurrentFileChip.textContent='Fichier : '+dashboardCurrentHtmlFilename();

  const saved=await dashboardLoadRootHandle();
  if(saved){
    dashboardRootHandle=saved;
    dashboardRootAuthorized=await dashboardRootHasPermission(saved,false);
  }

  await dashboardRefreshUpdateUi();

  if(dashboardRootAuthorized){
    try{
      const meta=await dashboardReadUpdateMeta();
      dashboardUpdateLastSeenStamp=Number(meta?.updatedAtMs)||0;
    }catch(error){}

    dashboardUpdatePollTimer=setInterval(
      dashboardCheckForNewHtmlVersion,
      DASHBOARD_UPDATE_POLL_MS
    );
  }
})();



/* ===== DARK / WHITE MODE ===== */
const THEME_STORAGE_KEY='hessers-dashboard-theme-v1';
const themeSwitch=document.getElementById('themeSwitch');

function applyDashboardTheme(theme){
  const white=theme==='white';

  document.body.classList.toggle('white-mode',white);
  themeSwitch.setAttribute('aria-checked',white?'true':'false');
  themeSwitch.title=white?'Passer en Dark mode':'Passer en White mode';

  try{
    localStorage.setItem(THEME_STORAGE_KEY,white?'white':'dark');
  }catch(error){
    console.warn('Impossible de mémoriser le thème.',error);
  }

  if(typeof renderFuelCharts==='function'){
    requestAnimationFrame(()=>{
      requestAnimationFrame(renderFuelCharts);
    });
  }
}

let savedDashboardTheme='dark';
try{
  savedDashboardTheme=localStorage.getItem(THEME_STORAGE_KEY)||'dark';
}catch(error){
  savedDashboardTheme='dark';
}

applyDashboardTheme(savedDashboardTheme==='white'?'white':'dark');

themeSwitch.addEventListener('click',()=>{
  applyDashboardTheme(
    document.body.classList.contains('white-mode')?'dark':'white'
  );
});
