
(()=>{
  if(window.__technicalDriverLiveLinkPatched)return;window.__technicalDriverLiveLinkPatched=true;
  if(typeof saveAffectations==='function'){
    const originalSaveAffectations=saveAffectations;
    saveAffectations=function(){
      const result=originalSaveAffectations.apply(this,arguments);
      setTimeout(()=>{
        try{ window.technicalRefreshAll?.(); }catch(_){}
        try{ window.technicalRenderDeadlineTableEnhanced?.(); }catch(_){}
        try{
          renderVidTable();
          const record=selectedVidRecord();
          if(record)document.getElementById('vidDetailDriver').textContent=vidAssignedDriver(record)||'Non affecté';
        }catch(_){}
      },0);
      return result;
    };
  }
  renderVidTable();
})();
