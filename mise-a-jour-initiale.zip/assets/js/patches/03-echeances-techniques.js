(function(){
  const CATEGORY_META={
    tachy:{title:'Tachygraphe',description:'Contrôle périodique du chronotachygraphe.',listTitle:'CONTRÔLES TACHYGRAPHE'},
    mines:{title:'Mines',description:'Passage aux mines des tracteurs et semi-remorques.',listTitle:'PASSAGES AUX MINES'},
    limiteur:{title:'Limiteur de vitesse',description:'Contrôle périodique du limiteur de vitesse.',listTitle:'CONTRÔLES LIMITEUR'},
    confinement:{title:'Confinement',description:'Suivi des échéances de confinement.',listTitle:'CONTRÔLES CONFINEMENT'},
    sanitaire:{title:'Sanitaire / ATP',description:'Renouvellement ATP et échéances sanitaires.',listTitle:'ÉCHÉANCES SANITAIRES / ATP'}
  };
  let currentTechnicalCategory='tachy';
  const hub=document.getElementById('technicalHub');
  const vidangePage=document.getElementById('technicalVidangePage');
  const deadlinePage=document.getElementById('technicalDeadlinePage');
  const search=document.getElementById('technicalDeadlineSearch');
  const statusFilter=document.getElementById('technicalDeadlineStatusFilter');

  function technicalEscape(value){return String(value??'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;')}
  function technicalNormalize(value){return String(value??'').toLocaleLowerCase('fr').normalize('NFD').replace(/[\u0300-\u036f]/g,'')}
  function technicalDate(value){
    if(!value) return null;
    const raw=String(value).trim();
    if(/^\d{4}-\d{2}-\d{2}$/.test(raw)){
      const d=new Date(raw+'T00:00:00');
      return Number.isFinite(d.getTime())?d:null;
    }
    const m=raw.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
    if(m){const d=new Date(`${m[3]}-${m[2]}-${m[1]}T00:00:00`);return Number.isFinite(d.getTime())?d:null}
    return null;
  }
  function technicalFormatDate(value){
    const d=technicalDate(value);
    if(!d) return value||'—';
    return d.toLocaleDateString('fr-FR');
  }
  function technicalStatus(item){
    const due=technicalDate(item.nextControl);
    if(!due) return {key:'ok',label:'À jour',days:null};
    const today=new Date();today.setHours(0,0,0,0);
    const days=Math.ceil((due-today)/86400000);
    if(days<0) return {key:'late',label:'Dépassé',days};
    if(days<=30) return {key:'soon',label:'À prévoir',days};
    return {key:'ok',label:'À jour',days};
  }
  function technicalRows(category=currentTechnicalCategory){return (Array.isArray(technicalDeadlines)?technicalDeadlines:[]).filter(item=>item.category===category)}
  function technicalStats(rows){
    const stats={total:rows.length,late:0,soon:0,ok:0};
    rows.forEach(item=>{stats[technicalStatus(item).key]++});
    return stats;
  }
  function technicalShowHub(){hub.hidden=false;vidangePage.hidden=true;deadlinePage.hidden=true;technicalRefreshHub()}
  function technicalOpenPage(page){
    hub.hidden=true;
    if(page==='vidange'){
      deadlinePage.hidden=true;vidangePage.hidden=false;
      if(typeof renderVidTable==='function') renderVidTable();
      return;
    }
    if(!CATEGORY_META[page]) return technicalShowHub();
    currentTechnicalCategory=page;
    vidangePage.hidden=true;deadlinePage.hidden=false;
    search.value='';statusFilter.value='';
    technicalRenderDeadlinePage();
  }
  window.technicalShowHub=technicalShowHub;
  window.technicalOpenPage=technicalOpenPage;

  function technicalRefreshHub(){
    const all=Array.isArray(technicalDeadlines)?technicalDeadlines:[];
    const stats=technicalStats(all);
    document.getElementById('technicalHubTotal').textContent=stats.total.toLocaleString('fr-FR');
    document.getElementById('technicalHubLate').textContent=stats.late.toLocaleString('fr-FR');
    document.getElementById('technicalHubSoon').textContent=stats.soon.toLocaleString('fr-FR');
    document.getElementById('technicalVidangeCount').textContent=`${vidangeData.length} véhicule${vidangeData.length>1?'s':''}`;
    const vidLate=vidangeData.filter(item=>calculateNextOil(item)<=0).length;
    const vidSoon=vidangeData.filter(item=>{const x=calculateNextOil(item);return x>0&&x<=5000}).length;
    const vidAlert=document.getElementById('technicalVidangeAlert');
    vidAlert.textContent=vidLate?`${vidLate} à faire`:vidSoon?`${vidSoon} à prévoir`:'À jour';
    vidAlert.classList.toggle('has-late',!!vidLate);vidAlert.classList.toggle('has-alert',!vidLate&&!!vidSoon);
    Object.keys(CATEGORY_META).forEach(category=>{
      const rows=technicalRows(category);const s=technicalStats(rows);
      const count=document.querySelector(`[data-tech-count="${category}"]`);
      const alert=document.querySelector(`[data-tech-alert="${category}"]`);
      if(count) count.textContent=`${rows.length} ligne${rows.length>1?'s':''}`;
      if(alert){
        alert.textContent=s.late?`${s.late} dépassée${s.late>1?'s':''}`:s.soon?`${s.soon} à prévoir`:'À jour';
        alert.classList.toggle('has-late',!!s.late);alert.classList.toggle('has-alert',!s.late&&!!s.soon);
      }
    });
  }

  function technicalAssignedDriver(registration){
    const reg=normalizeRegistration(registration);
    const seen=new Set();
    const names=(Array.isArray(affectations)?affectations:[])
      .filter(item=>normalizeRegistration(item.tractor)===reg||normalizeRegistration(item.semi)===reg)
      .map(item=>String(item?.name||'').trim())
      .filter(name=>{const key=technicalNormalize(name);if(!key||seen.has(key))return false;seen.add(key);return true})
      .sort((a,b)=>a.localeCompare(b,'fr',{numeric:true,sensitivity:'base'}));
    return names.join(' · ');
  }
  window.technicalAssignedDriver=technicalAssignedDriver;

  function technicalColumns(category){
    if(category==='mines') return [
      ['registration','IMMATRICULATION'],['driver','CHAUFFEUR'],['genre','GENRE'],['label','LIBELLÉ'],['nextControl','PROCHAIN CONTRÔLE'],['operator','EXPLOITANT'],['_status','STATUT']
    ];
    return [
      ['registration','IMMATRICULATION'],['driver','CHAUFFEUR'],['label','LIBELLÉ'],['lastControl','DERNIER CONTRÔLE'],['nextControl','PROCHAIN CONTRÔLE'],['operator','EXPLOITANT'],['_status','STATUT']
    ];
  }
  function technicalRenderDeadlinePage(){
    const meta=CATEGORY_META[currentTechnicalCategory];
    const allRows=technicalRows();const stats=technicalStats(allRows);
    document.getElementById('technicalDeadlineTitle').textContent=meta.title;
    document.getElementById('technicalDeadlineDescription').textContent=meta.description;
    document.getElementById('technicalDeadlineListTitle').textContent=meta.listTitle;
    document.getElementById('technicalDeadlineTotal').textContent=stats.total;
    document.getElementById('technicalDeadlineLate').textContent=stats.late;
    document.getElementById('technicalDeadlineSoon').textContent=stats.soon;
    document.getElementById('technicalDeadlineOk').textContent=stats.ok;
    document.getElementById('technicalDeadlineSourceCount').textContent=`${stats.total} ligne${stats.total>1?'s':''} importée${stats.total>1?'s':''}`;
    const cols=technicalColumns(currentTechnicalCategory);
    document.getElementById('technicalDeadlineHead').innerHTML=`<tr>${cols.map(([,label])=>`<th>${label}</th>`).join('')}<th class="tech-actions-head">ACTIONS</th></tr>`;
    technicalRenderDeadlineTable();
  }
  function technicalRenderDeadlineTable(){
    const q=technicalNormalize(search.value);
    const filter=statusFilter.value;
    const cols=technicalColumns(currentTechnicalCategory);
    const rows=technicalRows().filter(item=>{
      const status=technicalStatus(item);
      if(filter&&status.key!==filter) return false;
      const haystack=technicalNormalize(`${item.registration||''} ${technicalAssignedDriver(item.registration)||''} ${item.genre||''} ${item.model||''} ${item.label||''} ${item.operator||''} ${item.company||''} ${item.sourceState||''}`);
      return !q||haystack.includes(q);
    }).sort((a,b)=>{
      const da=technicalDate(a.nextControl)?.getTime()??Number.MAX_SAFE_INTEGER;
      const db=technicalDate(b.nextControl)?.getTime()??Number.MAX_SAFE_INTEGER;
      return da-db || String(a.registration||'').localeCompare(String(b.registration||''),'fr',{numeric:true,sensitivity:'base'});
    });
    const body=document.getElementById('technicalDeadlineBody');
    if(!rows.length){body.innerHTML=`<tr><td class="tech-empty" colspan="${cols.length+1}">Aucune échéance ne correspond à votre recherche.</td></tr>`}
    else body.innerHTML=rows.map(item=>{
      const status=technicalStatus(item);
      return `<tr data-tech-id="${technicalEscape(item.id)}">${cols.map(([key])=>{
        if(key==='_status') return `<td><span class="tech-status ${status.key}">${status.label}</span></td>`;
        if(key==='registration') return `<td><span class="tech-plate" data-tech-vehicle="${technicalEscape(item.registration)}">${technicalEscape(item.registration||'—')}</span></td>`;
        if(key==='driver') return `<td><span class="tech-driver tech-driver-linked">${technicalEscape(technicalAssignedDriver(item.registration)||'—')}</span></td>`;
        if(key==='nextControl'||key==='lastControl') return `<td class="tech-date">${technicalEscape(technicalFormatDate(item[key]))}</td>`;
        return `<td>${technicalEscape(item[key]||'—')}</td>`;
      }).join('')}<td class="tech-actions-cell"><button class="row-menu tech-row-menu" type="button" data-tech-row-menu="${technicalEscape(item.id)}" aria-label="Actions pour ${technicalEscape(item.registration||'cette ligne')}" aria-haspopup="menu" aria-expanded="false">•••</button></td></tr>`;
    }).join('');
    document.getElementById('technicalDeadlineCountLabel').textContent=`${rows.length} ligne${rows.length>1?'s':''} affichée${rows.length>1?'s':''}`;
    body._technicalRows=rows;
  }
  function technicalCsv(){
    const cols=technicalColumns(currentTechnicalCategory);const rows=technicalRows().sort((a,b)=>(technicalDate(a.nextControl)?.getTime()??0)-(technicalDate(b.nextControl)?.getTime()??0));
    const csv=[cols.map(([,label])=>label),...rows.map(item=>cols.map(([key])=>key==='_status'?technicalStatus(item).label:(key==='driver'?technicalAssignedDriver(item.registration):(key==='nextControl'||key==='lastControl'?technicalFormatDate(item[key]):item[key]||''))))];
    const text='\ufeff'+csv.map(row=>row.map(value=>`"${String(value).replace(/"/g,'""')}"`).join(';')).join('\r\n');
    const blob=new Blob([text],{type:'text/csv;charset=utf-8'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=`Suivi_${CATEGORY_META[currentTechnicalCategory].title.replace(/[^a-z0-9]+/gi,'_')}.csv`;document.body.appendChild(a);a.click();a.remove();URL.revokeObjectURL(url);
  }

  function technicalExcelSerialToIso(value){
    if(typeof value==='number'&&Number.isFinite(value)){
      const epoch=Date.UTC(1899,11,30);const d=new Date(epoch+Math.round(value)*86400000);return d.toISOString().slice(0,10);
    }
    const raw=String(value??'').trim();if(!raw)return '';
    const m=raw.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);if(m)return `${m[3]}-${String(m[2]).padStart(2,'0')}-${String(m[1]).padStart(2,'0')}`;
    return raw;
  }
  function technicalPlate(value){
    const text=String(value??'').trim().toUpperCase();const compact=text.replace(/[^A-Z0-9]/g,'');const m=compact.match(/^([A-Z]{2})(\d{3})([A-Z]{2})$/);return m?`${m[1]}-${m[2]}-${m[3]}`:text;
  }
  function technicalRowsFromSheet(sheet,category){
    const rows=sheet?.rows||[];const result=[];
    rows.slice(3).forEach((row,i)=>{if(!row||!row.some(v=>v!==undefined&&v!==null&&v!==''))return;const excelRow=i+4;if(category==='mines')result.push({id:`mines_${excelRow}`,category:'mines',registration:technicalPlate(row[0]),driver:String(row[1]??'').trim(),genre:String(row[2]??'').trim(),control:String(row[3]??'').trim(),label:String(row[4]??'').trim(),nextControl:technicalExcelSerialToIso(row[5]),company:String(row[6]??'').trim(),operator:String(row[7]??'').trim(),excelRow});else result.push({id:`${category}_${excelRow}`,category,registration:technicalPlate(row[0]),driver:String(row[1]??'').trim(),control:String(row[2]??'').trim(),label:String(row[3]??'').trim(),lastControl:technicalExcelSerialToIso(row[4]),nextControl:technicalExcelSerialToIso(row[5]),company:String(row[6]??'').trim(),operator:String(row[7]??'').trim(),excelRow})});
    return result;
  }
  async function technicalImportWorkbook(file){
    const notice=document.getElementById('technicalImportNotice');notice.textContent='Lecture du fichier Excel…';
    try{
      const sheets=await readXlsxSheets(file);
      const aliases={tachy:'tachy','mine tr + sr':'mines',limiteur:'limiteur',confinement:'confinement',sanitaire:'sanitaire'};
      const next=[];
      for(const sheet of sheets){const category=aliases[String(sheet.name||'').trim().toLocaleLowerCase('fr')];if(category)next.push(...technicalRowsFromSheet(sheet,category))}
      if(!next.length) throw new Error('Aucune des feuilles attendues (tachy, mine tr + sr, limiteur, confinement, Sanitaire) n’a été trouvée.');
      technicalDeadlines=next;
      if(!saveTechnicalDeadlines()) throw new Error('Impossible de sauvegarder les données importées.');
      notice.textContent=`${next.length} échéances importées · ${new Date().toLocaleString('fr-FR')}`;
      technicalRefreshAll();
    }catch(error){notice.textContent='Import impossible : '+String(error?.message||error);console.error(error)}
  }

  document.getElementById('technicalModulesGrid')?.addEventListener('click',event=>{const btn=event.target.closest('[data-tech-page]');if(btn)technicalOpenPage(btn.dataset.techPage)});
  document.querySelectorAll('[data-tech-back]').forEach(btn=>btn.addEventListener('click',technicalShowHub));
  search?.addEventListener('input',technicalRenderDeadlineTable);statusFilter?.addEventListener('change',technicalRenderDeadlineTable);
  document.getElementById('technicalDeadlineExport')?.addEventListener('click',technicalCsv);
  document.getElementById('importTechnicalDeadlines')?.addEventListener('click',()=>document.getElementById('technicalDeadlinesInput')?.click());
  document.getElementById('technicalDeadlinesInput')?.addEventListener('change',async event=>{const file=event.target.files?.[0];event.target.value='';if(file)await technicalImportWorkbook(file)});
  const technicalDeadlineBody=document.getElementById('technicalDeadlineBody');
  technicalDeadlineBody?.addEventListener('click',event=>{
    const plate=event.target.closest('[data-tech-vehicle]');if(plate&&typeof dashboardOpenVehicleDossier==='function'){dashboardOpenVehicleDossier(plate.dataset.techVehicle);return}
  });
  document.querySelectorAll('.home-alert[data-home-view="suivi-technique"]').forEach(alert=>alert.addEventListener('click',()=>setTimeout(()=>technicalOpenPage('vidange'),0)));
  document.querySelector('.nav-btn[data-view="suivi-technique"]')?.addEventListener('click',()=>setTimeout(technicalShowHub,0));

  window.technicalRefreshAll=function(){technicalRefreshHub();if(!deadlinePage.hidden)technicalRenderDeadlinePage()};
  technicalShowHub();
})();
