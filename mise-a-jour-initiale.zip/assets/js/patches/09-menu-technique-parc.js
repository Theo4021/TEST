(()=>{
  if(window.__techMenuParcMatchApplied)return;window.__techMenuParcMatchApplied=true;
  const menu=document.getElementById('technicalRowActionsMenu');
  const body=document.getElementById('technicalDeadlineBody');
  const editModal=document.getElementById('technicalEditModal');
  const deleteModal=document.getElementById('technicalDeleteModal');
  if(!menu||!body||!editModal||!deleteModal)return;
  let activeId='';
  let activeButton=null;

  const getItem=()=>Array.isArray(technicalDeadlines)?technicalDeadlines.find(item=>String(item.id)===String(activeId)):null;
  const escDate=value=>{if(!value)return'';const raw=String(value).trim();if(/^\d{4}-\d{2}-\d{2}$/.test(raw))return raw;const m=raw.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);return m?`${m[3]}-${m[2]}-${m[1]}`:''};
  const syncBody=()=>document.body.classList.toggle('modal-open',!!document.querySelector('.modal-overlay:not([hidden])'));

  function closeMenu(){
    if(activeButton)activeButton.setAttribute('aria-expanded','false');
    menu.hidden=true;activeButton=null;
  }
  function openMenu(button,id){
    try{if(typeof closeRowActionsMenu==='function')closeRowActionsMenu()}catch(_){ }
    closeMenu();activeId=id;activeButton=button;button.setAttribute('aria-expanded','true');menu.hidden=false;
    const br=button.getBoundingClientRect(),mr=menu.getBoundingClientRect();
    const left=Math.max(10,Math.min(br.right-mr.width,window.innerWidth-mr.width-10));
    let top=br.bottom+6;if(top+mr.height>window.innerHeight-10)top=br.top-mr.height-6;
    menu.style.left=`${left}px`;menu.style.top=`${Math.max(10,top)}px`;
  }
  function closeEdit(){editModal.hidden=true;document.getElementById('technicalEditError').textContent='';syncBody()}
  function closeDelete(){deleteModal.hidden=true;syncBody()}
  function refresh(){
    try{window.technicalRefreshAll?.()}catch(_){ }
    try{window.technicalRenderDeadlineTableEnhanced?.()}catch(_){ }
    try{refreshHomeDashboard?.()}catch(_){ }
    try{dashboardRefreshNotifications?.()}catch(_){ }
  }

  body.addEventListener('click',event=>{
    const button=event.target.closest('[data-tech-row-menu]');
    if(!button)return;
    event.stopPropagation();openMenu(button,button.dataset.techRowMenu);
  });
  document.addEventListener('click',event=>{if(!menu.hidden&&!menu.contains(event.target)&&!event.target.closest('[data-tech-row-menu]'))closeMenu()});
  window.addEventListener('resize',closeMenu);window.addEventListener('scroll',closeMenu,true);

  document.getElementById('technicalEditAction').addEventListener('click',()=>{
    const item=getItem();if(!item)return;closeMenu();
    document.getElementById('technicalEditSubtitle').textContent=`${item.control||item.category||'Contrôle'} · ${formatRegistration(item.registration||'')}`;
    document.getElementById('technicalEditRegistration').value=formatRegistration(item.registration||'');
    document.getElementById('technicalEditDriver').value=(typeof technicalAssignedDriver==='function'?technicalAssignedDriver(item.registration):'')||'Aucun chauffeur affecté';
    document.getElementById('technicalEditLabel').value=item.label||'';
    document.getElementById('technicalEditGenre').value=item.genre||'';
    document.getElementById('technicalEditGenreField').hidden=item.category!=='mines';
    document.getElementById('technicalEditLastControl').value=escDate(item.lastControl);
    document.getElementById('technicalEditNextControl').value=escDate(item.nextControl);
    document.getElementById('technicalEditOperator').value=item.operator||'';
    editModal.hidden=false;syncBody();requestAnimationFrame(()=>document.getElementById('technicalEditLabel').focus());
  });
  document.getElementById('technicalDeleteAction').addEventListener('click',()=>{
    const item=getItem();if(!item)return;closeMenu();document.getElementById('technicalDeleteRegistration').textContent=formatRegistration(item.registration||'');deleteModal.hidden=false;syncBody();requestAnimationFrame(()=>document.getElementById('technicalDeleteConfirm').focus());
  });

  document.getElementById('technicalEditForm').addEventListener('submit',event=>{
    event.preventDefault();const item=getItem();if(!item)return;
    const registration=formatRegistration(document.getElementById('technicalEditRegistration').value);
    const next=document.getElementById('technicalEditNextControl').value;
    const error=document.getElementById('technicalEditError');
    if(!normalizeRegistration(registration)){error.textContent='Renseignez une immatriculation valide.';return}
    if(!next){error.textContent='Renseignez la date du prochain contrôle.';return}
    item.registration=registration;
    item.label=document.getElementById('technicalEditLabel').value.trim();
    if(item.category==='mines')item.genre=document.getElementById('technicalEditGenre').value.trim();
    item.lastControl=document.getElementById('technicalEditLastControl').value;
    item.nextControl=next;
    item.operator=document.getElementById('technicalEditOperator').value.trim();
    item._modifiedAt=new Date().toISOString();
    item._modifiedBy=typeof dashboardUser==='string'&&dashboardUser?dashboardUser:'Utilisateur';
    const ok=typeof saveTechnicalDeadlines==='function'?saveTechnicalDeadlines():false;
    if(!ok){error.textContent='Impossible d’enregistrer la modification.';return}
    closeEdit();refresh();
  });
  document.getElementById('technicalDeleteConfirm').addEventListener('click',()=>{
    const index=Array.isArray(technicalDeadlines)?technicalDeadlines.findIndex(item=>String(item.id)===String(activeId)):-1;if(index<0)return;
    technicalDeadlines.splice(index,1);if(typeof saveTechnicalDeadlines==='function')saveTechnicalDeadlines();closeDelete();refresh();
  });

  ['technicalEditClose','technicalEditCancel'].forEach(id=>document.getElementById(id).addEventListener('click',closeEdit));
  ['technicalDeleteClose','technicalDeleteCancel'].forEach(id=>document.getElementById(id).addEventListener('click',closeDelete));
  editModal.addEventListener('click',event=>{if(event.target===editModal)closeEdit()});
  deleteModal.addEventListener('click',event=>{if(event.target===deleteModal)closeDelete()});
  document.addEventListener('keydown',event=>{if(event.key!=='Escape')return;if(!editModal.hidden)closeEdit();else if(!deleteModal.hidden)closeDelete();else closeMenu()});
})();
