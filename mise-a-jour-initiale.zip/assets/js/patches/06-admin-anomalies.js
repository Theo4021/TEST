(function(){
  const $=(s,r=document)=>r.querySelector(s);
  const $$=(s,r=document)=>Array.from(r.querySelectorAll(s));
  const esc=(v)=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
  const state={filter:'all',search:''};

  function ensureQualityActionCenter(){
    const list=$('#qualityList');
    if(!list)return false;
    const card=list.closest('.production-admin-card');
    if(card)card.classList.add('quality-action-center-card');
    list.classList.add('quality-action-list');
    const body=list.closest('.production-admin-body');
    if(!body)return true;

    if(!$('#qualityActionToolbar')){
      const summary=$('.quality-summary',body);
      const help=document.createElement('div');
      help.className='quality-help-line';
      help.id='qualityActionHelp';
      help.innerHTML='<strong>Correction guidée :</strong> cliquez sur « Corriger » pour ouvrir directement la bonne page avec l’élément déjà recherché. Après l’enregistrement, l’anomalie disparaît automatiquement.';
      summary?.insertAdjacentElement('afterend',help);

      const toolbar=document.createElement('div');
      toolbar.className='quality-action-toolbar';
      toolbar.id='qualityActionToolbar';
      toolbar.innerHTML=`
        <div class="quality-action-search-wrap">
          <span class="quality-action-search-icon">⌕</span>
          <input class="quality-action-search" id="qualityIssueSearch" type="search" placeholder="Rechercher une plaque, un chauffeur, un permis, une carte...">
        </div>
        <div class="quality-action-filters" role="group" aria-label="Filtrer les anomalies">
          <button class="quality-action-filter active" type="button" data-quality-filter="all">Toutes</button>
          <button class="quality-action-filter" type="button" data-quality-filter="high">Critiques</button>
          <button class="quality-action-filter" type="button" data-quality-filter="warn">À vérifier</button>
        </div>`;
      help.insertAdjacentElement('afterend',toolbar);
      const count=document.createElement('div');
      count.className='quality-result-count';count.id='qualityResultCount';
      toolbar.insertAdjacentElement('afterend',count);

      $('#qualityIssueSearch')?.addEventListener('input',event=>{state.search=String(event.target.value||'').trim().toLocaleLowerCase('fr');renderQualityActionCenter();});
      toolbar.addEventListener('click',event=>{
        const btn=event.target.closest('[data-quality-filter]');if(!btn)return;
        state.filter=btn.dataset.qualityFilter||'all';
        $$('.quality-action-filter',toolbar).forEach(b=>b.classList.toggle('active',b===btn));
        renderQualityActionCenter();
      });
    }
    return true;
  }

  function plateFrom(text){
    const match=String(text||'').match(/\b([A-Z]{2})-?(\d{3})-?([A-Z]{2})\b/i);
    return match?`${match[1].toUpperCase()}-${match[2]}-${match[3].toUpperCase()}`:'';
  }
  function techPageFrom(text){
    const hay=String(text||'').toLocaleLowerCase('fr');
    const entries=(typeof TECH_META==='object'&&TECH_META)?Object.entries(TECH_META):[];
    for(const [key,label] of entries){if(hay.includes(String(label).toLocaleLowerCase('fr')))return key;}
    return hay.includes('vidange')?'vidange':'';
  }
  function issueTarget(issue){
    const section=String(issue.section||'');
    const text=String(issue.text||'');
    const plate=plateFrom(text);
    let match;

    if(section==='Parc'){
      match=text.match(/N° de parc\s+([^\s.]+)/i);
      return {label:'Voir dans Parc',view:'parc',searchId:'parkSearch',searchValue:plate||(match?.[1]||'')};
    }
    if(section==='Affectations'){
      let value=plate;
      if(!value){
        match=text.match(/^Chauffeur\s+(.+?)\s+présent/i);if(match)value=match[1];
        if(!value&&text.includes(':'))value=text.split(':')[0].trim();
      }
      return {label:'Voir affectation',view:'affectations',searchId:'affSearch',searchValue:value};
    }
    if(section==='Chauffeurs'){
      match=text.match(/N° de permis\s+(.+?)\s+utilisé/i);
      return {label:'Voir chauffeurs',view:'chauffeur',searchId:'driverSearch',searchValue:match?.[1]||''};
    }
    if(section==='Cartes Rungis'){
      match=text.match(/Carte\s+(.+?)\s+présente/i);
      return {label:'Voir les cartes',view:'gestion-administrative',adminTab:'rungis',searchId:'rungisSearch',searchValue:match?.[1]||plate};
    }
    if(section==='Suivi technique'){
      const techPage=techPageFrom(text);
      return {label:'Voir le suivi',view:'suivi-technique',techPage:techPage||'vidange',searchId:techPage&&techPage!=='vidange'?'technicalDeadlineSearch':'vidSearch',searchValue:plate};
    }
    return {label:'Ouvrir la page',view:'administrateur'};
  }

  function issueHint(issue,target){
    const text=String(issue.text||'');
    if(/présente? \d+ fois|utilisé \d+ fois|affecté à \d+ chauffeurs|lignes identiques/i.test(text)) return 'Comparez les lignes affichées puis conservez/corrigez la bonne entrée.';
    if(/hors parc|absent du Parc/i.test(text)) return 'Vérifiez la plaque : ajoutez le véhicule au Parc s’il est actif, sinon corrigez la donnée source.';
    if(/km actuel inférieur/i.test(text)) return 'Corrigez le kilométrage actuel ou l’historique d’entretien du véhicule.';
    if(/aucune date d’échéance/i.test(text)) return 'Renseignez l’échéance dans la sous-page technique concernée.';
    return `Ouvre ${target.label.toLocaleLowerCase('fr')} avec le bon filtre.`;
  }

  function showViewSafe(view){
    if(typeof showSection==='function'){showSection(view);return;}
    if(typeof showView==='function'){
      const nav=$$('.nav-btn[data-view]').find(b=>b.dataset.view===view);
      showView(view,nav?.innerText?.trim()||view,view);
    }
  }
  function setSearch(id,value){
    if(!id)return;
    const input=$('#'+id);if(!input)return;
    input.value=value||'';
    input.dispatchEvent(new Event('input',{bubbles:true}));
    input.dispatchEvent(new Event('change',{bubbles:true}));
    setTimeout(()=>{try{input.focus();input.select?.();}catch{}},80);
  }
  function openIssue(issue){
    const target=issueTarget(issue);
    if(target.view==='gestion-administrative'){
      showViewSafe('gestion-administrative');
      if(target.adminTab&&typeof switchAdminTab==='function')switchAdminTab(target.adminTab);
      setTimeout(()=>setSearch(target.searchId,target.searchValue),60);
      return;
    }
    if(target.view==='suivi-technique'){
      showViewSafe('suivi-technique');
      setTimeout(()=>{
        if(target.techPage&&typeof window.technicalOpenPage==='function')window.technicalOpenPage(target.techPage);
        setTimeout(()=>setSearch(target.searchId,target.searchValue),70);
      },40);
      return;
    }
    if(target.view==='administrateur')return;
    showViewSafe(target.view);
    setTimeout(()=>setSearch(target.searchId,target.searchValue),60);
  }

  function filteredIssues(){
    let issues=(typeof dashboardDataIssues==='function'?dashboardDataIssues():[])||[];
    if(state.filter!=='all')issues=issues.filter(i=>i.level===state.filter);
    if(state.search){
      issues=issues.filter(i=>`${i.section||''} ${i.text||''}`.toLocaleLowerCase('fr').includes(state.search));
    }
    return issues;
  }

  function renderQualityActionCenter(){
    if(!ensureQualityActionCenter())return;
    const list=$('#qualityList');
    const score=$('#qualityScore'),title=$('#qualityTitle'),subtitle=$('#qualitySubtitle'),count=$('#qualityResultCount');
    const all=(typeof dashboardDataIssues==='function'?dashboardDataIssues():[])||[];
    const high=all.filter(x=>x.level==='high').length;
    const warn=all.length-high;
    const scoreValue=Math.max(0,100-high*8-warn*3);
    if(score){score.textContent=scoreValue;score.className='quality-score '+(scoreValue>=90?'good':scoreValue>=70?'warn':'bad');}
    if(title)title.textContent=all.length?`${all.length} anomalie${all.length>1?'s':''} détectée${all.length>1?'s':''}`:'Données cohérentes';
    if(subtitle)subtitle.textContent=all.length?`${high} critique${high>1?'s':''} · ${warn} à vérifier`:'Aucune anomalie détectée.';

    const issues=filteredIssues();
    if(count)count.textContent=issues.length===all.length?`${issues.length} anomalie${issues.length>1?'s':''}`:`${issues.length} affichée${issues.length>1?'s':''} sur ${all.length}`;
    if(!issues.length){
      list.innerHTML=`<div class="quality-empty-enhanced"><strong>${all.length?'Aucun résultat':'Tout est propre'}</strong>${all.length?'Aucune anomalie ne correspond au filtre actuel.':'Aucune anomalie détectée dans les données.'}</div>`;
      return;
    }

    const groups=new Map();
    issues.forEach(issue=>{const key=issue.section||'Autres';if(!groups.has(key))groups.set(key,[]);groups.get(key).push(issue);});
    list.innerHTML=[...groups.entries()].map(([section,rows])=>`
      <section class="quality-group-card" data-quality-group="${esc(section)}">
        <button class="quality-group-head" type="button">
          <span class="quality-group-title">${esc(section)}</span>
          <span class="quality-group-count">${rows.length}</span>
          <span class="quality-group-chevron">›</span>
        </button>
        <div class="quality-group-body">
          ${rows.map((issue,index)=>{const target=issueTarget(issue);return `
            <div class="quality-action-row" data-quality-issue="${esc(section)}:${index}">
              <span class="quality-severity ${issue.level==='high'?'high':'warn'}">${issue.level==='high'?'CRITIQUE':'À VÉRIFIER'}</span>
              <span class="quality-action-copy">
                <span class="quality-action-text">${esc(issue.text)}</span>
                <span class="quality-action-hint">${esc(issueHint(issue,target))}</span>
              </span>
              <button class="quality-fix-btn" type="button" data-quality-fix="1">${esc(target.label)}</button>
            </div>`}).join('')}
        </div>
      </section>`).join('');
    list._qualityGroupedIssues=[...groups.entries()].map(([section,rows])=>({section,rows}));
  }

  document.addEventListener('click',event=>{
    const head=event.target.closest('.quality-group-head');
    if(head&&head.closest('#qualityList')){head.closest('.quality-group-card')?.classList.toggle('collapsed');return;}
    const fix=event.target.closest('[data-quality-fix]');
    if(!fix)return;
    const row=fix.closest('.quality-action-row');
    const group=row?.closest('.quality-group-card');
    if(!row||!group)return;
    const section=group.dataset.qualityGroup||'';
    const rows=filteredIssues().filter(i=>(i.section||'Autres')===section);
    const siblings=$$('.quality-action-row',group);
    const index=siblings.indexOf(row);
    const issue=rows[index];
    if(issue)openIssue(issue);
  });

  $('#qualityRefresh')?.addEventListener('click',()=>setTimeout(renderQualityActionCenter,0));

  const previousRender=typeof dashboardRenderQuality==='function'?dashboardRenderQuality:null;
  if(previousRender){
    dashboardRenderQuality=function(){
      try{previousRender.apply(this,arguments);}catch(error){console.warn('Ancien contrôle qualité',error);}
      renderQualityActionCenter();
    };
  }

  // Réactualise le centre quand les données changent via les principaux rendus.
  const refreshNames=['renderPark','renderAffectations','renderDriverList','renderVidTable','renderRungis'];
  refreshNames.forEach(name=>{
    try{
      const original=globalThis[name];
      if(typeof original!=='function'||original.__qualityWrapped)return;
      const wrapped=function(){const result=original.apply(this,arguments);setTimeout(renderQualityActionCenter,0);return result;};
      wrapped.__qualityWrapped=true;globalThis[name]=wrapped;
    }catch{}
  });

  ensureQualityActionCenter();
  renderQualityActionCenter();
})();
