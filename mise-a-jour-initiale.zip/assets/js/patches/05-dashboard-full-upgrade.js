(function(){
  if(window.__dashboardFullUpgradeApplied) return;
  window.__dashboardFullUpgradeApplied=true;

  const TECH_META={tachy:'Tachygraphe',mines:'Mines',limiteur:'Limiteur',confinement:'Confinement',sanitaire:'Sanitaire / ATP'};
  let planningWindow='30';

  const $=(s,r=document)=>r.querySelector(s);
  const $$=(s,r=document)=>Array.from(r.querySelectorAll(s));
  const esc=v=>String(v??'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  const norm=v=>typeof normalizeAffText==='function'?normalizeAffText(v):String(v||'').toLowerCase();
  function dateOf(value){
    if(!value) return null;
    const raw=String(value).trim();
    let d=null;
    if(/^\d{4}-\d{2}-\d{2}$/.test(raw)) d=new Date(raw+'T00:00:00');
    else { const m=raw.match(/^(\d{2})\/(\d{2})\/(\d{4})$/); if(m) d=new Date(`${m[3]}-${m[2]}-${m[1]}T00:00:00`); }
    return d&&Number.isFinite(d.getTime())?d:null;
  }
  function dayDiff(value){
    const due=dateOf(value);if(!due)return null;
    const today=new Date();today.setHours(0,0,0,0);return Math.ceil((due-today)/86400000);
  }
  function fmtDate(value){const d=dateOf(value);return d?d.toLocaleDateString('fr-FR'):value||'—'}
  function deadlineStatus(item){
    const days=dayDiff(item.nextControl);
    if(days===null)return {key:'empty',label:'Sans date',days:null};
    if(days<0)return {key:'late',label:'Dépassé',days};
    if(days<=30)return {key:'soon',label:'À prévoir',days};
    return {key:'ok',label:'À jour',days};
  }
  function currentAssignmentForPlate(registration){
    const reg=normalizeRegistration(registration);
    return affectations.find(a=>normalizeRegistration(a.tractor)===reg||normalizeRegistration(a.semi)===reg)||null;
  }
  function currentDriverForPlate(registration){
    const reg=normalizeRegistration(registration);const seen=new Set();
    return affectations
      .filter(a=>normalizeRegistration(a.tractor)===reg||normalizeRegistration(a.semi)===reg)
      .map(a=>String(a.name||'').trim())
      .filter(name=>{const key=norm(name);if(!key||seen.has(key))return false;seen.add(key);return true})
      .sort((a,b)=>a.localeCompare(b,'fr',{numeric:true,sensitivity:'base'}))
      .join(' · ');
  }
  function isDriverMismatch(item){return false}
  function techItemInPark(item){return parkData.some(v=>normalizeRegistration(v.registration)===normalizeRegistration(item.registration))}
  function techQualityIssues(){
    const issues=[];
    const counts=new Map();
    (technicalDeadlines||[]).forEach(item=>{
      const reg=normalizeRegistration(item.registration);
      const key=`${item.category}|${reg}|${item.nextControl||''}|${norm(item.label||item.control||'')}`;
      if(reg)counts.set(key,(counts.get(key)||0)+1);
      if(reg&&!techItemInPark(item)) issues.push({level:'warn',section:'Suivi technique',text:`${formatRegistration(item.registration)} : présent dans ${TECH_META[item.category]||item.category} mais absent du Parc.`});
      if(!item.nextControl) issues.push({level:'warn',section:'Suivi technique',text:`${formatRegistration(item.registration)||'Ligne '+(item.excelRow||'')} : aucune date d’échéance dans ${TECH_META[item.category]||item.category}.`});
    });
    counts.forEach((count,key)=>{if(count>1){const [category,reg]=key.split('|');issues.push({level:'high',section:'Suivi technique',text:`${formatRegistration(reg)} : ${count} lignes identiques dans ${TECH_META[category]||category}.`})}});
    return issues;
  }

  /* 1. Planning technique commun */
  function ensureTechnicalPlanning(){
    const hub=$('#technicalHub');const modules=$('#technicalModulesGrid');if(!hub||!modules)return;
    if(!$('#technicalHubQuality')){
      const kpis=$('.technical-overview-kpis',hub);
      if(kpis){
        const box=document.createElement('div');box.className='card technical-overview-kpi technical-quality-kpi';box.innerHTML='<div class="technical-kpi-label">À VÉRIFIER</div><div class="technical-kpi-value" id="technicalHubQuality">0</div><div class="technical-kpi-sub">Incohérences détectées</div>';
        kpis.appendChild(box);
        kpis.classList.add('five');
      }
    }
    if($('#technicalPlanningCard')) return;
    const card=document.createElement('div');card.className='card technical-planning-card';card.id='technicalPlanningCard';
    card.innerHTML=`<div class="technical-planning-head"><div><div class="technical-planning-title">PROCHAINES ÉCHÉANCES</div><div class="technical-planning-sub">Vue commune de tous les contrôles réglementaires, triée par date.</div></div><div class="technical-planning-filters"><button class="technical-filter-btn" data-planning-window="late">Dépassées</button><button class="technical-filter-btn active" data-planning-window="30">30 jours</button><button class="technical-filter-btn" data-planning-window="60">60 jours</button><button class="technical-filter-btn" data-planning-window="90">90 jours</button><button class="technical-filter-btn" data-planning-window="all">Toutes</button></div></div><div class="technical-planning-wrap"><table class="technical-planning-table"><thead><tr><th>DATE</th><th>VÉHICULE</th><th>CONTRÔLE</th><th>CHAUFFEUR AFFECTÉ</th><th>STATUT</th></tr></thead><tbody id="technicalPlanningBody"></tbody></table></div><div class="technical-planning-foot"><span id="technicalPlanningCount">0 échéance affichée</span><span>Cliquez sur une ligne pour ouvrir la fiche véhicule</span></div>`;
    modules.parentNode.insertBefore(card,modules);
    card.addEventListener('click',event=>{
      const f=event.target.closest('[data-planning-window]');if(f){planningWindow=f.dataset.planningWindow;$$('[data-planning-window]',card).forEach(b=>b.classList.toggle('active',b===f));renderTechnicalPlanning();return}
      const row=event.target.closest('[data-planning-vehicle]');if(row&&typeof dashboardOpenVehicleDossier==='function') dashboardOpenVehicleDossier(row.dataset.planningVehicle);
    });
  }
  function planningRows(){
    return (technicalDeadlines||[]).filter(item=>dateOf(item.nextControl)).filter(item=>{
      const days=dayDiff(item.nextControl);if(days===null)return false;
      if(planningWindow==='late')return days<0;
      if(planningWindow==='all')return true;
      return days>=0&&days<=Number(planningWindow);
    }).sort((a,b)=>(dateOf(a.nextControl)?.getTime()||0)-(dateOf(b.nextControl)?.getTime()||0)||String(a.registration||'').localeCompare(String(b.registration||''),'fr',{numeric:true,sensitivity:'base'}));
  }
  function renderTechnicalPlanning(){
    ensureTechnicalPlanning();const body=$('#technicalPlanningBody');if(!body)return;
    const rows=planningRows();
    body.innerHTML=rows.length?rows.slice(0,150).map(item=>{
      const status=deadlineStatus(item);const current=currentDriverForPlate(item.registration);const mismatch=isDriverMismatch(item);const missing=!techItemInPark(item);
      return `<tr data-planning-vehicle="${esc(item.registration)}"><td class="planning-date">${esc(fmtDate(item.nextControl))}</td><td class="planning-plate">${esc(formatRegistration(item.registration))}${missing?'<span class="planning-warning">HORS PARC</span>':''}</td><td>${esc(TECH_META[item.category]||item.category)}<div class="technical-planning-sub">${esc(item.label||item.control||'—')}</div></td><td class="planning-driver">${esc(current||'—')}</td><td><span class="tech-status ${status.key==='empty'?'ok':status.key}">${esc(status.label)}</span></td></tr>`;
    }).join(''):`<tr><td colspan="5" class="tech-empty">Aucune échéance dans cette période.</td></tr>`;
    $('#technicalPlanningCount').textContent=`${rows.length} échéance${rows.length>1?'s':''} affichée${rows.length>1?'s':''}`;
    const q=$('#technicalHubQuality');if(q)q.textContent=techQualityIssues().length.toLocaleString('fr-FR');
  }

  /* 2. Cartes modules plus informatives */
  function enrichTechnicalCards(){
    Object.keys(TECH_META).forEach(category=>{
      const card=$(`[data-tech-page="${category}"]`);const meta=card&&$('.technical-module-meta',card);if(!meta)return;
      const rows=(technicalDeadlines||[]).filter(x=>x.category===category);
      const late=rows.filter(x=>(dayDiff(x.nextControl)??99999)<0).length;
      const d30=rows.filter(x=>{const d=dayDiff(x.nextControl);return d!==null&&d>=0&&d<=30}).length;
      let detail=meta.querySelector('.technical-module-detail');
      if(!detail){detail=document.createElement('span');detail.className='technical-module-detail';meta.appendChild(detail)}
      detail.className='technical-module-detail '+(late?'tech-mini-late':d30?'tech-mini-soon':'tech-mini-ok');
      detail.textContent=late?`${late} dépassée${late>1?'s':''} · ${d30} ≤30j`:d30?`${d30} dans 30j`:'Aucune urgence';
    });
    const vidCard=$('[data-tech-page="vidange"]');const meta=vidCard&&$('.technical-module-meta',vidCard);if(meta){
      const late=vidangeData.filter(v=>calculateNextOil(v)<=0).length;const soon=vidangeData.filter(v=>{const n=calculateNextOil(v);return n>0&&n<=5000}).length;
      let detail=meta.querySelector('.technical-module-detail');if(!detail){detail=document.createElement('span');detail.className='technical-module-detail';meta.appendChild(detail)}
      detail.className='technical-module-detail '+(late?'tech-mini-late':soon?'tech-mini-soon':'tech-mini-ok');detail.textContent=late?`${late} à faire · ${soon} ≤5 000 km`:soon?`${soon} à prévoir`:'Aucune urgence';
    }
  }

  /* 3. Filtre 30 / 60 / 90 jours dans les sous-pages */
  function ensureDeadlineWindowFilter(){
    const tools=$('.technical-deadline-tools');if(!tools||$('#technicalDeadlineWindowFilter'))return;
    const select=document.createElement('select');select.className='park-filter technical-window-filter';select.id='technicalDeadlineWindowFilter';select.innerHTML='<option value="">Toutes les dates</option><option value="late">Dépassées</option><option value="30">≤ 30 jours</option><option value="60">≤ 60 jours</option><option value="90">≤ 90 jours</option>';
    tools.appendChild(select);select.addEventListener('change',()=>window.technicalRenderDeadlineTableEnhanced?.());
  }

  /* 4. Notifications regroupees / depliables */
  function buildNotificationGroups(){
    const groups=[];
    const lateVid=vidangeData.map(v=>({v,remaining:calculateNextOil(v)})).filter(x=>x.remaining<=0).sort((a,b)=>a.remaining-b.remaining);
    const soonVid=vidangeData.map(v=>({v,remaining:calculateNextOil(v)})).filter(x=>x.remaining>0&&x.remaining<=5000).sort((a,b)=>a.remaining-b.remaining);
    if(lateVid.length||soonVid.length)groups.push({key:'vidanges',level:lateVid.length?'high':'warn',icon:'!',title:'Vidanges',sub:`${lateVid.length} à faire · ${soonVid.length} à prévoir`,view:'suivi-technique',techPage:'vidange',details:[...lateVid.slice(0,20).map(x=>({title:`${formatRegistration(x.v.registration)} · vidange dépassée`,text:`${Math.abs(Math.round(x.remaining)).toLocaleString('fr-FR')} km dépassés`,view:'suivi-technique',techPage:'vidange',searchId:'vidSearch',searchValue:formatRegistration(x.v.registration),state:'URGENT'})),...soonVid.slice(0,12).map(x=>({title:`${formatRegistration(x.v.registration)} · vidange à prévoir`,text:`${Math.round(x.remaining).toLocaleString('fr-FR')} km restants`,view:'suivi-technique',techPage:'vidange',searchId:'vidSearch',searchValue:formatRegistration(x.v.registration),state:'À VOIR'}))]});
    Object.entries(TECH_META).forEach(([category,label])=>{
      const rows=(technicalDeadlines||[]).filter(x=>x.category===category).map(x=>({item:x,days:dayDiff(x.nextControl)})).filter(x=>x.days!==null&&x.days<=30).sort((a,b)=>a.days-b.days);
      if(!rows.length)return;const late=rows.filter(x=>x.days<0).length;
      groups.push({key:'tech-'+category,level:late?'high':'warn',icon:'◷',title:label,sub:`${late} dépassée${late>1?'s':''} · ${rows.length-late} dans 30 jours`,view:'suivi-technique',techPage:category,details:rows.slice(0,30).map(x=>({title:`${formatRegistration(x.item.registration)} · ${fmtDate(x.item.nextControl)}`,text:`${currentDriverForPlate(x.item.registration)||'Aucun chauffeur affecté'} · ${x.item.label||x.item.control||label}`,view:'suivi-technique',techPage:category,searchId:'technicalDeadlineSearch',searchValue:formatRegistration(x.item.registration),state:x.days<0?'URGENT':'À VOIR'}))});
    });
    const fines=adminFines.filter(f=>f.status==='À traiter');if(fines.length)groups.push({key:'fines',level:'warn',icon:'€',title:'Amendes à traiter',sub:`${fines.length} dossier${fines.length>1?'s':''} demandant une action`,view:'gestion-administrative',adminTab:'fines',details:fines.slice(0,30).map(f=>({title:`${f.reference||formatRegistration(f.vehicle)||'Amende'} · ${f.driver||'—'}`,text:`${f.date||'—'} · ${f.offense||'Infraction non renseignée'}`,view:'gestion-administrative',adminTab:'fines',fineId:f.id,state:'À VOIR'}))});
    const stale=claimData.filter(c=>{if(c.status==='Clos'||!c.date)return false;const d=new Date(c.date+'T00:00:00');return Number.isFinite(d.getTime())&&Date.now()-d.getTime()>14*86400000});if(stale.length)groups.push({key:'claims',level:'warn',icon:'⚠',title:'Sinistres anciens',sub:`${stale.length} ouvert${stale.length>1?'s':''} depuis plus de 14 jours`,view:'sinistre',details:stale.slice(0,30).map(c=>({title:`${c.number||'Sans n° dossier'} · ${c.vehicle||'—'}`,text:`${c.driver||'—'} · ${c.date||'—'} · ${c.status||'Ouvert'}`,view:'sinistre',claimId:c.id,state:'À VOIR'}))});
    const quality=techQualityIssues();if(quality.length)groups.push({key:'quality',level:quality.some(i=>i.level==='high')?'high':'warn',icon:'!',title:'Anomalies de données',sub:`${quality.length} incohérence${quality.length>1?'s':''} technique${quality.length>1?'s':''}`,view:'suivi-technique',details:quality.slice(0,30).map(i=>({title:i.section,text:i.text,view:'suivi-technique',state:i.level==='high'?'URGENT':'À VOIR'}))});
    return groups.sort((a,b)=>({high:0,warn:1,info:2}[a.level]??9)-({high:0,warn:1,info:2}[b.level]??9)||a.title.localeCompare(b.title,'fr'));
  }
  async function openNotifTarget(item){
    $('#notificationPanel').hidden=true;
    if(item.fineId){showView('gestion-administrative','Gestion administrative','gestion-administrative');if(typeof switchAdminTab==='function')switchAdminTab('fines');if(typeof openFineModal==='function')openFineModal(item.fineId);return}
    if(item.claimId){showView('sinistre','Sinistre','sinistre');selectedClaimId=item.claimId;renderClaims();loadClaimDetail();return}
    const nav=$$('.nav-btn').find(b=>b.dataset.view===item.view);if(nav)showView(item.view,item.view==='accueil'?'Gestion de Parc':nav.innerText.trim(),item.view);
    if(item.adminTab&&typeof switchAdminTab==='function')switchAdminTab(item.adminTab);
    if(item.view==='suivi-technique'&&item.techPage&&typeof window.technicalOpenPage==='function')window.technicalOpenPage(item.techPage);
    if(item.searchId&&item.searchValue){const input=$('#'+item.searchId);if(input){input.value=item.searchValue;input.dispatchEvent(new Event('input',{bubbles:true}))}}
  }
  function renderGroupedNotifications(){
    const list=$('#notificationList');if(!list)return;const groups=buildNotificationGroups();const total=groups.reduce((s,g)=>s+g.details.length,0);const badge=$('#notificationBadge');const sub=$('#notificationSubtitle');if(badge){badge.textContent=groups.length>99?'99+':groups.length;badge.hidden=!groups.length}if(sub)sub.textContent=groups.length?`${groups.length} catégorie${groups.length>1?'s':''} à surveiller · ${total} élément${total>1?'s':''}`:'Aucun élément urgent';
    list.innerHTML=groups.length?groups.map((g,gi)=>`<div class="notification-group ${g.level==='warn'?'warn':g.level==='info'?'info':''}" data-notif-group="${gi}"><button class="notification-group-head" type="button"><span class="notification-group-icon">${esc(g.icon)}</span><span><span class="notification-group-title">${esc(g.title)}</span><span class="notification-group-sub">${esc(g.sub)}</span></span><span class="notification-group-count">${g.details.length}</span><span class="notification-group-chevron">›</span></button><div class="notification-group-details">${g.details.map((d,di)=>`<button class="notification-detail-row" type="button" data-notif-detail="${gi}:${di}"><span><span class="notification-detail-title">${esc(d.title)}</span><span class="notification-detail-text">${esc(d.text)}</span></span><span class="notification-detail-state">${esc(d.state||'À VOIR')}</span></button>`).join('')}</div></div>`).join(''):'<div class="notification-empty">Tout est calme pour le moment.</div>';
    list._groupedNotifications=groups;
  }
  const notifList=$('#notificationList');if(notifList&&!notifList.dataset.groupHandler){notifList.dataset.groupHandler='1';notifList.addEventListener('click',event=>{const head=event.target.closest('.notification-group-head');if(head){head.closest('.notification-group')?.classList.toggle('open');event.stopPropagation();return}const detail=event.target.closest('[data-notif-detail]');if(detail){const [gi,di]=detail.dataset.notifDetail.split(':').map(Number);const item=notifList._groupedNotifications?.[gi]?.details?.[di];if(item){event.stopImmediatePropagation();openNotifTarget(item)}}},true)}
  const bell=$('#notificationBell');if(bell){bell.addEventListener('click',()=>setTimeout(renderGroupedNotifications,0),true)}
  window.dashboardRefreshNotifications=renderGroupedNotifications;

  /* 5. Fiche vehicule par onglets */
  function vehicleTechRows(plate){return (technicalDeadlines||[]).filter(x=>normalizeRegistration(x.registration)===normalizeRegistration(plate)).sort((a,b)=>(dateOf(a.nextControl)?.getTime()??Number.MAX_SAFE_INTEGER)-(dateOf(b.nextControl)?.getTime()??Number.MAX_SAFE_INTEGER))}
  function upgradeVehicleDossier(){
    const body=$('#vehicleDossierBody');if(!body||!dashboardCurrentVehicleDossier)return;
    const plate=dashboardCurrentVehicleDossier;const links=dashboardFindVehicleLinks(plate);
    $$('.vehicle-dossier-tabs,.vehicle-tab-panels',body).forEach(x=>x.remove());
    const existingGrid=$('.vehicle-dossier-grid',body);if(existingGrid)existingGrid.style.display='none';
    const existingActions=$('.vehicle-dossier-actions',body);if(existingActions)existingActions.style.display='none';
    const tabs=document.createElement('div');tabs.className='vehicle-dossier-tabs';tabs.innerHTML='<button class="vehicle-dossier-tab active" data-vehicle-tab="summary">Résumé</button><button class="vehicle-dossier-tab" data-vehicle-tab="technical">Technique</button><button class="vehicle-dossier-tab" data-vehicle-tab="claims">Sinistres</button><button class="vehicle-dossier-tab" data-vehicle-tab="fines">Amendes</button><button class="vehicle-dossier-tab" data-vehicle-tab="admin">Administratif</button>';
    const panels=document.createElement('div');panels.className='vehicle-tab-panels';
    const techRows=vehicleTechRows(plate);const maint=links.maintenance;const currentDriver=links.assignment?.name||'—';
    panels.innerHTML=`<div class="vehicle-tab-panel" data-vehicle-panel="summary"><div class="vehicle-admin-grid"><div class="vehicle-admin-box"><div class="vehicle-admin-label">AFFECTATION</div><div class="vehicle-admin-value">${esc(currentDriver)}</div></div><div class="vehicle-admin-box"><div class="vehicle-admin-label">TYPE / N° PARC</div><div class="vehicle-admin-value">${esc(links.vehicle?.type||'—')} · ${esc(links.vehicle?.parkNumber||'—')}</div></div><div class="vehicle-admin-box"><div class="vehicle-admin-label">TÉLÉPHONE PRO</div><div class="vehicle-admin-value">${esc(links.assignment?.phone||'—')}</div></div><div class="vehicle-admin-box"><div class="vehicle-admin-label">DERNIÈRE MODIFICATION</div><div class="vehicle-admin-value">${esc(links.vehicle?._modifiedBy||'—')} · ${esc(typeof dashboardDateTime==='function'?dashboardDateTime(links.vehicle?._modifiedAt):'—')}</div></div></div></div><div class="vehicle-tab-panel" data-vehicle-panel="technical" hidden><div class="vehicle-tech-list">${maint?`<div class="vehicle-tech-row"><span class="vehicle-tech-category">Vidange</span><span><div class="vehicle-tech-main">${calculateNextOil(maint)<=0?'À faire':calculateNextOil(maint)<=5000?'À prévoir':'À jour'}</div><div class="vehicle-tech-sub">${Math.abs(Math.round(calculateNextOil(maint))).toLocaleString('fr-FR')} km ${calculateNextOil(maint)<=0?'dépassés':'restants'}</div></span><span class="vehicle-tech-status ${calculateNextOil(maint)<=0?'late':calculateNextOil(maint)<=5000?'soon':'ok'}">${calculateNextOil(maint)<=0?'URGENT':calculateNextOil(maint)<=5000?'À VOIR':'OK'}</span></div>`:''}${techRows.map(item=>{const st=deadlineStatus(item);return `<div class="vehicle-tech-row"><span class="vehicle-tech-category">${esc(TECH_META[item.category]||item.category)}</span><span><div class="vehicle-tech-main">${esc(fmtDate(item.nextControl))} · ${esc(item.label||item.control||'Contrôle')}</div><div class="vehicle-tech-sub">${esc(currentDriverForPlate(item.registration)||'Aucun chauffeur affecté')}</div></span><span class="vehicle-tech-status ${st.key==='empty'?'ok':st.key}">${esc(st.label)}</span></div>`}).join('')}${!maint&&!techRows.length?'<div class="vehicle-tab-empty">Aucun suivi technique pour ce véhicule.</div>':''}</div></div><div class="vehicle-tab-panel" data-vehicle-panel="claims" hidden><div class="vehicle-simple-list">${links.claims.length?links.claims.map(c=>`<button class="vehicle-simple-row" type="button" data-tab-claim="${esc(c.id)}"><span class="vehicle-tech-category">${esc(c.status||'Sinistre')}</span><span><div class="vehicle-tech-main">${esc(c.number||'Sans n° dossier')}</div><div class="vehicle-tech-sub">${esc(c.date||'—')} · ${esc(c.type||'Sinistre')}</div></span><span class="vehicle-tech-status">›</span></button>`).join(''):'<div class="vehicle-tab-empty">Aucun sinistre lié.</div>'}</div></div><div class="vehicle-tab-panel" data-vehicle-panel="fines" hidden><div class="vehicle-simple-list">${links.fines.length?links.fines.map(f=>`<button class="vehicle-simple-row" type="button" data-tab-fine="${esc(f.id)}"><span class="vehicle-tech-category">${esc(f.status||'Amende')}</span><span><div class="vehicle-tech-main">${esc(f.reference||'Amende')}</div><div class="vehicle-tech-sub">${esc(f.date||'—')} · ${esc(f.offense||'—')}</div></span><span class="vehicle-tech-status">›</span></button>`).join(''):'<div class="vehicle-tab-empty">Aucune amende liée.</div>'}</div></div><div class="vehicle-tab-panel" data-vehicle-panel="admin" hidden><div class="vehicle-admin-grid"><div class="vehicle-admin-box"><div class="vehicle-admin-label">CARTE RUNGIS</div><div class="vehicle-admin-value">${esc(links.rungis.map(r=>r.cardNumber).filter(Boolean).join(', ')||'—')}</div></div><div class="vehicle-admin-box"><div class="vehicle-admin-label">CHAUFFEUR</div><div class="vehicle-admin-value">${esc(currentDriver)}</div></div><div class="vehicle-admin-box"><div class="vehicle-admin-label">TRACTEUR / SEMI ASSOCIÉ</div><div class="vehicle-admin-value">${esc(links.assignment?(links.vehicle?.type==='Tracteur'?formatRegistration(links.assignment.semi||''):formatRegistration(links.assignment.tractor||''))||'—':'—')}</div></div><div class="vehicle-admin-box"><div class="vehicle-admin-label">N° PERSONNEL</div><div class="vehicle-admin-value">${esc(links.assignment?.personal||'—')}</div></div></div></div>`;
    const anchor=$('.vehicle-summary-grid',body);if(anchor){anchor.insertAdjacentElement('afterend',tabs);tabs.insertAdjacentElement('afterend',panels)}else{body.prepend(panels);body.prepend(tabs)}
    tabs.addEventListener('click',event=>{const btn=event.target.closest('[data-vehicle-tab]');if(!btn)return;$$('.vehicle-dossier-tab',tabs).forEach(b=>b.classList.toggle('active',b===btn));$$('.vehicle-tab-panel',panels).forEach(p=>p.hidden=p.dataset.vehiclePanel!==btn.dataset.vehicleTab)});
    panels.addEventListener('click',event=>{const fine=event.target.closest('[data-tab-fine]');if(fine){dashboardCloseVehicleDossier();showView('gestion-administrative','Gestion administrative','gestion-administrative');if(typeof switchAdminTab==='function')switchAdminTab('fines');openFineModal(fine.dataset.tabFine);return}const claim=event.target.closest('[data-tab-claim]');if(claim){dashboardCloseVehicleDossier();showView('sinistre','Sinistre','sinistre');selectedClaimId=claim.dataset.tabClaim;renderClaims();loadClaimDetail();}});
  }
  const previousOpenVehicle=dashboardOpenVehicleDossier;dashboardOpenVehicleDossier=function(){const r=previousOpenVehicle.apply(this,arguments);setTimeout(upgradeVehicleDossier,0);return r;};

  /* 6. Etendre le controle qualite existant */
  if(typeof dashboardDataIssues==='function'){
    const baseIssues=dashboardDataIssues;dashboardDataIssues=function(){const initial=baseIssues.apply(this,arguments)||[];const extra=techQualityIssues();const seen=new Set();return [...initial,...extra].filter(item=>{const key=`${item.section}|${item.text}`;if(seen.has(key))return false;seen.add(key);return true}).slice(0,150)};
  }

  /* 7. Sous-page échéances : fenêtre 30/60/90 + indicateurs incohérence */
  ensureDeadlineWindowFilter();
  window.technicalRenderDeadlineTableEnhanced=function(){
    const search=$('#technicalDeadlineSearch');const statusFilter=$('#technicalDeadlineStatusFilter');const windowFilter=$('#technicalDeadlineWindowFilter');const body=$('#technicalDeadlineBody');if(!search||!statusFilter||!body)return;
    const category=(()=>{const t=$('#technicalDeadlineTitle')?.textContent||'';return Object.keys(TECH_META).find(k=>TECH_META[k]===t)||null})();if(!category)return;
    const cols=category==='mines'?[['registration','IMMATRICULATION'],['driver','CHAUFFEUR'],['genre','GENRE'],['label','LIBELLÉ'],['nextControl','PROCHAIN CONTRÔLE'],['operator','EXPLOITANT'],['_status','STATUT']]:[['registration','IMMATRICULATION'],['driver','CHAUFFEUR'],['label','LIBELLÉ'],['lastControl','DERNIER CONTRÔLE'],['nextControl','PROCHAIN CONTRÔLE'],['operator','EXPLOITANT'],['_status','STATUT']];
    const qv=norm(search.value);const sf=statusFilter.value;const wf=windowFilter?.value||'';
    const rows=(technicalDeadlines||[]).filter(x=>x.category===category).filter(item=>{const st=deadlineStatus(item);if(sf&&st.key!==sf)return false;const days=dayDiff(item.nextControl);if(wf==='late'&&!(days!==null&&days<0))return false;if(['30','60','90'].includes(wf)&&!(days!==null&&days>=0&&days<=Number(wf)))return false;const hay=norm(`${item.registration||''} ${currentDriverForPlate(item.registration)||''} ${item.genre||''} ${item.model||''} ${item.label||''} ${item.operator||''} ${item.company||''} ${item.sourceState||''}`);return !qv||hay.includes(qv)}).sort((a,b)=>(dateOf(a.nextControl)?.getTime()??Number.MAX_SAFE_INTEGER)-(dateOf(b.nextControl)?.getTime()??Number.MAX_SAFE_INTEGER));
    body.innerHTML=rows.length?rows.map(item=>{const st=deadlineStatus(item);return `<tr data-tech-id="${esc(item.id)}">${cols.map(([key])=>{if(key==='_status')return `<td><span class="tech-status ${st.key==='empty'?'ok':st.key}">${esc(st.label)}</span></td>`;if(key==='registration')return `<td><span class="tech-plate" data-tech-vehicle="${esc(item.registration)}">${esc(formatRegistration(item.registration)||'—')}</span>${!techItemInPark(item)?'<span class="tech-row-warning">HORS PARC</span>':''}</td>`;if(key==='driver')return `<td><span class="tech-driver tech-driver-linked">${esc(currentDriverForPlate(item.registration)||'—')}</span></td>`;if(key==='nextControl'||key==='lastControl')return `<td class="tech-date">${esc(fmtDate(item[key]))}</td>`;return `<td>${esc(item[key]||'—')}</td>`}).join('')}<td class="tech-actions-cell"><button class="row-menu tech-row-menu" type="button" data-tech-row-menu="${esc(item.id)}" aria-label="Actions pour ${esc(item.registration||'cette ligne')}" aria-haspopup="menu" aria-expanded="false">•••</button></td></tr>`}).join(''):`<tr><td class="tech-empty" colspan="${cols.length+1}">Aucune échéance ne correspond aux filtres.</td></tr>`;
    $('#technicalDeadlineCountLabel').textContent=`${rows.length} ligne${rows.length>1?'s':''} affichée${rows.length>1?'s':''}`;
  };
  $('#technicalDeadlineSearch')?.addEventListener('input',()=>setTimeout(window.technicalRenderDeadlineTableEnhanced,0));$('#technicalDeadlineStatusFilter')?.addEventListener('change',()=>setTimeout(window.technicalRenderDeadlineTableEnhanced,0));
  const oldTechOpen=window.technicalOpenPage;if(typeof oldTechOpen==='function')window.technicalOpenPage=function(page){oldTechOpen(page);ensureDeadlineWindowFilter();setTimeout(()=>{if(page&&page!=='vidange')window.technicalRenderDeadlineTableEnhanced?.();renderTechnicalPlanning();enrichTechnicalCards()},0)};
  const oldRefresh=window.technicalRefreshAll;if(typeof oldRefresh==='function')window.technicalRefreshAll=function(){oldRefresh();renderTechnicalPlanning();enrichTechnicalCards();renderGroupedNotifications()};

  /* 8. Accueil = resume, notifications = actions uniquement */
  function simplifyHomeActions(){
    const list=$('#homeTaskList');if(!list)return;
    $$('.home-task-row',list).forEach(row=>{if(row.dataset.homeAction==='vehicle')row.remove()});
    const count=$('#homeActionCount');if(count)count.textContent=String($$('.home-task-row',list).length);
  }
  const homeObserver=new MutationObserver(simplifyHomeActions);if($('#homeTaskList'))homeObserver.observe($('#homeTaskList'),{childList:true});

  ensureTechnicalPlanning();renderTechnicalPlanning();enrichTechnicalCards();renderGroupedNotifications();simplifyHomeActions();
})();
