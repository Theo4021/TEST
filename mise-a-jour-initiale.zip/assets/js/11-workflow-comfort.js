
(()=>{
  const q=id=>document.getElementById(id);
  function filter(id,anchor,label,options,render){
    const select=document.createElement('select');select.id=id;select.className='workflow-filter';select.setAttribute('aria-label',label);
    options.forEach(([value,text])=>select.add(new Option(text,value)));
    const target=q(anchor);target.insertAdjacentElement('afterend',select);
    select.addEventListener('change',render);return select;
  }
  filter('parkAssignmentFilter','parkTypeFilter','Filtrer les affectations',[['','Toutes les affectations'],['assigned','Affectés'],['unassigned','Non affectés']],()=>renderParkTable());
  filter('fineListStatus','fineSearch','Filtrer les amendes',[['','Tous les statuts'],['todo','À traiter / À prévenir'],['À traiter','À traiter'],['À prévenir','À prévenir'],['pending','À envoyer / Contesté'],['Clos','Clos']],()=>renderFines());
  filter('vidStatusFilter','vidSearch','Filtrer les vidanges',[['','Tous les statuts'],['late','À faire'],['soon','À prévoir'],['ok','À jour']],()=>renderVidTable());
  function setFilter(id,value){const el=q(id);el.value=value;el.dispatchEvent(new Event('change',{bubbles:true}));}
  function counter(id,action){
    const value=q(id);if(!value)return;
    const card=value.closest('.card,.home-stat-box');if(!card)return;
    card.classList.add('counter-filter');card.setAttribute('role','button');card.tabIndex=0;card.title='Afficher les éléments correspondants';
    card.addEventListener('click',e=>{e.stopImmediatePropagation();action();},true);
    card.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();card.click();}});
  }
  [['parkTotal',''],['parkTractors','Tracteur'],['parkTrailers','Semi']].forEach(([id,type])=>counter(id,()=>{parkSearch.value='';parkTypeFilter.value=type;setFilter('parkAssignmentFilter','');}));
  counter('parkUnassigned',()=>{parkSearch.value='';parkTypeFilter.value='';setFilter('parkAssignmentFilter','unassigned');});
  counter('homeUnassigned',()=>{showView('parc','Parc','parc');parkSearch.value='';parkTypeFilter.value='';setFilter('parkAssignmentFilter','unassigned');});
  [['fineTotal',''],['fineTodo','todo'],['finePending','pending'],['fineClosed','Clos']].forEach(([id,status])=>counter(id,()=>{q('fineSearch').value='';setFilter('fineListStatus',status);}));
  [['vidTotal',''],['vidLate','late'],['vidSoon','soon'],['vidOk','ok']].forEach(([id,status])=>counter(id,()=>{q('vidSearch').value='';setFilter('vidStatusFilter',status);}));
  [['technicalDeadlineTotal',''],['technicalDeadlineLate','late'],['technicalDeadlineSoon','soon'],['technicalDeadlineOk','ok']].forEach(([id,status])=>counter(id,()=>{q('technicalDeadlineSearch').value='';if(q('technicalDeadlineWindowFilter'))q('technicalDeadlineWindowFilter').value='';setFilter('technicalDeadlineStatusFilter',status);}));

  const positions=new Map();
  window.dashboardRememberPosition=()=>{
    const page=document.querySelector('.view.active');if(!page)return;
    positions.set(page.id,{x:window.scrollX,y:window.scrollY,children:[...page.querySelectorAll('*')].filter(el=>el.scrollTop||el.scrollLeft).map(el=>[el,el.scrollTop,el.scrollLeft])});
  };
  window.dashboardRestorePosition=id=>requestAnimationFrame(()=>{
    const state=positions.get(id);window.scrollTo({top:state?.y||0,left:state?.x||0,behavior:'instant'});
    state?.children.forEach(([el,top,left])=>{el.scrollTop=top;el.scrollLeft=left;});
  });
  const rememberedFilters=['parkSearch','parkTypeFilter','parkAssignmentFilter','driverSearch','driverStatusFilter','fineSearch','fineListStatus','vidSearch','vidStatusFilter','affSearch'];
  try{const saved=JSON.parse(sessionStorage.getItem('dashboard-list-filters')||'{}');rememberedFilters.forEach(id=>{if(q(id)&&typeof saved[id]==='string')q(id).value=saved[id];});}catch{}
  function rememberFilters(){try{sessionStorage.setItem('dashboard-list-filters',JSON.stringify(Object.fromEntries(rememberedFilters.filter(id=>q(id)).map(id=>[id,q(id).value]))));}catch{}}
  document.addEventListener('input',rememberFilters);document.addEventListener('change',rememberFilters);

  let driverBaseline=null;
  const values=root=>JSON.stringify([...root.querySelectorAll('input:not([type="file"]),select,textarea')].map(el=>[el.id,el.type==='checkbox'?el.checked:el.value]));
  const driverDirty=()=>driverBaseline!==null && driverBaseline!==values(q('driverDetailContent'));
  window.dashboardAllowLeave=()=>{
    if(!driverDirty())return true;
    if(!confirm('La fiche chauffeur contient des modifications non enregistrées. Les abandonner ?'))return false;
    driverBaseline=null;fillDriverForm();window.driverLockReadonly?.(true);return true;
  };
  window.addEventListener('click',event=>{
    const target=event.target.closest?.('button,[data-driver-id],[data-home-view]');if(!target)return;
    if(target.closest('.nav')||target.matches('[data-driver-id],#cancelDriverEdit')||target.hasAttribute('data-home-view')||target.hasAttribute('data-driver-action')){
      if(!window.dashboardAllowLeave()){event.preventDefault();event.stopImmediatePropagation();}
    }
  },true);
  document.addEventListener('click',event=>{
    if(event.target.closest('#editDriver'))driverBaseline=values(q('driverDetailContent'));
    if(event.target.closest('#cancelDriverEdit'))driverBaseline=null;
    if(event.target.closest('#saveDriver'))setTimeout(()=>{if(q('driverSaveNotice').textContent==='Modifications enregistrées.'){driverBaseline=null;history();}},0);
  });
  const modalBaselines=new WeakMap();
  const modalOf=el=>el.closest?.('.modal-overlay');
  document.addEventListener('focusin',event=>{const modal=modalOf(event.target);if(modal&&!modalBaselines.has(modal))modalBaselines.set(modal,values(modal));});
  const dirtyModal=modal=>modalBaselines.has(modal)&&modalBaselines.get(modal)!==values(modal);
  window.addEventListener('click',event=>{
    const modal=modalOf(event.target);if(!modal)return;
    const button=event.target.closest('button');
    if(event.target===modal || (button&&/^(close|cancel)/i.test(button.id))){
      if(dirtyModal(modal)&&!confirm('Abandonner les modifications non enregistrées ?')){event.preventDefault();event.stopImmediatePropagation();return;}
      modalBaselines.delete(modal);
    }
  },true);
  window.addEventListener('keydown',event=>{
    if(event.key!=='Escape')return;
    const modal=[...document.querySelectorAll('.modal-overlay:not([hidden])')].find(dirtyModal);
    if(modal&&!confirm('Abandonner les modifications non enregistrées ?')){event.preventDefault();event.stopImmediatePropagation();}
    else if(modal)modalBaselines.delete(modal);
  },true);
  document.querySelectorAll('.modal-overlay').forEach(modal=>new MutationObserver(()=>{if(modal.hidden)modalBaselines.delete(modal);}).observe(modal,{attributes:true,attributeFilter:['hidden']}));
  window.addEventListener('beforeunload',event=>{if(driverDirty()||[...document.querySelectorAll('.modal-overlay:not([hidden])')].some(dirtyModal)){event.preventDefault();event.returnValue='';}});

  const undo=document.createElement('div');undo.className='workflow-undo';undo.hidden=true;undo.setAttribute('role','status');
  const message=document.createElement('span'),restore=document.createElement('button'),dismiss=document.createElement('button');
  restore.type=dismiss.type='button';restore.textContent='Annuler';dismiss.textContent='×';dismiss.setAttribute('aria-label','Fermer');undo.append(message,restore,dismiss);document.body.append(undo);
  const undoStack=[];
  function updateUndo(){undo.hidden=!undoStack.length;message.textContent=undoStack.at(-1)?.label||'';}
  window.dashboardOfferUndo=(label,action)=>{undoStack.push({label,action});updateUndo();};
  restore.onclick=()=>{const entry=undoStack.at(-1);if(entry&&entry.action()){undoStack.pop();refreshHomeDashboard();updateUndo();}else message.textContent='Restauration impossible : vérifiez les doublons ou le stockage.';};
  dismiss.onclick=()=>{undo.hidden=true;};

  function history(){
    q('driverDepartureHistory')?.remove();const driver=getSelectedDriver();if(!driver?.departureHistory?.length)return;
    const box=document.createElement('details');box.className='departure-history';box.id='driverDepartureHistory';
    const summary=document.createElement('summary');summary.textContent='Historique des départs et affectations';box.append(summary);
    driver.departureHistory.forEach(entry=>{const p=document.createElement('p');p.textContent=new Date(entry.date).toLocaleDateString('fr-FR')+' · '+(entry.released?'Affectations libérées':'Affectations conservées')+' · '+(entry.assignments.map(row=>[row.tractor,row.semi].filter(Boolean).map(formatRegistration).join(' / ')).join(' ; ')||'Aucune affectation');box.append(p);});
    q('driverDetailContent').append(box);
  }
  const oldFill=fillDriverForm;fillDriverForm=function(){const result=oldFill.apply(this,arguments);driverBaseline=null;history();return result;};
  const oldRefresh=refreshHomeDashboard;refreshHomeDashboard=function(){const result=oldRefresh.apply(this,arguments);document.querySelectorAll('.fleet-due small').forEach(el=>{if(/^\d{4}-\d{2}-\d{2}$/.test(el.textContent))el.textContent=el.textContent.split('-').reverse().join('/');});return result;};
  renderParkTable();renderFines();renderVidTable();renderDriverList();renderAffectations();refreshHomeDashboard();history();
})();
