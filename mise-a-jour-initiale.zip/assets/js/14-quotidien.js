/* Shared navigation and attention model for the home, search and notification views. */
(()=>{
  'use strict';
  const q=id=>document.getElementById(id), esc=dashboardEsc;
  const norm=value=>globalNormalize(String(value??'')).replace(/[^a-z0-9]/g,'');
  const plate=value=>formatRegistration(value||'');
  const has=value=>String(value??'').trim()!=='';
  const same=(a,b)=>!!norm(a)&&norm(a)===norm(b);
  const labels={urgent:'Urgent',warn:'À vérifier',info:'Info',ok:'OK'};
  const button=(label,fn)=>{const b=document.createElement('button');b.type='button';b.className='tool-btn';b.textContent=label;b.onclick=fn;return b;};
  function dialog(id,title){
    const el=document.createElement('dialog');el.id=id;el.className='daily-dialog';
    const head=document.createElement('div');head.className='daily-toolbar';
    const h=document.createElement('h2');h.id=id+'Title';h.textContent=title;
    el.setAttribute('aria-labelledby',h.id);head.append(h,button('Fermer',()=>el.close()));el.append(head);document.body.append(el);return el;
  }
  function open(el){if(!el.open)el.showModal();}
  function go(item){
    if(window.dashboardAllowLeave&&!window.dashboardAllowLeave())return;
    document.querySelectorAll('.daily-dialog[open]').forEach(el=>el.close());
    q('notificationPanel').hidden=true;closeGlobalSearch();
    if(item.kind==='vehicle'){dashboardOpenVehicleDossier(item.plate);return;}
    if(item.kind==='driver'){
      showView('chauffeur','Chauffeurs','chauffeur');selectedDriverId=item.id;
      const driver=driverProfiles.find(d=>d.id===item.id);
      driverSearch.value='';driverStatusFilter.value=driverIsInactive(driver)?'inactive':'active';
      renderDriverList();fillDriverForm();window.driverLockReadonly?.(true);return;
    }
    if(item.kind==='fine'){showView('gestion-administrative','Amendes','gestion-administrative');switchAdminTab('fines');openFineModal(item.id);return;}
    if(item.kind==='claim'){showView('sinistre','Sinistres','sinistre');selectedClaimId=item.id;renderClaims();loadClaimDetail();return;}
    if(item.kind==='tech'){
      showView('suivi-technique','Suivi technique','suivi-technique');window.technicalOpenPage(item.category);
      const oil=item.category==='vidange',input=q(oil?'vidSearch':'technicalDeadlineSearch');
      const status=q(oil?'vidStatusFilter':'technicalDeadlineStatusFilter');if(status)status.value='';
      if(q('technicalDeadlineWindowFilter'))q('technicalDeadlineWindowFilter').value='';
      input.value=plate(item.plate);input.dispatchEvent(new Event('input',{bubbles:true}));return;
    }
    if(item.kind==='rungis'){showView('gestion-administrative','Cartes Rungis','gestion-administrative');switchAdminTab('rungis');q('rungisSearch').value=plate(item.plate);renderRungis();}
  }
  function row(item){return `<button type="button" class="daily-row"><span>${esc(item.title)}${item.detail?`<small>${esc(item.detail)}</small>`:''}</span><span class="daily-status" data-daily-tone="${item.tone||'info'}">${esc(item.badge||labels[item.tone]||'Ouvrir')}</span></button>`;}
  function rows(root,items,empty='Aucun résultat.'){root.innerHTML=items.length?items.map(row).join(''):`<div class="daily-empty">${esc(empty)}</div>`;[...root.querySelectorAll('.daily-row')].forEach((el,i)=>el.onclick=()=>go(items[i]));}
  function days(value){
    return fleetDays(value);
  }
  function attention(){
    const items=[];
    adminFines.filter(f=>['aenvoyer','designe','designee','atraiter'].includes(norm(f.status))).forEach(f=>items.push({kind:'fine',id:f.id,title:`Amende · ${f.reference||plate(f.vehicle)}`,detail:f.driver,tone:'urgent',badge:'À envoyer'}));
    vidangeData.forEach(v=>{const n=calculateNextOil(v);if(!has(v.currentKm)||!Number.isFinite(n)||n>5000)return;items.push({kind:'tech',category:'vidange',plate:v.registration,title:`Vidange · ${plate(v.registration)}`,detail:`${Math.abs(Math.round(n)).toLocaleString('fr-FR')} km ${n<=0?'dépassés':'restants'}`,tone:n<=0?'urgent':'warn'});});
    technicalDeadlines.forEach(v=>{if(!parkData.some(p=>same(p.registration,v.registration)))return;const n=days(v.nextControl);if(n===null||n>30)return;items.push({kind:'tech',category:v.category,plate:v.registration,title:`${v.label||v.control||v.category} · ${plate(v.registration)}`,detail:plate(v.registration)+' · '+v.nextControl,tone:n<0?'urgent':'warn'});});
    claimData.filter(c=>norm(c.status)!=='clos').forEach(c=>items.push({kind:'claim',id:c.id,title:`Sinistre · ${c.number||plate(c.vehicle)}`,detail:c.driver,tone:'warn',badge:'Ouvert'}));
    parkData.filter(v=>!isVehicleAssigned(v)).forEach(v=>items.push({kind:'vehicle',plate:v.registration,title:plate(v.registration),detail:v.type,tone:'info',badge:'Non affecté'}));
    return items.sort((a,b)=>({urgent:0,warn:1,info:2}[a.tone]-{urgent:0,warn:1,info:2}[b.tone])||a.title.localeCompare(b.title,'fr'));
  }
  const home=document.createElement('section');home.className='daily-panel daily-home-clean';home.id='dailyHome';
  home.innerHTML='<div class="daily-home-head"><div class="daily-home-heading"><h2>À traiter aujourd’hui</h2><span id="dailyHomeCount"></span></div><div class="daily-home-summary" id="dailyHomeSummary"></div></div><div class="daily-home-actions" id="dailyHomeList"></div><div class="daily-home-footer"><select id="dailyHomeFilter" aria-label="Filtrer les actions"><option value="all">Toutes les actions</option><option value="urgent">Urgent</option><option value="warn">À vérifier</option><option value="info">Info</option></select><button type="button" class="tool-btn" id="dailyHomeMore">Voir toutes les actions</button></div>';
  q('accueil').querySelector('.home-kpis').after(home);
  q('homeDashboardStrip')?.remove();
  function renderHomeRow(item){return `<button type="button" class="daily-home-row"><span class="daily-home-dot" data-daily-tone="${item.tone||'info'}"></span><span><strong>${esc(item.title)}</strong>${item.detail?`<small>${esc(item.detail)}</small>`:''}</span><em>${esc(item.badge||labels[item.tone]||'Ouvrir')}</em></button>`;}
  function refreshHome(){
    const all=attention(),filter=q('dailyHomeFilter').value;
    const list=all.filter(x=>filter==='all'||x.tone===filter);
    const urgent=all.filter(x=>x.tone==='urgent').length,warn=all.filter(x=>x.tone==='warn').length,info=all.filter(x=>x.tone==='info').length;
    q('dailyHomeCount').textContent=all.length?all.length+' actions':'À jour';
    q('dailyHomeSummary').innerHTML=`<button type="button" data-filter="urgent"><span>${urgent}</span><small>Urgent</small></button><button type="button" data-filter="warn"><span>${warn}</span><small>À vérifier</small></button><button type="button" data-filter="info"><span>${info}</span><small>Infos</small></button>`;
    q('dailyHomeSummary').querySelectorAll('button').forEach(btn=>{btn.classList.toggle('active',filter===btn.dataset.filter);btn.onclick=()=>{q('dailyHomeFilter').value=filter===btn.dataset.filter?'all':btn.dataset.filter;refreshHome();};});
    const shown=list.slice(0,5);
    q('dailyHomeList').innerHTML=shown.length?shown.map(renderHomeRow).join(''):`<div class="daily-empty">Rien à traiter ici.</div>`;
    [...q('dailyHomeList').querySelectorAll('.daily-home-row')].forEach((el,i)=>el.onclick=()=>go(shown[i]));
    q('dailyHomeMore').hidden=list.length<=5;q('dailyHomeMore').textContent=list.length>5?'Voir '+list.length+' actions':'Voir toutes les actions';
  }
  q('dailyHomeFilter').onchange=refreshHome;
  q('dailyHomeMore').onclick=()=>{q('notificationPanel').hidden=false;notifications();};
  const oldHome=refreshHomeDashboard;refreshHomeDashboard=function(){const r=oldHome.apply(this,arguments);refreshHome();return r;};

  let notificationFilter='all';
  function notifications(){
    const all=attention(),list=q('notificationList');list.innerHTML='';
    const filters=document.createElement('div');filters.className='daily-toolbar';
    [['all','Tout'],['urgent','Urgent'],['warn','À vérifier'],['info','Info']].forEach(([key,label])=>{const b=button(label,()=>{notificationFilter=key;notifications();});b.setAttribute('aria-pressed',String(notificationFilter===key));filters.append(b);});
    const content=document.createElement('div');content.className='daily-list';list.append(filters,content);rows(content,all.filter(x=>notificationFilter==='all'||x.tone===notificationFilter),'Aucune alerte dans cette catégorie.');
    q('notificationBadge').textContent=all.length;q('notificationBadge').hidden=!all.length;q('notificationSubtitle').textContent=all.length+' éléments';
  }
  window.dashboardRefreshNotifications=notifications;
  q('notificationBell').addEventListener('click',()=>setTimeout(notifications,10));

  const search=dialog('dailySearch','Recherche globale'),input=document.createElement('input');
  input.type='search';input.placeholder='Plaque, chauffeur, numéro de parc…';input.setAttribute('aria-label','Recherche globale');
  const searchTools=document.createElement('div');searchTools.className='daily-toolbar';searchTools.append(input);
  const searchCount=document.createElement('span'),searchList=document.createElement('div');searchList.className='daily-list';search.append(searchTools,searchCount,searchList);
  function find(raw){
    const term=norm(raw);if(term.length<2)return [];
    const matches=(...values)=>values.some(v=>norm(v).includes(term));
    const drivers=driverProfiles.filter(d=>matches(driverDisplayName(d),d.phone,d.licenseNumber));
    const assignments=affectations.filter(a=>matches(a.name,a.tractor,a.semi,a.personal)||drivers.some(d=>same(driverDisplayName(d),a.name)));
    const plates=new Set();
    parkData.filter(v=>matches(v.registration,v.parkNumber)||assignments.some(a=>same(a.tractor,v.registration)||same(a.semi,v.registration))).forEach(v=>plates.add(norm(v.registration)));
    assignments.forEach(a=>[a.tractor,a.semi].filter(has).forEach(p=>plates.add(norm(p))));
    const linked=p=>!!norm(p)&&(plates.has(norm(p))||matches(p));
    const relatedAssignments=affectations.filter(a=>linked(a.tractor)||linked(a.semi));
    const results=parkData.filter(v=>linked(v.registration)).map(v=>({kind:'vehicle',plate:v.registration,title:plate(v.registration),detail:`${v.type} · Parc ${v.parkNumber||'—'} · ${dashboardFindVehicleLinks(v.registration).assignment?.name||'Non affecté'}`,badge:'Véhicule'}));
    driverProfiles.filter(d=>drivers.includes(d)||relatedAssignments.some(a=>same(a.name,driverDisplayName(d)))).forEach(d=>results.push({kind:'driver',id:d.id,title:driverDisplayName(d),detail:driverStatusLabel(d),badge:'Chauffeur'}));
    vidangeData.filter(v=>linked(v.registration)).forEach(v=>results.push({kind:'tech',category:'vidange',plate:v.registration,title:plate(v.registration),badge:'Vidange'}));
    technicalDeadlines.filter(v=>linked(v.registration)||matches(v.label)).forEach(v=>results.push({kind:'tech',category:v.category,plate:v.registration,title:plate(v.registration),detail:v.nextControl,badge:v.label||v.category}));
    adminFines.filter(f=>linked(f.vehicle)||matches(f.driver,f.reference)).forEach(f=>results.push({kind:'fine',id:f.id,title:f.reference||plate(f.vehicle),detail:f.driver,badge:'Amende'}));
    claimData.filter(c=>linked(c.vehicle)||matches(c.driver,c.number)).forEach(c=>results.push({kind:'claim',id:c.id,title:c.number||plate(c.vehicle),detail:c.driver,badge:'Sinistre'}));
    adminRungis.filter(r=>linked(r.vehicle)||matches(r.cardNumber)).forEach(r=>results.push({kind:'rungis',plate:r.vehicle,title:r.cardNumber||plate(r.vehicle),detail:plate(r.vehicle),badge:'Rungis'}));
    return results;
  }
  function renderSearch(){const result=find(input.value);searchCount.textContent=result.length+' résultats';rows(searchList,result,input.value.trim().length<2?'Saisissez au moins deux caractères.':'Aucun résultat.');}
  function openSearch(){input.value=q('globalSearch').value;closeGlobalSearch();open(search);renderSearch();input.focus();}
  input.oninput=renderSearch;
  // Capture Enter before the legacy dropdown handler to display every linked result.
  q('globalSearch').addEventListener('keydown',event=>{if(event.key==='Enter'&&globalSearchActiveIndex<0){event.preventDefault();event.stopImmediatePropagation();openSearch();}},true);

  function driverIssues(d){
    if(driverIsInactive(d))return ['Inactif'];
    const issues=[];
    if(!has(d.phone))issues.push('Téléphone manquant');
    if(!has(d.licenseNumber))issues.push('Permis manquant');
    if(!has(d.birthCity))issues.push('Ville de naissance manquante');
    if(!has(d.birthPostalCode))issues.push('Code postal de naissance manquant');
    if(!affectations.some(a=>same(a.name,driverDisplayName(d))&&(has(a.tractor)||has(a.semi))))issues.push('Sans affectation');
    return issues;
  }
  const check=dialog('dailyDriverCheck','Chauffeurs à vérifier'),checkList=document.createElement('div');checkList.className='daily-list';
  const checkFilter=document.createElement('select');checkFilter.setAttribute('aria-label','Chauffeurs à vérifier');
  [['active','Actifs à compléter'],['inactive','Inactifs'],['all','Tous les points à vérifier']].forEach(([v,t])=>checkFilter.add(new Option(t,v)));check.append(checkFilter,checkList);
  function renderChecks(){rows(checkList,driverProfiles.filter(d=>checkFilter.value==='all'||driverIsInactive(d)===(checkFilter.value==='inactive')).map(d=>({d,issues:driverIssues(d)})).filter(x=>x.issues.length).sort((a,b)=>driverDisplayName(a.d).localeCompare(driverDisplayName(b.d),'fr')).map(({d,issues})=>({kind:'driver',id:d.id,title:driverDisplayName(d),detail:issues.join(' · '),tone:driverIsInactive(d)?'info':'warn'})),'Aucune fiche à compléter.');}
  checkFilter.onchange=renderChecks;
  q('exportDriversCsv').after(button('À vérifier',()=>{renderChecks();open(check);}));

  const backupStatus=document.createElement('div');backupStatus.className='daily-backup';backupStatus.id='dailyBackup';
  const backupText=document.createElement('span');backupText.textContent='Dernière sauvegarde : non vérifiée';
  const backupButton=button('Sauvegarder',async()=>{
    backupButton.disabled=true;
    try{const ok=await dashboardCreateBackup(dashboardBackupTimestampName('manuel'),'Sauvegarde manuelle');if(!ok)throw new Error('Une sauvegarde est déjà en cours.');await refreshBackup();dashboardToast('Sauvegarde créée','','success');}
    catch(error){dashboardToast('Sauvegarde impossible',String(error),'error');}finally{backupButton.disabled=false;}
  });backupStatus.append(backupText,backupButton);home.after(backupStatus);
  async function refreshBackup(){
    if(!sharedConnected){backupText.textContent='Sauvegarde partagée : non connecté';return;}
    try{const list=await dashboardListBackups();backupText.textContent=list[0]?.manifest?.createdAt?'Dernière sauvegarde : '+new Date(list[0].manifest.createdAt).toLocaleString('fr-FR'):'Dernière sauvegarde : aucune';}
    catch{backupText.textContent='Dernière sauvegarde : vérification impossible';}
  }
  const originalBackup=dashboardCreateBackup;dashboardCreateBackup=async function(){const ok=await originalBackup.apply(this,arguments);if(ok)await refreshBackup();return ok;};
  document.addEventListener('dashboard-navigation',()=>{refreshHome();refreshBackup();});
  const activity=q('admin-tab-activity');if(activity)activity.textContent='Historique';
  const release=document.querySelector('.admin-release strong');if(release)release.textContent='2026.09.15 · Usage quotidien';

  const originalDossier=dashboardOpenVehicleDossier;
  dashboardOpenVehicleDossier=function(registration){
    const result=originalDossier.apply(this,arguments);
    setTimeout(()=>{
      const body=q('vehicleDossierBody'),tabs=body.querySelector('.vehicle-dossier-tabs'),panels=body.querySelector('.vehicle-tab-panels');
      if(!tabs||!panels||body.querySelector('[data-vehicle-tab="history"]'))return;
      const tab=button('Historique',async()=>{
        if(panel.dataset.loaded)return;
        panel.textContent='Chargement…';
        try{
          if(!sharedConnected){panel.textContent='Historique partagé indisponible : non connecté.';return;}
          const history=(await administratorReadHistory()).filter(e=>norm(e.entity).includes(norm(registration))||norm(e.detail).includes(norm(registration)));
          if(!same(dashboardCurrentVehicleDossier,registration))return;
          panel.innerHTML='<p>Historique récent · 7 derniers jours enregistrés</p>'+(history.length?'<table class="daily-history"><thead><tr><th>Date</th><th>Utilisateur</th><th>Action</th><th>Modification</th></tr></thead><tbody>'+history.map(e=>`<tr><td>${esc(new Date(e.timestamp).toLocaleString('fr-FR'))}</td><td>${esc(e.user)}</td><td>${esc(e.action)}</td><td>${esc(e.detail)}</td></tr>`).join('')+'</tbody></table>':'<div class="daily-empty">Aucune modification dans cet historique récent.</div>');panel.dataset.loaded='1';
        }catch{panel.textContent='Historique indisponible. Réessayez en rouvrant la fiche.';}
      });tab.className='vehicle-dossier-tab';tab.dataset.vehicleTab='history';
      const panel=document.createElement('div');panel.className='vehicle-tab-panel';panel.dataset.vehiclePanel='history';panel.hidden=true;tabs.append(tab);panels.append(panel);
      const summary=body.querySelector('[data-vehicle-panel="summary"]');
      if(summary){const state=document.createElement('p');const assigned=!!dashboardFindVehicleLinks(registration).assignment;state.textContent=assigned?'Affecté':'Non affecté';state.className='daily-status';state.dataset.dailyTone=assigned?'ok':'info';summary.prepend(state);}
    },20);return result;
  };

  // Printing uses the currently filtered rows, not a screenshot of the interface.
  function printPage(root,title){
    const visible=el=>!el.closest('[hidden]')&&getComputedStyle(el).display!=='none'&&el.getClientRects().length;
    const tables=[...root.querySelectorAll('table')].filter(visible);
    const content=tables.map(table=>{
      const copy=table.cloneNode(true);
      const headings=[...copy.querySelectorAll('thead th')];const actions=headings.map((th,i)=>/actions/i.test(th.textContent)?i:-1).filter(i=>i>=0);
      copy.querySelectorAll('tr').forEach(tr=>{actions.slice().reverse().forEach(i=>tr.children[i]?.remove());});
      copy.querySelectorAll('input,select,[hidden],.row-actions-menu').forEach(el=>el.remove());
      copy.querySelectorAll('button').forEach(el=>el.replaceWith(document.createTextNode(el.textContent)));
      copy.querySelectorAll('*').forEach(el=>{el.removeAttribute('style');el.removeAttribute('class');el.removeAttribute('id');});return copy.outerHTML;
    }).join('');
    if(!content){dashboardToast('Rien à imprimer','Aucune liste visible.','warn');return;}
    q('dailyPrintFrame')?.remove();const frame=document.createElement('iframe');frame.id='dailyPrintFrame';frame.title='Impression';frame.style.cssText='position:fixed;width:0;height:0;border:0';document.body.append(frame);
    const doc=frame.contentDocument;doc.open();doc.write(`<!doctype html><html lang="fr"><head><title>${esc(title)}</title><style>@page{size:A4 landscape;margin:12mm}body{font:11px Arial;color:#111}h1{font-size:20px;font-weight:400}table{width:100%;border-collapse:collapse;margin:16px 0}th,td{text-align:left;padding:7px;border-bottom:1px solid #ccc;overflow-wrap:anywhere}thead{display:table-header-group}tr{break-inside:avoid}a{color:inherit;text-decoration:none}</style></head><body><h1>H.ESSERS · ${esc(title)}</h1><p>${new Date().toLocaleString('fr-FR')}</p>${content}</body></html>`);doc.close();
    setTimeout(()=>{frame.contentWindow.focus();frame.contentWindow.print();},100);
  }
  [['exportParkCsv','parc','Parc véhicules'],['exportAssignmentsCsv','affectations','Affectations'],['technicalDeadlineExport','suivi-technique','Suivi technique']].forEach(([id,root,title])=>{q(id)?.after(button('Imprimer / PDF',()=>printPage(q(root),title)));});
  const fineTools=q('fineSearch').closest('.admin-tools');fineTools.append(button('Imprimer / PDF',()=>printPage(q('fineSearch').closest('.admin-card'),'Amendes')));
  const toneMap=new Map([['urgent','urgent'],['depass e','urgent'],['depasse','urgent'],['afaire','urgent'],['aenvoyer','urgent'],['atraiter','urgent'],['aprevoir','warn'],['averifier','warn'],['avoir','warn'],['ok','ok'],['ajour','ok'],['inactif','info'],['clos','info']]);
  function statusColors(){document.querySelectorAll('.status-badge,.vehicle-tech-status,.driver-status-badge,.fine-status,.vid-status,.technical-status,.badge,.tag').forEach(el=>{const tone=toneMap.get(norm(el.textContent));if(tone)el.dataset.dailyTone=tone;});}
  let timer;new MutationObserver(()=>{clearTimeout(timer);timer=setTimeout(()=>{statusColors();},80);}).observe(document.querySelector('.main'),{childList:true,subtree:true});
  window.dashboardDaily={attention,find,driverIssues,go,refreshHome,refreshBackup,printPage};
  refreshHome();refreshBackup();statusColors();
})();
