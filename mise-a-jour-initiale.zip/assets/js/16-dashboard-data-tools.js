(()=> {
  const $=(selector,root=document)=>root.querySelector(selector);
  const HISTORY_KEY='hessers-local-change-history-v1';
  const tableNames={
    parkTable:'Parc_ visible.csv',
    affTable:'Affectations_ visibles.csv',
    driverTable:'Chauffeurs_ visibles.csv',
    claimTable:'Sinistres_ visibles.csv',
    vidTable:'Vidanges_ visibles.csv',
    technicalDeadlineBody:'Echeances_techniques_ visibles.csv',
    fuelTable:'Carburant_ visible.csv',
    fineTable:'Amendes_ visibles.csv',
    rungisTable:'Cartes_Rungis_ visibles.csv'
  };
  const escCsv=value=>`"${String(value??'').replace(/"/g,'""')}"`;
  const download=(filename,rows)=>{
    const content='\uFEFF'+rows.map(row=>row.map(escCsv).join(';')).join('\r\n');
    const url=URL.createObjectURL(new Blob([content],{type:'text/csv;charset=utf-8;'}));
    const link=document.createElement('a');link.href=url;link.download=filename;document.body.appendChild(link);link.click();link.remove();
    setTimeout(()=>URL.revokeObjectURL(url),500);
  };
  const historyRead=()=>{
    try{return JSON.parse(localStorage.getItem(HISTORY_KEY)||'[]')||[]}
    catch(error){console.warn('Impossible de lire l’historique local.',error);return []}
  };
  const historyWrite=items=>{
    try{localStorage.setItem(HISTORY_KEY,JSON.stringify(items.slice(0,100)))}
    catch(error){console.warn('Impossible d’enregistrer l’historique local.',error)}
  };
  const recordChange=(key,before,after)=>{
    if(key===HISTORY_KEY || before===after) return;
    let oldValue,newValue;
    try{oldValue=JSON.parse(before||'null');newValue=JSON.parse(after||'null')}
    catch(error){console.warn('Impossible de comparer une modification locale.',error);return}
    const label=key.replace(/^hessers-/,'').replace(/-v\d+$/,'').replace(/-/g,' ');
    let detail='Donnée mise à jour';
    if(Array.isArray(oldValue)&&Array.isArray(newValue)){
      const id=item=>String(item?.id||item?.registration||item?.name||item?.cardNumber||'');
      const beforeIds=new Set(oldValue.map(id)),afterIds=new Set(newValue.map(id));
      const added=newValue.filter(item=>!beforeIds.has(id(item))).length;
      const removed=oldValue.filter(item=>!afterIds.has(id(item))).length;
      if(added||removed) detail=`${added} ajout${added>1?'s':''}, ${removed} suppression${removed>1?'s':''}`;
      else detail='Modification de fiche(s)';
    }
    const items=historyRead();
    items.unshift({at:new Date().toISOString(),dataset:label,detail});
    historyWrite(items);
    renderHistory();
  };
  const originalSet=Storage.prototype.setItem;
  if(!Storage.prototype.__dashboardLocalHistory){
    Storage.prototype.setItem=function(key,value){
      if(this===localStorage && key!==HISTORY_KEY && /^hessers-/.test(key)){
        const before=this.getItem(key);
        originalSet.call(this,key,value);
        recordChange(key,before,String(value));
        return;
      }
      return originalSet.call(this,key,value);
    };
    Storage.prototype.__dashboardLocalHistory=true;
  }
  function addExportButtons(){
    Object.entries(tableNames).forEach(([id,filename])=>{
      const table=$('#'+id);if(!table)return;
      const wrap=table.closest('.table-wrap,.fuel-table-wrap,.admin-table-wrap,.vid-table-wrap,.technical-deadline-table-wrap');
      if(!wrap||wrap.dataset.localExportReady)return;
      wrap.dataset.localExportReady='1';
      const toolbar=document.createElement('div');toolbar.className='local-tools-wrap';
      const button=document.createElement('button');button.type='button';button.className='tool-btn local-export-visible';button.textContent='Exporter visible';
      button.addEventListener('click',()=>{
        const headers=[...table.closest('table').querySelectorAll('thead th')].map(th=>th.textContent.trim()).filter((_,i)=>i!==table.closest('table').querySelectorAll('thead th').length-1);
        const rows=[...table.querySelectorAll('tr')].filter(row=>!row.querySelector('.empty-row,.fuel-empty,.vehicle-none')).map(row=>[...row.children].slice(0,-1).map(cell=>cell.textContent.trim()));
        if(rows.length) download(filename, [headers,...rows]);
      });
      toolbar.append(button);wrap.parentElement.insertBefore(toolbar,wrap);
    });
  }
  function renderHistory(){
    const list=$('#localChangeHistoryList');if(!list)return;
    const items=historyRead();
    list.innerHTML=items.length?items.slice(0,12).map(item=>`<li><strong>${item.dataset}</strong><span>${item.detail}</span><time>${new Date(item.at).toLocaleString('fr-FR')}</time></li>`).join(''):'<li class="local-history-empty">Aucune modification locale enregistrée.</li>';
  }
  function addHistoryPanel(){
    const host=$('.superadmin-history');if(!host||$('#localChangeHistory'))return;
    const panel=document.createElement('div');panel.className='card local-change-history';panel.id='localChangeHistory';
    panel.innerHTML='<div class="superadmin-card-head"><div><div class="superadmin-card-title">HISTORIQUE LOCAL</div><div class="superadmin-card-sub">Dernières modifications conservées dans ce navigateur</div></div><button type="button" class="tool-btn" id="clearLocalChangeHistory">Effacer</button></div><ul id="localChangeHistoryList"></ul>';
    host.parentElement.append(panel);
    $('#clearLocalChangeHistory').addEventListener('click',()=>{historyWrite([]);renderHistory()});
    renderHistory();
  }
  const init=()=>{addExportButtons();addHistoryPanel();};
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
  window.addEventListener('dashboard-data-refreshed',addExportButtons);
})();
