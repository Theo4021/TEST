
(()=>{
  const editableIds=[
    'driverLastName','driverFirstName','driverStatus','driverBirthDate','driverBirthCity',
    'driverBirthPostalCode','driverPhone','driverAddress','driverPostalCode','driverCity',
    'driverLicenseNumber','driverLicenseIssueDate','driverLicenseExpiry'
  ];
  const fields=()=>editableIds.map(id=>document.getElementById(id)).filter(Boolean);
  const detail=()=>document.getElementById('driverDetailContent');
  const notice=()=>document.getElementById('driverSaveNotice');
  let editing=false;

  function ensureButtons(){
    const save=document.getElementById('saveDriver');
    if(!save)return {};
    let actions=document.querySelector('.driver-edit-actions');
    if(!actions){
      actions=document.createElement('div');
      actions.className='driver-edit-actions';
      save.replaceWith(actions);
      actions.appendChild(save);
    }
    let edit=document.getElementById('editDriver');
    if(!edit){
      edit=document.createElement('button');
      edit.id='editDriver';
      edit.type='button';
      edit.className='driver-edit-btn';
      edit.textContent='Modifier la fiche';
      actions.prepend(edit);
    }
    let cancel=document.getElementById('cancelDriverEdit');
    if(!cancel){
      cancel=document.createElement('button');
      cancel.id='cancelDriverEdit';
      cancel.type='button';
      cancel.className='driver-cancel-btn';
      cancel.textContent='Annuler';
      edit.insertAdjacentElement('afterend',cancel);
    }
    save.textContent='Enregistrer';
    return {edit,cancel,save};
  }

  function setReadonly(readonly){
    const buttons=ensureButtons();
    editing=!readonly;
    fields().forEach(field=>{
      field.disabled=readonly;
      field.readOnly=readonly && field.tagName!=='SELECT';
      field.setAttribute('aria-readonly',String(readonly));
    });
    detail()?.classList.toggle('driver-readonly',readonly);
    if(buttons.edit)buttons.edit.hidden=!readonly;
    if(buttons.cancel)buttons.cancel.hidden=readonly;
    if(buttons.save)buttons.save.hidden=readonly;
  }

  function lockSoon(){
    setTimeout(()=>setReadonly(true),0);
  }

  document.addEventListener('click',event=>{
    const edit=event.target.closest('#editDriver');
    const cancel=event.target.closest('#cancelDriverEdit');
    const driverRow=event.target.closest('[data-driver-id]');
    if(edit){
      event.preventDefault();
      setReadonly(false);
      const n=notice();
      if(n){n.style.color='#8e98a2';n.textContent='Modification activée.';}
      document.getElementById('driverLastName')?.focus();
      return;
    }
    if(cancel){
      event.preventDefault();
      if(typeof fillDriverForm==='function')fillDriverForm();
      lockSoon();
      return;
    }
    if(driverRow && !event.target.closest('[data-driver-menu]')){
      lockSoon();
    }
  },true);

  document.addEventListener('click',event=>{
    if(event.target.closest('#saveDriver')){
      setTimeout(()=>{if(document.getElementById('driverSaveNotice')?.textContent==='Modifications enregistrées.')setReadonly(true);},0);
    }
  },false);

  const start=()=>setReadonly(true);
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start,{once:true});
  else start();
  window.driverLockReadonly=setReadonly;
})();
