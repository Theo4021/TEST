(()=>{
  const home=document.getElementById('accueil');
  if(!home) return;

  const stacks=home.querySelectorAll('.home-main-grid > .home-stack');
  if(stacks.length<2 || document.getElementById('homeQuickActions')) return;

  const card=document.createElement('div');
  card.className='card home-section-card home-quick-actions';
  card.id='homeQuickActions';
  card.innerHTML=`
    <div class="home-section-head">
      <div class="home-section-title">ACCÈS RAPIDES</div>
    </div>
    <div class="home-quick-actions-grid">
      <button type="button" data-quick-view="parc">Ajouter un véhicule</button>
      <button type="button" data-quick-view="affectations">Nouvelle affectation</button>
      <button type="button" data-quick-view="gestion-administrative">Ajouter une amende</button>
      <button type="button" data-quick-view="carburant">Nouvelle commande carburant</button>
    </div>
  `;

  stacks[1].prepend(card);
  card.addEventListener('click',event=>{
    const button=event.target.closest('[data-quick-view]');
    if(!button || typeof showView!=='function') return;
    const view=button.dataset.quickView;
    showView(view,view==='parc'?'Parc':view==='affectations'?'Affectations':view==='carburant'?'Carburant':'Gestion administrative',view);
    if(view==='parc') document.getElementById('addParkVehicle')?.click();
    if(view==='affectations') document.getElementById('addAssignment')?.click();
    if(view==='gestion-administrative'){
      document.querySelector('[data-admin-tab="fines"]')?.click();
      document.getElementById('addFine')?.click();
    }
    if(view==='carburant') document.getElementById('addFuelEntry')?.click();
  });
})();
