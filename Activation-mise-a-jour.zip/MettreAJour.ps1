$ErrorActionPreference = 'Stop'
$repoUrl = 'https://raw.githubusercontent.com/Theo4021/Dashboard/main/Dashboard-update.zip'
$tempZip = Join-Path $env:TEMP ('dashboard-update-' + [guid]::NewGuid().ToString('N') + '.zip')

try {
  [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
  Write-Host 'Recherche de la derniere version du dashboard...'
  try {
    Invoke-WebRequest -Uri $repoUrl -OutFile $tempZip -UseBasicParsing
  } catch {
    throw "Impossible de telecharger la mise a jour. Verifiez votre connexion et que le depot GitHub est public et contient Dashboard-update.zip.`n$($_.Exception.Message)"
  }
  if (!(Test-Path -LiteralPath $tempZip) -or (Get-Item -LiteralPath $tempZip).Length -lt 1000) {
    throw 'Le fichier de mise a jour recu est vide ou invalide.'
  }

  $env:DASHBOARD_UPDATE_ZIP = $tempZip
  $env:DASHBOARD_INSTALL_DIR = $PSScriptRoot
  & (Join-Path $PSScriptRoot 'InstallerDashboard.ps1')
  if ($LASTEXITCODE -and $LASTEXITCODE -ne 0) { throw 'L installation de la mise a jour a echoue.' }
} catch {
  Add-Type -AssemblyName System.Windows.Forms
  [Windows.Forms.MessageBox]::Show($_.Exception.Message, 'Mise a jour du dashboard', 'OK', 'Error') | Out-Null
} finally {
  Remove-Item Env:DASHBOARD_UPDATE_ZIP -ErrorAction SilentlyContinue
  Remove-Item Env:DASHBOARD_INSTALL_DIR -ErrorAction SilentlyContinue
  Remove-Item -LiteralPath $tempZip -Force -ErrorAction SilentlyContinue
}
