﻿# Dashboard update assistant. Does not change Windows execution policy.
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.IO.Compression.FileSystem
$ErrorActionPreference = 'Stop'

function Check-LocalPath([string]$Path) {
  $node = Get-Item -LiteralPath $Path -Force
  while ($node) {
    if ($node.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Dossier avec lien symbolique refuse.' }
    $node = $node.Parent
  }
}
function Hash-Bytes([byte[]]$Bytes) {
  $hash = [Security.Cryptography.SHA256]::Create()
  try { return ([BitConverter]::ToString($hash.ComputeHash($Bytes))).Replace('-','').ToLowerInvariant() }
  finally { $hash.Dispose() }
}
function Read-ZipBytes($Entry) {
  $stream = $Entry.Open(); $memory = New-Object IO.MemoryStream
  try { $stream.CopyTo($memory); return ,$memory.ToArray() }
  finally { $stream.Dispose(); $memory.Dispose() }
}
function Safe-AppPath([string]$Name) {
  if ($Name -notmatch '^(Dashboard\.html|index\.html|assets/[a-zA-Z0-9_./-]+)$') { throw "Chemin non autorise : $Name" }
  foreach ($part in $Name.Split('/')) {
    if (!$part -or $part -eq '.' -or $part -eq '..' -or $part.EndsWith('.')) { throw 'Chemin invalide.' }
  }
  if ($Name.StartsWith('assets/') -and $Name -ne 'assets/maintenance/Mettre-a-jour.ps1.txt' -and $Name -notmatch '\.(js|css|png|jpg|jpeg|svg|webp|ico|woff2?)(\.txt)?$') { throw 'Type de fichier non autorise.' }
}

$lockStream = $null; $lockPath = $null; $archive = $null
$work = $null; $destination = $null; $oldAssetsMoved = $false; $oldHtmlMoved = $false
$newAssetsMoved = $false; $newHtmlMoved = $false; $success = $false
try {
  $zipPath = $env:DASHBOARD_UPDATE_ZIP
  if (!$zipPath -or !(Test-Path -LiteralPath $zipPath -PathType Leaf)) {
    $picker = New-Object Windows.Forms.OpenFileDialog
    $picker.Title = 'Choisir le ZIP de mise a jour (ou version.zip pour restaurer)'
    $picker.Filter = 'Archive ZIP (*.zip)|*.zip'
    if ($picker.ShowDialog() -ne 'OK') { return }
    $zipPath = $picker.FileName
  }
  $archive = [IO.Compression.ZipFile]::OpenRead($zipPath)
  if ($archive.Entries.Count -gt 2000) { throw 'Archive trop volumineuse.' }
  $manifests = @($archive.Entries | Where-Object { $_.FullName -match '(^|/)update-manifest.json$' })
  if ($manifests.Count -ne 1 -or $manifests[0].Length -gt 1048576) { throw 'Ce ZIP ne contient pas un manifeste de mise a jour valide.' }
  $manifestEntry = $manifests[0]
  $prefix = $manifestEntry.FullName.Substring(0,$manifestEntry.FullName.Length-'update-manifest.json'.Length)
  $manifest = [Text.Encoding]::UTF8.GetString((Read-ZipBytes $manifestEntry)).TrimStart([char]0xFEFF) | ConvertFrom-Json
  if ($manifest.application -ne 'hessers-dashboard' -or $manifest.format -ne 1 -or $manifest.entry -notin @('Dashboard.html','index.html')) { throw 'Archive incompatible.' }
  $files = @($manifest.files)
  if ($files.Count -lt 3 -or $files.Count -gt 1000) { throw 'Liste de fichiers invalide.' }
  $payload = @{}; $total = 0
  foreach ($item in $files) {
    $name = [string]$item.path; Safe-AppPath $name
    if ($payload.ContainsKey($name) -or $item.sha256 -notmatch '^[a-fA-F0-9]{64}$') { throw 'Doublon ou empreinte invalide.' }
    $entries = @($archive.Entries | Where-Object { $_.FullName -ceq ($prefix+$name) -or ($name.EndsWith('.js') -and $_.FullName -ceq ($prefix+$name+'.txt')) })
    if ($entries.Count -ne 1 -or $entries[0].Length -gt 20971520) { throw "Fichier manquant, duplique ou trop grand : $name" }
    $total += $entries[0].Length
    if ($total -gt 104857600) { throw 'Archive trop volumineuse.' }
    $bytes = Read-ZipBytes $entries[0]
    if ((Hash-Bytes $bytes) -ne $item.sha256) { throw "Fichier altere : $name" }
    $payload[$name] = $bytes
  }
  if (!$payload.ContainsKey($manifest.entry) -or !($payload.Keys | Where-Object { $_ -match '^assets/js/.+\.js$' }) -or !($payload.Keys | Where-Object { $_ -match '^assets/css/.+\.css$' })) { throw 'Archive incomplete.' }
  $html = [Text.Encoding]::UTF8.GetString($payload[$manifest.entry])
  foreach ($ref in [regex]::Matches($html,'(?:src|href)=["''](assets/[^"''?#]+)')) {
    if (!$payload.ContainsKey($ref.Groups[1].Value)) { throw 'Une ressource du HTML est absente du ZIP.' }
  }
  $archive.Dispose(); $archive = $null

  $destination = $env:DASHBOARD_INSTALL_DIR
  if (!$destination -or !(Test-Path -LiteralPath $destination -PathType Container)) {
    $folder = New-Object Windows.Forms.FolderBrowserDialog
    $folder.Description = 'Choisir le dossier ACTUEL contenant Dashboard.html ou index.html et assets'
    if ($folder.ShowDialog() -ne 'OK') { return }
    $destination = $folder.SelectedPath
  }
  Check-LocalPath $destination
  if ($destination -eq [IO.Path]::GetPathRoot($destination)) { throw 'La racine du disque ne peut pas etre utilisee.' }
  $entryCandidates = @(@('Dashboard.html','index.html') | Where-Object { Test-Path -LiteralPath (Join-Path $destination $_) -PathType Leaf })
  if ($entryCandidates.Count -eq 0 -or !(Test-Path -LiteralPath (Join-Path $destination 'assets') -PathType Container)) { throw 'Le dossier choisi doit contenir Dashboard.html ou index.html et le dossier assets.' }
  $entryName = if ($entryCandidates -contains $manifest.entry) { $manifest.entry } else { $entryCandidates[0] }
  $entryPath = Join-Path $destination $entryName
  Check-LocalPath $entryPath
  $assetsPath = Join-Path $destination 'assets'; Check-LocalPath $assetsPath
  foreach ($node in Get-ChildItem -LiteralPath $assetsPath -Recurse -Force) {
    if ($node.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Lien symbolique dans assets : installation refusee.' }
  }
  $answer = [Windows.Forms.MessageBox]::Show("Installer la version $($manifest.version) dans :`n$destination`n`nTous les utilisateurs doivent fermer le dashboard.`nData sera conserve. Continuer ?",'Confirmer la mise a jour','YesNo','Warning')
  if ($answer -ne 'Yes') { return }
  $lockPath = Join-Path $destination '.dashboard-update.lock'
  $lockStream = [IO.File]::Open($lockPath,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
  $backupRoot = Join-Path $destination 'Sauvegardes_versions'
  if (!(Test-Path -LiteralPath $backupRoot)) { [IO.Directory]::CreateDirectory($backupRoot) | Out-Null }
  Check-LocalPath $backupRoot
  $work = Join-Path $backupRoot ((Get-Date -Format 'yyyyMMdd-HHmmss')+'-'+[guid]::NewGuid().ToString('N'))
  [IO.Directory]::CreateDirectory($work) | Out-Null
  $stage = Join-Path $work 'nouvelle-version'; [IO.Directory]::CreateDirectory($stage) | Out-Null
  foreach ($name in $payload.Keys) {
    $target = Join-Path $stage $name
    [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($target)) | Out-Null
    [IO.File]::WriteAllBytes($target,$payload[$name])
  }

  # A complete, reusable rollback archive is written before moving any app file.
  $backupZip = Join-Path $work 'version.zip'
  $backupArchive = [IO.Compression.ZipFile]::Open($backupZip,[IO.Compression.ZipArchiveMode]::Create)
  try {
    $backupFiles = @(); $originalFiles = @((Get-Item -LiteralPath $entryPath)) + @(Get-ChildItem -LiteralPath $assetsPath -Recurse -File)
    foreach ($file in $originalFiles) {
      $relative = $file.FullName.Substring($destination.TrimEnd('\').Length+1).Replace('\','/')
      Safe-AppPath $relative
      [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($backupArchive,$file.FullName,$relative) | Out-Null
      $backupFiles += @{path=$relative;sha256=(Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash.ToLowerInvariant()}
    }
    $oldManifest = @{application='hessers-dashboard';format=1;version='Sauvegarde '+(Get-Date -Format 's');entry=$entryName;files=$backupFiles} | ConvertTo-Json -Depth 5
    $writer = New-Object IO.StreamWriter($backupArchive.CreateEntry('update-manifest.json').Open())
    try {$writer.Write($oldManifest)} finally {$writer.Dispose()}
  } finally {$backupArchive.Dispose()}
  $oldAssets = Join-Path $work 'anciens-assets'; $oldHtml = Join-Path $work $entryName
  Move-Item -LiteralPath $assetsPath -Destination $oldAssets; $oldAssetsMoved = $true
  Move-Item -LiteralPath $entryPath -Destination $oldHtml; $oldHtmlMoved = $true
  Move-Item -LiteralPath (Join-Path $stage 'assets') -Destination $assetsPath; $newAssetsMoved = $true
  Move-Item -LiteralPath (Join-Path $stage $manifest.entry) -Destination $entryPath; $newHtmlMoved = $true
  $success = $true
  [Windows.Forms.MessageBox]::Show("Mise a jour terminee. Vous pouvez rouvrir $entryName.`nSauvegarde : $backupZip",'Dashboard') | Out-Null
} catch {
  $message = $_.Exception.Message
  if ($work -and !$success) {
    try {
      if ($newHtmlMoved) { Move-Item -LiteralPath $entryPath -Destination (Join-Path $work 'html-echec.html') }
      if ($newAssetsMoved) { Move-Item -LiteralPath $assetsPath -Destination (Join-Path $work 'assets-echec') }
      if ($oldHtmlMoved) { Move-Item -LiteralPath $oldHtml -Destination $entryPath }
      if ($oldAssetsMoved) { Move-Item -LiteralPath $oldAssets -Destination $assetsPath }
      $message += "`nLa version precedente est conservee."
    } catch { $message += "`nRestauration automatique impossible. Ne rouvrez pas le dashboard. Contactez le service informatique avec ce dossier : $work" }
  }
  [Windows.Forms.MessageBox]::Show($message,'Installation interrompue','OK','Error') | Out-Null
} finally {
  if ($archive) {$archive.Dispose()}
  if ($lockStream) { $lockStream.Dispose(); [IO.File]::Delete($lockPath) }
}
