
(()=>{
  const page=document.querySelector('#administrateur .superadmin-page');
  if(!page)return;
  const find=selector=>page.querySelector(selector);
  const head=find('.superadmin-head');
  const quality=find('#qualityList').closest('.production-admin-card');
  const backups=find('#backupList').closest('.production-admin-card');
  const history=find('.superadmin-history');
  const kpis=find('.superadmin-kpis');
  const users=find('.superadmin-top-grid');
  const update=find('.dashboard-update-card');
  const security=find('.adminsec-tools');
  const oldGrid=find('.production-admin-grid');
  const tabs=document.createElement('div');tabs.className='admin-workspace-tabs';tabs.setAttribute('role','tablist');tabs.setAttribute('aria-label','Administration');
  head.after(tabs);
  const definitions=[['anomalies','Anomalies'],['activity','Activité'],['backups','Sauvegardes'],['updates','Mises à jour'],['settings','Réglages']];
  const panels=new Map();
  definitions.forEach(([key,label])=>{
    const tab=document.createElement('button');tab.type='button';tab.id='admin-tab-'+key;tab.dataset.workspaceTab=key;tab.textContent=label;tab.setAttribute('role','tab');tab.setAttribute('aria-controls','admin-panel-'+key);tabs.append(tab);
    const panel=document.createElement('div');panel.id='admin-panel-'+key;panel.setAttribute('role','tabpanel');panel.setAttribute('aria-labelledby',tab.id);page.append(panel);panels.set(key,panel);
    tab.addEventListener('click',()=>select(key));
  });
  panels.get('anomalies').append(quality);
  const connections=document.createElement('details');connections.className='admin-connections';
  const summary=document.createElement('summary');summary.textContent='Utilisateurs et connexions';connections.append(summary,users);
  panels.get('activity').append(kpis,history,connections);
  const syncStrip=find('#adminSyncStrip');
  if(syncStrip)panels.get('backups').append(syncStrip);
  panels.get('backups').append(backups);
  const securityBlock=document.createElement('section');securityBlock.className='admin-settings-block';
  const securityTitle=document.createElement('h2');securityTitle.textContent='Accès administrateur';securityBlock.append(securityTitle,security);
  panels.get('settings').append(securityBlock);
  panels.get('updates').append(update);
  const settingsNote=document.createElement('p');settingsNote.className='admin-explanation';
  settingsNote.textContent='Ce verrou protège les actions dans l’interface. Les droits du dossier partagé restent gérés par Windows.';
  securityBlock.append(settingsNote);
  oldGrid.remove();
  quality.querySelector('.superadmin-card-title').textContent='Anomalies à corriger';
  quality.querySelector('.superadmin-card-sub').remove();
  backups.querySelector('.superadmin-card-title').textContent='Sauvegardes des données';
  backups.querySelector('.superadmin-card-sub').textContent='Sauvegarde automatique quotidienne et restauration des données.';
  update.querySelector('.superadmin-card-title').textContent='Installer une nouvelle version';
  update.querySelector('.superadmin-card-sub').textContent='Le site et vos données sont mis à jour séparément.';
  const legacy=document.createElement('div');legacy.hidden=true;
  const body=update.querySelector('.dashboard-update-body');
  while(body.firstChild)legacy.append(body.firstChild);
  body.append(legacy);
  const guide=document.createElement('div');guide.className='admin-update-guide';
  guide.innerHTML='<div class="admin-release"><span>VERSION INSTALLÉE</span><strong>2026.09.09 · Suivi technique</strong><p>HTML, styles, scripts et images séparés</p></div><ol class="admin-install-steps"><li><strong>Préparer</strong><p>Téléchargez le ZIP fourni pour la nouvelle version. Demandez aux utilisateurs de fermer le dashboard.</p></li><li><strong>Installer sur Windows</strong><p>Lancez Mettre-a-jour.ps1, choisissez le ZIP puis le dossier actuel du dashboard. Vérifiez le dossier avant de confirmer.</p></li><li><strong>Rouvrir</strong><p>Après le message de réussite, ouvrez le même fichier HTML. Le nom Dashboard.html ou index.html est conservé.</p></li></ol><div class="admin-update-buttons"></div><details class="admin-recovery"><summary>Revenir à une ancienne version</summary><p>Dans le dossier Sauvegardes_versions, ouvrez la sauvegarde voulue. Relancez l’assistant et choisissez son fichier version.zip. Les données ne sont pas restaurées par cette opération.</p></details><p class="admin-explanation">L’assistant vérifie les fichiers avant installation et tente de rétablir la version précédente en cas d’erreur. Data et les sauvegardes de données ne sont jamais remplacés. Si Windows bloque le script, contactez votre service informatique.</p>';
  body.append(guide);
  const updateButton=find('#dashboardUpdateButton');
  updateButton.textContent='Ouvrir la procédure';guide.querySelector('.admin-update-buttons').append(updateButton);
  find('#dashboardUpdateBackupCount').hidden=true;
  const headings={activity:['Activité récente','Retrouvez les modifications et leur auteur.'],backups:['Protéger les données','Créez une sauvegarde avant une opération importante.'],settings:['Accès et sécurité','Gérez le verrouillage de l’administration.']};
  Object.entries(headings).forEach(([key,[title,copy]])=>{const header=document.createElement('header');header.className='admin-section-intro';const h=document.createElement('h2');h.textContent=title;const p=document.createElement('p');p.textContent=copy;header.append(h,p);panels.get(key).prepend(header);});
  const refresh=find('#superadminRefresh');panels.get('activity').querySelector('.admin-section-intro').append(refresh);
  find('#superadminState').setAttribute('title','État de la connexion aux données partagées');
  find('#qualityIssueSearch').placeholder='Plaque, chauffeur, permis…';
  find('#qualityIssueSearch').setAttribute('aria-label','Rechercher une anomalie');
  find('#superadminHistorySearch').setAttribute('aria-label','Rechercher dans l’historique');
  find('#superadminUserFilter').setAttribute('aria-label','Utilisateur');
  find('#superadminActionFilter').setAttribute('aria-label','Type d’action');
  function select(key){
    panels.forEach((panel,id)=>{panel.hidden=id!==key;});
    tabs.querySelectorAll('button').forEach(tab=>{const active=tab.dataset.workspaceTab===key;tab.setAttribute('aria-selected',String(active));tab.tabIndex=active?0:-1;});
    try{sessionStorage.setItem('dashboard-admin-tab',key);}catch(error){}
  }
  tabs.addEventListener('keydown',event=>{
    if(!['ArrowLeft','ArrowRight','Home','End'].includes(event.key))return;
    const buttons=[...tabs.querySelectorAll('button')];const index=buttons.indexOf(document.activeElement);if(index<0)return;
    event.preventDefault();const next=event.key==='Home'?0:event.key==='End'?buttons.length-1:(index+(event.key==='ArrowRight'?1:-1)+buttons.length)%buttons.length;
    buttons[next].click();buttons[next].focus();
  });
  document.addEventListener('dashboard-navigation',event=>{if(event.detail?.view==='administrateur')dashboardRenderQuality();});
  let initial='anomalies';try{initial=sessionStorage.getItem('dashboard-admin-tab')||initial;}catch(error){}
  select(panels.has(initial)?initial:'anomalies');
})();
