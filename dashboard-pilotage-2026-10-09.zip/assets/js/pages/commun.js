function showView(id,pageTitle,activeNavId=id){
  if(window.dashboardAllowLeave && !window.dashboardAllowLeave()) return false;
  if(typeof sharedConnected!=='undefined' && !sharedConnected){
    if(typeof openSharedStorageModal==='function') openSharedStorageModal();
    return false;
  }
  window.dashboardRememberPosition?.();
  navButtons.forEach(button=>button.classList.toggle('active',button.dataset.view === activeNavId));
  views.forEach(view=>view.classList.remove('active'));
  const targetView = document.getElementById(id);
  if(!targetView) return;
  targetView.classList.add('active');
  document.dispatchEvent(new CustomEvent('dashboard-navigation',{detail:{view:id}}));
  title.textContent = pageTitle;
  if(id === 'accueil' && typeof refreshHomeDashboard === 'function'){
    refreshHomeDashboard();
  }

  // Les canvas carburant n'ont pas de dimensions fiables tant que leur page est cachée.
  // On attend donc deux frames après l'affichage de l'onglet avant de les redessiner.
  if(id === 'carburant' && typeof renderFuelCharts === 'function'){
    requestAnimationFrame(()=>{
      requestAnimationFrame(renderFuelCharts);
    });
  }

  if(typeof administratorHandleViewChange === 'function'){
    administratorHandleViewChange(id);
  }
  if(window.dashboardRestorePosition) window.dashboardRestorePosition(id);
  else window.scrollTo({top:0,behavior:'smooth'});
}

function saveParkData(){
  try{
    localStorage.setItem(PARK_STORAGE_KEY,JSON.stringify(parkData));
    return true;
  }catch(error){
    console.warn('Impossible d’enregistrer les données du parc dans ce navigateur.',error);
    return false;
  }
}

function updateParkStats(){
  const tractors = parkData.filter(item=>item.type === 'Tracteur');
  const semis = parkData.filter(item=>item.type === 'Semi');
  const usedTractors = new Set(affectations.map(item=>normalizeRegistration(item.tractor)).filter(Boolean));
  const usedSemis = new Set(affectations.map(item=>normalizeRegistration(item.semi)).filter(Boolean));
  const unassignedTractors = tractors.filter(item=>!usedTractors.has(normalizeRegistration(item.registration))).length;
  const unassignedSemis = semis.filter(item=>!usedSemis.has(normalizeRegistration(item.registration))).length;

  document.getElementById('parkTotal').textContent = parkData.length;
  document.getElementById('parkTractors').textContent = tractors.length;
  document.getElementById('parkTrailers').textContent = semis.length;
  document.getElementById('parkUnassigned').textContent = unassignedTractors + unassignedSemis;
  document.getElementById('parkUnassignedBreakdown').textContent =
    `${unassignedTractors} tracteur${unassignedTractors > 1 ? 's' : ''} · ${unassignedSemis} semi${unassignedSemis > 1 ? 's' : ''}`;
}

function isVehicleAssigned(item){
  const registration = normalizeRegistration(item.registration);
  if(item.type === 'Tracteur'){
    return affectations.some(assignment=>normalizeRegistration(assignment.tractor) === registration);
  }
  return affectations.some(assignment=>normalizeRegistration(assignment.semi) === registration);
}

function renderParkTable(){
  const query = normalizeParkText(parkSearch.value);
  const selectedType = parkTypeFilter.value;
  const filteredData = parkData.filter(item=>{
    const searchableText = normalizeParkText(`${item.registration} ${item.type} ${item.parkNumber}`);
    const assignmentFilter=document.getElementById('parkAssignmentFilter')?.value||'';
    return searchableText.includes(query) && (!selectedType || item.type === selectedType) && (!assignmentFilter || isVehicleAssigned(item)===(assignmentFilter==='assigned'));
  }).sort((a,b)=>
    (parkTypeOrder[a.type] ?? 99) - (parkTypeOrder[b.type] ?? 99) ||
    normalizeRegistration(a.registration).localeCompare(
      normalizeRegistration(b.registration),'fr',{numeric:true,sensitivity:'base'}
    )
  );

  if(!filteredData.length){
    parkTable.innerHTML = '<tr><td colspan="6" class="empty-row">Aucun véhicule ne correspond à votre recherche.</td></tr>';
  }else{
    parkTable.innerHTML = filteredData.map(item=>{
      const displayedRegistration = formatRegistration(item.registration);
      return `
        <tr data-registration="${item.registration}">
          <td class="plate-cell" data-open-vehicle="${displayedRegistration}" title="Ouvrir la fiche véhicule">${displayedRegistration}</td>
          <td><span class="type-chip ${item.type === 'Tracteur' ? 'type-tractor' : 'type-semi'}">${item.type}</span></td>
          <td><span class="park-number ${item.parkNumber ? '' : 'empty'}">${item.parkNumber || '—'}</span></td>
          <td>
            <span class="assignment-status ${isVehicleAssigned(item) ? 'assigned' : 'unassigned'}">
              ${isVehicleAssigned(item) ? 'Affecté' : 'Non affecté'}
            </span>
          </td>
          <td>${dashboardModificationHtml(item)}</td>
          <td><button class="row-menu" type="button" data-registration="${item.registration}" aria-label="Actions pour ${displayedRegistration}" aria-haspopup="menu" aria-expanded="false">•••</button></td>
        </tr>
      `;
    }).join('');
  }

  updateParkStats();
  if(typeof populateVehicleSelects === 'function') populateVehicleSelects();
  parkResultCount.textContent = `${filteredData.length} véhicule${filteredData.length > 1 ? 's' : ''} affiché${filteredData.length > 1 ? 's' : ''}`;
}

function closeRowActionsMenu(){
  if(activeActionButton) activeActionButton.setAttribute('aria-expanded','false');
  rowActionsMenu.hidden = true;
  activeParkRegistration = null;
  activeActionButton = null;
}

function openRowActionsMenu(button,registration){
  closeRowActionsMenu();
  activeParkRegistration = registration;
  activeActionButton = button;
  button.setAttribute('aria-expanded','true');
  rowActionsMenu.hidden = false;

  const buttonRect = button.getBoundingClientRect();
  const menuRect = rowActionsMenu.getBoundingClientRect();
  const left = Math.max(10,Math.min(buttonRect.right - menuRect.width,window.innerWidth - menuRect.width - 10));
  let top = buttonRect.bottom + 6;
  if(top + menuRect.height > window.innerHeight - 10) top = buttonRect.top - menuRect.height - 6;
  rowActionsMenu.style.left = `${left}px`;
  rowActionsMenu.style.top = `${Math.max(10,top)}px`;
}

function syncModalState(){
  document.body.classList.toggle('modal-open',
    !addVehicleModal.hidden ||
    !editVehicleModal.hidden ||
    !deleteVehicleModal.hidden ||
    !addAssignmentModal.hidden ||
    !editAssignmentModal.hidden ||
    !deleteAssignmentModal.hidden
  );
}

function updateParkNumberField(){
  const isSemi = newVehicleType.value === 'Semi';
  newVehicleParkNumber.disabled = !isSemi;
  newVehicleParkNumber.required = isSemi;
  parkNumberField.classList.toggle('disabled',!isSemi);
  if(!isSemi) newVehicleParkNumber.value = '';
}

function openAddVehicleModal(){
  closeRowActionsMenu();
  addVehicleForm.reset();
  addVehicleError.textContent = '';
  updateParkNumberField();
  addVehicleModal.hidden = false;
  syncModalState();
  requestAnimationFrame(()=>newVehicleRegistration.focus());
}

function closeAddVehicleModal(){
  addVehicleModal.hidden = true;
  addVehicleError.textContent = '';
  syncModalState();
}

function updateEditParkNumberField(){
  const isSemi = editVehicleType.value === 'Semi';
  editVehicleParkNumber.disabled = !isSemi;
  editVehicleParkNumber.required = isSemi;
  editParkNumberField.classList.toggle('disabled',!isSemi);
  if(!isSemi) editVehicleParkNumber.value = '';
}

function openEditVehicleModal(registration){
  const normalized = normalizeRegistration(registration);
  const item = parkData.find(vehicle=>normalizeRegistration(vehicle.registration) === normalized);
  if(!item) return;

  editingOriginalRegistration = normalizeRegistration(item.registration);
  editVehicleError.textContent = '';
  editVehicleRegistration.value = formatRegistration(item.registration);
  editVehicleType.value = item.type;
  editVehicleParkNumber.value = item.parkNumber || '';
  updateEditParkNumberField();
  editVehicleModal.hidden = false;
  syncModalState();
  requestAnimationFrame(()=>editVehicleRegistration.focus());
}

function closeEditVehicleModal(){
  editVehicleModal.hidden = true;
  editVehicleError.textContent = '';
  editingOriginalRegistration = null;
  syncModalState();
}

function propagateVehicleChange(oldRegistration,newRegistration,newType,newParkNumber){
  const oldNormalized = normalizeRegistration(oldRegistration);
  const newFormatted = formatRegistration(newRegistration);

  affectations.forEach(item=>{
    if(normalizeRegistration(item.tractor) === oldNormalized){
      item.tractor = newType === 'Tracteur' ? newFormatted : item.tractor;
    }
    if(normalizeRegistration(item.semi) === oldNormalized){
      item.semi = newType === 'Semi' ? newFormatted : item.semi;
      if(newType === 'Semi') item.number = newParkNumber || item.number;
    }
  });
}

function openDeleteVehicleModal(registration){
  pendingDeleteRegistration = registration;
  deleteVehicleRegistration.textContent = formatRegistration(registration);
  deleteVehicleModal.hidden = false;
  syncModalState();
  requestAnimationFrame(()=>document.getElementById('confirmDeleteVehicle').focus());
}

function closeDeleteVehicleModal(){
  deleteVehicleModal.hidden = true;
  pendingDeleteRegistration = null;
  syncModalState();
}

function csvEscape(value){
  const text = String(value ?? '').replace(/"/g,'""');
  return `"${text}"`;
}

function downloadCsv(filename,headers,rows){
  const content = '\uFEFF' + [
    headers.map(csvEscape).join(';'),
    ...rows.map(row=>row.map(csvEscape).join(';'))
  ].join('\r\n');

  const blob = new Blob([content],{type:'text/csv;charset=utf-8;'});
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

function normalizeAffText(value){
  return String(value ?? '')
    .toLocaleLowerCase('fr')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g,'')
    .replace(/[^a-z0-9]/g,'');
}

function saveAffectations(){
  try{
    localStorage.setItem(AFFECT_STORAGE_KEY,JSON.stringify(affectations));
    return true;
  }catch(error){
    console.warn('Impossible d’enregistrer les affectations dans ce navigateur.',error);
    return false;
  }
}

function updateAffectationStats(){
  affTotal.textContent = affectations.length;
  affAssigned.textContent = affectations.filter(item=>normalizeRegistration(item.tractor)).length;
  affUnassigned.textContent = affectations.filter(item=>!normalizeRegistration(item.tractor)).length;
  affIssues.textContent = affectations.filter(affectationHasIssue).length;
}

function setAffectationFieldsDisabled(disabled){
  [affName,affTractor,affSemi,affNumber,affPhone,affPersonal,saveAssignment].forEach(element=>{
    element.disabled = disabled;
  });
}

function ensureSelectValue(select,value){
  const normalized = normalizeRegistration(value);
  if(!normalized){
    select.value = '';
    return;
  }
  const formatted = formatRegistration(normalized);
  const exists = [...select.options].some(option=>normalizeRegistration(option.value) === normalized);
  if(!exists){
    const option = document.createElement('option');
    option.value = formatted;
    option.textContent = `${formatted} · Hors Parc`;
    option.dataset.outsidePark = 'true';
    select.appendChild(option);
  }
  const match = [...select.options].find(option=>normalizeRegistration(option.value) === normalized);
  if(match) select.value = match.value;
}

function populateVehicleSelects(){
  if(!affTractor || !affSemi) return;
  const tractorValue = affTractor.value;
  const semiValue = affSemi.value;

  affTractor.innerHTML = '<option value="">—</option>' + vehicleOptions('Tracteur').map(item=>{
    const plate = formatRegistration(item.registration);
    return `<option value="${plate}">${plate}</option>`;
  }).join('');

  affSemi.innerHTML = '<option value="">—</option>' + vehicleOptions('Semi').map(item=>{
    const plate = formatRegistration(item.registration);
    return `<option value="${plate}">${plate}</option>`;
  }).join('');

  if(tractorValue) ensureSelectValue(affTractor,tractorValue);
  if(semiValue) ensureSelectValue(affSemi,semiValue);
}

function populateNewAssignmentSelects(){
  newAssignmentTractor.innerHTML = '<option value="">—</option>' + vehicleOptions('Tracteur').map(item=>{
    const plate = formatRegistration(item.registration);
    return `<option value="${plate}">${plate}</option>`;
  }).join('');

  newAssignmentSemi.innerHTML = '<option value="">—</option>' + vehicleOptions('Semi').map(item=>{
    const plate = formatRegistration(item.registration);
    return `<option value="${plate}">${plate}</option>`;
  }).join('');
}

function openAddAssignmentModal(){
  closeRowActionsMenu();
  addAssignmentForm.reset();
  addAssignmentError.textContent = '';
  populateNewAssignmentSelects();
  populateAssignmentDriverChoices(newAssignmentName);
  addAssignmentModal.hidden = false;
  syncModalState();
  requestAnimationFrame(()=>newAssignmentName.focus());
}

function closeAddAssignmentModal(){
  addAssignmentModal.hidden = true;
  addAssignmentError.textContent = '';
  syncModalState();
}

function openEditAssignmentModal(index){
  if(index < 0 || !affectations[index]) return;
  selectedAffectationIndex = index;
  loadSelectedAffectation();
  renderAffectations();
  editAssignmentModal.hidden = false;
  syncModalState();
  requestAnimationFrame(()=>affTractor.focus());
}

function closeEditAssignmentModal(){
  editAssignmentModal.hidden = true;
  affNotice.textContent = '';
  selectedAffectationIndex = -1;
  setAffectationFieldsDisabled(true);
  renderAffectations();
  syncModalState();
}

function closeAffectationActionsMenu(){
  if(activeAffectationActionButton) activeAffectationActionButton.setAttribute('aria-expanded','false');
  affectationActionsMenu.hidden = true;
  activeAffectationIndex = -1;
  activeAffectationActionButton = null;
}

function openAffectationActionsMenu(button,index){
  closeAffectationActionsMenu();
  activeAffectationIndex = index;
  activeAffectationActionButton = button;
  button.setAttribute('aria-expanded','true');
  affectationActionsMenu.hidden = false;

  const buttonRect = button.getBoundingClientRect();
  const menuRect = affectationActionsMenu.getBoundingClientRect();
  const left = Math.max(10,Math.min(buttonRect.right - menuRect.width,window.innerWidth - menuRect.width - 10));
  let top = buttonRect.bottom + 6;
  if(top + menuRect.height > window.innerHeight - 10) top = buttonRect.top - menuRect.height - 6;
  affectationActionsMenu.style.left = `${left}px`;
  affectationActionsMenu.style.top = `${Math.max(10,top)}px`;
}

function clearSelectedAffectation(){
  selectedAffectationIndex = -1;
  selectedDriverName.textContent = 'Aucun chauffeur sélectionné';
  affName.value = '';
  affTractor.value = '';
  affSemi.value = '';
  affNumber.value = '';
  affPhone.value = '';
  affPersonal.value = '';
  affNotice.textContent = '';
  setAffectationFieldsDisabled(true);
}

function openDeleteAssignmentModal(index){
  const item = affectations[index];
  if(!item) return;
  pendingDeleteAffectationIndex = index;
  deleteAssignmentName.textContent = item.name;
  deleteAssignmentModal.hidden = false;
  syncModalState();
  requestAnimationFrame(()=>document.getElementById('confirmDeleteAssignment').focus());
}

function closeDeleteAssignmentModal(){
  deleteAssignmentModal.hidden = true;
  pendingDeleteAffectationIndex = -1;
  syncModalState();
}

function renderAffectations(){
  const query = normalizeAffText(affSearch.value);
  const filtered = affectations
    .map((item,index)=>({item,index}))
    .filter(({item})=>normalizeAffText(
      `${item.name} ${item.tractor} ${item.semi} ${item.number} ${item.phone} ${item.personal}`
    ).includes(query));

  if(!filtered.length){
    affTable.innerHTML = '<tr><td colspan="8" class="empty-row">Aucune affectation ne correspond à votre recherche.</td></tr>';
  }else{
    affTable.innerHTML = filtered.map(({item,index})=>{
      const tractor = item.tractor ? formatRegistration(item.tractor) : '—';
      const semi = item.semi ? formatRegistration(item.semi) : '—';
      const tractorIssue = normalizeRegistration(item.tractor) && !vehicleExistsInPark(item.tractor,'Tracteur');
      const semiIssue = normalizeRegistration(item.semi) && !vehicleExistsInPark(item.semi,'Semi');
      return `
        <tr data-index="${index}" class="${index === selectedAffectationIndex ? 'selected' : ''}">
          <td><strong>${item.name}</strong></td>
          <td class="${item.tractor ? 'aff-plate' : 'aff-empty'}" ${item.tractor ? `data-open-vehicle="${tractor}" title="Ouvrir la fiche véhicule"` : ''}>${tractor}${tractorIssue ? '<span class="issue-badge">HORS PARC</span>' : ''}</td>
          <td class="${item.semi ? 'aff-plate' : 'aff-empty'}" ${item.semi ? `data-open-vehicle="${semi}" title="Ouvrir la fiche véhicule"` : ''}>${semi}${semiIssue ? '<span class="issue-badge">HORS PARC</span>' : ''}</td>
          <td class="${item.number ? '' : 'aff-empty'}">${item.number || '—'}</td>
          <td class="${item.phone ? '' : 'aff-empty'}">${item.phone || '—'}</td>
          <td class="${item.personal ? '' : 'aff-empty'}">${item.personal || '—'}</td>
          <td>${dashboardModificationHtml(item)}</td>
          <td>
            <button
              class="row-menu affectation-row-menu"
              type="button"
              data-index="${index}"
              aria-label="Actions pour ${item.name}"
              aria-haspopup="menu"
              aria-expanded="false"
            >•••</button>
          </td>
        </tr>
      `;
    }).join('');
  }

  updateAffectationStats();
  updateParkStats();
  affCount.textContent = `${filtered.length} chauffeur${filtered.length > 1 ? 's' : ''} affiché${filtered.length > 1 ? 's' : ''}`;
}

function loadSelectedAffectation(){
  const item = affectations[selectedAffectationIndex];
  if(!item) return;

  populateVehicleSelects();
  populateAssignmentDriverChoices(affName,item.name);
  selectedDriverName.textContent = item.name;
  affName.value = item.name;
  ensureSelectValue(affTractor,item.tractor);
  ensureSelectValue(affSemi,item.semi);
  affNumber.value = item.number || '';
  affPhone.value = item.phone || '';
  affPersonal.value = item.personal || '';
  affNotice.textContent = '';
  setAffectationFieldsDisabled(false);
}

function splitDriverDisplayName(displayName){
  const parts = String(displayName || '').trim().split(/\s+/).filter(Boolean);
  if(!parts.length) return {lastName:'',firstName:''};
  if(parts.length === 1) return {lastName:parts[0],firstName:''};
  return {
    lastName: parts.slice(0,-1).join(' '),
    firstName: parts[parts.length-1]
  };
}

function createDriverFromName(displayName){
  const split = splitDriverDisplayName(displayName);
  return {
    id: 'drv_' + Math.random().toString(36).slice(2) + Date.now().toString(36),
    lastName: split.lastName,
    firstName: split.firstName,
    status: 'titulaire',
    birthDate: '',
    birthCity: '',
    birthPostalCode: '',
    phone: '',
    address: '',
    postalCode: '',
    city: '',
    licenseNumber: '',
    licenseIssueDate: '',
    licenseExpiry: ''
  };
}

function seedDriversFromAffectations(){
  const seen = new Set();
  return affectations
    .filter(item=>String(item.name || '').trim())
    .filter(item=>{
      const key = normalizeAffText(item.name);
      if(seen.has(key)) return false;
      seen.add(key);
      return true;
    })
    .map(item=>{
      const driver = createDriverFromName(item.name);
      driver.phone = String(item.phone || '').trim();
      return driver;
    })
    .sort((a,b)=>
      a.lastName.localeCompare(b.lastName,'fr',{sensitivity:'base'}) ||
      a.firstName.localeCompare(b.firstName,'fr',{sensitivity:'base'})
    );
}

function normalizeDriverStatus(value){
  const raw=String(value||'').trim().toLowerCase();
  if(raw==='regional'||raw==='régional') return 'regional';
  if(raw==='jockey') return 'jockey';
  if(['inactive','inactif','parti','partie','sorti','sortie'].includes(raw)) return 'inactive';
  return 'titulaire';
}

function saveDriverProfiles(){
  try{
    localStorage.setItem(DRIVER_STORAGE_KEY,JSON.stringify(driverProfiles));
    return true;
  }catch(error){
    console.warn('Impossible d’enregistrer les fiches chauffeurs.',error);
    return false;
  }
}

function populateAssignmentDriverChoices(select,currentName=''){
  if(!select) return;

  const currentKey=normalizeAffText(currentName);
  const assignedNames=new Set(
    affectations
      .map(item=>normalizeAffText(item.name))
      .filter(Boolean)
  );

  const choices=(Array.isArray(driverProfiles)?driverProfiles:[])
    .map(driver=>({
      name:driverDisplayName(driver),
      lastName:String(driver.lastName||''),
      firstName:String(driver.firstName||''),
      status:normalizeDriverStatus(driver.status)
    }))
    .filter(item=>item.name)
    .filter(item=>item.status!=='inactive' || normalizeAffText(item.name)===currentKey)
    .sort((a,b)=>
      a.lastName.localeCompare(b.lastName,'fr',{sensitivity:'base'}) ||
      a.firstName.localeCompare(b.firstName,'fr',{sensitivity:'base'})
    );

  const seen=new Set();
  let options='<option value="">— Sélectionner un chauffeur —</option>';

  choices.forEach(item=>{
    const key=normalizeAffText(item.name);
    if(!key || seen.has(key)) return;
    seen.add(key);
    const allowsMultiple=item.status==='regional';
    const alreadyAssigned=assignedNames.has(key) && key!==currentKey && !allowsMultiple;
    const statusLabel=DRIVER_STATUSES[item.status]||'Titulaire';
    const suffix=alreadyAssigned?' · Déjà affecté':allowsMultiple?' · Régional · Multi-affectation':` · ${statusLabel}`;
    options += `<option value="${item.name.replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}" ${alreadyAssigned?'disabled':''}>${item.name}${suffix}</option>`;
  });

  if(currentName && !seen.has(currentKey)){
    const safe=String(currentName)
      .replace(/&/g,'&amp;')
      .replace(/"/g,'&quot;')
      .replace(/</g,'&lt;')
      .replace(/>/g,'&gt;');
    options += `<option value="${safe}">${safe}</option>`;
  }

  select.innerHTML=options;
  if(currentName) select.value=currentName;
}

function setDriverEditMode(enabled){
  driverEditMode = Boolean(enabled);
  driverDetailContent.classList.toggle('driver-readonly',!driverEditMode);
  driverEditableFields.forEach(field=>{
    field.disabled = !driverEditMode;
  });
  if(editDriverButton) editDriverButton.hidden = driverEditMode;
  if(cancelDriverEditButton) cancelDriverEditButton.hidden = !driverEditMode;
  if(saveDriverButton) saveDriverButton.hidden = !driverEditMode;
}

function renderDriverList(){
  const q = normalizeAffText(driverSearch.value);
  const statusFilter = driverStatusFilter?.value || 'active';
  const visible = [...driverProfiles]
    .filter(item=>{
      const status=normalizeDriverStatus(item.status);
      return statusFilter==='active' ? status!=='inactive' : status===normalizeDriverStatus(statusFilter);
    })
    .filter(item=>normalizeAffText(`${item.lastName} ${item.firstName} ${driverStatusLabel(item)} ${item.birthCity||''} ${item.birthPostalCode||''} ${item.city} ${item.phone} ${item.licenseNumber} ${item.licenseIssueDate||''}`).includes(q))
    .sort((a,b)=>
      a.lastName.localeCompare(b.lastName,'fr',{sensitivity:'base'}) ||
      a.firstName.localeCompare(b.firstName,'fr',{sensitivity:'base'})
    );

  if(!visible.length){
    driverList.innerHTML = '<div class="empty-row">Aucun chauffeur ne correspond à votre filtre.</div>';
  }else{
    driverList.innerHTML = visible.map(item=>`
      <div class="driver-item ${item.id === selectedDriverId ? 'selected' : ''}" data-driver-id="${item.id}">
        <div class="driver-avatar">${driverInitials(item)}</div>
        <div>
          <div class="driver-list-name">${driverDisplayName(item) || 'Sans nom'}${driverStatusBadge(item)}</div>
          <div class="driver-list-sub">${driverSecondaryLine(item)}</div>
        </div>
        <button class="driver-menu-btn" type="button" data-driver-menu="${item.id}" aria-label="Actions pour ${driverDisplayName(item)}">•••</button>
      </div>
    `).join('');
  }

  driverListCount.textContent = `${visible.length} chauffeur${visible.length > 1 ? 's' : ''} affiché${visible.length > 1 ? 's' : ''}`;
}

function getSelectedDriver(){
  return driverProfiles.find(item=>item.id === selectedDriverId) || null;
}

function fillDriverForm(){
  const item = getSelectedDriver();
  if(!item){
    driverEmptyState.hidden = false;
    driverDetailContent.hidden = true;
    return;
  }

  driverEmptyState.hidden = true;
  driverDetailContent.hidden = false;
  driverDetailName.textContent = driverDisplayName(item) || 'Fiche chauffeur';
  driverBigAvatar.textContent = driverInitials(item);

  driverLastName.value = item.lastName || '';
  driverFirstName.value = item.firstName || '';
  driverStatus.value = normalizeDriverStatus(item.status);
  driverBirthDate.value = item.birthDate || '';
  driverBirthCity.value = item.birthCity || '';
  driverBirthPostalCode.value = item.birthPostalCode || '';
  driverPhone.value = item.phone || '';
  driverAddress.value = item.address || '';
  driverPostalCode.value = item.postalCode || '';
  driverCity.value = item.city || '';
  driverLicenseNumber.value = item.licenseNumber || '';
  driverLicenseIssueDate.value = item.licenseIssueDate || '';
  driverLicenseExpiry.value = item.licenseExpiry || '';
  driverSaveNotice.textContent = '';
  setDriverEditMode(false);
}

function closeDriverActionsMenu(){
  driverActionsMenu.hidden = true;
  activeDriverId = null;
  activeDriverMenuButton = null;
}

function openDriverActionsMenu(button,id){
  closeDriverActionsMenu();
  activeDriverId = id;
  activeDriverMenuButton = button;
  driverActionsMenu.hidden = false;

  const buttonRect = button.getBoundingClientRect();
  const menuRect = driverActionsMenu.getBoundingClientRect();
  const left = Math.max(10,Math.min(buttonRect.right-menuRect.width,window.innerWidth-menuRect.width-10));
  let top = buttonRect.bottom+6;
  if(top+menuRect.height > window.innerHeight-10) top = buttonRect.top-menuRect.height-6;
  driverActionsMenu.style.left = `${left}px`;
  driverActionsMenu.style.top = `${Math.max(10,top)}px`;
}

function syncDriverModalState(){
  const currentModalOpen =
    !addDriverModal.hidden ||
    !deleteDriverModal.hidden;
  if(currentModalOpen) document.body.classList.add('modal-open');
  else if(
    document.querySelectorAll('.modal-overlay:not([hidden])').length === 0
  ) document.body.classList.remove('modal-open');
}

function openAddDriverModal(){
  addDriverForm.reset();
  if(newDriverStatus) newDriverStatus.value='titulaire';
  addDriverError.textContent = '';
  addDriverModal.hidden = false;
  syncDriverModalState();
  requestAnimationFrame(()=>newDriverLastName.focus());
}

function closeAddDriverModal(){
  addDriverModal.hidden = true;
  addDriverError.textContent = '';
  syncDriverModalState();
}

function closeDeleteDriverModal(){
  deleteDriverModal.hidden = true;
  pendingDeleteDriverId = null;
  syncDriverModalState();
}

function closeClaimActionsMenu(){
  claimActionsMenu.hidden = true;
  activeClaimMenuId = null;
  activeClaimMenuButton = null;
}

function openClaimActionsMenu(button,id){
  closeClaimActionsMenu();
  activeClaimMenuId = id;
  activeClaimMenuButton = button;
  claimActionsMenu.hidden = false;

  const rect = button.getBoundingClientRect();
  const menuRect = claimActionsMenu.getBoundingClientRect();
  const left = Math.max(10,Math.min(rect.right-menuRect.width,window.innerWidth-menuRect.width-10));
  let top = rect.bottom+6;
  if(top+menuRect.height > window.innerHeight-10){
    top = rect.top-menuRect.height-6;
  }

  claimActionsMenu.style.left = `${left}px`;
  claimActionsMenu.style.top = `${Math.max(10,top)}px`;
}

function openDeleteClaimModal(id){
  const item = claimData.find(claim=>claim.id === id);
  if(!item) return;

  pendingDeleteClaimId = id;
  deleteClaimNumber.textContent = item.number || 'sans n° de dossier';
  deleteClaimModal.hidden = false;
  document.body.classList.add('modal-open');
  requestAnimationFrame(()=>document.getElementById('confirmDeleteClaim').focus());
}

function closeDeleteClaimModal(){
  deleteClaimModal.hidden = true;
  pendingDeleteClaimId = null;

  if(document.querySelectorAll('.modal-overlay:not([hidden])').length === 0){
    document.body.classList.remove('modal-open');
  }
}

async function deleteAllClaimFiles(claimId){
  try{
    const files = await getClaimFiles(claimId);
    for(const file of files){
      await deleteClaimFile(file.key);
    }
  }catch(error){
    console.warn('Impossible de supprimer toutes les pièces jointes du sinistre.',error);
  }
}

function saveClaims(){
  try{
    localStorage.setItem(CLAIM_STORAGE_KEY,JSON.stringify(claimData));
    return true;
  }catch(error){
    console.warn('Impossible d’enregistrer les sinistres.',error);
    return false;
  }
}

function saveClaimEvents(){
  try{
    localStorage.setItem(CLAIM_EVENTS_KEY,JSON.stringify(claimEventsData.slice(0,30)));
  }catch(error){
    console.warn('Impossible d’enregistrer l’historique des sinistres.',error);
  }
}

function addClaimEvent(message){
  claimEventsData.unshift({
    id:'evt_'+Date.now()+'_'+Math.random().toString(36).slice(2),
    message,
    date:new Date().toISOString()
  });
  claimEventsData = claimEventsData.slice(0,30);
  saveClaimEvents();
  renderClaimEvents();
}

function getSelectedClaim(){
  return claimData.find(item=>item.id === selectedClaimId) || null;
}

function formatClaimDate(value){
  if(!value) return '—';
  const d = new Date(value+'T00:00:00');
  return Number.isNaN(d.getTime()) ? value : d.toLocaleDateString('fr-FR');
}

function formatMoney(value){
  const number = Number(String(value ?? '').replace(',','.'));
  if(!Number.isFinite(number)) return 0;
  return number;
}

function normalizeClaimSearch(value){
  return String(value || '')
    .toLocaleLowerCase('fr')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g,'');
}

function updateClaimKpis(){
  const opened = claimData.filter(item=>item.status === 'Ouvert' || item.status === 'Urgent').length;
  const waiting = claimData.filter(item=>item.status === 'En attente').length;
  const closed = claimData.filter(item=>item.status === 'Clos').length;
  const cost = claimData
    .filter(item=>item.status !== 'Clos')
    .reduce((sum,item)=>sum+formatMoney(item.cost),0);

  document.getElementById('claimOpenCount').textContent = opened;
  document.getElementById('claimWaitingCount').textContent = waiting;
  document.getElementById('claimClosedCount').textContent = closed;
  document.getElementById('claimCostTotal').textContent =
    cost.toLocaleString('fr-FR',{maximumFractionDigits:2})+' €';
}

function renderClaims(){
  const q = normalizeClaimSearch(claimSearch.value);
  const rows = [...claimData]
    .sort((a,b)=>String(b.date || '').localeCompare(String(a.date || '')))
    .filter(item=>{
      const searchable = normalizeClaimSearch(
        `${item.number} ${item.date} ${item.driver} ${item.vehicle} ${item.type} ${item.status} AXA France`
      );
      return searchable.includes(q);
    });

  if(!rows.length){
    claimTable.innerHTML = `
      <tr>
        <td colspan="7" class="claim-empty-table">
          ${claimData.length ? 'Aucun sinistre ne correspond à votre recherche.' : 'Aucun sinistre enregistré.'}
        </td>
      </tr>
    `;
  }else{
    claimTable.innerHTML = rows.map(item=>`
      <tr data-claim-id="${item.id}" class="${item.id === selectedClaimId ? 'selected' : ''}">
        <td>${formatClaimDate(item.date)}</td>
        <td>${item.driver || '—'}</td>
        <td class="plate-cell">${item.vehicle || '—'}</td>
        <td>${item.type || '—'}</td>
        <td><span class="claim-status ${claimStatusClass(item.status)}">${item.status || 'Ouvert'}</span></td>
        <td>AXA France</td>
        <td><button class="claim-row-menu" type="button" data-claim-menu="${item.id}" aria-label="Actions pour ${item.number}">•••</button></td>
      </tr>
    `).join('');
  }

  claimCountLabel.textContent =
    `${rows.length} sinistre${rows.length > 1 ? 's' : ''} affiché${rows.length > 1 ? 's' : ''}`;

  // Jusqu'à 11 sinistres : la liste s'affiche entièrement.
  // À partir du 12e : hauteur fixe + défilement interne.
  claimTableWrap.classList.toggle('claim-scroll', rows.length > 11);

  updateClaimKpis();
  renderClaimTypeSummary();
}

function fillClaimSelectors(item){
  const driverSelect = document.getElementById('claimDetailDriver');
  const vehicleSelect = document.getElementById('claimDetailVehicle');

  const drivers = claimDriverOptions();
  driverSelect.innerHTML =
    '<option value="">— Sélectionner —</option>' +
    drivers.map(name=>`<option value="${name.replace(/"/g,'&quot;')}">${name}</option>`).join('');

  const vehicles = claimVehicleOptions();
  vehicleSelect.innerHTML =
    '<option value="">— Sélectionner —</option>' +
    vehicles.map(vehicle=>`<option value="${vehicle.value}">${vehicle.label}</option>`).join('');

  if(item.driver && ![...driverSelect.options].some(option=>option.value === item.driver)){
    const option = document.createElement('option');
    option.value = item.driver;
    option.textContent = item.driver;
    driverSelect.appendChild(option);
  }
  if(item.vehicle && ![...vehicleSelect.options].some(option=>option.value === item.vehicle)){
    const option = document.createElement('option');
    option.value = item.vehicle;
    option.textContent = item.vehicle;
    vehicleSelect.appendChild(option);
  }

  driverSelect.value = item.driver || '';
  vehicleSelect.value = item.vehicle || '';
}

function loadClaimDetail(){
  const item = getSelectedClaim();

  if(!item){
    claimDetailEmpty.hidden = false;
    claimDetailContent.hidden = true;
    return;
  }

  claimDetailEmpty.hidden = true;
  claimDetailContent.hidden = false;
  claimDraftSnapshot = JSON.parse(JSON.stringify(item));

  document.getElementById('claimDetailNumber').value = item.number || '';
  document.getElementById('claimDetailDate').value = item.date || '';
  fillClaimSelectors(item);
  document.getElementById('claimDetailThirdParty').value = item.thirdParty || '';
  document.getElementById('claimDetailType').value = item.type || '';
  document.getElementById('claimDetailCost').value = item.cost || '';
  document.getElementById('claimDetailStatus').value = item.status || 'Ouvert';
  document.getElementById('claimDetailDescription').value = item.description || '';

  renderClaimTimeline();
  renderClaimAttachments();
}

function readClaimFormInto(item){
  item.number = document.getElementById('claimDetailNumber').value.trim();
  item.date = document.getElementById('claimDetailDate').value;
  item.driver = document.getElementById('claimDetailDriver').value;
  item.vehicle = document.getElementById('claimDetailVehicle').value;
  item.thirdParty = document.getElementById('claimDetailThirdParty').value.trim();
  item.type = document.getElementById('claimDetailType').value.trim();
  item.cost = document.getElementById('claimDetailCost').value.trim();
  item.status = document.getElementById('claimDetailStatus').value;
  item.description = document.getElementById('claimDetailDescription').value.trim();
  item.insurance = 'AXA France';
}

function renderClaimTimeline(){
  const item = getSelectedClaim();
  const progress = item ? Math.max(0,Math.min(3,Number(item.progress) || 0)) : 0;

  claimTimeline.querySelectorAll('.claim-step').forEach(step=>{
    const stage = Number(step.dataset.stage);
    step.classList.toggle('done',stage <= progress);
    step.classList.toggle('current',stage === progress);
  });
}

function openClaimFileDb(){
  return new Promise((resolve,reject)=>{
    const request = indexedDB.open(CLAIM_FILE_DB,1);

    request.onupgradeneeded = ()=>{
      const db = request.result;
      if(!db.objectStoreNames.contains(CLAIM_FILE_STORE)){
        const store = db.createObjectStore(CLAIM_FILE_STORE,{keyPath:'key'});
        store.createIndex('claimId','claimId',{unique:false});
      }
    };

    request.onsuccess = ()=>resolve(request.result);
    request.onerror = ()=>reject(request.error);
  });
}

async function putClaimFile(claimId,file){
  const db = await openClaimFileDb();
  const id = 'file_'+Date.now()+'_'+Math.random().toString(36).slice(2);
  const record = {
    key:`${claimId}::${id}`,
    claimId,
    id,
    name:file.name,
    type:file.type,
    size:file.size,
    blob:file,
    addedAt:new Date().toISOString()
  };

  await new Promise((resolve,reject)=>{
    const tx = db.transaction(CLAIM_FILE_STORE,'readwrite');
    tx.objectStore(CLAIM_FILE_STORE).put(record);
    tx.oncomplete = resolve;
    tx.onerror = ()=>reject(tx.error);
  });
  db.close();
  return record;
}

async function getClaimFiles(claimId){
  if(!claimId) return [];
  const db = await openClaimFileDb();

  const records = await new Promise((resolve,reject)=>{
    const tx = db.transaction(CLAIM_FILE_STORE,'readonly');
    const index = tx.objectStore(CLAIM_FILE_STORE).index('claimId');
    const request = index.getAll(claimId);
    request.onsuccess = ()=>resolve(request.result || []);
    request.onerror = ()=>reject(request.error);
  });

  db.close();
  return records.sort((a,b)=>String(a.addedAt).localeCompare(String(b.addedAt)));
}

async function deleteClaimFile(key){
  const db = await openClaimFileDb();
  await new Promise((resolve,reject)=>{
    const tx = db.transaction(CLAIM_FILE_STORE,'readwrite');
    tx.objectStore(CLAIM_FILE_STORE).delete(key);
    tx.oncomplete = resolve;
    tx.onerror = ()=>reject(tx.error);
  });
  db.close();
}

function formatFileSize(bytes){
  if(bytes < 1024) return bytes+' o';
  if(bytes < 1024*1024) return (bytes/1024).toFixed(1).replace('.',',')+' Ko';
  return (bytes/(1024*1024)).toFixed(1).replace('.',',')+' Mo';
}

async function renderClaimAttachments(){
  const item = getSelectedClaim();
  if(!item){
    claimAttachmentList.innerHTML = '';
    return;
  }

  try{
    const files = await getClaimFiles(item.id);

    claimAttachmentList.innerHTML = files.map(file=>`
      <div class="claim-file" data-file-key="${file.key}">
        <span>▤</span>
        <span class="claim-file-name" title="${file.name.replace(/"/g,'&quot;')}">${file.name}</span>
        <span class="claim-file-meta">${formatFileSize(file.size)}</span>
        <button class="claim-file-remove" type="button" data-delete-file="${file.key}" aria-label="Supprimer ${file.name.replace(/"/g,'&quot;')}">✕</button>
      </div>
    `).join('') + `
      <button class="claim-file add" type="button" id="addClaimAttachment"><span class="button-icon"><svg class="app-icon" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v14M5 12h14"/></svg></span>Ajouter</button>
    `;

    document.getElementById('addClaimAttachment').addEventListener('click',()=>{
      claimAttachmentInput.click();
    });
  }catch(error){
    console.warn('Impossible de charger les pièces jointes.',error);
    claimAttachmentList.innerHTML = `
      <button class="claim-file add" type="button" id="addClaimAttachment"><span class="button-icon"><svg class="app-icon" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v14M5 12h14"/></svg></span>Ajouter</button>
    `;
    document.getElementById('addClaimAttachment').addEventListener('click',()=>{
      claimAttachmentInput.click();
    });
  }
}

function renderClaimTypeSummary(){
  const container = document.getElementById('claimTypeSummary');

  if(!claimData.length){
    container.innerHTML = '<div class="claim-empty-summary">Aucun sinistre enregistré.</div>';
    return;
  }

  const counts = new Map();
  claimData.forEach(item=>{
    const type = String(item.type || '').trim() || 'Non renseigné';
    counts.set(type,(counts.get(type) || 0)+1);
  });

  const entries = [...counts.entries()].sort((a,b)=>b[1]-a[1]).slice(0,5);
  const colors = ['#db3333','#f39b2f','#5ba7ff','#7b61d1','#6b747e'];
  const total = claimData.length;

  let current = 0;
  const gradientParts = entries.map(([type,count],index)=>{
    const start = current;
    current += count/total*100;
    return `${colors[index]} ${start}% ${current}%`;
  });

  container.innerHTML = `
    <div class="claim-donut-wrap">
      <div class="claim-donut" style="background:conic-gradient(${gradientParts.join(',')})">
        <div class="claim-donut-center">${total}<small>Sinistre${total > 1 ? 's' : ''}</small></div>
      </div>
      <div class="claim-legend">
        ${entries.map(([type,count],index)=>`
          <div class="claim-legend-row">
            <span class="claim-dot" style="background:${colors[index]}"></span>
            ${type} · ${count}
          </div>
        `).join('')}
      </div>
    </div>
  `;
}

function renderClaimEvents(){
  const container = document.getElementById('claimEvents');

  if(!claimEventsData.length){
    container.innerHTML = '<div class="claim-empty-summary">Aucun événement pour le moment.</div>';
    return;
  }

  container.innerHTML = claimEventsData.slice(0,5).map(event=>{
    const date = new Date(event.date);
    const formatted = Number.isNaN(date.getTime())
      ? ''
      : date.toLocaleString('fr-FR',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'});

    return `
      <div class="claim-event">
        <span class="claim-event-dot"></span>
        <span>${event.message}</span>
        <span class="claim-event-time">${formatted}</span>
      </div>
    `;
  }).join('');
}

function saveTechnicalDeadlines(){
  try{localStorage.setItem(TECH_DEADLINE_STORAGE_KEY,JSON.stringify(technicalDeadlines));return true}
  catch(error){console.warn('Sauvegarde des échéances techniques impossible.',error);return false}
}

function saveVidangeData(){
  try{localStorage.setItem(VIDANGE_STORAGE_KEY,JSON.stringify(vidangeData));return true}
  catch(error){console.warn('Impossible d’enregistrer le suivi des vidanges.',error);return false}
}

function kmNumber(value){
  if(value===null || value===undefined || value==='') return null;
  const n=Number(String(value).replace(/\s/g,'').replace(',','.'));
  return Number.isFinite(n)?n:null;
}

function excelNumeric(value){const n=kmNumber(value);return n===null?0:n}

function calculateNextOil(record){
  if(record._fromPark&&record.currentKm==null)return NaN;
  const E=excelNumeric(record.currentKm),F=excelNumeric(record.lastMajorKm),G=excelNumeric(record.lastGarageKm);
  return F===G ? G+Number(record.sameInterval||0)-E : F+Number(record.differentInterval||0)-E;
}

function formatKm(value){const n=kmNumber(value);return n===null?'—':`${n.toLocaleString('fr-FR')} km`}

function formatRemaining(value){return Number.isFinite(Number(value))?`${Number(value).toLocaleString('fr-FR')} km`:'À renseigner'}

function sortedVidangeData(){
  return [...vidangeData].sort((a,b)=>calculateNextOil(a)-calculateNextOil(b)||
    normalizeRegistration(a.registration).localeCompare(normalizeRegistration(b.registration),'fr',{numeric:true}));
}

function vidAssignedDriver(record){
  return window.technicalAssignedDriver?.(record.registration)||'';
}

function updateVidKpis(){
  let late=0,soon=0,ok=0;
  vidangeData.forEach(r=>{const s=vidStatus(r);if(s.className==='late')late++;else if(s.className==='soon')soon++;else if(s.className==='ok')ok++});
  document.getElementById('vidTotal').textContent=vidangeData.length;
  document.getElementById('vidLate').textContent=late;
  document.getElementById('vidSoon').textContent=soon;
  document.getElementById('vidOk').textContent=ok;
}

function renderVidTable(){
  const q=vidSearchText(vidSearch.value);
  const statusFilter=document.getElementById('vidStatusFilter')?.value||'';
  const visible=sortedVidangeData().filter(r=>(!statusFilter||vidStatus(r).className===statusFilter)&&vidSearchText(`${r.registration} ${vidAssignedDriver(r)} ${r.currentKm??''}`).includes(q));
  if(!visible.length){
    vidTable.innerHTML='<tr><td colspan="7" class="empty-row">Aucun véhicule ne correspond à votre recherche.</td></tr>';
  }else{
    vidTable.innerHTML=visible.map(r=>{
      const next=calculateNextOil(r),status=vidStatus(r),driver=vidAssignedDriver(r);
      return `<tr data-vid-id="${r.id}" class="${r.id===selectedVidangeId?'selected':''}">
        <td class="plate-cell">${formatRegistration(r.registration)}</td>
        <td>${String(driver||'Non affecté').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}</td>
        <td><span class="vid-next ${status.className}">${formatRemaining(next)}</span></td>
        <td class="vid-km">${formatKm(r.currentKm)}</td>
        <td class="vid-km ${r.lastMajorKm===null?'vid-empty':''}">${formatKm(r.lastMajorKm)}</td>
        <td class="vid-km ${r.lastGarageKm===null?'vid-empty':''}">${formatKm(r.lastGarageKm)}</td>
        <td><span class="vid-status ${status.className}">${status.label}</span></td>
      </tr>`;
    }).join('');
  }
  vidCountLabel.textContent=`${visible.length} véhicule${visible.length>1?'s':''} affiché${visible.length>1?'s':''}`;
  vidTableWrap.classList.toggle('scroll',visible.length>11);
  updateVidKpis();
}

function selectedVidRecord(){return vidangeData.find(r=>r.id===selectedVidangeId)||null}

function refreshVidDetailComputed(r){
  const s=vidStatus(r),next=calculateNextOil(r);
  const badge=document.getElementById('vidDetailStatus');
  const value=document.getElementById('vidDetailNext');
  badge.className=`vid-status ${s.className}`;badge.textContent=s.label;
  value.className=`vid-calc-value vid-next ${s.className}`;value.textContent=formatRemaining(next);
  document.getElementById('vidDetailRule').innerHTML=
    `Règle issue de la formule Excel de ce véhicule :<br>`+
    `si <strong>KM dernière grosse vidange = dernier passage garage</strong> → +${Number(r.sameInterval).toLocaleString('fr-FR')} km ; `+
    `sinon → +${Number(r.differentInterval).toLocaleString('fr-FR')} km.`;
}

function loadVidDetail(){
  const r=selectedVidRecord();
  if(!r){vidDetailEmpty.hidden=false;vidDetailContent.hidden=true;return}
  vidDetailEmpty.hidden=true;vidDetailContent.hidden=false;vidangeDraft=JSON.parse(JSON.stringify(r));
  document.getElementById('vidDetailPlate').textContent=formatRegistration(r.registration);
  document.getElementById('vidDetailDriver').textContent=vidAssignedDriver(r)||'Non affecté';
  document.getElementById('vidCurrentKm').value=r.currentKm??'';
  document.getElementById('vidLastMajorKm').value=r.lastMajorKm??'';
  document.getElementById('vidLastGarageKm').value=r.lastGarageKm??'';
  document.getElementById('vidNotice').textContent='';
  refreshVidDetailComputed(r);
}

function printVidangeSimple(){
  const q=vidSearchText(vidSearch.value);
  const rows=sortedVidangeData().filter(r=>
    vidSearchText(`${r.registration} ${vidAssignedDriver(r)} ${r.currentKm??''}`).includes(q)
  );

  const escapePrint=value=>String(value??'')
    .replace(/&/g,'&amp;')
    .replace(/</g,'&lt;')
    .replace(/>/g,'&gt;')
    .replace(/"/g,'&quot;')
    .replace(/'/g,'&#039;');

  const body=rows.map(r=>{
    const driver=vidAssignedDriver(r)||'Non affecté';
    const next=calculateNextOil(r);
    const status=vidStatus(r);

    return `
      <tr>
        <td class="plate">${escapePrint(formatRegistration(r.registration))}</td>
        <td>${escapePrint(driver)}</td>
        <td class="number ${status.className}">${escapePrint(formatRemaining(next))}</td>
        <td class="number">${escapePrint(formatKm(r.currentKm))}</td>
        <td class="number">${escapePrint(formatKm(r.lastMajorKm))}</td>
        <td class="number">${escapePrint(formatKm(r.lastGarageKm))}</td>
      </tr>
    `;
  }).join('');

  const printFrame=document.createElement('iframe');
  printFrame.style.position='fixed';
  printFrame.style.right='0';
  printFrame.style.bottom='0';
  printFrame.style.width='0';
  printFrame.style.height='0';
  printFrame.style.border='0';
  printFrame.style.visibility='hidden';
  document.body.appendChild(printFrame);

  const doc=printFrame.contentDocument || printFrame.contentWindow.document;
  doc.open();
  doc.write(`<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<title>Liste des vidanges</title>
<style>
  @page{
    size:A4 landscape;
    margin:10mm;
  }

  *{
    box-sizing:border-box;
  }

  body{
    margin:0;
    background:#fff;
    color:#000;
    font-family:Arial,Helvetica,sans-serif;
    font-size:8.5pt;
  }

  h1{
    margin:0 0 3mm;
    font-size:14pt;
    font-weight:700;
  }

  .print-meta{
    margin-bottom:4mm;
    color:#444;
    font-size:8pt;
  }

  table{
    width:88%;
    margin-right:auto;
    border-collapse:collapse;
    table-layout:fixed;
  }

  thead{
    display:table-header-group;
  }

  tr{
    page-break-inside:avoid;
  }

  th,
  td{
    border:1px solid #555;
    padding:2.1mm 1.4mm;
    vertical-align:middle;
  }

  th{
    background:#eee;
    font-size:7.5pt;
    font-weight:700;
    text-align:left;
  }

  td{
    line-height:1.2;
  }

  .plate{
    font-weight:700;
    white-space:nowrap;
  }

  .number{
    text-align:right;
    white-space:nowrap;
  }

  .status{
    text-align:center;
    font-weight:700;
    white-space:nowrap;
  }

  .late{
    font-weight:700;
  }

  .soon{
    font-weight:700;
  }

  th:nth-child(1){width:15%}
  th:nth-child(2){width:25%}
  th:nth-child(3){width:15%}
  th:nth-child(4){width:15%}
  th:nth-child(5){width:15%}
  th:nth-child(6){width:15%}
  
</style>
</head>
<body>
  <h1>Suivi des vidanges</h1>
  <div class="print-meta">
    ${rows.length} véhicule${rows.length>1?'s':''} · Impression du ${new Date().toLocaleDateString('fr-FR')}
  </div>

  <table>
    <thead>
      <tr>
        <th>Immatriculation</th>
        <th>Chauffeur</th>
        <th>Prochaine vidange</th>
        <th>Km actuel</th>
        <th>Dernière grosse vidange</th>
        <th>Dernier passage garage</th>
      </tr>
    </thead>
    <tbody>
      ${body || '<tr><td colspan="6">Aucune ligne à imprimer.</td></tr>'}
    </tbody>
  </table>
<style>
/* ===== POPUPS PLUS CARRES ===== */
.modal-card,
.confirm-card,
.jef-card,
.admin-modal-card,
.fuel-modal-card,
.user-id-modal-card,
.shared-storage-modal-card,
.adminsec-modal-card{
  border-radius:6px !important;
  overflow:hidden;
}

.modal-head,
.modal-body,
.modal-actions{
  border-radius:0 !important;
}

.modal-close-btn,
.modal-btn,
.tool-btn,
.modal-card .btn,
.confirm-card .btn,
.jef-card .btn,
.admin-modal-card .btn,
.fuel-modal-card .btn,
.user-id-modal-card .btn,
.shared-storage-modal-card .btn,
.adminsec-modal-card .btn{
  border-radius:4px !important;
}

.form-field input,
.form-field select,
.claim-select,
.claim-input,
.claim-textarea,
.jef-textarea,
.jef-preview input,
.user-id-field input,
.adminsec-field input,
.shared-storage-simple input,
.shared-storage-simple select,
.shared-storage-simple textarea{
  border-radius:4px !important;
}

.confirm-warning,
.jef-instructions,
.shared-storage-hero,
.shared-storage-message,
.adminsec-error{
  border-radius:4px !important;
}

.modal-icon,
.adminsec-icon{
  border-radius:6px !important;
}
</style>

</body>
</html>`);
  doc.close();

  setTimeout(()=>{
    printFrame.contentWindow.focus();
    printFrame.contentWindow.print();

    setTimeout(()=>{
      printFrame.remove();
    },1000);
  },250);
}

function openJefPreview(fileName){
  jefError.textContent='';
  jefFileName.textContent=fileName || '—';
  jefPreviewBody.innerHTML='';
  jefSummary.classList.add('loading');
  jefSummary.textContent='Lecture du fichier Excel…';
  applyJef.disabled=true;
  jefMatches=[];
  jefModal.hidden=false;
  document.body.classList.add('modal-open');
}

function closeJefModal(){
  jefModal.hidden=true;
  jefError.textContent='';
  jefSummary.classList.remove('loading');
  if(document.querySelectorAll('.modal-overlay:not([hidden])').length===0){
    document.body.classList.remove('modal-open');
  }
}

function xmlDocument(xmlText){
  const doc=new DOMParser().parseFromString(xmlText,'application/xml');
  if(doc.getElementsByTagName('parsererror').length){
    throw new Error('Le fichier Excel contient un XML illisible.');
  }
  return doc;
}

function columnIndexFromCellRef(ref){
  const letters=String(ref||'').match(/[A-Z]+/i)?.[0]?.toUpperCase() || '';
  let value=0;
  for(const char of letters){
    value=value*26+(char.charCodeAt(0)-64);
  }
  return Math.max(0,value-1);
}

function normalizeXlsxPath(target){
  let path=String(target||'').replace(/\\/g,'/');
  if(path.startsWith('/')) path=path.slice(1);
  if(path.startsWith('xl/')) return path;
  while(path.startsWith('../')) path=path.slice(3);
  return 'xl/'+path.replace(/^\/+/,'');
}

async function readSharedStrings(zip){
  const entry=zip.file('xl/sharedStrings.xml');
  if(!entry) return [];

  const doc=xmlDocument(await entry.async('string'));
  return [...doc.getElementsByTagName('si')].map(si=>
    [...si.getElementsByTagName('t')].map(node=>node.textContent||'').join('')
  );
}

function cellValue(cell,sharedStrings){
  const type=cell.getAttribute('t') || '';

  if(type==='inlineStr'){
    return [...cell.getElementsByTagName('t')].map(node=>node.textContent||'').join('');
  }

  const valueNode=cell.getElementsByTagName('v')[0];
  if(!valueNode) return '';

  const raw=valueNode.textContent ?? '';

  if(type==='s'){
    return sharedStrings[Number(raw)] ?? '';
  }
  if(type==='b'){
    return raw==='1';
  }
  if(type==='str'){
    return raw;
  }

  const number=Number(raw);
  return Number.isFinite(number) ? number : raw;
}

async function readWorksheetRows(zip,path,sharedStrings){
  const entry=zip.file(path);
  if(!entry) return [];

  const doc=xmlDocument(await entry.async('string'));
  const result=[];

  for(const rowNode of [...doc.getElementsByTagName('row')]){
    const rowIndex=Math.max(0,Number(rowNode.getAttribute('r')||1)-1);
    const row=[];

    for(const cell of [...rowNode.getElementsByTagName('c')]){
      const col=columnIndexFromCellRef(cell.getAttribute('r'));
      row[col]=cellValue(cell,sharedStrings);
    }

    result[rowIndex]=row;
  }

  return result;
}

async function readXlsxSheets(file){
  if(typeof JSZip==='undefined'){
    throw new Error('Le lecteur Excel intégré n’est pas disponible.');
  }

  const zip=await JSZip.loadAsync(file);
  const workbookEntry=zip.file('xl/workbook.xml');
  const relsEntry=zip.file('xl/_rels/workbook.xml.rels');

  if(!workbookEntry || !relsEntry){
    throw new Error('Ce fichier ne semble pas être un classeur .xlsx valide.');
  }

  const [workbookXml,relsXml,sharedStrings]=await Promise.all([
    workbookEntry.async('string'),
    relsEntry.async('string'),
    readSharedStrings(zip)
  ]);

  const workbookDoc=xmlDocument(workbookXml);
  const relsDoc=xmlDocument(relsXml);

  const relMap=new Map(
    [...relsDoc.getElementsByTagName('Relationship')].map(rel=>[
      rel.getAttribute('Id'),
      rel.getAttribute('Target')
    ])
  );

  const sheets=[];

  for(const sheetNode of [...workbookDoc.getElementsByTagName('sheet')]){
    const name=sheetNode.getAttribute('name') || 'Feuille';
    const relationId=
      sheetNode.getAttribute('r:id') ||
      sheetNode.getAttributeNS(
        'http://schemas.openxmlformats.org/officeDocument/2006/relationships',
        'id'
      );

    const target=relMap.get(relationId);
    if(!target) continue;

    const path=normalizeXlsxPath(target);
    const rows=await readWorksheetRows(zip,path,sharedStrings);
    sheets.push({name,rows});
  }

  return sheets;
}

function normalizedHeader(value){
  return String(value??'')
    .toLocaleLowerCase('fr')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g,'')
    .replace(/[^a-z0-9]/g,'');
}

function plateFromCell(value,trackedByPlate){
  const text=String(value??'').trim().toUpperCase();
  const normalized=normalizeRegistration(text);

  if(trackedByPlate.has(normalized)){
    return trackedByPlate.get(normalized).registration;
  }

  const compact=text.replace(/[^A-Z0-9]/g,'');
  const match=compact.match(/^([A-Z]{2})(\d{3})([A-Z]{2})$/);
  if(!match) return null;

  const formatted=`${match[1]}-${match[2]}-${match[3]}`;
  const known=trackedByPlate.get(normalizeRegistration(formatted));
  return known ? known.registration : formatted;
}

function mileageFromCell(value){
  if(typeof value==='number'){
    if(Number.isFinite(value) && value>=0 && value<=3000000) return Math.round(value);
    return null;
  }

  const cleaned=String(value??'')
    .replace(/\u00a0/g,' ')
    .replace(/\s/g,'')
    .replace(/[^\d.,-]/g,'');

  if(!cleaned) return null;

  const normalized=cleaned
    .replace(/[.,](?=\d{3}(?:\D|$))/g,'')
    .replace(',','.');

  const number=Number(normalized);
  if(!Number.isFinite(number) || number<0 || number>3000000) return null;
  return Math.round(number);
}

function mileageHeaderScore(value){
  const h=normalizedHeader(value);
  if(!h) return 0;

  if(
    h.includes('kilometrageactuel') ||
    h.includes('kilometragecourant') ||
    h.includes('kmactuel') ||
    h.includes('currentkm') ||
    h.includes('currentmileage') ||
    h.includes('odometer') ||
    h.includes('compteurkilometrique')
  ) return 160;

  if(
    h.includes('kilometrage') ||
    h.includes('mileage') ||
    h==='km' ||
    h.includes('odometre')
  ) return 80;

  if(
    h.includes('vidange') ||
    h.includes('garage') ||
    h.includes('derniere') ||
    h.includes('dernier') ||
    h.includes('prochaine')
  ) return -120;

  return 0;
}

function plateHeaderScore(value){
  const h=normalizedHeader(value);
  if(!h) return 0;

  if(h.includes('immatriculation') || h.includes('immat')) return 160;
  if(h.includes('plaque') || h.includes('registration') || h.includes('licenseplate')) return 120;
  if(h==='vehicule' || h==='vehicle') return 50;
  return 0;
}

function extractJefFromSheet(sheet,trackedByPlate){
  const rows=sheet.rows || [];
  const maxCols=Math.max(0,...rows.map(row=>Array.isArray(row)?row.length:0));

  if(!maxCols) return {sheetName:sheet.name,items:[],score:0};

  const plateCounts=new Array(maxCols).fill(0);
  let firstPlateRow=Infinity;

  rows.forEach((row,rowIndex)=>{
    if(!Array.isArray(row)) return;

    for(let col=0;col<row.length;col++){
      const plate=plateFromCell(row[col],trackedByPlate);
      if(plate && trackedByPlate.has(normalizeRegistration(plate))){
        plateCounts[col]++;
        firstPlateRow=Math.min(firstPlateRow,rowIndex);
      }
    }
  });

  let plateCol=plateCounts.indexOf(Math.max(...plateCounts));
  const plateCount=plateCounts[plateCol] || 0;

  if(!plateCount){
    return {sheetName:sheet.name,items:[],score:0};
  }

  const headerLimit=Number.isFinite(firstPlateRow)
    ? Math.min(firstPlateRow+1,30)
    : Math.min(rows.length,30);

  let bestHeaderRow=-1;
  let bestPlateHeader=-Infinity;

  for(let r=0;r<headerLimit;r++){
    const score=plateHeaderScore(rows[r]?.[plateCol]);
    if(score>bestPlateHeader){
      bestPlateHeader=score;
      bestHeaderRow=r;
    }
  }

  let kmCol=-1;
  let kmScore=-Infinity;

  for(let col=0;col<maxCols;col++){
    if(col===plateCol) continue;

    let headerScore=0;
    for(let r=0;r<headerLimit;r++){
      headerScore=Math.max(headerScore,mileageHeaderScore(rows[r]?.[col]));
    }

    let numericOnPlateRows=0;
    let plausibleChanges=0;

    rows.forEach(row=>{
      if(!Array.isArray(row)) return;
      const plate=plateFromCell(row[plateCol],trackedByPlate);
      if(!plate || !trackedByPlate.has(normalizeRegistration(plate))) return;

      const km=mileageFromCell(row[col]);
      if(km!==null){
        numericOnPlateRows++;
        if(km>=1000) plausibleChanges++;
      }
    });

    const score=headerScore + numericOnPlateRows*3 + plausibleChanges;
    if(score>kmScore){
      kmScore=score;
      kmCol=col;
    }
  }

  if(kmCol<0){
    return {sheetName:sheet.name,items:[],score:0};
  }

  const byPlate=new Map();

  rows.forEach((row,rowIndex)=>{
    if(!Array.isArray(row)) return;

    const plate=plateFromCell(row[plateCol],trackedByPlate);
    if(!plate) return;

    const normalized=normalizeRegistration(plate);
    const km=mileageFromCell(row[kmCol]);

    if(km===null) return;

    byPlate.set(normalized,{
      registration:plate,
      normalized,
      km,
      row:rowIndex+1
    });
  });

  const knownCount=[...byPlate.keys()].filter(key=>trackedByPlate.has(key)).length;
  const score=knownCount*100 + Math.max(0,kmScore) + plateCount;

  return {
    sheetName:sheet.name,
    items:[...byPlate.values()],
    score,
    plateCol,
    kmCol
  };
}

async function parseJefXlsx(file){
  const sheets=await readXlsxSheets(file);
  if(!sheets.length){
    throw new Error('Aucune feuille exploitable n’a été trouvée dans ce fichier Excel.');
  }

  const trackedByPlate=new Map(
    vidangeData.map(record=>[
      normalizeRegistration(record.registration),
      record
    ])
  );

  const candidates=sheets
    .map(sheet=>extractJefFromSheet(sheet,trackedByPlate))
    .sort((a,b)=>b.score-a.score);

  const best=candidates[0];

  if(!best || !best.items.length){
    throw new Error(
      'Aucune immatriculation et aucun kilométrage exploitable n’ont été détectés dans ce fichier.'
    );
  }

  jefDetectedSheet=best.sheetName;

  return best.items.map(item=>{
    const record=trackedByPlate.get(item.normalized);

    return {
      ...item,
      recordId:record?.id || null,
      currentKm:record?.currentKm ?? null
    };
  });
}

function renderJefPreview(){
  const matched=jefMatches.filter(item=>item.recordId).length;
  const unmatched=jefMatches.length-matched;

  jefPreviewBody.innerHTML=jefMatches.map((item,index)=>`
    <tr>
      <td class="plate-cell">${formatRegistration(item.registration)}</td>
      <td>
        <input
          type="text"
          inputmode="numeric"
          value="${item.km}"
          data-jef-km="${index}"
          ${item.recordId?'':'disabled'}
        >
      </td>
      <td>
        ${item.currentKm===null
          ? '—'
          : Number(item.currentKm).toLocaleString('fr-FR')+' km'}
      </td>
      <td>
        <span class="jef-match ${item.recordId?'ok':'bad'}">
          ${item.recordId?'✓ Véhicule trouvé':'✕ Absent du suivi'}
        </span>
      </td>
    </tr>
  `).join('');

  jefSummary.classList.remove('loading');
  jefSummary.textContent=
    `Feuille détectée : ${jefDetectedSheet} · `+
    `${matched} véhicule${matched>1?'s':''} rapproché${matched>1?'s':''}`+
    (unmatched
      ? ` · ${unmatched} immatriculation${unmatched>1?'s':''} non trouvée${unmatched>1?'s':''}`
      : '');

  applyJef.disabled=matched===0;

  jefPreviewBody.querySelectorAll('[data-jef-km]').forEach(input=>{
    input.addEventListener('input',()=>{
      input.value=input.value.replace(/\D/g,'');
      const index=Number(input.dataset.jefKm);
      if(jefMatches[index]){
        jefMatches[index].km=Number(input.value||0);
      }
    });
  });
}

function saveAdminFines(){localStorage.setItem(ADMIN_FINE_KEY,JSON.stringify(adminFines))}

function saveAdminRungis(){localStorage.setItem(ADMIN_RUNGIS_KEY,JSON.stringify(adminRungis))}

function saveAdminSites(){localStorage.setItem(ADMIN_SITES_KEY,JSON.stringify(adminSites))}

function switchAdminTab(tab){
  adminActiveTab=tab;
  document.dispatchEvent(new CustomEvent('dashboard-navigation',{detail:{admin:tab}}));
  document.querySelectorAll('[data-admin-tab]').forEach(card=>card.classList.toggle('active',card.dataset.adminTab===tab));
  document.getElementById('adminSectionFines').classList.toggle('active',tab==='fines');
  document.getElementById('adminSectionRungis').classList.toggle('active',tab==='rungis');
  document.getElementById('adminSectionSites').classList.toggle('active',tab==='sites');
}

function fineStatusClass(status){
  if(status==='Clos') return 'done';
  if(status==='À prévenir'||status==='À envoyer'||status==='Désigné'||status==='Contesté') return 'pending';
  return 'todo';
}

function fineStatusLabel(status){
  return status==='Désigné' ? 'À envoyer' : (status||'À traiter');
}

function updateFineKpis(){
  document.getElementById('fineTotal').textContent=adminFines.length;
  document.getElementById('fineTodo').textContent=adminFines.filter(x=>x.status==='À traiter'||x.status==='À prévenir').length;
  document.getElementById('finePending').textContent=adminFines.filter(x=>x.status==='À envoyer'||x.status==='Désigné'||x.status==='Contesté').length;
  document.getElementById('fineClosed').textContent=adminFines.filter(x=>x.status==='Clos').length;
  document.getElementById('adminHubFineCount').textContent=adminFines.length;
}

function renderFines(){
  const q=adminNorm(document.getElementById('fineSearch').value);
  const visible=[...adminFines]
    .filter(item=>{const status=document.getElementById('fineListStatus')?.value||'';const itemStatus=fineStatusLabel(item.status);return !status || (status==='pending'?['À envoyer','Contesté'].includes(itemStatus):status==='todo'?['À traiter','À prévenir'].includes(itemStatus):(itemStatus||'À traiter')===status);})
    .sort((a,b)=>String(b.date||'').localeCompare(String(a.date||'')))
    .filter(item=>adminNorm(`${item.date} ${item.vehicle} ${item.driver} ${item.offense} ${item.reference} ${item.status}`).includes(q));

  if(!visible.length){
    fineTable.innerHTML=`<tr><td colspan="8" class="admin-empty">${adminFines.length?'Aucune amende ne correspond à votre recherche.':'Aucune amende enregistrée.'}</td></tr>`;
  }else{
    fineTable.innerHTML=visible.map(item=>`
      <tr data-fine-row="${item.id}" title="Ouvrir l’amende">
        <td>${item.date?new Date(item.date+'T00:00:00').toLocaleDateString('fr-FR'):'—'}</td>
        <td class="plate-cell">${item.vehicle||'—'}</td>
        <td>${item.driver||'—'}</td>
        <td>${item.offense||'—'}</td>
        <td>${item.amount?Number(String(item.amount).replace(',','.')).toLocaleString('fr-FR',{minimumFractionDigits:2,maximumFractionDigits:2})+' €':'—'}</td>
        <td>
          ${item.reference||'—'}
          ${Number(item.attachmentCount||0)>0 ? `<span class="fine-file-count">📎 ${Number(item.attachmentCount||0)}</span>` : ''}
        </td>
        <td><span class="admin-status ${fineStatusClass(item.status)}">${fineStatusLabel(item.status)}</span></td>
        <td><button class="admin-row-menu" type="button" data-admin-menu-type="fine" data-admin-menu-id="${item.id}">•••</button></td>
      </tr>
    `).join('');
  }

  document.getElementById('fineCountLabel').textContent=`${visible.length} amende${visible.length>1?'s':''} affichée${visible.length>1?'s':''}`;
  fineTableWrap.classList.toggle('scroll',visible.length>11);
  updateFineKpis();
}

function rungisVehicleInfo(registration){
  if(!registration) return null;
  const key=normalizeRegistration(registration);
  return parkData.find(v=>normalizeRegistration(v.registration)===key)||null;
}

function updateRungisKpis(){
  const assigned=adminRungis.filter(item=>String(item.vehicle||'').trim()).length;
  const free=adminRungis.length-assigned;
  const outside=adminRungis.filter(item=>item.vehicle && !rungisVehicleInfo(item.vehicle)).length;

  document.getElementById('rungisTotal').textContent=adminRungis.length;
  document.getElementById('rungisAssigned').textContent=assigned;
  document.getElementById('rungisFree').textContent=free;
  document.getElementById('rungisOutsidePark').textContent=outside;
  document.getElementById('adminHubRungisCount').textContent=adminRungis.length;
}

function renderRungis(){
  const q=adminNorm(document.getElementById('rungisSearch').value);

  const visible=[...adminRungis]
    .sort((a,b)=>String(a.cardNumber||'').localeCompare(String(b.cardNumber||''),'fr',{numeric:true}))
    .filter(item=>{
      const vehicle=rungisVehicleInfo(item.vehicle);
      const parkNumber=vehicle?.parkNumber||'';
      return adminNorm(`${item.cardNumber} ${item.vehicle} ${parkNumber}`).includes(q);
    });

  if(!visible.length){
    rungisTable.innerHTML=`<tr><td colspan="4" class="admin-empty">${adminRungis.length?'Aucune carte ne correspond à votre recherche.':'Aucune carte Rungis enregistrée.'}</td></tr>`;
  }else{
    rungisTable.innerHTML=visible.map(item=>{
      const vehicle=rungisVehicleInfo(item.vehicle);
      const parkNumber=vehicle?.parkNumber||'—';

      return `<tr>
        <td><strong>${item.cardNumber||'—'}</strong></td>
        <td class="plate-cell">${item.vehicle?formatRegistration(item.vehicle):'—'}</td>
        <td>${parkNumber}</td>
        <td><button class="admin-row-menu" type="button" data-admin-menu-type="rungis" data-admin-menu-id="${item.id}">•••</button></td>
      </tr>`;
    }).join('');
  }

  document.getElementById('rungisCountLabel').textContent=
    `${visible.length} carte${visible.length>1?'s':''} affichée${visible.length>1?'s':''}`;

  rungisTableWrap.classList.toggle('scroll',visible.length>11);
  updateRungisKpis();
}

function fineSafeFilePart(value){
  return String(value||'')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g,'')
    .replace(/[<>:"/\\|?*\x00-\x1F]/g,'_')
    .replace(/\s+/g,' ')
    .trim()
    .slice(0,120) || 'fichier';
}

async function fineFilesDirectory(create=false){
  if(!sharedConnected || !sharedDirectoryHandle) return null;
  return await sharedDirectoryHandle.getDirectoryHandle(FINE_FILES_FOLDER,{create});
}

async function putFineFile(fineId,file){
  if(!sharedConnected || !sharedDirectoryHandle){
    throw new Error('Stockage partagé non connecté.');
  }

  const dir=await fineFilesDirectory(true);
  const id='file_'+Date.now()+'_'+Math.random().toString(36).slice(2);
  const storedName=
    `${fineSafeFilePart(fineId)}__${id}__${fineSafeFilePart(file.name)}`;

  const handle=await dir.getFileHandle(storedName,{create:true});
  const writable=await handle.createWritable();
  await writable.write(file);
  await writable.close();

  return {
    key:'fine-shared::'+storedName,
    fineId,
    id,
    name:file.name,
    type:file.type,
    size:file.size,
    addedAt:new Date().toISOString()
  };
}

async function getFineFiles(fineId){
  if(!fineId || !sharedConnected || !sharedDirectoryHandle) return [];

  let dir;
  try{
    dir=await fineFilesDirectory(false);
  }catch(error){
    if(error?.name==='NotFoundError') return [];
    throw error;
  }
  if(!dir) return [];

  const prefix=fineSafeFilePart(fineId)+'__';
  const records=[];

  for await(const [storedName,handle] of dir.entries()){
    if(handle.kind!=='file' || !storedName.startsWith(prefix)) continue;

    const file=await handle.getFile();
    const first=storedName.indexOf('__');
    const second=storedName.indexOf('__',first+2);
    const id=second>first ? storedName.slice(first+2,second) : storedName;
    const displayName=second>=0 ? storedName.slice(second+2) : storedName;

    records.push({
      key:'fine-shared::'+storedName,
      fineId,
      id,
      name:displayName,
      type:file.type,
      size:file.size,
      addedAt:new Date(file.lastModified).toISOString()
    });
  }

  return records.sort((a,b)=>String(a.addedAt).localeCompare(String(b.addedAt)));
}

async function deleteFineFile(key){
  if(!sharedConnected || !sharedDirectoryHandle) return;
  if(!String(key||'').startsWith('fine-shared::')) return;

  const dir=await fineFilesDirectory(false);
  if(!dir) return;

  await dir.removeEntry(String(key).slice('fine-shared::'.length));
}

async function deleteAllFineFiles(fineId){
  if(!fineId || !sharedConnected || !sharedDirectoryHandle) return;

  let dir;
  try{
    dir=await fineFilesDirectory(false);
  }catch(error){
    if(error?.name==='NotFoundError') return;
    throw error;
  }
  if(!dir) return;

  const prefix=fineSafeFilePart(fineId)+'__';
  const toDelete=[];

  for await(const [name,handle] of dir.entries()){
    if(handle.kind==='file' && name.startsWith(prefix)) toDelete.push(name);
  }

  for(const name of toDelete){
    await dir.removeEntry(name);
  }
}

async function openFineFile(key){
  if(!sharedConnected || !sharedDirectoryHandle) return;
  if(!String(key||'').startsWith('fine-shared::')) return;

  try{
    const dir=await fineFilesDirectory(false);
    const storedName=String(key).slice('fine-shared::'.length);
    const handle=await dir.getFileHandle(storedName);
    const file=await handle.getFile();
    const url=URL.createObjectURL(file);

    const link=document.createElement('a');
    link.href=url;
    link.target='_blank';
    link.rel='noopener';
    link.click();

    setTimeout(()=>URL.revokeObjectURL(url),15000);
  }catch(error){
    dashboardToast('Fichier impossible à ouvrir',String(error),'error',4000);
  }
}

function fineFormatSize(bytes){
  if(bytes<1024) return bytes+' o';
  if(bytes<1024*1024) return (bytes/1024).toFixed(1).replace('.',',')+' Ko';
  return (bytes/(1024*1024)).toFixed(1).replace('.',',')+' Mo';
}

async function renderFineAttachments(){
  if(!fineAttachmentList) return;

  fineAttachmentWarning.hidden=sharedConnected;

  const savedFiles=editingFineId
    ? await getFineFiles(editingFineId).catch(error=>{
        console.warn('Impossible de lire les pièces jointes Amende.',error);
        return [];
      })
    : [];

  const savedHtml=savedFiles.map(file=>`
    <div class="fine-file">
      <span>▤</span>
      <span class="fine-file-name saved"
            data-open-fine-file="${dashboardEsc(file.key)}"
            title="Ouvrir ${dashboardEsc(file.name)}">${dashboardEsc(file.name)}</span>
      <span class="fine-file-meta">${fineFormatSize(file.size)}</span>
      <button class="fine-file-remove"
              type="button"
              data-delete-fine-file="${dashboardEsc(file.key)}"
              aria-label="Supprimer ${dashboardEsc(file.name)}">✕</button>
    </div>
  `).join('');

  const pendingHtml=pendingFineFiles.map((file,index)=>`
    <div class="fine-file pending">
      <span>▤</span>
      <span class="fine-file-name" title="${dashboardEsc(file.name)}">${dashboardEsc(file.name)}</span>
      <span class="fine-file-meta">${fineFormatSize(file.size)} · à enregistrer</span>
      <button class="fine-file-remove"
              type="button"
              data-remove-pending-fine-file="${index}"
              aria-label="Retirer ${dashboardEsc(file.name)}">✕</button>
    </div>
  `).join('');

  fineAttachmentList.innerHTML=(savedHtml+pendingHtml) ||
    '<span class="vehicle-none">Aucune pièce jointe.</span>';
}

async function updateFineAttachmentCount(fineId){
  const item=adminFines.find(x=>x.id===fineId);
  if(!item) return;

  const files=await getFineFiles(fineId).catch(()=>[]);
  item.attachmentCount=files.length;
  saveAdminFines();
  renderFines();
}

function fineDriverKey(value){
  return adminNorm(value).replace(/\s+/g,' ').trim();
}

function findFineDriverProfile(name){
  const key=fineDriverKey(name);
  if(!key || !Array.isArray(driverProfiles)) return null;
  return driverProfiles.find(driver=>fineDriverKey(driverDisplayName(driver))===key) || null;
}

function updateFineDriverProfileButton(){
  if(!openFineDriverProfileButton || !fineDriverSelect) return;
  const name=String(fineDriverSelect.value||'').trim();
  const profile=findFineDriverProfile(name);
  openFineDriverProfileButton.disabled=!profile;
  openFineDriverProfileButton.title=profile
    ? `Ouvrir la fiche chauffeur de ${driverDisplayName(profile)}`
    : (name ? 'Aucune fiche chauffeur correspondante trouvée' : 'Sélectionnez un chauffeur');
}

function fineDriverPreviewDate(value){
  const raw=String(value||'').trim();
  if(!raw) return '—';
  const match=raw.match(/^(\d{4})-(\d{2})-(\d{2})/);
  return match ? `${match[3]}/${match[2]}/${match[1]}` : raw;
}

function fineDriverPreviewSet(id,value){
  const element=document.getElementById(id);
  if(element) element.textContent=String(value||'').trim() || '—';
}

function closeFineDriverPreview(){
  if(fineDriverPreview) fineDriverPreview.hidden=true;
}

function renderFineDriverPreview(profile){
  if(!profile || !fineDriverPreview) return;
  const fullName=driverDisplayName(profile);
  const initials=`${String(profile.firstName||'').trim().charAt(0)}${String(profile.lastName||'').trim().charAt(0)}`.toUpperCase() || '—';
  fineDriverPreviewSet('fineDriverPreviewTitle',fullName);
  fineDriverPreviewSet('fineDriverPreviewName',fullName);
  fineDriverPreviewSet('fineDriverPreviewAvatar',initials);
  fineDriverPreviewSet('fineDriverPreviewBirthDate',fineDriverPreviewDate(profile.birthDate));
  fineDriverPreviewSet('fineDriverPreviewBirthCity',profile.birthCity);
  fineDriverPreviewSet('fineDriverPreviewBirthPostalCode',profile.birthPostalCode);
  fineDriverPreviewSet('fineDriverPreviewPhone',profile.phone);
  fineDriverPreviewSet('fineDriverPreviewAddress',profile.address);
  fineDriverPreviewSet('fineDriverPreviewPostalCode',profile.postalCode);
  fineDriverPreviewSet('fineDriverPreviewCity',profile.city);
  fineDriverPreviewSet('fineDriverPreviewLicense',profile.licenseNumber);
  fineDriverPreviewSet('fineDriverPreviewLicenseIssue',fineDriverPreviewDate(profile.licenseIssueDate));
  fineDriverPreviewSet('fineDriverPreviewLicenseExpiry',fineDriverPreviewDate(profile.licenseExpiry));
  fineDriverPreview.hidden=false;
}

function openFineSelectedDriverProfile(){
  const name=String(fineDriverSelect?.value||'').trim();
  const profile=findFineDriverProfile(name);
  if(!profile){
    dashboardToast(
      'Fiche chauffeur introuvable',
      name ? `Aucune fiche chauffeur ne correspond à ${name}.` : 'Sélectionnez d’abord un chauffeur.',
      'warn',
      3500
    );
    return;
  }
  renderFineDriverPreview(profile);
}

function fillFineSelectors(){
  const vehicleList=document.getElementById('fineVehicleList');
  if(vehicleList){
    vehicleList.innerHTML=vehicleOptionsForAdmin()
      .map(x=>`<option value="${x.value}" label="${x.label}"></option>`).join('');
  }
  const driverList=document.getElementById('fineDriverList');
  if(driverList){
    driverList.innerHTML=driverOptionsForAdmin()
      .map(name=>`<option value="${name}"></option>`).join('');
  }
  const offenseList=document.getElementById('fineOffenseList');
  if(offenseList){
    const known=new Map();
    adminFines.forEach(item=>{
      const label=String(item.offense||'').trim();
      const key=adminNorm(label);
      if(label&&!known.has(key)) known.set(key,label);
    });
    offenseList.innerHTML=[...known.values()]
      .sort((a,b)=>a.localeCompare(b,'fr',{sensitivity:'base'}))
      .map(label=>`<option value="${label}"></option>`).join('');
  }
  updateFineDriverProfileButton();
}

function openFineModal(id=null){
  editingFineId=id;
  pendingFineFiles=[];
  closeFineDriverPreview();
  fineForm.reset();
  fillFineSelectors();
  document.getElementById('fineModalTitle').textContent=id?'Modifier l’amende':'Ajouter une amende';
  const item=adminFines.find(x=>x.id===id);
  if(item){
    document.getElementById('fineDate').value=item.date||'';
    document.getElementById('fineVehicle').value=item.vehicle||'';
    document.getElementById('fineDriver').value=item.driver||'';
    document.getElementById('fineAmount').value=item.amount||'';
    document.getElementById('fineOffense').value=item.offense||'';
    document.getElementById('fineReference').value=item.reference||'';
    document.getElementById('fineStatus').value=item.status||'À traiter';
    document.getElementById('fineNotes').value=item.notes||'';
  }else{
    document.getElementById('fineStatus').value='À traiter';
  }
  updateFineDriverProfileButton();
  fineModal.hidden=false;
  document.body.classList.add('modal-open');
  renderFineAttachments();
}

function closeFineModal(){
  closeFineDriverPreview();
  fineModal.hidden=true;
  editingFineId=null;
  pendingFineFiles=[];
  if(fineAttachmentInput) fineAttachmentInput.value='';
  if(document.querySelectorAll('.modal-overlay:not([hidden])').length===0)document.body.classList.remove('modal-open')
}

function fillRungisVehicles(){
  const select=document.getElementById('rungisVehicle');
  select.innerHTML=
    '<option value="">— Aucune immatriculation —</option>'+
    vehicleOptionsForAdmin().map(x=>`<option value="${x.value}">${x.label}</option>`).join('');
}

function updateRungisParkPreview(){
  const registration=document.getElementById('rungisVehicle').value;
  const vehicle=rungisVehicleInfo(registration);
  document.getElementById('rungisParkNumberPreview').value=vehicle?.parkNumber||'—';
}

function openRungisModal(id=null){
  editingRungisId=id;
  rungisForm.reset();
  rungisError.textContent='';
  fillRungisVehicles();

  document.getElementById('rungisModalTitle').textContent=
    id?'Modifier la carte Rungis':'Ajouter une carte Rungis';

  const item=adminRungis.find(x=>x.id===id);

  if(item){
    document.getElementById('rungisCardNumber').value=item.cardNumber||'';

    const select=document.getElementById('rungisVehicle');
    const registration=item.vehicle?formatRegistration(item.vehicle):'';

    if(registration && ![...select.options].some(option=>option.value===registration)){
      const option=document.createElement('option');
      option.value=registration;
      option.textContent=`${registration} · HORS PARC`;
      select.appendChild(option);
    }

    select.value=registration;
  }

  updateRungisParkPreview();
  rungisModal.hidden=false;
  document.body.classList.add('modal-open');
}

function closeRungisModal(){
  rungisModal.hidden=true;
  editingRungisId=null;
  rungisError.textContent='';
  if(document.querySelectorAll('.modal-overlay:not([hidden])').length===0){
    document.body.classList.remove('modal-open');
  }
}

function closeAdminActions(){adminActionsMenu.hidden=true;adminActionType=null;adminActionId=null}

function openAdminDelete(type,id){
  deleteAdminType=type;deleteAdminId=id;
  const item=type==='fine'?adminFines.find(x=>x.id===id):adminRungis.find(x=>x.id===id);
  document.getElementById('adminDeleteText').textContent=type==='fine'
    ? `L’amende ${item?.reference?item.reference:'sélectionnée'} sera supprimée.`
    : `La carte Rungis ${item?.cardNumber||'sélectionnée'} sera supprimée.`;
  adminDeleteModal.hidden=false;document.body.classList.add('modal-open');
}

function closeAdminDelete(){adminDeleteModal.hidden=true;deleteAdminType=null;deleteAdminId=null;if(document.querySelectorAll('.modal-overlay:not([hidden])').length===0)document.body.classList.remove('modal-open')}

function renderAdminSites(){
  ['dkv','ids','lumesia'].forEach(key=>{
    const url=String(adminSites[key]||'').trim();
    document.getElementById('siteUrl_'+key).textContent=url||'Adresse non configurée';
    const button=document.querySelector(`[data-open-site="${key}"]`);
    button.classList.toggle('disabled',!url);
  });
}

function openSiteUrlModal(key){
  editingSiteKey=key;
  document.getElementById('siteUrlModalTitle').textContent=`Configurer ${key==='dkv'?'DKV':key==='ids'?'IDS':'Lumesia'}`;
  document.getElementById('siteUrlInput').value=adminSites[key]||'';
  document.getElementById('siteUrlError').textContent='';
  document.getElementById('siteUrlModal').hidden=false;document.body.classList.add('modal-open');
}

function closeSiteUrlModal(){document.getElementById('siteUrlModal').hidden=true;editingSiteKey=null;if(document.querySelectorAll('.modal-overlay:not([hidden])').length===0)document.body.classList.remove('modal-open')}

function saveFuelEntries(){
  try{
    localStorage.setItem(FUEL_STORAGE_KEY,JSON.stringify(fuelEntries));
    return true;
  }catch(error){
    console.warn('Impossible d’enregistrer le suivi carburant.',error);
    return false;
  }
}

function averageFuelField(field){
  const values=fuelEntries
    .map(item=>fuelNumber(item[field]))
    .filter(value=>value!==null);

  if(!values.length) return null;

  return values.reduce((sum,value)=>sum+value,0)/values.length;
}

function fuelFormatQuantity(value){
  const number=fuelNumber(value);
  return number===null
    ? '—'
    : `${number.toLocaleString('fr-FR',{maximumFractionDigits:0})} L`;
}

function fuelFormatTotalCost(value){
  const number=fuelNumber(value);
  return number===null
    ? '—'
    : number.toLocaleString('fr-FR',{minimumFractionDigits:2,maximumFractionDigits:2})+' €';
}

function updateFuelKpis(){
  document.getElementById('fuelAvgDiesel').textContent=
    fuelFormatPrice(averageFuelField('dieselPrice'));

  document.getElementById('fuelAvgGnr').textContent=
    fuelFormatPrice(averageFuelField('gnrPrice'));

  document.getElementById('fuelAvgAdblue').textContent=
    fuelFormatPrice(averageFuelField('adbluePrice'));
}

function latestFuelEntry(){
  return [...fuelEntries]
    .sort((a,b)=>
      String(b.deliveryDate||b.orderDate||'')
        .localeCompare(String(a.deliveryDate||a.orderDate||''))
    )[0] || null;
}

function updateFuelLastCard(){
  const item=latestFuelEntry();

  document.getElementById('fuelLastSupplier').textContent=item?.supplier||'—';
  document.getElementById('fuelLastDelivery').textContent=
    item ? fuelFormatDate(item.deliveryDate||item.orderDate) : '—';
  document.getElementById('fuelLastDiesel').textContent=
    item ? fuelFormatPrice(item.dieselPrice) : '—';
  document.getElementById('fuelLastGnr').textContent=
    item ? fuelFormatPrice(item.gnrPrice) : '—';
}

function updateFuelSummary(){
  const totals={diesel:0,gnr:0,adblue:0,cost:0};
  const suppliers=new Set();

  fuelEntries.forEach(item=>{
    if(item.supplier) suppliers.add(fuelNorm(item.supplier));
    const diesel=fuelNumber(item.dieselQty)||0;
    const gnr=fuelNumber(item.gnrQty)||0;
    const adblue=fuelNumber(item.adblueQty)||0;
    totals.diesel+=diesel;
    totals.gnr+=gnr;
    totals.adblue+=adblue;
    totals.cost+=diesel/1000*(fuelNumber(item.dieselPrice)||0);
    totals.cost+=gnr/1000*(fuelNumber(item.gnrPrice)||0);
    totals.cost+=adblue/1000*(fuelNumber(item.adbluePrice)||0);
  });

  document.getElementById('fuelSummaryOrders').textContent=fuelEntries.length;
  document.getElementById('fuelSummarySuppliers').textContent=suppliers.size;
  document.getElementById('fuelSummaryDiesel').textContent=fuelFormatQuantity(totals.diesel);
  document.getElementById('fuelSummaryGnr').textContent=fuelFormatQuantity(totals.gnr);
  document.getElementById('fuelSummaryAdblue').textContent=fuelFormatQuantity(totals.adblue);
  document.getElementById('fuelSummaryCost').textContent=fuelFormatTotalCost(totals.cost);
}

function renderFuelStatistics(){
  const body=document.getElementById('fuelStatsTable');
  const select=document.getElementById('fuelStatsPeriod');
  if(!body||!select) return;

  const mode=select.value||'all';
  const now=new Date();
  now.setHours(23,59,59,999);
  let cutoff=null;
  if(mode==='year') cutoff=new Date(now.getFullYear(),0,1);
  if(mode==='quarter') cutoff=new Date(now.getFullYear(),now.getMonth()-2,1);
  if(mode==='month') cutoff=new Date(now.getFullYear(),now.getMonth(),1);

  const groups=new Map();
  fuelEntries.forEach(item=>{
    const raw=item.deliveryDate||item.orderDate;
    const date=raw?new Date(`${raw}T00:00:00`):null;
    if(cutoff&&(!date||date<cutoff||date>now)) return;

    const supplier=String(item.supplier||'Non renseigné');
    const row=groups.get(supplier)||{diesel:0,gnr:0,adblue:0,dieselCost:0,gnrCost:0,adblueCost:0};
    const diesel=fuelNumber(item.dieselQty)||0;
    const gnr=fuelNumber(item.gnrQty)||0;
    const adblue=fuelNumber(item.adblueQty)||0;
    row.diesel+=diesel;
    row.gnr+=gnr;
    row.adblue+=adblue;
    row.dieselCost+=diesel/1000*(fuelNumber(item.dieselPrice)||0);
    row.gnrCost+=gnr/1000*(fuelNumber(item.gnrPrice)||0);
    row.adblueCost+=adblue/1000*(fuelNumber(item.adbluePrice)||0);
    groups.set(supplier,row);
  });

  const rows=[...groups.entries()].sort((a,b)=>a[0].localeCompare(b[0],'fr'));
  body.innerHTML=rows.length?rows.map(([supplier,row])=>{
    const totalQuantity=row.diesel+row.gnr+row.adblue;
    const totalCost=row.dieselCost+row.gnrCost+row.adblueCost;
    return `<tr><td><strong>${fuelEscape(supplier)}</strong></td><td>${fuelFormatQuantity(row.diesel)}</td><td>${fuelFormatTotalCost(row.dieselCost)}</td><td>${fuelFormatQuantity(row.gnr)}</td><td>${fuelFormatTotalCost(row.gnrCost)}</td><td>${fuelFormatQuantity(row.adblue)}</td><td>${fuelFormatTotalCost(row.adblueCost)}</td><td><strong>${fuelFormatQuantity(totalQuantity)}</strong></td><td><strong>${fuelFormatTotalCost(totalCost)}</strong></td></tr>`;
  }).join(''):'<tr><td colspan="9" class="fuel-stats-empty">Aucune commande pour cette période.</td></tr>';
}

function renderFuelMonthlyCosts(){
  const body=document.getElementById('fuelMonthlyCostTable');
  if(!body) return;

  const groups=new Map();
  fuelEntries.forEach(item=>{
    const raw=item.deliveryDate||item.orderDate;
    if(!raw) return;
    const month=String(raw).slice(0,7);
    if(!/^\d{4}-\d{2}$/.test(month)) return;
    const row=groups.get(month)||{diesel:0,gnr:0,adblue:0};
    row.diesel+=(fuelNumber(item.dieselQty)||0)/1000*(fuelNumber(item.dieselPrice)||0);
    row.gnr+=(fuelNumber(item.gnrQty)||0)/1000*(fuelNumber(item.gnrPrice)||0);
    row.adblue+=(fuelNumber(item.adblueQty)||0)/1000*(fuelNumber(item.adbluePrice)||0);
    groups.set(month,row);
  });

  const rows=[...groups.entries()].sort((a,b)=>b[0].localeCompare(a[0]));
  body.innerHTML=rows.length?rows.map(([month,row])=>{
    const total=row.diesel+row.gnr+row.adblue;
    const label=new Date(`${month}-01T00:00:00`).toLocaleDateString('fr-FR',{month:'long',year:'numeric'});
    return `<tr><td><strong>${fuelEscape(label.charAt(0).toUpperCase()+label.slice(1))}</strong></td><td>${fuelFormatTotalCost(row.diesel)}</td><td>${fuelFormatTotalCost(row.gnr)}</td><td>${fuelFormatTotalCost(row.adblue)}</td><td><strong>${fuelFormatTotalCost(total)}</strong></td></tr>`;
  }).join(''):'<tr><td colspan="5" class="fuel-stats-empty">Aucune commande avec quantité et prix renseignés.</td></tr>';
}

function renderFuelTable(){
  const q=fuelNorm(fuelSearch.value);

  const visible=[...fuelEntries].filter(item=>!window.dashboardFuelMatches||window.dashboardFuelMatches(item))
    .sort((a,b)=>{
      const dateA=String(a.deliveryDate||a.orderDate||'');
      const dateB=String(b.deliveryDate||b.orderDate||'');
      const dateCompare=dateB.localeCompare(dateA);
      if(dateCompare) return dateCompare;
      return String(a.supplier||'').localeCompare(String(b.supplier||''),'fr',{sensitivity:'base'});
    })
    .filter(item=>
      fuelNorm(
        `${item.supplier} ${item.orderDate} ${item.deliveryDate} `+
        `${item.dieselQty} ${item.gnrQty} ${item.adblueQty} `+
        `${item.dieselPrice} ${item.gnrPrice} ${item.adbluePrice}`
      ).includes(q)
    );

  if(!visible.length){
    fuelTable.innerHTML=`
      <tr>
        <td colspan="10" class="fuel-empty">
          ${fuelEntries.length
            ? 'Aucune commande ne correspond à votre recherche.'
            : 'Aucune commande carburant enregistrée.'}
        </td>
      </tr>
    `;
  }else{
    fuelTable.innerHTML=visible.map(item=>`
      <tr>
        <td><strong>${fuelEscape(item.supplier||'—')}</strong></td>
        <td>${fuelFormatDate(item.orderDate)}</td>
        <td>${fuelFormatDate(item.deliveryDate)}</td>
        <td class="fuel-quantity">${fuelFormatQuantity(item.dieselQty)}</td>
        <td class="fuel-quantity">${fuelFormatQuantity(item.gnrQty)}</td>
        <td class="fuel-quantity">${fuelFormatQuantity(item.adblueQty)}</td>
        <td class="fuel-price">${fuelFormatPrice(item.dieselPrice)}</td>
        <td class="fuel-price">${fuelFormatPrice(item.gnrPrice)}</td>
        <td class="fuel-price">${fuelFormatPrice(item.adbluePrice)}</td>
        <td>
          <button
            class="fuel-row-menu"
            type="button"
            data-fuel-menu="${item.id}"
            aria-label="Actions"
          >•••</button>
        </td>
      </tr>
    `).join('');
  }

  document.getElementById('fuelCountLabel').textContent=
    `${visible.length} commande${visible.length>1?'s':''} affichée${visible.length>1?'s':''}`;

  fuelTableWrap.classList.toggle('scroll',visible.length>11);

  updateFuelKpis();
  updateFuelLastCard();
  updateFuelSummary();
  renderFuelStatistics();
  renderFuelMonthlyCosts();

  requestAnimationFrame(renderFuelCharts);
}

function fuelSupplierOptions(){
  const defaults=['Stedis','3C','F3C','Granjon'];
  const known=new Map();
  [...defaults,...fuelEntries.map(item=>String(item.supplier||'').trim())]
    .filter(Boolean)
    .forEach(name=>{
      const key=name.toLocaleLowerCase('fr');
      if(!known.has(key)) known.set(key,name);
    });
  return [...known.values()].sort((a,b)=>a.localeCompare(b,'fr'));
}

function refreshFuelSupplierSelect(selected=''){
  const select=document.getElementById('fuelSupplier');
  if(!select) return;
  const options=fuelSupplierOptions();
  select.innerHTML='<option value="">— Sélectionner un fournisseur —</option>'+
    options.map(name=>`<option value="${fuelEscape(name)}">${fuelEscape(name)}</option>`).join('');
  const match=options.find(name=>name.toLocaleLowerCase('fr')===String(selected||'').toLocaleLowerCase('fr'));
  if(match) select.value=match;
}

function openFuelModal(id=null){
  editingFuelId=id;
  fuelForm.reset();
  fuelError.textContent='';

  const item=fuelEntries.find(entry=>entry.id===id);

  document.getElementById('fuelModalTitle').textContent=
    item ? 'Modifier la commande' : 'Ajouter une commande';

  refreshFuelSupplierSelect(item?.supplier||'');

  if(item){
    document.getElementById('fuelSupplier').value=item.supplier||'';
    document.getElementById('fuelOrderDate').value=item.orderDate||'';
    document.getElementById('fuelDeliveryDate').value=item.deliveryDate||'';
    document.getElementById('fuelDieselQty').value=item.dieselQty??'';
    document.getElementById('fuelGnrQty').value=item.gnrQty??'';
    document.getElementById('fuelAdblueQty').value=item.adblueQty??'';
    document.getElementById('fuelDieselPrice').value=item.dieselPrice??'';
    document.getElementById('fuelGnrPrice').value=item.gnrPrice??'';
    document.getElementById('fuelAdbluePrice').value=item.adbluePrice??'';
  }

  fuelModal.hidden=false;
  document.body.classList.add('modal-open');
}

function closeFuelModal(){
  fuelModal.hidden=true;
  editingFuelId=null;
  fuelError.textContent='';

  if(document.querySelectorAll('.modal-overlay:not([hidden])').length===0){
    document.body.classList.remove('modal-open');
  }
}

function closeFuelActionsMenu(){
  fuelActionsMenu.hidden=true;
  activeFuelMenuId=null;
}

function openFuelActionsMenu(button,id){
  closeFuelActionsMenu();

  activeFuelMenuId=id;
  fuelActionsMenu.hidden=false;

  const rect=button.getBoundingClientRect();
  const menuRect=fuelActionsMenu.getBoundingClientRect();

  const left=Math.max(
    10,
    Math.min(
      rect.right-menuRect.width,
      window.innerWidth-menuRect.width-10
    )
  );

  let top=rect.bottom+6;

  if(top+menuRect.height>window.innerHeight-10){
    top=rect.top-menuRect.height-6;
  }

  fuelActionsMenu.style.left=left+'px';
  fuelActionsMenu.style.top=Math.max(10,top)+'px';
}

function openDeleteFuelModal(id){
  const item=fuelEntries.find(entry=>entry.id===id);
  if(!item) return;

  pendingDeleteFuelId=id;

  document.getElementById('deleteFuelText').textContent=
    `La commande ${item.supplier||''} du ${fuelFormatDate(item.orderDate)} sera supprimée.`;

  deleteFuelModal.hidden=false;
  document.body.classList.add('modal-open');
}

function closeDeleteFuelModal(){
  deleteFuelModal.hidden=true;
  pendingDeleteFuelId=null;

  if(document.querySelectorAll('.modal-overlay:not([hidden])').length===0){
    document.body.classList.remove('modal-open');
  }
}

function drawFuelChart(canvas,emptyElement,data){
  if(!canvas || !emptyElement) return;

  const rect=canvas.getBoundingClientRect();
  const chartWrap=canvas.parentElement;
  let tooltip=chartWrap?.querySelector('.fuel-chart-tooltip');
  if(!tooltip && chartWrap){
    tooltip=document.createElement('div');
    tooltip.className='fuel-chart-tooltip';
    tooltip.hidden=true;
    chartWrap.appendChild(tooltip);
    canvas.addEventListener('pointerleave',()=>{tooltip.hidden=true;});
    canvas.addEventListener('pointermove',event=>{
      if(!canvas._fuelChartPoints?.length) return;
      const bounds=canvas.getBoundingClientRect();
      const pointerX=event.clientX-bounds.left;
      const pointerY=event.clientY-bounds.top;
      const nearest=canvas._fuelChartPoints.reduce((best,point)=>{
        const distance=Math.hypot(point.x-pointerX,point.y-pointerY);
        return distance<best.distance?{point,distance}:best;
      },{point:null,distance:Infinity});
      if(!nearest.point || nearest.distance>18){
        tooltip.hidden=true;
        return;
      }
      tooltip.innerHTML=`<strong>${fuelFormatDate(nearest.point.date)}</strong><span>${fuelFormatPrice(nearest.point.value)} / m³</span>`;
      tooltip.hidden=false;
      const left=Math.min(Math.max(nearest.point.x-tooltip.offsetWidth/2,4),bounds.width-tooltip.offsetWidth-4);
      const top=Math.max(nearest.point.y-tooltip.offsetHeight-10,4);
      tooltip.style.left=`${left}px`;
      tooltip.style.top=`${top}px`;
    });
  }

  // Si la page Carburant est masquée, le canvas peut mesurer 0 x 0.
  // Ne surtout pas le redimensionner à 1 px : le navigateur étirerait ensuite
  // cette image minuscule sur toute la carte, ce qui créait le gros bloc rouge.
  if(rect.width < 10 || rect.height < 10) return;

  const dpr=Math.max(1,window.devicePixelRatio||1);
  const pixelWidth=Math.max(1,Math.round(rect.width*dpr));
  const pixelHeight=Math.max(1,Math.round(rect.height*dpr));

  // On ne redimensionne réellement le buffer que lorsque c'est nécessaire.
  if(canvas.width!==pixelWidth) canvas.width=pixelWidth;
  if(canvas.height!==pixelHeight) canvas.height=pixelHeight;

  const ctx=canvas.getContext('2d');
  if(!ctx) return;

  // Remise à zéro systématique : évite toute accumulation de scale()
  // lors des redessins, changements de thème ou redimensionnements.
  ctx.setTransform(1,0,0,1,0,0);
  ctx.clearRect(0,0,canvas.width,canvas.height);
  ctx.setTransform(dpr,0,0,dpr,0,0);

  const width=rect.width;
  const height=rect.height;

  if(!data.length){
    emptyElement.hidden=false;
    return;
  }

  emptyElement.hidden=true;

  const padding={left:42,right:15,top:16,bottom:31};
  const plotWidth=width-padding.left-padding.right;
  const plotHeight=height-padding.top-padding.bottom;

  const values=data.map(point=>point.value);

  let min=Math.min(...values);
  let max=Math.max(...values);

  if(min===max){
    min-=0.02;
    max+=0.02;
  }else{
    const extra=(max-min)*0.15;
    min-=extra;
    max+=extra;
  }

  const x=index=>
    data.length===1
      ? padding.left+plotWidth/2
      : padding.left+(index/(data.length-1))*plotWidth;

  const y=value=>
    padding.top+(max-value)/(max-min)*plotHeight;

  ctx.lineWidth=1;
  ctx.strokeStyle='rgba(255,255,255,.08)';
  ctx.fillStyle='#808a94';
  ctx.font='10px Inter, Segoe UI, Arial';

  for(let i=0;i<=4;i++){
    const yy=padding.top+(i/4)*plotHeight;

    ctx.beginPath();
    ctx.moveTo(padding.left,yy);
    ctx.lineTo(width-padding.right,yy);
    ctx.stroke();

    const value=max-(i/4)*(max-min);
    ctx.fillText(
      value.toLocaleString('fr-FR',{
        minimumFractionDigits:3,
        maximumFractionDigits:3
      }),
      2,
      yy+3
    );
  }

  ctx.strokeStyle='#db3333';
  ctx.lineWidth=2;

  ctx.beginPath();
  data.forEach((point,index)=>{
    const xx=x(index);
    const yy=y(point.value);

    if(index===0) ctx.moveTo(xx,yy);
    else ctx.lineTo(xx,yy);
  });
  ctx.stroke();

  data.forEach((point,index)=>{
    const xx=x(index);
    const yy=y(point.value);

    ctx.fillStyle='#db3333';
    ctx.beginPath();
    ctx.arc(xx,yy,3.5,0,Math.PI*2);
    ctx.fill();
  });
  canvas._fuelChartPoints=data.map((point,index)=>({
    date:point.date,
    value:point.value,
    x:x(index),
    y:y(point.value)
  }));

  const dateIndices=data.length<=4
    ? data.map((_,index)=>index)
    : [0,Math.floor((data.length-1)/2),data.length-1];

  ctx.fillStyle='#808a94';
  ctx.textAlign='center';

  dateIndices.forEach(index=>{
    const date=new Date(data[index].date+'T00:00:00');

    ctx.fillText(
      date.toLocaleDateString('fr-FR',{
        day:'2-digit',
        month:'2-digit'
      }),
      x(index),
      height-8
    );
  });

  ctx.textAlign='start';
}

function renderFuelCharts(){
  drawFuelChart(
    document.getElementById('fuelDieselChart'),
    document.getElementById('fuelDieselChartEmpty'),
    fuelChartData('dieselPrice')
  );

  drawFuelChart(
    document.getElementById('fuelGnrChart'),
    document.getElementById('fuelGnrChartEmpty'),
    fuelChartData('gnrPrice')
  );
}

function globalNormalize(value){
  return String(value??'')
    .toLocaleLowerCase('fr')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g,'')
    .replace(/[^a-z0-9]/g,'');
}

function globalEscape(value){
  return String(value??'')
    .replace(/&/g,'&amp;')
    .replace(/</g,'&lt;')
    .replace(/>/g,'&gt;')
    .replace(/"/g,'&quot;')
    .replace(/'/g,'&#039;');
}

function globalResultIconSvg(icon){
  const icons={
    '▣': `<svg class="app-icon" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h11v10H3z"/><path d="M14 10h4l3 3v3h-7z"/><circle cx="7" cy="18" r="2"/><circle cx="18" cy="18" r="2"/></svg>`,
    '♙': `<svg class="app-icon" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="4"/><path d="M4.5 21a7.5 7.5 0 0 1 15 0"/></svg>`,
    '⚠': `<svg class="app-icon" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3 2.5 20h19z"/><path d="M12 9v4"/><path d="M12 17h.01"/></svg>`,
    '🔧': `<svg class="app-icon" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14.7 6.3a4 4 0 0 0-5-5l2.1 2.1-2.8 2.8-2.1-2.1a4 4 0 0 0 5 5L20 17.2 17.2 20z"/></svg>`,
    '⛽': `<svg class="app-icon" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 22V4a2 2 0 0 1 2-2h7a2 2 0 0 1 2 2v18"/><path d="M3 22h15"/><path d="M8 6h5v5H8z"/><path d="M16 7h2l3 3v7a2 2 0 0 1-4 0v-4"/></svg>`,
    '▰': `<svg class="app-icon" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 5h16v14H4z"/><path d="M8 9h8"/><path d="M8 13h8"/><path d="M8 17h5"/></svg>`,
    '↗': `<svg class="app-icon" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 4h6v6"/><path d="M10 14 20 4"/><path d="M20 13v6a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1h6"/></svg>`
  };
  return icons[icon] || `<svg class="app-icon" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/></svg>`;
}

function globalPageTitle(view){
  const names={
    accueil:'Gestion de Parc',
    parc:'Parc',
    chauffeur:'Chauffeur',
    sinistre:'Sinistre',
    'suivi-technique':'Suivi technique',
    carburant:'Carburant',
    'gestion-administrative':'Gestion administrative'
  };
  return names[view]||view;
}

function buildGlobalSearchMatches(rawQuery){
  const query=globalNormalize(rawQuery);
  if(query.length<2) return [];

  const results=[];
  const push=(item)=>{
    if(results.length<60) results.push(item);
  };

  /* Véhicules */
  parkData.forEach(vehicle=>{
    const plate=formatRegistration(vehicle.registration);
    const searchable=globalNormalize(
      `${plate} ${vehicle.registration} ${vehicle.type} ${vehicle.parkNumber||''}`
    );

    if(searchable.includes(query)){
      push({
        icon:'▣',
        title:plate,
        meta:`${vehicle.type}${vehicle.parkNumber?' · N° parc '+vehicle.parkNumber:''}`,
        page:'Parc',
        view:'parc',
        searchId:'parkSearch',
        searchValue:plate,
        priority:searchable.startsWith(query)?0:2
      });
    }
  });

  /* Chauffeurs */
  driverProfiles.forEach(driver=>{
    const name=[driver.lastName,driver.firstName].filter(Boolean).join(' ').trim();
    if(!name) return;

    const searchable=globalNormalize(
      `${name} ${driver.phone||''} ${driver.city||''} ${driver.licenseNumber||''}`
    );

    if(searchable.includes(query)){
      push({
        icon:'♙',
        title:name,
        meta:[driver.phone,driver.city].filter(Boolean).join(' · ')||'Fiche chauffeur',
        page:'Chauffeur',
        view:'chauffeur',
        searchId:'driverSearch',
        searchValue:name,
        priority:globalNormalize(name).startsWith(query)?0:2
      });
    }
  });

  /* Sinistres */
  claimData.forEach(claim=>{
    const searchable=globalNormalize(
      `${claim.number||''} ${claim.driver||''} ${claim.vehicle||''} ${claim.type||''} ${claim.status||''}`
    );

    if(searchable.includes(query)){
      push({
        icon:'⚠',
        title:claim.number||claim.type||'Sinistre',
        meta:[claim.vehicle,claim.driver,claim.status].filter(Boolean).join(' · '),
        page:'Sinistre',
        view:'sinistre',
        searchId:'claimSearch',
        searchValue:claim.number||claim.vehicle||claim.driver||claim.type||'',
        priority:0
      });
    }
  });

  /* Vidanges */
  vidangeData.forEach(record=>{
    const plate=formatRegistration(record.registration);
    const driver=fleetCurrentDrivers(record.registration);
    const searchable=globalNormalize(`${plate} ${driver} ${record.currentKm??''}`);

    if(searchable.includes(query)){
      const remaining=calculateNextOil(record);
      push({
        icon:'🔧',
        title:plate,
        meta:`${driver||'Sans chauffeur'} · ${Number(remaining).toLocaleString('fr-FR')} km`,
        page:'Suivi technique',
        view:'suivi-technique',
        searchId:'vidSearch',
        searchValue:plate,
        priority:1
      });
    }
  });

  /* Amendes */
  adminFines.forEach(fine=>{
    const searchable=globalNormalize(
      `${fine.reference||''} ${fine.vehicle||''} ${fine.driver||''} ${fine.offense||''} ${fine.status||''}`
    );

    if(searchable.includes(query)){
      push({
        icon:'⚠',
        title:fine.reference||fine.offense||'Amende',
        meta:[fine.vehicle,fine.driver,fine.status].filter(Boolean).join(' · '),
        page:'Amendes',
        view:'gestion-administrative',
        adminTab:'fines',
        searchId:'fineSearch',
        searchValue:fine.reference||fine.vehicle||fine.driver||fine.offense||'',
        priority:1
      });
    }
  });

  /* Cartes Rungis */
  adminRungis.forEach(card=>{
    const vehicle=homeRungisVehicleInfo(card.vehicle);
    const searchable=globalNormalize(
      `${card.cardNumber||''} ${card.vehicle||''} ${vehicle?.parkNumber||''}`
    );

    if(searchable.includes(query)){
      push({
        icon:'▣',
        title:`Carte ${card.cardNumber||'—'}`,
        meta:[card.vehicle,vehicle?.parkNumber?`N° parc ${vehicle.parkNumber}`:''].filter(Boolean).join(' · '),
        page:'Cartes Rungis',
        view:'gestion-administrative',
        adminTab:'rungis',
        searchId:'rungisSearch',
        searchValue:card.cardNumber||card.vehicle||vehicle?.parkNumber||'',
        priority:1
      });
    }
  });

  /* Carburant */
  fuelEntries.forEach(entry=>{
    const searchable=globalNormalize(
      `${entry.supplier||''} ${entry.orderDate||''} ${entry.deliveryDate||''}`
    );

    if(searchable.includes(query)){
      push({
        icon:'⛽',
        title:entry.supplier||'Commande carburant',
        meta:[
          entry.orderDate?fuelFormatDate(entry.orderDate):'',
          entry.dieselPrice?`Gasoil ${fuelFormatPrice(entry.dieselPrice)}`:''
        ].filter(Boolean).join(' · '),
        page:'Carburant',
        view:'carburant',
        searchId:'fuelSearch',
        searchValue:entry.supplier||entry.orderDate||'',
        priority:1
      });
    }
  });

  /* Contrôles réglementaires : mêmes affectations que le parc. */
  technicalDeadlines.forEach(record=>{
    const plate=formatRegistration(record.registration);
    const driver=fleetCurrentDrivers(record.registration);
    const category=FLEET_CONTROL_NAMES[record.category]||record.category;
    if(globalNormalize(`${plate} ${driver} ${category} ${record.label||''} ${record.nextControl||''}`).includes(query)){
      results.push({icon:'🔧',title:plate,meta:[category,record.nextControl,driver].filter(Boolean).join(' · '),page:'Contrôles',view:'suivi-technique',techPage:record.category,searchId:'technicalDeadlineSearch',searchValue:plate,priority:1});
    }
  });

  /* Accès directs aux pages */
  [
    ['parc','Parc','▣','Véhicules et affectations'],
    ['chauffeur','Chauffeur','♙','Fiches chauffeurs'],
    ['sinistre','Sinistre','⚠','Déclaration et suivi des sinistres'],
    ['suivi-technique','Suivi technique','🔧','Vidanges et import JEF'],
    ['carburant','Carburant','⛽','Commandes et prix carburant'],
    ['gestion-administrative','Gestion administrative','▰','Amendes, Rungis et outils']
  ].forEach(([view,title,icon,meta])=>{
    if(globalNormalize(`${title} ${meta}`).includes(query)){
      push({
        icon,
        title:`Ouvrir ${title}`,
        meta,
        page:'Navigation',
        view,
        priority:3
      });
    }
  });

  /* DKV / IDS / Lumesia */
  [
    ['DKV','dkv'],
    ['IDS','ids'],
    ['Lumesia','lumesia']
  ].forEach(([name,key])=>{
    if(globalNormalize(name).includes(query)){
      push({
        icon:'↗',
        title:name,
        meta:'Site & outil',
        page:'Administratif',
        view:'gestion-administrative',
        adminTab:'sites',
        priority:2
      });
    }
  });

  return results
    .sort((a,b)=>
      (a.priority??9)-(b.priority??9) ||
      a.title.localeCompare(b.title,'fr',{sensitivity:'base'})
    )
    .slice(0,14);
}

function renderGlobalSearch(){
  const query=globalSearch.value.trim();

  globalSearchClear.hidden=!query;
  globalSearchActiveIndex=-1;

  if(query.length<2){
    globalSearchMatches=[];
    globalSearchResults.innerHTML=`
      <div class="global-search-help">
        Tapez au moins 2 caractères.<br>
        Vous pouvez rechercher une plaque, un chauffeur, un sinistre, une amende,
        une carte Rungis, une commande carburant ou une page.
      </div>
    `;
    globalSearchResults.hidden=!document.activeElement.isSameNode(globalSearch);
    return;
  }

  globalSearchMatches=buildGlobalSearchMatches(query);

  if(!globalSearchMatches.length){
    globalSearchResults.innerHTML=`
      <div class="global-search-empty">
        Aucun résultat pour « ${globalEscape(query)} »
      </div>
    `;
    globalSearchResults.hidden=false;
    return;
  }

  globalSearchResults.innerHTML=globalSearchMatches.map((result,index)=>`
    <button class="global-result" type="button" data-global-result="${index}">
      <span class="global-result-icon">${globalResultIconSvg(result.icon)}</span>
      <span>
        <div class="global-result-title">${globalEscape(result.title)}</div>
        <div class="global-result-meta">${globalEscape(result.meta||'')}</div>
      </span>
      <span class="global-result-page">${globalEscape(result.page||'')}</span>
    </button>
  `).join('');

  globalSearchResults.hidden=false;
}

function closeGlobalSearch(){
  globalSearchResults.hidden=true;
  globalSearchActiveIndex=-1;
}

function activateGlobalSearchResult(index){
  const result=globalSearchMatches[index];
  if(!result) return;

  showView(
    result.view,
    globalPageTitle(result.view),
    result.view
  );

  if(result.view==='gestion-administrative' && result.adminTab){
    switchAdminTab(result.adminTab);
  }

  if(result.view==='suivi-technique' && typeof window.technicalOpenPage==='function'){
    window.technicalOpenPage(result.techPage||'vidange');
    if(result.techPage){
      const status=document.getElementById('technicalDeadlineStatusFilter');
      if(status){status.value='';status.dispatchEvent(new Event('change',{bubbles:true}));}
      const period=document.getElementById('technicalDeadlineWindowFilter');
      if(period){period.value='all';period.dispatchEvent(new Event('change',{bubbles:true}));}
    }
  }
  if(result.searchId){
    const targetSearch=document.getElementById(result.searchId);

    if(targetSearch){
      targetSearch.value=result.searchValue||'';
      targetSearch.dispatchEvent(new Event('input',{bubbles:true}));
    }
  }

  globalSearch.value='';
  globalSearchClear.hidden=true;
  closeGlobalSearch();
}

function normalizeDashboardUser(value){
  return String(value||'')
    .trim()
    .toUpperCase()
    .replace(/\s+/g,'')
    .replace(/[^A-Z0-9._-]/g,'')
    .slice(0,30);
}

function refreshDashboardUserBadge(){
  dashboardUserLabel.textContent=dashboardUser || 'Utilisateur';
  dashboardUserBadge.title=dashboardUser
    ? 'Utilisateur : '+dashboardUser+' — cliquer pour changer'
    : 'Définir l’identifiant utilisateur';
}

function openDashboardUserModal(force=false){
  dashboardUserInput.value=dashboardUser || '';
  dashboardUserError.classList.remove('show');
  dashboardUserModal.hidden=false;
  document.body.classList.add('modal-open');
  setTimeout(()=>dashboardUserInput.focus(),40);

  if(force){
    closeDashboardUserModal.hidden=true;
  }else{
    closeDashboardUserModal.hidden=false;
  }
}

function closeDashboardUserDialog(){
  if(!dashboardUser) return;
  dashboardUserModal.hidden=true;
  if(document.querySelectorAll('.modal-overlay:not([hidden])').length===0){
    document.body.classList.remove('modal-open');
  }
}

function saveDashboardUser(){
  const previousDashboardUser=dashboardUser;
  const value=normalizeDashboardUser(dashboardUserInput.value);
  if(!value){
    dashboardUserError.classList.add('show');
    dashboardUserInput.focus();
    return false;
  }

  dashboardUser=value;
  localStorage.setItem(DASHBOARD_USER_KEY,dashboardUser);
  refreshDashboardUserBadge();
  dashboardUserModal.hidden=true;

  if(typeof administratorUserChanged === 'function'){
    administratorUserChanged(previousDashboardUser,dashboardUser);
  }

  if(document.querySelectorAll('.modal-overlay:not([hidden])').length===0){
    document.body.classList.remove('modal-open');
  }

  return true;
}

function refreshAdministratorAccess(){
  const button=document.getElementById('administratorNavButton');
  if(!button) return;

  const allowed=administratorIsAdmin();
  button.hidden=!allowed;

  const current=document.querySelector('.view.active')?.id;
  if(!allowed && current==='administrateur' && typeof showView==='function'){
    showView('accueil','Gestion de Parc','accueil');
  }
}

function openSharedStorageModal(){
  if(sharedConnected) return;
  sharedStorageModal.hidden=false;
  closeSharedStorageModal.hidden=true;
  document.body.classList.add('modal-open');
  sharedSetUiState('local');
}

function closeSharedStorageDialog(){
  if(!sharedConnected) return;
  sharedStorageModal.hidden=true;
  if(document.querySelectorAll('.modal-overlay:not([hidden])').length===0){
    document.body.classList.remove('modal-open');
  }
}

function openSharedHandleDb(){
  return new Promise((resolve,reject)=>{
    const request=indexedDB.open(SHARED_DB_NAME,1);
    request.onupgradeneeded=()=>{
      const db=request.result;
      if(!db.objectStoreNames.contains(SHARED_DB_STORE)){
        db.createObjectStore(SHARED_DB_STORE);
      }
    };
    request.onsuccess=()=>resolve(request.result);
    request.onerror=()=>reject(request.error);
  });
}

async function saveSharedDirectoryHandle(handle){
  try{
    const db=await openSharedHandleDb();
    await new Promise((resolve,reject)=>{
      const tx=db.transaction(SHARED_DB_STORE,'readwrite');
      tx.objectStore(SHARED_DB_STORE).put(handle,SHARED_HANDLE_KEY);
      tx.oncomplete=resolve;
      tx.onerror=()=>reject(tx.error);
    });
    db.close();
  }catch(error){
    console.warn('Impossible de mémoriser le dossier Groupdrive.',error);
  }
}

async function loadSharedDirectoryHandle(){
  try{
    const db=await openSharedHandleDb();
    const handle=await new Promise((resolve,reject)=>{
      const tx=db.transaction(SHARED_DB_STORE,'readonly');
      const request=tx.objectStore(SHARED_DB_STORE).get(SHARED_HANDLE_KEY);
      request.onsuccess=()=>resolve(request.result||null);
      request.onerror=()=>reject(request.error);
    });
    db.close();
    return handle;
  }catch(error){
    console.warn('Impossible de relire le dossier Groupdrive mémorisé.',error);
    return null;
  }
}

async function forgetSharedDirectoryHandle(){
  try{
    const db=await openSharedHandleDb();
    await new Promise((resolve,reject)=>{
      const tx=db.transaction(SHARED_DB_STORE,'readwrite');
      tx.objectStore(SHARED_DB_STORE).delete(SHARED_HANDLE_KEY);
      tx.oncomplete=resolve;
      tx.onerror=()=>reject(tx.error);
    });
    db.close();
  }catch(error){
    console.warn(error);
  }
}

function dashboardEsc(value){
  return String(value??'')
    .replace(/&/g,'&amp;')
    .replace(/</g,'&lt;')
    .replace(/>/g,'&gt;')
    .replace(/"/g,'&quot;')
    .replace(/'/g,'&#039;');
}

function dashboardDateTime(value){
  if(!value) return '—';
  const d=new Date(value);
  if(Number.isNaN(d.getTime())) return '—';
  return d.toLocaleString('fr-FR',{
    day:'2-digit',month:'2-digit',year:'numeric',
    hour:'2-digit',minute:'2-digit'
  });
}

function dashboardVisibleValue(value){
  if(value===null || value===undefined || value==='') return '—';
  if(typeof value==='boolean') return value?'Oui':'Non';
  return String(value);
}

function dashboardDatasetFieldLabels(descriptor){
  const key=descriptor?.key;
  const maps={
    [PARK_STORAGE_KEY]:{registration:'Immatriculation',type:'Type',parkNumber:'N° parc'},
    [AFFECT_STORAGE_KEY]:{name:'Chauffeur',tractor:'Tracteur',semi:'Semi',number:'N° parc',phone:'Téléphone pro',personal:'N° personnel'},
    [DRIVER_STORAGE_KEY]:{lastName:'Nom',firstName:'Prénom',status:'Type de chauffeur',birthDate:'Date de naissance',birthCity:'Ville de naissance',birthPostalCode:'Code postal ville de naissance',phone:'Téléphone',address:'Adresse',postalCode:'Code postal',city:'Ville',licenseNumber:'N° permis',licenseIssueDate:'Délivrance permis',licenseExpiry:'Expiration permis'},
    [CLAIM_STORAGE_KEY]:{number:'N° dossier',date:'Date',driver:'Chauffeur',vehicle:'Véhicule',thirdParty:'Tiers',type:'Type',cost:'Coût',status:'Statut',description:'Description'},
    [VIDANGE_STORAGE_KEY]:{registration:'Immatriculation',driver:'Chauffeur',currentKm:'Km actuel',lastMajorKm:'Dernière grosse vidange',lastGarageKm:'Dernier passage garage'},
    [TECH_DEADLINE_STORAGE_KEY]:{category:'Catégorie',registration:'Immatriculation',driver:'Chauffeur',genre:'Genre',model:'Marque / Modèle',control:'Contrôle',label:'Libellé',lastControl:'Dernier contrôle',nextControl:'Prochain contrôle',company:'Société',operator:'Exploitant',sourceState:'État source',appointment:'Renseignements RDV'},
    [ADMIN_FINE_KEY]:{date:'Date',vehicle:'Véhicule',driver:'Chauffeur',offense:'Infraction',amount:'Montant',reference:'Référence',status:'Statut',notes:'Notes'},
    [ADMIN_RUNGIS_KEY]:{cardNumber:'N° carte',vehicle:'Immatriculation'},
    [ADMIN_SITES_KEY]:{dkv:'DKV',ids:'IDS',lumesia:'Lumesia'},
    [FUEL_STORAGE_KEY]:{supplier:'Fournisseur',orderDate:'Date commande',deliveryDate:'Date livraison',dieselPrice:'Prix gasoil',gnrPrice:'Prix GNR',adbluePrice:'Prix AdBlue'}
  };
  return maps[key]||{};
}

function dashboardDescribeObjectChanges(before,after,descriptor){
  const labels=dashboardDatasetFieldLabels(descriptor);
  const keys=new Set([...Object.keys(before||{}),...Object.keys(after||{})]);
  const changes=[];

  for(const key of keys){
    if(key==='id' || key.startsWith('_')) continue;
    const a=before?.[key];
    const b=after?.[key];
    if(JSON.stringify(a)===JSON.stringify(b)) continue;

    const label=labels[key]||key;
    changes.push(`${label}: ${dashboardVisibleValue(a)} → ${dashboardVisibleValue(b)}`);
  }

  return changes;
}

function dashboardDescribeCreatedItem(item,descriptor){
  const labels=dashboardDatasetFieldLabels(descriptor);
  const parts=[];
  for(const [key,value] of Object.entries(item||{})){
    if(key==='id'||key.startsWith('_')||value===null||value===undefined||value==='') continue;
    parts.push(`${labels[key]||key}: ${dashboardVisibleValue(value)}`);
    if(parts.length>=4) break;
  }
  return parts.length?parts.join(' · '):'Nouvel élément enregistré';
}

function dashboardToast(title,text='',type='success',duration=2600){
  if(!dashboardToastStack) return;
  const node=document.createElement('div');
  node.className=`dashboard-toast ${type}`;
  node.innerHTML=`<strong>${dashboardEsc(title)}</strong>${text?dashboardEsc(text):''}`;
  dashboardToastStack.appendChild(node);
  setTimeout(()=>{
    node.style.opacity='0';
    node.style.transform='translateY(7px)';
    setTimeout(()=>node.remove(),180);
  },duration);
}

function dashboardToastSharedSave(){
  const now=Date.now();
  if(now-dashboardLastSaveToast<1200) return;
  dashboardLastSaveToast=now;
  dashboardToast('Enregistré','Modification synchronisée avec le Groupdrive.','success',2000);
}

function dashboardValidateAssignment(candidate,currentIndex=-1){
  const tractor=normalizeRegistration(candidate?.tractor);
  const semi=normalizeRegistration(candidate?.semi);
  const candidateRegional=typeof driverAllowsMultipleAssignments==='function' && driverAllowsMultipleAssignments(candidate?.name);

  if(tractor){
    const duplicates=affectations
      .map((item,index)=>({item,index}))
      .filter(({item,index})=>index!==currentIndex && normalizeRegistration(item.tractor)===tractor);
    const blocking=duplicates.find(({item})=>!(candidateRegional && driverAllowsMultipleAssignments(item.name)));
    if(blocking){
      return `Le tracteur ${formatRegistration(tractor)} est déjà affecté à ${blocking.item.name}. Le partage d'un véhicule est réservé aux chauffeurs Régionaux.`;
    }
  }

  if(semi){
    const duplicates=affectations
      .map((item,index)=>({item,index}))
      .filter(({item,index})=>index!==currentIndex && normalizeRegistration(item.semi)===semi);
    const blocking=duplicates.find(({item})=>!(candidateRegional && driverAllowsMultipleAssignments(item.name)));
    if(blocking){
      return `La semi ${formatRegistration(semi)} est déjà affectée à ${blocking.item.name}. Le partage d'un véhicule est réservé aux chauffeurs Régionaux.`;
    }
  }

  return '';
}

function dashboardDataIssues(){
  const issues=[];

  const duplicateGroups=(values)=>{
    const counts=new Map();
    values.filter(Boolean).forEach(value=>counts.set(value,(counts.get(value)||0)+1));
    return [...counts.entries()].filter(([,count])=>count>1);
  };

  duplicateGroups(parkData.map(v=>normalizeRegistration(v.registration))).forEach(([reg,count])=>{
    issues.push({level:'high',section:'Parc',text:`Immatriculation ${formatRegistration(reg)} présente ${count} fois.`});
  });

  duplicateGroups(parkData.map(v=>String(v.parkNumber||'').trim())).forEach(([n,count])=>{
    issues.push({level:'high',section:'Parc',text:`N° de parc ${n} utilisé ${count} fois.`});
  });

  duplicateGroups(affectations.map(a=>normalizeAffText(a.name))).forEach(([name,count])=>{
    const sample=affectations.find(a=>normalizeAffText(a.name)===name);
    if(sample && driverAllowsMultipleAssignments(sample.name)) return;
    issues.push({level:'high',section:'Affectations',text:`Chauffeur ${sample?.name||name} présent ${count} fois.`});
  });

  duplicateGroups(affectations.map(a=>normalizeRegistration(a.tractor))).forEach(([reg,count])=>{
    const rows=affectations.filter(a=>normalizeRegistration(a.tractor)===reg);
    if(rows.length>1 && rows.every(a=>driverAllowsMultipleAssignments(a.name))) return;
    issues.push({level:'high',section:'Affectations',text:`Tracteur ${formatRegistration(reg)} affecté à ${count} chauffeurs.`});
  });

  duplicateGroups(affectations.map(a=>normalizeRegistration(a.semi))).forEach(([reg,count])=>{
    const rows=affectations.filter(a=>normalizeRegistration(a.semi)===reg);
    if(rows.length>1 && rows.every(a=>driverAllowsMultipleAssignments(a.name))) return;
    issues.push({level:'high',section:'Affectations',text:`Semi ${formatRegistration(reg)} affectée à ${count} chauffeurs.`});
  });

  affectations.forEach(a=>{
    const t=normalizeRegistration(a.tractor);
    const s=normalizeRegistration(a.semi);
    if(t && !vehicleExistsInPark(t,'Tracteur')){
      issues.push({level:'warn',section:'Affectations',text:`${a.name} : tracteur ${formatRegistration(t)} hors parc.`});
    }
    if(s && !vehicleExistsInPark(s,'Semi')){
      issues.push({level:'warn',section:'Affectations',text:`${a.name} : semi ${formatRegistration(s)} hors parc.`});
    }
  });

  duplicateGroups(driverProfiles.map(d=>String(d.licenseNumber||'').trim().toUpperCase())).forEach(([license,count])=>{
    issues.push({level:'high',section:'Chauffeurs',text:`N° de permis ${license} utilisé sur ${count} fiches.`});
  });

  vidangeData.forEach(v=>{
    const current=kmNumber(v.currentKm);
    const major=kmNumber(v.lastMajorKm);
    const garage=kmNumber(v.lastGarageKm);
    if(current!==null && major!==null && current<major){
      issues.push({level:'high',section:'Suivi technique',text:`${formatRegistration(v.registration)} : km actuel inférieur à la dernière grosse vidange.`});
    }
    if(current!==null && garage!==null && current<garage){
      issues.push({level:'high',section:'Suivi technique',text:`${formatRegistration(v.registration)} : km actuel inférieur au dernier passage garage.`});
    }
  });

  duplicateGroups(adminRungis.map(r=>String(r.cardNumber||'').trim().toLocaleLowerCase('fr'))).forEach(([card,count])=>{
    issues.push({level:'high',section:'Cartes Rungis',text:`Carte ${card} présente ${count} fois.`});
  });

  return issues;
}

function dashboardRenderQuality(){
  if(!qualityScore) return;
  const issues=dashboardDataIssues();
  const high=issues.filter(x=>x.level==='high').length;
  const warn=issues.length-high;
  const score=Math.max(0,100-high*8-warn*3);

  qualityScore.textContent=score;
  qualityScore.className='quality-score '+(score>=90?'good':score>=70?'warn':'bad');

  if(!issues.length){
    qualityTitle.textContent='Données cohérentes';
    qualitySubtitle.textContent='Aucune anomalie détectée.';
    qualityList.innerHTML='<div class="vehicle-none">Aucune anomalie détectée.</div>';
    return;
  }

  qualityTitle.textContent=`${issues.length} anomalie${issues.length>1?'s':''} détectée${issues.length>1?'s':''}`;
  qualitySubtitle.textContent=`${high} critique${high>1?'s':''} · ${warn} à vérifier`;
  qualityList.innerHTML=issues.slice(0,30).map(issue=>
    `<div class="quality-item"><strong>${dashboardEsc(issue.section)}</strong> · ${dashboardEsc(issue.text)}</div>`
  ).join('');
}

function dashboardReadLocalList(key){
  try{
    const value=JSON.parse(localStorage.getItem(key));
    return Array.isArray(value)?value:[];
  }catch(error){return []}
}

function dashboardWriteLocalList(key,value){
  localStorage.setItem(key,JSON.stringify(value));
}

function dashboardRecentVehicles(){
  return dashboardReadLocalList(DASHBOARD_RECENTS_KEY);
}

function dashboardFavoriteVehicles(){
  return dashboardReadLocalList(DASHBOARD_FAVORITES_KEY);
}

function dashboardRememberVehicle(registration){
  const plate=formatRegistration(registration);
  let recents=dashboardRecentVehicles().filter(x=>normalizeRegistration(x)!==normalizeRegistration(plate));
  recents.unshift(plate);
  recents=recents.slice(0,6);
  dashboardWriteLocalList(DASHBOARD_RECENTS_KEY,recents);
  dashboardRenderQuickVehicles();
}

function dashboardToggleFavorite(registration){
  const plate=formatRegistration(registration);
  let favs=dashboardFavoriteVehicles();
  const exists=favs.some(x=>normalizeRegistration(x)===normalizeRegistration(plate));
  if(exists) favs=favs.filter(x=>normalizeRegistration(x)!==normalizeRegistration(plate));
  else favs.unshift(plate);
  dashboardWriteLocalList(DASHBOARD_FAVORITES_KEY,favs.slice(0,10));
  dashboardRenderQuickVehicles();
  return !exists;
}

function dashboardBuildNotifications(){
  const items=[];

  const late=[...vidangeData]
    .map(v=>({v,remaining:calculateNextOil(v)}))
    .filter(x=>x.remaining<=0)
    .sort((a,b)=>a.remaining-b.remaining);

  late.slice(0,5).forEach(({v,remaining})=>{
    items.push({
      level:'high',icon:'!',title:`Vidange à faire · ${formatRegistration(v.registration)}`,
      text:`Échéance dépassée de ${Math.abs(Math.round(remaining)).toLocaleString('fr-FR')} km.`,
      view:'suivi-technique',searchId:'vidSearch',searchValue:formatRegistration(v.registration)
    });
  });
  if(late.length>5){
    items.push({level:'high',icon:'!',title:`${late.length-5} autres vidanges dépassées`,text:'Ouvrir le suivi technique.',view:'suivi-technique'});
  }

  const soon=vidangeData.filter(v=>{
    const remaining=calculateNextOil(v);
    return remaining>0 && remaining<=5000;
  }).length;
  if(soon){
    items.push({level:'warn',icon:'~',title:`${soon} vidange${soon>1?'s':''} à prévoir`,text:'Échéance dans moins de 5 000 km.',view:'suivi-technique'});
  }

  const assigned=new Set();
  affectations.forEach(a=>{
    if(a.tractor) assigned.add(normalizeRegistration(a.tractor));
    if(a.semi) assigned.add(normalizeRegistration(a.semi));
  });
  const unassigned=parkData.filter(v=>!assigned.has(normalizeRegistration(v.registration))).length;
  if(unassigned){
    items.push({level:'info',icon:'i',title:`${unassigned} véhicule${unassigned>1?'s':''} non affecté${unassigned>1?'s':''}`,text:'Consulter le Parc.',view:'parc'});
  }

  const fines=adminFines.filter(f=>f.status==='À traiter').length;
  if(fines){
    items.push({level:'warn',icon:'€',title:`${fines} amende${fines>1?'s':''} à traiter`,text:'Gestion administrative.',view:'gestion-administrative',adminTab:'fines'});
  }

  const staleClaims=claimData.filter(c=>{
    if(c.status==='Clos'||!c.date) return false;
    const d=new Date(c.date+'T00:00:00');
    return Number.isFinite(d.getTime()) && Date.now()-d.getTime()>14*24*60*60*1000;
  }).length;
  if(staleClaims){
    items.push({level:'warn',icon:'⚠',title:`${staleClaims} sinistre${staleClaims>1?'s':''} ouvert${staleClaims>1?'s':''} depuis +14 jours`,text:'Vérifier leur avancement.',view:'sinistre'});
  }

  const issues=dashboardDataIssues();
  if(issues.length){
    items.push({
      level:issues.some(x=>x.level==='high')?'high':'warn',
      icon:'!',title:`${issues.length} anomalie${issues.length>1?'s':''} de données`,
      text:administratorIsAdmin()?'Voir le contrôle qualité dans Administrateur.':'Certaines données nécessitent une vérification.',
      view:administratorIsAdmin()?'administrateur':'parc',
      requiresAdmin:administratorIsAdmin()
    });
  }

  return items;
}

async function dashboardOpenNotification(item){
  notificationPanel.hidden=true;

  if(item.requiresAdmin && typeof adminSecurityRequestAccess==='function'){
    const allowed=await adminSecurityRequestAccess();
    if(!allowed) return;
  }

  const nav=[...navButtons].find(b=>b.dataset.view===item.view);
  if(nav){
    showView(item.view,item.view==='accueil'?'Gestion de Parc':nav.innerText.trim(),item.view);
  }

  if(item.adminTab && typeof switchAdminTab==='function') switchAdminTab(item.adminTab);
  if(item.view==='suivi-technique' && item.searchId==='vidSearch' && typeof window.technicalOpenPage==='function') window.technicalOpenPage('vidange');
  if(item.searchId && item.searchValue){
    const input=document.getElementById(item.searchId);
    if(input){
      input.value=item.searchValue;
      input.dispatchEvent(new Event('input',{bubbles:true}));
    }
  }
}

function dashboardRenderQuickVehicles(){
  if(!notificationQuickVehicles) return;
  const favs=dashboardFavoriteVehicles();
  const recents=dashboardRecentVehicles().filter(r=>!favs.some(f=>normalizeRegistration(f)===normalizeRegistration(r)));
  const chips=[
    ...favs.map(reg=>({reg,label:'★ '+reg})),
    ...recents.slice(0,5).map(reg=>({reg,label:reg}))
  ];
  notificationQuickVehicles.innerHTML=chips.length
    ? chips.map(x=>`<button class="notification-chip" type="button" data-quick-vehicle="${dashboardEsc(x.reg)}">${dashboardEsc(x.label)}</button>`).join('')
    : '<span class="vehicle-none">Aucun véhicule consulté.</span>';
}

function dashboardRefreshNotifications(){
  if(!notificationList) return;
  const items=dashboardBuildNotifications();
  const levelOrder={high:0,warn:1,info:2};
  const viewOrder={'suivi-technique':0,'gestion-administrative':1,'sinistre':2,'parc':3,'affectations':4,'chauffeur':5,'administrateur':6};
  const sortedItems=items
    .map((item,index)=>({...item,_originalIndex:index}))
    .sort((a,b)=>{
      const levelDiff=(levelOrder[a.level]??9)-(levelOrder[b.level]??9);
      if(levelDiff!==0) return levelDiff;
      const viewDiff=(viewOrder[a.view]??9)-(viewOrder[b.view]??9);
      if(viewDiff!==0) return viewDiff;
      const aDetail=a.searchValue?0:1;
      const bDetail=b.searchValue?0:1;
      if(aDetail!==bDetail) return aDetail-bDetail;
      return String(a.title).localeCompare(String(b.title),'fr',{numeric:true,sensitivity:'base'});
    });

  notificationBadge.textContent=sortedItems.length>99?'99+':sortedItems.length;
  notificationBadge.hidden=!sortedItems.length;
  notificationSubtitle.textContent=sortedItems.length
    ? `${sortedItems.length} élément${sortedItems.length>1?'s':''} à surveiller`
    : 'Aucun élément urgent';

  if(sortedItems.length){
    let currentLevel='';
    notificationList.innerHTML=sortedItems.map((item,index)=>{
      const label=item.level==='high'?'URGENT':item.level==='warn'?'À VOIR':'INFO';
      const section=currentLevel!==label ? `<div class="notification-section-label">${label}</div>` : '';
      currentLevel=label;
      return `${section}
        <button class="notification-item ${item.level==='warn'?'warn':item.level==='info'?'info':''}" type="button" data-notification-index="${index}">
          <span class="notification-icon">${dashboardEsc(item.icon)}</span>
          <span><span class="notification-item-title">${dashboardEsc(item.title)}</span><span class="notification-item-text">${dashboardEsc(item.text)}</span></span>
          <span class="notification-priority">${label}</span>
        </button>`;
    }).join('');
  }else{
    notificationList.innerHTML='<div class="notification-empty">Tout est calme pour le moment.</div>';
  }

  notificationList._dashboardItems=sortedItems;
  dashboardRenderQuickVehicles();
  dashboardRenderQuality();
}

function dashboardFindVehicleLinks(registration){
  const reg=normalizeRegistration(registration);
  const vehicle=parkData.find(v=>normalizeRegistration(v.registration)===reg)||null;
  const assignment=affectations.find(a=>
    normalizeRegistration(a.tractor)===reg || normalizeRegistration(a.semi)===reg
  )||null;
  const driver=assignment
    ? driverProfiles.find(d=>normalizeAffText(`${d.lastName} ${d.firstName}`)===normalizeAffText(assignment.name))||null
    : null;
  const maintenance=vidangeData.find(v=>normalizeRegistration(v.registration)===reg)||null;
  const claims=claimData.filter(c=>normalizeRegistration(c.vehicle)===reg);
  const fines=adminFines.filter(f=>normalizeRegistration(f.vehicle)===reg);
  const rungis=adminRungis.filter(r=>normalizeRegistration(r.vehicle)===reg);
  return {vehicle,assignment,driver,maintenance,claims,fines,rungis};
}

function dashboardVehicleLinkedItems(items,renderer){
  if(!items.length) return '<div class="vehicle-none">Aucun élément lié.</div>';
  return `<div class="vehicle-linked-list">${items.slice(0,6).map(renderer).join('')}</div>`;
}

function dashboardOpenVehicleDossier(registration){
  const links=dashboardFindVehicleLinks(registration);
  if(!links.vehicle){
    dashboardToast('Véhicule introuvable',formatRegistration(registration),'warn');
    return;
  }

  const {vehicle,assignment,driver,maintenance,claims,fines,rungis}=links;
  const plate=formatRegistration(vehicle.registration);
  dashboardCurrentVehicleDossier=plate;
  dashboardRememberVehicle(plate);

  const counterpart=assignment
    ? (vehicle.type==='Tracteur'?assignment.semi:assignment.tractor)
    : '';
  const remaining=maintenance?calculateNextOil(maintenance):null;
  const favorite=dashboardFavoriteVehicles().some(x=>normalizeRegistration(x)===normalizeRegistration(plate));

  vehicleDossierTitle.textContent=`Fiche véhicule · ${plate}`;
  vehicleDossierBody.innerHTML=`
    <div class="vehicle-dossier-top">
      <div>
        <div class="vehicle-dossier-plate">${dashboardEsc(plate)}</div>
        <div class="vehicle-dossier-meta">${dashboardEsc(vehicle.type)}${vehicle.parkNumber?' · Parc '+dashboardEsc(vehicle.parkNumber):''}</div>
      </div>
      <button class="vehicle-favorite-btn ${favorite?'active':''}" id="vehicleFavoriteButton" type="button">${favorite?'★ Favori':'☆ Ajouter aux favoris'}</button>
    </div>

    <div class="vehicle-summary-grid">
      <div class="vehicle-summary-cell"><div class="vehicle-summary-label">AFFECTATION</div><div class="vehicle-summary-value">${assignment?'Affecté':'Non affecté'}</div></div>
      <div class="vehicle-summary-cell"><div class="vehicle-summary-label">CHAUFFEUR</div><div class="vehicle-summary-value">${dashboardEsc(assignment?.name||'—')}</div></div>
      <div class="vehicle-summary-cell"><div class="vehicle-summary-label">PROCHAINE VIDANGE</div><div class="vehicle-summary-value">${remaining===null?'—':remaining<=0?`${Math.abs(Math.round(remaining)).toLocaleString('fr-FR')} km dépassés`:`${Math.round(remaining).toLocaleString('fr-FR')} km`}</div></div>
      <div class="vehicle-summary-cell"><div class="vehicle-summary-label">SINISTRES</div><div class="vehicle-summary-value">${claims.length}</div></div>
    </div>

    <div class="vehicle-dossier-grid">
      <div class="vehicle-section">
        <div class="vehicle-section-head">AFFECTATION & CHAUFFEUR</div>
        <div class="vehicle-section-content">
          <div class="vehicle-line"><span class="vehicle-line-label">Chauffeur</span><span class="vehicle-line-value">${dashboardEsc(assignment?.name||'—')}</span></div>
          <div class="vehicle-line"><span class="vehicle-line-label">${vehicle.type==='Tracteur'?'Semi':'Tracteur'} associé${vehicle.type==='Tracteur'?'e':''}</span><span class="vehicle-line-value">${dashboardEsc(counterpart?formatRegistration(counterpart):'—')}</span></div>
          <div class="vehicle-line"><span class="vehicle-line-label">Téléphone pro</span><span class="vehicle-line-value">${dashboardEsc(assignment?.phone||'—')}</span></div>
          <div class="vehicle-line"><span class="vehicle-line-label">N° personnel</span><span class="vehicle-line-value">${dashboardEsc(assignment?.personal||'—')}</span></div>
          <div class="vehicle-line"><span class="vehicle-line-label">Permis</span><span class="vehicle-line-value">${dashboardEsc(driver?.licenseNumber||'—')}</span></div>
          <div class="vehicle-line"><span class="vehicle-line-label">Délivré le</span><span class="vehicle-line-value">${dashboardEsc(driver?.licenseIssueDate||'—')}</span></div>
        </div>
      </div>

      <div class="vehicle-section">
        <div class="vehicle-section-head">SUIVI TECHNIQUE</div>
        <div class="vehicle-section-content">
          <div class="vehicle-line"><span class="vehicle-line-label">Km actuel</span><span class="vehicle-line-value">${maintenance?.currentKm!=null?Number(maintenance.currentKm).toLocaleString('fr-FR')+' km':'—'}</span></div>
          <div class="vehicle-line"><span class="vehicle-line-label">Dernière grosse vidange</span><span class="vehicle-line-value">${maintenance?.lastMajorKm!=null?Number(maintenance.lastMajorKm).toLocaleString('fr-FR')+' km':'—'}</span></div>
          <div class="vehicle-line"><span class="vehicle-line-label">Dernier passage garage</span><span class="vehicle-line-value">${maintenance?.lastGarageKm!=null?Number(maintenance.lastGarageKm).toLocaleString('fr-FR')+' km':'—'}</span></div>
          <div class="vehicle-line"><span class="vehicle-line-label">État vidange</span><span class="vehicle-line-value">${remaining===null?'Non suivi':remaining<=0?'À faire':remaining<=5000?'À prévoir':'À jour'}</span></div>
        </div>
      </div>

      <div class="vehicle-section">
        <div class="vehicle-section-head">SINISTRES</div>
        <div class="vehicle-section-content">
          ${dashboardVehicleLinkedItems(claims,c=>`<div class="vehicle-linked-item"><strong>${dashboardEsc(c.number||'Sans n° dossier')}</strong> · ${dashboardEsc(c.status||'—')}<br>${dashboardEsc(c.date||'—')} · ${dashboardEsc(c.type||'Sinistre')}</div>`)}
        </div>
      </div>

      <div class="vehicle-section">
        <div class="vehicle-section-head">AMENDES & CARTE RUNGIS</div>
        <div class="vehicle-section-content">
          ${dashboardVehicleLinkedItems(fines,f=>`<div class="vehicle-linked-item"><strong>${dashboardEsc(f.reference||'Amende')}</strong> · ${dashboardEsc(f.status||'—')}${Number(f.attachmentCount||0)>0?` · 📎 ${Number(f.attachmentCount||0)}`:''}<br>${dashboardEsc(f.date||'—')} · ${dashboardEsc(f.offense||'—')}</div>`)}
          <div style="height:8px"></div>
          ${dashboardVehicleLinkedItems(rungis,r=>`<div class="vehicle-linked-item"><strong>Carte Rungis ${dashboardEsc(r.cardNumber||'—')}</strong></div>`)}
        </div>
      </div>

      <div class="vehicle-section full">
        <div class="vehicle-section-head">TRAÇABILITÉ</div>
        <div class="vehicle-section-content">
          <div class="vehicle-line"><span class="vehicle-line-label">Créé par</span><span class="vehicle-line-value">${dashboardEsc(vehicle._createdBy||'Donnée initiale')}</span></div>
          <div class="vehicle-line"><span class="vehicle-line-label">Création</span><span class="vehicle-line-value">${dashboardEsc(dashboardDateTime(vehicle._createdAt))}</span></div>
          <div class="vehicle-line"><span class="vehicle-line-label">Dernière modification</span><span class="vehicle-line-value">${dashboardEsc(vehicle._modifiedBy||'—')} · ${dashboardEsc(dashboardDateTime(vehicle._modifiedAt))}</span></div>
        </div>
      </div>
    </div>

    <div class="vehicle-dossier-actions">
      <button class="tool-btn" type="button" data-vehicle-go="parc">Ouvrir dans Parc</button>
      <button class="tool-btn" type="button" data-vehicle-go="affectations">Ouvrir Affectations</button>
      ${maintenance?'<button class="tool-btn" type="button" data-vehicle-go="suivi-technique">Ouvrir Suivi technique</button>':''}
      ${claims.length?'<button class="tool-btn" type="button" data-vehicle-go="sinistre">Voir les sinistres</button>':''}
    </div>
  `;

  document.getElementById('vehicleFavoriteButton')?.addEventListener('click',event=>{
    const active=dashboardToggleFavorite(plate);
    event.currentTarget.classList.toggle('active',active);
    event.currentTarget.textContent=active?'★ Favori':'☆ Ajouter aux favoris';
  });

  vehicleDossierModal.hidden=false;
  document.body.classList.add('modal-open');
}

function dashboardCloseVehicleDossier(){
  vehicleDossierModal.hidden=true;
  dashboardCurrentVehicleDossier='';
  if(document.querySelectorAll('.modal-overlay:not([hidden])').length===0) document.body.classList.remove('modal-open');
}

function dashboardCompareRecord(a,b){
  return JSON.stringify(a??null)===JSON.stringify(b??null);
}

function dashboardDetectSharedConflict(descriptor,previous,next,remote){
  if(!remote) return null;

  if(descriptor.kind==='object'){
    const keys=new Set([
      ...Object.keys(previous||{}),
      ...Object.keys(next||{}),
      ...Object.keys(remote||{})
    ]);
    const conflicts=[];
    for(const key of keys){
      if(key.startsWith('_')) continue;
      const localChanged=!dashboardCompareRecord(previous?.[key],next?.[key]);
      const remoteChanged=!dashboardCompareRecord(previous?.[key],remote?.[key]);
      if(localChanged && remoteChanged && !dashboardCompareRecord(next?.[key],remote?.[key])){
        conflicts.push(key);
      }
    }
    if(!conflicts.length) return null;
    const labels=dashboardDatasetFieldLabels(descriptor);
    return {ids:conflicts,labels:conflicts.map(k=>labels[k]||k),items:[]};
  }

  const p=sharedRecordMap(descriptor,Array.isArray(previous)?previous:[]);
  const n=sharedRecordMap(descriptor,Array.isArray(next)?next:[]);
  const r=sharedRecordMap(descriptor,Array.isArray(remote)?remote:[]);
  const ids=new Set([...p.keys(),...n.keys(),...r.keys()]);
  const conflicts=[];

  for(const id of ids){
    const pv=p.get(id);
    const nv=n.get(id);
    const rv=r.get(id);
    const localChanged=!dashboardCompareRecord(pv,nv);
    const remoteChanged=!dashboardCompareRecord(pv,rv);
    if(localChanged && remoteChanged && !dashboardCompareRecord(nv,rv)){
      conflicts.push({id,local:nv,remote:rv,before:pv});
    }
  }

  if(!conflicts.length) return null;
  return {
    ids:conflicts.map(x=>x.id),
    labels:conflicts.map(x=>administratorEntityLabel(descriptor,x.local||x.remote||x.before)||x.id),
    items:conflicts
  };
}

function dashboardAskSharedConflict(descriptor,conflict,remoteDoc){
  const remoteUser=conflict.items
    .map(x=>x.remote?._modifiedBy)
    .filter(Boolean)[0] || remoteDoc?.updatedBy || 'un autre utilisateur';

  sharedConflictBanner.innerHTML=
    `La même donnée a été modifiée par <b>${dashboardEsc(remoteUser)}</b> pendant votre saisie.`;

  sharedConflictItems.innerHTML=conflict.labels.map((label,index)=>{
    const item=conflict.items[index];
    const changes=item
      ? dashboardDescribeObjectChanges(item.before||{},item.remote||{},descriptor).join(' · ')
      : 'Modification distante détectée';
    return `<div class="conflict-item"><strong>${dashboardEsc(label)}</strong><br>${dashboardEsc(changes||'Modification distante détectée')}</div>`;
  }).join('');

  sharedConflictModal.hidden=false;
  document.body.classList.add('modal-open');

  return new Promise(resolve=>{sharedConflictResolver=resolve});
}

function dashboardResolveConflictChoice(keep){
  sharedConflictModal.hidden=true;
  if(document.querySelectorAll('.modal-overlay:not([hidden])').length===0) document.body.classList.remove('modal-open');
  if(sharedConflictResolver){
    const resolve=sharedConflictResolver;
    sharedConflictResolver=null;
    resolve(keep);
  }
}

async function dashboardFileExists(dir,name){
  try{
    await dir.getFileHandle(name);
    return true;
  }catch(error){
    if(error?.name==='NotFoundError') return false;
    throw error;
  }
}

async function dashboardWriteRawJson(dir,name,payload){
  const handle=await dir.getFileHandle(name,{create:true});
  const writable=await handle.createWritable();
  await writable.write(JSON.stringify(payload,null,2));
  await writable.close();
}

async function dashboardReadRawJson(dir,name){
  const handle=await dir.getFileHandle(name);
  const file=await handle.getFile();
  return JSON.parse(await file.text());
}

function dashboardFlashShortcutHelp(){
  if(!shortcutHelp) return;
  shortcutHelp.classList.add('show');
  clearTimeout(shortcutHelpTimer);
  shortcutHelpTimer=setTimeout(()=>shortcutHelp.classList.remove('show'),2200);
}

function dashboardSetSidebarCollapsed(collapsed,save=true){
  const state=Boolean(collapsed);
  appShell?.classList.toggle('sidebar-collapsed',state);

  if(sidebarCollapseButton){
    sidebarCollapseButton.title=state?'Agrandir le menu':'Réduire le menu';
    sidebarCollapseButton.setAttribute('aria-label',state?'Agrandir le menu':'Réduire le menu');
  }
  if(sidebarCollapseLabel){
    sidebarCollapseLabel.textContent=state?'Agrandir le menu':'Réduire le menu';
  }

  if(save){
    localStorage.setItem(SIDEBAR_COLLAPSED_KEY,state?'1':'0');
  }

  // Le changement de largeur peut modifier les dimensions des graphiques.
  if(typeof renderFuelCharts==='function'){
    requestAnimationFrame(()=>{
      requestAnimationFrame(renderFuelCharts);
    });
  }
}

function dashboardToggleSidebar(){
  dashboardSetSidebarCollapsed(!appShell?.classList.contains('sidebar-collapsed'));
}

async function dashboardReadFileBytes(fileHandle){
  const file=await fileHandle.getFile();
  return await file.arrayBuffer();
}

function applyDashboardTheme(theme){
  const white=theme==='white';

  document.body.classList.toggle('white-mode',white);
  themeSwitch.setAttribute('aria-checked',white?'true':'false');
  themeSwitch.title=white?'Passer en Dark mode':'Passer en White mode';

  try{
    localStorage.setItem(THEME_STORAGE_KEY,white?'white':'dark');
  }catch(error){
    console.warn('Impossible de mémoriser le thème.',error);
  }

  if(typeof renderFuelCharts==='function'){
    requestAnimationFrame(()=>{
      requestAnimationFrame(renderFuelCharts);
    });
  }
}
