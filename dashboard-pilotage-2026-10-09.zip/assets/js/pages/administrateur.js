function adminNorm(value){
  return String(value||'').toLocaleLowerCase('fr').normalize('NFD').replace(/[\u0300-\u036f]/g,'');
}

function administratorIsAdmin(){
  return String(dashboardUser||'').toUpperCase()===ADMINISTRATOR_USER;
}

function administratorSafePart(value){
  return String(value||'')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g,'')
    .replace(/[<>:"/\\|?*\x00-\x1F]/g,'_')
    .replace(/\s+/g,'_')
    .replace(/[^A-Za-z0-9._-]/g,'_')
    .slice(0,80) || 'inconnu';
}

function administratorLocalDateKey(value=new Date()){
  const date=value instanceof Date ? value : new Date(value);
  const y=date.getFullYear();
  const m=String(date.getMonth()+1).padStart(2,'0');
  const d=String(date.getDate()).padStart(2,'0');
  return `${y}-${m}-${d}`;
}

function administratorPageLabel(id){
  return ({
    accueil:'Accueil',
    parc:'Parc',
    affectations:'Affectations',
    chauffeur:'Chauffeur',
    sinistre:'Sinistre',
    'suivi-technique':'Suivi technique',
    carburant:'Carburant',
    'gestion-administrative':'Gestion administrative',
    administrateur:'Administrateur'
  })[id] || String(id||'—');
}

async function administratorGetDirectory(name,create=false){
  if(!sharedConnected || !sharedDirectoryHandle) return null;
  return await sharedDirectoryHandle.getDirectoryHandle(name,{create});
}

async function administratorWriteJsonFile(directory,fileName,payload){
  const handle=await directory.getFileHandle(fileName,{create:true});
  const writable=await handle.createWritable();
  await writable.write(JSON.stringify(payload,null,2));
  await writable.close();
}

async function administratorWriteHistory(event){
  if(!sharedConnected || !sharedDirectoryHandle || !dashboardUser) return;

  try{
    const root=await administratorGetDirectory(ADMIN_HISTORY_FOLDER,true);
    if(!root) return;

    const now=new Date();
    const day=administratorLocalDateKey(now);
    const dayDir=await root.getDirectoryHandle(day,{create:true});

    const payload={
      id:'evt_'+Date.now()+'_'+Math.random().toString(36).slice(2,8),
      timestamp:now.toISOString(),
      user:dashboardUser,
      action:event.action || 'Activité',
      section:event.section || administratorPageLabel(administratorLastKnownPage),
      entity:event.entity || '',
      detail:event.detail || '',
      session:sharedClientId
    };

    const stamp=
      String(now.getHours()).padStart(2,'0')+
      String(now.getMinutes()).padStart(2,'0')+
      String(now.getSeconds()).padStart(2,'0')+
      '_'+String(now.getMilliseconds()).padStart(3,'0');

    const fileName=
      `${stamp}_${administratorSafePart(dashboardUser)}_${Math.random().toString(36).slice(2,7)}.json`;

    await administratorWriteJsonFile(dayDir,fileName,payload);
  }catch(error){
    console.warn('Historique administrateur indisponible.',error);
  }
}

async function administratorWritePresence(){
  if(!sharedConnected || !sharedDirectoryHandle || !dashboardUser) return;

  try{
    const dir=await administratorGetDirectory(ADMIN_PRESENCE_FOLDER,true);
    if(!dir) return;

    const now=new Date();
    const activeView=document.querySelector('.view.active')?.id || administratorLastKnownPage || 'accueil';
    administratorLastKnownPage=activeView;

    const payload={
      user:dashboardUser,
      session:sharedClientId,
      connectedAt:administratorSessionStartedAt,
      heartbeatAt:now.toISOString(),
      page:activeView,
      pageLabel:administratorPageLabel(activeView),
      online:true
    };

    await administratorWriteJsonFile(
      dir,
      administratorSafePart(dashboardUser)+'.json',
      payload
    );

    administratorLastPresenceWrite=Date.now();
  }catch(error){
    console.warn('Présence utilisateur indisponible.',error);
  }
}

async function administratorStartPresence(force=false){
  if(!sharedConnected || !dashboardUser) return;

  const currentUser=dashboardUser;

  if(administratorPresenceUser && administratorPresenceUser!==currentUser){
    try{
      const dir=await administratorGetDirectory(ADMIN_PRESENCE_FOLDER,false);
      if(dir){
        await dir.removeEntry(administratorSafePart(administratorPresenceUser)+'.json');
      }
    }catch(error){}
    administratorConnectionLoggedUser='';
  }

  administratorPresenceUser=currentUser;

  if(administratorPresenceTimer){
    clearInterval(administratorPresenceTimer);
    administratorPresenceTimer=null;
  }

  await administratorWritePresence();

  administratorPresenceTimer=setInterval(()=>{
    administratorWritePresence();
  },ADMIN_PRESENCE_INTERVAL);

  if(force || administratorConnectionLoggedUser!==currentUser){
    administratorConnectionLoggedUser=currentUser;
    administratorSessionStartedAt=new Date().toISOString();
    await administratorWriteHistory({
      action:'Connexion',
      section:'Dashboard',
      entity:currentUser,
      detail:'Ouverture du dashboard'
    });
  }
}

async function administratorStopPresence(removeFile=false){
  if(administratorPresenceTimer){
    clearInterval(administratorPresenceTimer);
    administratorPresenceTimer=null;
  }

  if(removeFile && sharedConnected && sharedDirectoryHandle && administratorPresenceUser){
    try{
      const dir=await administratorGetDirectory(ADMIN_PRESENCE_FOLDER,false);
      if(dir){
        await dir.removeEntry(administratorSafePart(administratorPresenceUser)+'.json');
      }
    }catch(error){}
  }
}

function administratorEntityLabel(descriptor,item){
  if(!item) return '';

  if(descriptor.key===PARK_STORAGE_KEY) return formatRegistration(item.registration||'');
  if(descriptor.key===AFFECT_STORAGE_KEY) return item.name||'';
  if(descriptor.key===DRIVER_STORAGE_KEY) return `${item.lastName||''} ${item.firstName||''}`.trim();
  if(descriptor.key===CLAIM_STORAGE_KEY) return item.number ? `Dossier ${item.number}` : (item.vehicle||'Sinistre');
  if(descriptor.key===VIDANGE_STORAGE_KEY) return formatRegistration(item.registration||'');
  if(descriptor.key===TECH_DEADLINE_STORAGE_KEY) return `${String(item.control||item.category||'Échéance').trim()} · ${formatRegistration(item.registration||'')}`;
  if(descriptor.key===ADMIN_FINE_KEY) return item.reference || item.vehicle || 'Amende';
  if(descriptor.key===ADMIN_RUNGIS_KEY) return item.cardNumber ? `Carte ${item.cardNumber}` : 'Carte Rungis';
  if(descriptor.key===FUEL_STORAGE_KEY) return item.supplier || 'Commande carburant';

  return item.id||'';
}

function administratorSectionLabel(descriptor){
  if(descriptor.key===PARK_STORAGE_KEY) return 'Parc';
  if(descriptor.key===AFFECT_STORAGE_KEY) return 'Affectations';
  if(descriptor.key===DRIVER_STORAGE_KEY) return 'Chauffeur';
  if(descriptor.key===CLAIM_STORAGE_KEY) return 'Sinistre';
  if(descriptor.key===VIDANGE_STORAGE_KEY) return 'Suivi technique';
  if(descriptor.key===TECH_DEADLINE_STORAGE_KEY) return 'Échéances techniques';
  if(descriptor.key===ADMIN_FINE_KEY) return 'Amendes';
  if(descriptor.key===ADMIN_RUNGIS_KEY) return 'Cartes Rungis';
  if(descriptor.key===ADMIN_SITES_KEY) return 'Sites & outils';
  if(descriptor.key===FUEL_STORAGE_KEY) return 'Carburant';
  return 'Dashboard';
}

function administratorDiffDataset(descriptor,previous,next){
  if(descriptor.key===CLAIM_EVENTS_KEY) return [];

  if(descriptor.kind==='object'){
    const prev=previous||{};
    const after=next||{};
    const changes=dashboardDescribeObjectChanges(prev,after,descriptor);
    if(!changes.length) return [];
    return [{
      action:'Modification',
      section:administratorSectionLabel(descriptor),
      entity:'Paramètres',
      detail:changes.join(' · ')
    }];
  }

  const prevArray=Array.isArray(previous)?previous:[];
  const nextArray=Array.isArray(next)?next:[];
  const prevMap=sharedRecordMap(descriptor,prevArray);
  const nextMap=sharedRecordMap(descriptor,nextArray);

  const created=[];
  const modified=[];
  const deleted=[];

  for(const [id,item] of nextMap.entries()){
    if(!prevMap.has(id)){
      created.push(item);
    }else if(JSON.stringify(prevMap.get(id))!==JSON.stringify(item)){
      modified.push({before:prevMap.get(id),after:item});
    }
  }

  for(const [id,item] of prevMap.entries()){
    if(!nextMap.has(id)) deleted.push(item);
  }

  const total=created.length+modified.length+deleted.length;
  if(!total) return [];

  const events=[];
  created.forEach(item=>events.push({
    action:'Ajout',
    section:administratorSectionLabel(descriptor),
    entity:administratorEntityLabel(descriptor,item),
    detail:dashboardDescribeCreatedItem(item,descriptor)
  }));
  modified.forEach(change=>events.push({
    action:'Modification',
    section:administratorSectionLabel(descriptor),
    entity:administratorEntityLabel(descriptor,change.after),
    detail:dashboardDescribeObjectChanges(change.before,change.after,descriptor).join(' · ') || 'Élément modifié'
  }));
  deleted.forEach(item=>events.push({
    action:'Suppression',
    section:administratorSectionLabel(descriptor),
    entity:administratorEntityLabel(descriptor,item),
    detail:'Élément supprimé'
  }));

  return events;
}

async function administratorLogDatasetChanges(descriptor,previous,next){
  const events=administratorDiffDataset(descriptor,previous,next);
  for(const event of events){
    await administratorWriteHistory(event);
  }

  if(events.length){
    administratorWritePresence();
  }
}

function administratorUserChanged(previousUser,newUser){
  if(typeof adminSecurityLock==='function'){
    adminSecurityLock(true);
  }

  refreshAdministratorAccess();

  if(typeof sharedConnected!=='undefined' && sharedConnected){
    administratorStartPresence(previousUser!==newUser);
  }
}

function adminSecurityToB64(bytes){
  let value='';
  bytes.forEach(byte=>value+=String.fromCharCode(byte));
  return btoa(value);
}

function adminSecurityFromB64(value){
  const raw=atob(value);
  const bytes=new Uint8Array(raw.length);
  for(let i=0;i<raw.length;i++) bytes[i]=raw.charCodeAt(i);
  return bytes;
}

async function adminSecurityDerive(password,salt,iterations){
  const source=await crypto.subtle.importKey(
    'raw',new TextEncoder().encode(password),'PBKDF2',false,['deriveBits']
  );
  const result=await crypto.subtle.deriveBits(
    {name:'PBKDF2',hash:'SHA-256',salt,iterations},
    source,256
  );
  return new Uint8Array(result);
}

function adminSecurityEqual(a,b){
  if(a.length!==b.length) return false;
  let diff=0;
  for(let i=0;i<a.length;i++) diff|=a[i]^b[i];
  return diff===0;
}

async function adminSecurityReadConfig(){
  if(!sharedConnected || !sharedDirectoryHandle) return null;
  try{
    const handle=await sharedDirectoryHandle.getFileHandle(ADMIN_SECURITY_FILE);
    const file=await handle.getFile();
    const config=JSON.parse(await file.text());
    return config?.salt && config?.hash ? config : null;
  }catch(error){
    if(error?.name==='NotFoundError') return null;
    throw error;
  }
}

async function adminSecurityCreateConfig(password){
  if(!sharedConnected || !sharedDirectoryHandle){
    throw new Error('Le dossier partagé doit être connecté.');
  }

  const salt=crypto.getRandomValues(new Uint8Array(16));
  const hash=await adminSecurityDerive(password,salt,ADMIN_SECURITY_ITERATIONS);
  const config={
    version:1,
    algorithm:'PBKDF2-SHA256',
    iterations:ADMIN_SECURITY_ITERATIONS,
    salt:adminSecurityToB64(salt),
    hash:adminSecurityToB64(hash),
    adminUser:ADMINISTRATOR_USER,
    updatedAt:new Date().toISOString(),
    updatedBy:dashboardUser
  };

  const handle=await sharedDirectoryHandle.getFileHandle(ADMIN_SECURITY_FILE,{create:true});
  const writable=await handle.createWritable();
  await writable.write(JSON.stringify(config,null,2));
  await writable.close();
}

async function adminSecurityVerify(password,config){
  const salt=adminSecurityFromB64(config.salt);
  const expected=adminSecurityFromB64(config.hash);
  const actual=await adminSecurityDerive(
    password,
    salt,
    Number(config.iterations)||ADMIN_SECURITY_ITERATIONS
  );
  return adminSecurityEqual(actual,expected);
}

function adminSecurityIsUnlocked(){
  if(!adminSecurityUnlocked) return false;
  if(Date.now()>adminSecurityUnlockedUntil){
    adminSecurityLock(true);
    return false;
  }
  return true;
}

function adminSecurityTouch(){
  if(adminSecurityUnlocked){
    adminSecurityUnlockedUntil=Date.now()+ADMIN_SECURITY_TIMEOUT;
  }
}

function adminSecurityUpdateUi(){
  const open=adminSecurityUnlocked && Date.now()<=adminSecurityUnlockedUntil;
  adminSecurityChip?.classList.toggle('unlocked',open);
  if(adminSecurityChipText) adminSecurityChipText.textContent=open?'Déverrouillé':'Verrouillé';
  if(adminSecurityLockButton) adminSecurityLockButton.disabled=!open;
}

function adminSecurityShowError(text){
  adminSecurityError.textContent=text;
  adminSecurityError.classList.add('show');
}

function adminSecurityClearError(){
  adminSecurityError.textContent='';
  adminSecurityError.classList.remove('show');
}

function adminSecurityOpen(mode){
  adminSecurityMode=mode;
  adminSecurityClearError();
  adminSecurityPassword.value='';
  adminSecurityConfirm.value='';
  adminSecurityModal.hidden=false;
  document.body.classList.add('modal-open');

  if(mode==='setup'){
    adminSecurityIntro.innerHTML='Première utilisation : crée le mot de passe de l’espace <b>Administrateur</b>.';
    adminSecurityConfirmWrap.hidden=false;
    adminSecuritySubmit.textContent='Créer le mot de passe';
  }else if(mode==='change'){
    adminSecurityIntro.textContent='Choisis un nouveau mot de passe administrateur.';
    adminSecurityConfirmWrap.hidden=false;
    adminSecuritySubmit.textContent='Changer le mot de passe';
  }else{
    adminSecurityIntro.textContent='Saisis le mot de passe administrateur pour accéder à la supervision.';
    adminSecurityConfirmWrap.hidden=true;
    adminSecuritySubmit.textContent='Déverrouiller';
  }

  setTimeout(()=>adminSecurityPassword.focus(),50);
}

function adminSecurityCloseModal(result=false){
  adminSecurityModal.hidden=true;
  adminSecurityPassword.value='';
  adminSecurityConfirm.value='';
  adminSecurityClearError();

  if(document.querySelectorAll('.modal-overlay:not([hidden])').length===0){
    document.body.classList.remove('modal-open');
  }

  if(adminSecurityResolver){
    const resolve=adminSecurityResolver;
    adminSecurityResolver=null;
    resolve(result);
  }
}

function adminSecurityLock(returnHome=true){
  adminSecurityUnlocked=false;
  adminSecurityUnlockedUntil=0;
  adminSecurityUpdateUi();

  if(returnHome && document.querySelector('.view.active')?.id==='administrateur'){
    showView('accueil','Gestion de Parc','accueil');
  }
}

async function adminSecurityRequestAccess(){
  if(!administratorIsAdmin()) return false;

  if(!sharedConnected || !sharedDirectoryHandle){
    alert('Connecte d’abord le dossier partagé.');
    return false;
  }

  if(adminSecurityIsUnlocked()){
    adminSecurityTouch();
    return true;
  }

  let config;
  try{
    config=await adminSecurityReadConfig();
  }catch(error){
    alert('Impossible de lire la sécurité Administrateur : '+String(error));
    return false;
  }

  adminSecurityOpen(config?'login':'setup');

  return await new Promise(resolve=>{
    adminSecurityResolver=resolve;
  });
}

async function adminSecuritySubmitForm(){
  adminSecurityClearError();

  if(Date.now()<adminSecurityBlockedUntil){
    const sec=Math.ceil((adminSecurityBlockedUntil-Date.now())/1000);
    adminSecurityShowError(`Trop de tentatives. Réessaie dans ${sec} seconde(s).`);
    return;
  }

  const password=String(adminSecurityPassword.value||'');

  if(adminSecurityMode==='setup' || adminSecurityMode==='change'){
    if(password.length<ADMIN_SECURITY_MIN_LENGTH){
      adminSecurityShowError(`Utilise au moins ${ADMIN_SECURITY_MIN_LENGTH} caractères.`);
      return;
    }
    if(password!==String(adminSecurityConfirm.value||'')){
      adminSecurityShowError('Les deux mots de passe ne correspondent pas.');
      return;
    }

    try{
      adminSecuritySubmit.disabled=true;
      await adminSecurityCreateConfig(password);
      adminSecurityUnlocked=true;
      adminSecurityUnlockedUntil=Date.now()+ADMIN_SECURITY_TIMEOUT;
      adminSecurityFailures=0;
      adminSecurityUpdateUi();

      administratorWriteHistory({
        action:'Sécurité',
        section:'Administrateur',
        entity:'Mot de passe',
        detail:adminSecurityMode==='setup'
          ? 'Protection administrateur activée'
          : 'Mot de passe administrateur modifié'
      });

      adminSecurityCloseModal(adminSecurityMode==='setup');
    }catch(error){
      adminSecurityShowError('Impossible d’enregistrer le mot de passe : '+String(error));
    }finally{
      adminSecuritySubmit.disabled=false;
    }
    return;
  }

  try{
    adminSecuritySubmit.disabled=true;
    const config=await adminSecurityReadConfig();

    if(!config){
      adminSecurityOpen('setup');
      return;
    }

    const valid=await adminSecurityVerify(password,config);

    if(!valid){
      adminSecurityFailures++;
      if(adminSecurityFailures>=5){
        adminSecurityFailures=0;
        adminSecurityBlockedUntil=Date.now()+30000;
        adminSecurityShowError('5 tentatives incorrectes. Accès bloqué 30 secondes.');
      }else{
        adminSecurityShowError(`Mot de passe incorrect (${adminSecurityFailures}/5).`);
      }
      return;
    }

    adminSecurityUnlocked=true;
    adminSecurityUnlockedUntil=Date.now()+ADMIN_SECURITY_TIMEOUT;
    adminSecurityFailures=0;
    adminSecurityUpdateUi();

    administratorWriteHistory({
      action:'Connexion Admin',
      section:'Administrateur',
      entity:dashboardUser,
      detail:'Espace administrateur déverrouillé'
    });

    adminSecurityCloseModal(true);
  }catch(error){
    adminSecurityShowError('Erreur de vérification : '+String(error));
  }finally{
    adminSecuritySubmit.disabled=false;
    if(adminSecurityMode==='login') adminSecuritySubmit.textContent='Déverrouiller';
  }
}

async function adminSecurityChangePasswordFlow(){
  if(!administratorIsAdmin()) return;

  if(!adminSecurityIsUnlocked()){
    const allowed=await adminSecurityRequestAccess();
    if(!allowed) return;
  }

  adminSecurityOpen('change');
}

function administratorEscape(value){
  return String(value??'')
    .replace(/&/g,'&amp;')
    .replace(/</g,'&lt;')
    .replace(/>/g,'&gt;')
    .replace(/"/g,'&quot;')
    .replace(/'/g,'&#039;');
}

function administratorInitials(user){
  const text=String(user||'?').trim();
  return text.slice(0,2).toUpperCase();
}

function administratorFormatDateTime(value){
  const date=new Date(value);
  if(Number.isNaN(date.getTime())) return {date:'—',time:'—',full:'—'};

  return {
    date:new Intl.DateTimeFormat('fr-FR',{day:'2-digit',month:'2-digit',year:'numeric'}).format(date),
    time:new Intl.DateTimeFormat('fr-FR',{hour:'2-digit',minute:'2-digit',second:'2-digit'}).format(date),
    full:new Intl.DateTimeFormat('fr-FR',{
      day:'2-digit',month:'2-digit',year:'numeric',
      hour:'2-digit',minute:'2-digit',second:'2-digit'
    }).format(date)
  };
}

function administratorRelativeTime(value){
  const ms=Date.now()-new Date(value).getTime();
  if(!Number.isFinite(ms)) return '—';
  if(ms<15000) return 'À l’instant';
  if(ms<60000) return `Il y a ${Math.max(1,Math.floor(ms/1000))} s`;
  if(ms<3600000) return `Il y a ${Math.floor(ms/60000)} min`;
  return administratorFormatDateTime(value).time;
}

function administratorActionClass(action){
  if(action==='Connexion') return 'login';
  if(action==='Ajout') return 'add';
  if(action==='Suppression') return 'delete';
  if(action==='Modification' || action==='Mise à jour en lot' || action==='Pièce jointe') return 'edit';
  return '';
}

async function administratorReadPresence(){
  if(!sharedConnected || !sharedDirectoryHandle) return [];

  let dir;
  try{
    dir=await administratorGetDirectory(ADMIN_PRESENCE_FOLDER,false);
  }catch(error){
    if(error?.name==='NotFoundError') return [];
    throw error;
  }
  if(!dir) return [];

  const records=[];

  for await(const [name,handle] of dir.entries()){
    if(handle.kind!=='file' || !name.toLowerCase().endsWith('.json')) continue;

    try{
      const file=await handle.getFile();
      const data=JSON.parse(await file.text());
      if(!data?.user || !data?.heartbeatAt) continue;

      const age=Date.now()-new Date(data.heartbeatAt).getTime();
      if(data.online!==false && age<=ADMIN_ONLINE_MAX_AGE){
        records.push(data);
      }
    }catch(error){}
  }

  // Une ligne maximum par utilisateur.
  const byUser=new Map();
  records.forEach(item=>{
    const key=String(item.user).toUpperCase();
    const previous=byUser.get(key);
    if(!previous || new Date(item.heartbeatAt)>new Date(previous.heartbeatAt)){
      byUser.set(key,item);
    }
  });

  return [...byUser.values()].sort((a,b)=>
    String(a.user).localeCompare(String(b.user),'fr',{sensitivity:'base'})
  );
}

async function administratorReadHistory(options={}){
  if(!sharedConnected || !sharedDirectoryHandle) return [];

  let root;
  try{
    root=await administratorGetDirectory(ADMIN_HISTORY_FOLDER,false);
  }catch(error){
    if(error?.name==='NotFoundError') return [];
    throw error;
  }
  if(!root) return [];

  const dayNames=[];
  for await(const [name,handle] of root.entries()){
    if(handle.kind==='directory' && /^\d{4}-\d{2}-\d{2}$/.test(name)){
      dayNames.push(name);
    }
  }

  dayNames.sort().reverse();

  const records=[];

  for(const dayName of (options.all?dayNames:dayNames.slice(0,7))){
    if(!options.all && records.length>=ADMIN_HISTORY_MAX_RECORDS) break;

    let dayDir;
    try{
      dayDir=await root.getDirectoryHandle(dayName);
    }catch(error){continue}

    const files=[];
    for await(const [name,handle] of dayDir.entries()){
      if(handle.kind==='file' && name.toLowerCase().endsWith('.json')){
        files.push({name,handle});
      }
    }

    files.sort((a,b)=>b.name.localeCompare(a.name));

    for(const entry of files){
      if(!options.all && records.length>=ADMIN_HISTORY_MAX_RECORDS) break;

      try{
        const file=await entry.handle.getFile();
        const data=JSON.parse(await file.text());
        if(data?.timestamp && data?.user) records.push(data);
      }catch(error){}
    }
  }

  return records.sort((a,b)=>new Date(b.timestamp)-new Date(a.timestamp));
}

function administratorRenderOnline(){
  const rows=administratorPresenceRecords;
  superadminOnlineCount.textContent=rows.length;
  superadminOnlineBadge.textContent=rows.length;
  superadminOnlineEmpty.hidden=rows.length>0;
  superadminOnlineTable.innerHTML=rows.map(item=>`
    <tr>
      <td>
        <div class="superadmin-user">
          <span class="superadmin-user-avatar">${administratorEscape(administratorInitials(item.user))}</span>
          <span>${administratorEscape(item.user)}</span>
        </div>
      </td>
      <td><span class="superadmin-online">En ligne</span></td>
      <td>${administratorEscape(item.pageLabel||administratorPageLabel(item.page))}</td>
      <td title="${administratorEscape(administratorFormatDateTime(item.heartbeatAt).full)}">${administratorEscape(administratorRelativeTime(item.heartbeatAt))}</td>
    </tr>
  `).join('');
}

function administratorRenderLogins(){
  const logins=administratorHistoryRecords
    .filter(item=>item.action==='Connexion')
    .slice(0,10);

  superadminLoginEmpty.hidden=logins.length>0;
  superadminLoginTable.innerHTML=logins.map(item=>{
    const stamp=administratorFormatDateTime(item.timestamp);
    return `
      <tr>
        <td>
          <div class="superadmin-user">
            <span class="superadmin-user-avatar">${administratorEscape(administratorInitials(item.user))}</span>
            <span>${administratorEscape(item.user)}</span>
          </div>
        </td>
        <td>${administratorEscape(stamp.date)}</td>
        <td>${administratorEscape(stamp.time)}</td>
      </tr>
    `;
  }).join('');
}

function administratorFilteredHistory(){
  const search=String(superadminHistorySearch.value||'').trim().toLocaleLowerCase('fr');
  const user=superadminUserFilter.value;
  const action=superadminActionFilter.value;

  return administratorHistoryRecords.filter(item=>{
    if(user && item.user!==user) return false;
    if(action && item.action!==action) return false;

    if(search){
      const haystack=[
        item.user,item.action,item.section,item.entity,item.detail
      ].join(' ').toLocaleLowerCase('fr');
      if(!haystack.includes(search)) return false;
    }

    return true;
  });
}

function administratorRefreshUserFilter(){
  const current=superadminUserFilter.value;
  const users=[...new Set(administratorHistoryRecords.map(item=>item.user).filter(Boolean))]
    .sort((a,b)=>a.localeCompare(b,'fr',{sensitivity:'base'}));

  superadminUserFilter.innerHTML=
    '<option value="">Tous les utilisateurs</option>'+
    users.map(user=>`<option value="${administratorEscape(user)}">${administratorEscape(user)}</option>`).join('');

  if(users.includes(current)) superadminUserFilter.value=current;
}

function administratorRenderHistory(){
  const rows=administratorFilteredHistory();
  superadminHistoryEmpty.hidden=rows.length>0;
  superadminHistoryCount.textContent=
    `${rows.length} événement${rows.length>1?'s':''} affiché${rows.length>1?'s':''}`;

  superadminHistoryTable.innerHTML=rows.map(item=>{
    const stamp=administratorFormatDateTime(item.timestamp);
    return `
      <tr>
        <td title="${administratorEscape(stamp.full)}">${administratorEscape(stamp.date)} · ${administratorEscape(stamp.time)}</td>
        <td><strong>${administratorEscape(item.user)}</strong></td>
        <td><span class="superadmin-action-badge ${administratorActionClass(item.action)}">${administratorEscape(item.action)}</span></td>
        <td>${administratorEscape(item.section||'—')}</td>
        <td>${administratorEscape(item.entity||'—')}</td>
        <td>${administratorEscape(item.detail||'—')}</td>
      </tr>
    `;
  }).join('');
}

function administratorRenderKpis(){
  const today=administratorLocalDateKey(new Date());

  const todayRows=administratorHistoryRecords.filter(item=>
    administratorLocalDateKey(item.timestamp)===today
  );

  const logins=todayRows.filter(item=>item.action==='Connexion').length;
  const actions=todayRows.filter(item=>item.action!=='Connexion').length;

  superadminLoginToday.textContent=logins;
  superadminActionsToday.textContent=actions;

  const latest=administratorHistoryRecords[0];
  if(latest){
    superadminLastActivity.textContent=administratorFormatDateTime(latest.timestamp).time;
    superadminLastActivityUser.textContent=`${latest.user} · ${latest.action}`;
  }else{
    superadminLastActivity.textContent='—';
    superadminLastActivityUser.textContent='Aucune activité';
  }
}

function administratorRenderAll(){
  administratorRenderOnline();
  administratorRenderLogins();
  administratorRefreshUserFilter();
  administratorRenderHistory();
  administratorRenderKpis();
}

function administratorSetState(mode,text){
  superadminState.classList.remove('ok','error');
  if(mode==='ok') superadminState.classList.add('ok');
  if(mode==='error') superadminState.classList.add('error');
  superadminStateText.textContent=text;
}

async function administratorRefreshDashboard(){
  if(administratorRefreshRunning || !administratorIsAdmin()) return;
  administratorRefreshRunning=true;
  superadminRefreshButton.disabled=true;

  try{
    if(!sharedConnected || !sharedDirectoryHandle){
      administratorPresenceRecords=[];
      administratorHistoryRecords=[];
      administratorRenderAll();
      administratorSetState('error','Dossier partagé non connecté');
      return;
    }

    administratorSetState('','Actualisation…');

    await administratorWritePresence();

    const [presence,history]=await Promise.all([
      administratorReadPresence(),
      administratorReadHistory()
    ]);

    administratorPresenceRecords=presence;
    administratorHistoryRecords=history;
    administratorRenderAll();
    administratorSetState('ok','À jour');
  }catch(error){
    console.warn('Page Administrateur indisponible.',error);
    administratorSetState('error','Erreur de lecture');
  }finally{
    administratorRefreshRunning=false;
    superadminRefreshButton.disabled=false;
  }
}

function administratorHandleViewChange(id){
  administratorLastKnownPage=id || administratorLastKnownPage;

  if(sharedConnected && dashboardUser){
    administratorWritePresence();
  }

  if(id==='administrateur' && administratorIsAdmin()){
    administratorRefreshDashboard();

    if(administratorRefreshTimer) clearInterval(administratorRefreshTimer);
    administratorRefreshTimer=setInterval(()=>{
      if(document.querySelector('.view.active')?.id==='administrateur'){
        administratorRefreshDashboard();
      }
    },10000);
  }else if(administratorRefreshTimer){
    clearInterval(administratorRefreshTimer);
    administratorRefreshTimer=null;
  }
}

function administratorCsvEscape(value){
  const text=String(value??'');
  if(/[;"\n\r]/.test(text)){
    return '"'+text.replace(/"/g,'""')+'"';
  }
  return text;
}

function administratorExportCsv(){
  const rows=administratorFilteredHistory();
  const header=['Date / heure','Utilisateur','Action','Section','Élément','Détail'];
  const lines=[header.map(administratorCsvEscape).join(';')];

  rows.forEach(item=>{
    const stamp=administratorFormatDateTime(item.timestamp).full;
    lines.push([
      stamp,item.user,item.action,item.section,item.entity,item.detail
    ].map(administratorCsvEscape).join(';'));
  });

  const blob=new Blob(['\ufeff'+lines.join('\r\n')],{type:'text/csv;charset=utf-8'});
  const url=URL.createObjectURL(blob);
  const link=document.createElement('a');
  link.href=url;
  link.download='historique_dashboard_'+administratorLocalDateKey(new Date())+'.csv';
  document.body.appendChild(link);
  link.click();
  link.remove();
  setTimeout(()=>URL.revokeObjectURL(url),1000);
}

function dashboardModificationHtml(item){
  if(!item?._modifiedAt && !item?._modifiedBy){
    return '<span class="last-modification">—</span>';
  }
  return `<span class="last-modification"><strong>${dashboardEsc(item._modifiedBy||'—')}</strong><br>${dashboardEsc(dashboardDateTime(item._modifiedAt))}</span>`;
}

async function dashboardGetBackupRoot(create=false){
  if(!sharedConnected||!sharedDirectoryHandle) return null;
  return await sharedDirectoryHandle.getDirectoryHandle(DASHBOARD_BACKUP_FOLDER,{create});
}

function dashboardBackupTimestampName(prefix='manuel'){
  const d=new Date();
  const pad=n=>String(n).padStart(2,'0');
  return `${prefix}_${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}_${pad(d.getHours())}-${pad(d.getMinutes())}-${pad(d.getSeconds())}`;
}

async function dashboardCreateBackup(name,reason='Sauvegarde manuelle'){
  if(!sharedConnected||!sharedDirectoryHandle) throw new Error('Dossier partagé non connecté.');
  if(dashboardBackupInProgress) return false;

  dashboardBackupInProgress=true;
  try{
    const root=await dashboardGetBackupRoot(true);
    const dir=await root.getDirectoryHandle(name,{create:true});
    let files=0;

    for(const descriptor of SHARED_DATASETS){
      const doc=await sharedReadDocument(descriptor);
      if(!doc) continue;
      const clean={...doc};
      delete clean._lastModified;
      await dashboardWriteRawJson(dir,descriptor.file,clean);
      files++;
    }

    const security=await adminSecurityReadConfig().catch(()=>null);
    if(security){
      await dashboardWriteRawJson(dir,ADMIN_SECURITY_FILE,security);
    }

    await dashboardWriteRawJson(dir,'manifest.json',{
      version:1,
      createdAt:new Date().toISOString(),
      createdBy:dashboardUser||'inconnu',
      reason,
      files
    });

    administratorWriteHistory({
      action:'Sauvegarde',
      section:'Administrateur',
      entity:name,
      detail:`${files} fichiers de données sauvegardés`
    });

    return true;
  }finally{
    dashboardBackupInProgress=false;
  }
}

async function dashboardEnsureDailyBackup(){
  if(!sharedConnected||!sharedDirectoryHandle) return;
  const day=administratorLocalDateKey(new Date());
  if(dashboardBackupReadyForDay===day) return;

  const root=await dashboardGetBackupRoot(true);
  const dir=await root.getDirectoryHandle(day,{create:true});
  const exists=await dashboardFileExists(dir,'manifest.json');
  if(!exists){
    await dashboardCreateBackup(day,'Sauvegarde automatique quotidienne');
  }
  dashboardBackupReadyForDay=day;
  dashboardRefreshBackupList();
}

async function dashboardListBackups(){
  if(!sharedConnected||!sharedDirectoryHandle) return [];
  let root;
  try{
    root=await dashboardGetBackupRoot(false);
  }catch(error){
    if(error?.name==='NotFoundError') return [];
    throw error;
  }
  const result=[];
  for await(const [name,handle] of root.entries()){
    if(handle.kind!=='directory') continue;
    try{
      const manifest=await dashboardReadRawJson(handle,'manifest.json');
      result.push({name,manifest});
    }catch(error){}
  }
  return result.sort((a,b)=>String(b.manifest?.createdAt||b.name).localeCompare(String(a.manifest?.createdAt||a.name)));
}

async function dashboardRefreshBackupList(){
  const list=document.getElementById('backupList');
  const count=document.getElementById('backupCount');
  if(!list||!count) return;

  if(!sharedConnected){
    count.textContent='0';
    list.innerHTML='<div class="vehicle-none">Dossier partagé non connecté.</div>';
    return;
  }

  try{
    const backups=await dashboardListBackups();
    count.textContent=backups.length;
    list.innerHTML=backups.length
      ? backups.slice(0,14).map(b=>`
          <div class="backup-row">
            <div>
              <div class="backup-name">${dashboardEsc(b.name)}</div>
              <div class="backup-meta">${dashboardEsc(dashboardDateTime(b.manifest?.createdAt))} · ${dashboardEsc(b.manifest?.createdBy||'—')} · ${dashboardEsc(b.manifest?.reason||'Sauvegarde')} · ${Number(b.manifest?.files)||0} fichiers de données</div>
            </div>
            <button type="button" data-restore-backup="${dashboardEsc(b.name)}">Restaurer</button>
          </div>
        `).join('')
      : '<div class="vehicle-none">Aucune sauvegarde détectée.</div>';
  }catch(error){
    list.innerHTML=`<div class="vehicle-none">Impossible de lire les sauvegardes : ${dashboardEsc(error)}</div>`;
  }
}

async function dashboardRestoreBackup(name){
  if(!administratorIsAdmin()) return;
  if(typeof adminSecurityIsUnlocked==='function' && !adminSecurityIsUnlocked()){
    const allowed=await adminSecurityRequestAccess();
    if(!allowed) return;
  }
  if(!confirm(`Restaurer la sauvegarde "${name}" ?\n\nLes données actuelles seront remplacées. Une sauvegarde de sécurité sera créée avant la restauration.`)) return;

  try{
    dashboardToast('Restauration','Création d’une sauvegarde de sécurité…','warn',3500);
    const protectedBackup=await dashboardCreateBackup(dashboardBackupTimestampName('avant-restauration'),'Sauvegarde avant restauration');
    if(!protectedBackup) throw new Error('Sauvegarde de sécurité occupée. Réessayez après sa fin.');

    const root=await dashboardGetBackupRoot(false);
    const dir=await root.getDirectoryHandle(name);

    for(const descriptor of SHARED_DATASETS){
      try{
        const doc=await dashboardReadRawJson(dir,descriptor.file);
        const handle=await sharedDirectoryHandle.getFileHandle(descriptor.file,{create:true});
        const writable=await handle.createWritable();
        await writable.write(JSON.stringify(doc,null,2));
        await writable.close();
      }catch(error){
        if(error?.name!=='NotFoundError') throw error;
      }
    }

    administratorWriteHistory({
      action:'Restauration',
      section:'Administrateur',
      entity:name,
      detail:'Sauvegarde restaurée'
    });

    await sharedSyncFromDisk(true);
    dashboardRefreshNotifications();
    dashboardRenderQuality();
    dashboardToast('Restauration terminée',`Sauvegarde ${name} restaurée.`,'success',3500);
  }catch(error){
    dashboardToast('Échec de restauration',String(error),'error',5000);
  }
}

function dashboardLoadedHtmlFilename(){
  try{
    const path=decodeURIComponent(location.pathname||'');
    const name=path.split('/').filter(Boolean).pop()||DASHBOARD_FIXED_HTML_NAME;
    return name.toLowerCase().endsWith('.html') ? name : DASHBOARD_FIXED_HTML_NAME;
  }catch(error){
    return DASHBOARD_FIXED_HTML_NAME;
  }
}

function dashboardCurrentHtmlFilename(){
  // Toutes les nouvelles versions utilisent volontairement le même nom.
  return DASHBOARD_FIXED_HTML_NAME;
}

function dashboardFixedHtmlUrl(){
  try{
    const url=new URL(location.href);
    const parts=url.pathname.split('/');
    parts[parts.length-1]=encodeURIComponent(DASHBOARD_FIXED_HTML_NAME);
    url.pathname=parts.join('/');
    url.search='';
    url.hash='';
    return url.href;
  }catch(error){
    return DASHBOARD_FIXED_HTML_NAME;
  }
}

function dashboardOpenRootDb(){
  return new Promise((resolve,reject)=>{
    const req=indexedDB.open(DASHBOARD_ROOT_DB,1);
    req.onupgradeneeded=()=>{
      const db=req.result;
      if(!db.objectStoreNames.contains(DASHBOARD_ROOT_STORE)){
        db.createObjectStore(DASHBOARD_ROOT_STORE);
      }
    };
    req.onsuccess=()=>resolve(req.result);
    req.onerror=()=>reject(req.error);
  });
}

async function dashboardSaveRootHandle(handle){
  try{
    const db=await dashboardOpenRootDb();
    await new Promise((resolve,reject)=>{
      const tx=db.transaction(DASHBOARD_ROOT_STORE,'readwrite');
      tx.objectStore(DASHBOARD_ROOT_STORE).put(handle,DASHBOARD_ROOT_HANDLE_KEY);
      tx.oncomplete=resolve;
      tx.onerror=()=>reject(tx.error);
    });
    db.close();
  }catch(error){
    console.warn('Impossible de mémoriser le dossier principal.',error);
  }
}

async function dashboardLoadRootHandle(){
  try{
    const db=await dashboardOpenRootDb();
    const handle=await new Promise((resolve,reject)=>{
      const tx=db.transaction(DASHBOARD_ROOT_STORE,'readonly');
      const req=tx.objectStore(DASHBOARD_ROOT_STORE).get(DASHBOARD_ROOT_HANDLE_KEY);
      req.onsuccess=()=>resolve(req.result||null);
      req.onerror=()=>reject(req.error);
    });
    db.close();
    return handle;
  }catch(error){
    console.warn('Impossible de relire le dossier principal.',error);
    return null;
  }
}

async function dashboardRootHasPermission(handle,request=false){
  if(!handle) return false;
  try{
    const options={mode:'readwrite'};
    if(await handle.queryPermission(options)==='granted') return true;
    if(request && await handle.requestPermission(options)==='granted') return true;
  }catch(error){
    console.warn(error);
  }
  return false;
}

async function dashboardCountHtmlBackups(){
  if(!dashboardRootHandle || !dashboardRootAuthorized) return 0;
  let count=0;
  for(const folderName of ['Sauvegardes_versions',DASHBOARD_HTML_BACKUP_FOLDER]){
    try{
      const dir=await dashboardRootHandle.getDirectoryHandle(folderName);
      for await(const [,handle] of dir.entries()){
        if(handle.kind==='directory' || handle.kind==='file') count++;
      }
    }catch(error){
      if(error?.name!=='NotFoundError') throw error;
    }
  }
  return count;
}

async function dashboardRefreshUpdateUi(){
  const filename=dashboardCurrentHtmlFilename();
  dashboardUpdateCurrentFileChip.textContent='Fichier : '+filename;

  if(dashboardRootAuthorized){
    dashboardUpdateRootChip.textContent='Dossier principal autorisé';
    dashboardUpdateRootChip.className='dashboard-update-chip ok';
    dashboardAuthorizeRootButton.textContent='Changer de dossier';
  }else if(dashboardRootHandle){
    dashboardUpdateRootChip.textContent='Autorisation à renouveler';
    dashboardUpdateRootChip.className='dashboard-update-chip warn';
    dashboardAuthorizeRootButton.textContent='Autoriser le dossier';
  }else{
    dashboardUpdateRootChip.textContent='Dossier principal non autorisé';
    dashboardUpdateRootChip.className='dashboard-update-chip warn';
    dashboardAuthorizeRootButton.textContent='Autoriser le dossier';
  }

  dashboardUpdateButton.disabled=false;
  dashboardRestorePreviousButton.disabled=true;

  try{
    dashboardUpdateBackupCount.textContent=await dashboardCountHtmlBackups();
  }catch(error){
    dashboardUpdateBackupCount.textContent='—';
  }
}

async function dashboardAuthorizeRoot(forcePicker=false){
  if(typeof window.showDirectoryPicker!=='function'){
    dashboardToast('Impossible','Cette version d’Edge ne permet pas l’accès au dossier.','error',4000);
    return false;
  }

  try{
    if(dashboardRootHandle && !forcePicker){
      const allowed=await dashboardRootHasPermission(dashboardRootHandle,true);
      if(allowed){
        dashboardRootAuthorized=true;
        await dashboardRefreshUpdateUi();
        return true;
      }
    }

    const handle=await window.showDirectoryPicker({mode:'readwrite'});
    const allowed=await dashboardRootHasPermission(handle,true);
    if(!allowed) return false;

    // On vérifie que c'est bien le dossier principal du dashboard.
    // Pendant la migration vers le nom fixe Dashboard.html, l'ancienne page
    // peut encore être ouverte sous son ancien nom : les deux cas sont acceptés.
    const candidates=[DASHBOARD_FIXED_HTML_NAME,dashboardLoadedHtmlFilename()]
      .filter((name,index,array)=>name && array.indexOf(name)===index);
    let rootLooksValid=false;

    for(const name of candidates){
      try{
        await handle.getFileHandle(name);
        rootLooksValid=true;
        break;
      }catch(error){
        if(error?.name!=='NotFoundError') throw error;
      }
    }

    if(!rootLooksValid){
      try{
        await handle.getDirectoryHandle('Data');
        rootLooksValid=true;
      }catch(error){
        if(error?.name!=='NotFoundError') throw error;
      }
    }

    if(!rootLooksValid){
      dashboardToast(
        'Mauvais dossier',
        'Sélectionne le dossier principal qui contient Dashboard.html ou le dossier Data.',
        'warn',
        5000
      );
      return false;
    }

    dashboardRootHandle=handle;
    dashboardRootAuthorized=true;
    await dashboardSaveRootHandle(handle);
    await dashboardRefreshUpdateUi();

    dashboardToast(
      'Dossier autorisé',
      'Les prochaines mises à jour pourront remplacer automatiquement le HTML.',
      'success'
    );
    return true;
  }catch(error){
    if(error?.name!=='AbortError'){
      dashboardToast('Autorisation impossible',String(error),'error',4500);
    }
    return false;
  }
}

function dashboardBackupHtmlName(originalName){
  const dot=originalName.toLowerCase().lastIndexOf('.html');
  const base=dot>=0?originalName.slice(0,dot):originalName;
  const d=new Date();
  const pad=n=>String(n).padStart(2,'0');
  const stamp=
    `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}_`+
    `${pad(d.getHours())}-${pad(d.getMinutes())}-${pad(d.getSeconds())}`;
  return `${base}_${stamp}.html`;
}

async function dashboardBackupCurrentHtml(){
  if(!dashboardRootHandle || !dashboardRootAuthorized){
    throw new Error('Dossier principal non autorisé.');
  }

  const candidates=[DASHBOARD_FIXED_HTML_NAME,dashboardLoadedHtmlFilename()]
    .filter((name,index,array)=>name && array.indexOf(name)===index);

  let sourceName='';
  let currentHandle=null;
  for(const name of candidates){
    try{
      currentHandle=await dashboardRootHandle.getFileHandle(name);
      sourceName=name;
      break;
    }catch(error){
      if(error?.name!=='NotFoundError') throw error;
    }
  }

  // Première migration : si aucun ancien HTML n'existe plus dans le dossier,
  // on autorise quand même la création du nouveau Dashboard.html.
  if(!currentHandle) return null;

  const bytes=await dashboardReadFileBytes(currentHandle);
  const backupDir=await dashboardRootHandle.getDirectoryHandle(
    DASHBOARD_HTML_BACKUP_FOLDER,
    {create:true}
  );

  const backupName=dashboardBackupHtmlName(sourceName);
  const backupHandle=await backupDir.getFileHandle(backupName,{create:true});
  const writable=await backupHandle.createWritable();
  await writable.write(bytes);
  await writable.close();

  return backupName;
}

async function dashboardWriteUpdateMeta(data){
  if(!dashboardRootHandle || !dashboardRootAuthorized) return;

  try{
    const handle=await dashboardRootHandle.getFileHandle(
      DASHBOARD_UPDATE_META_FILE,
      {create:true}
    );
    const writable=await handle.createWritable();
    await writable.write(JSON.stringify(data,null,2));
    await writable.close();
  }catch(error){
    console.warn('Impossible d’écrire dashboard_update.json',error);
  }
}

async function dashboardReadUpdateMeta(){
  if(!dashboardRootHandle || !dashboardRootAuthorized) return null;
  try{
    const handle=await dashboardRootHandle.getFileHandle(DASHBOARD_UPDATE_META_FILE);
    const file=await handle.getFile();
    return JSON.parse(await file.text());
  }catch(error){
    if(error?.name==='NotFoundError') return null;
    throw error;
  }
}

let dashboardPendingUpdate=null;

function dashboardIsUpdatePath(path){
  if(path==='Dashboard.html') return true;
  if(!path.startsWith('assets/')) return false;
  if(path.split('/').some(part=>!part || part==='.' || part==='..')) return false;
  return /\.(?:js|js\.txt|css|css\.txt|png|jpe?g|svg|webp|ico|woff2?)$/i.test(path);
}

async function dashboardCollectUpdateFiles(directoryHandle,prefix='',files=[]){
  for await(const [name,handle] of directoryHandle.entries()){
    const path=prefix ? `${prefix}/${name}` : name;
    if(handle.kind==='directory'){
      // La mise à jour ne parcourt que les ressources de l'application, jamais Data/ ni les sauvegardes.
      if(path==='assets' || path.startsWith('assets/')){
        await dashboardCollectUpdateFiles(handle,path,files);
      }
      continue;
    }
    if(dashboardIsUpdatePath(path)) files.push({path,handle});
    if(files.length>3000) throw new Error('Le dossier contient trop de fichiers pour une mise à jour.');
  }
  return files;
}

async function dashboardBytesEqual(a,b){
  if(a.byteLength!==b.byteLength) return false;
  const left=new Uint8Array(a),right=new Uint8Array(b);
  for(let i=0;i<left.length;i++) if(left[i]!==right[i]) return false;
  return true;
}

async function dashboardCompareUpdateFolder(sourceHandle){
  const sourceFiles=await dashboardCollectUpdateFiles(sourceHandle);
  if(!sourceFiles.some(file=>file.path==='Dashboard.html')){
    throw new Error('Ce dossier ne contient pas Dashboard.html. Sélectionne le dossier extrait qui contient aussi assets.');
  }
  if(!sourceFiles.some(file=>file.path.startsWith('assets/js/')) || !sourceFiles.some(file=>file.path.startsWith('assets/css/'))){
    throw new Error('Le dossier de mise à jour est incomplet : les dossiers assets/js et assets/css sont nécessaires.');
  }
  const htmlEntry=sourceFiles.find(file=>file.path==='Dashboard.html');
  const htmlPreview=(await (await htmlEntry.handle.getFile()).slice(0,300000).text()).toLowerCase();
  const signatures=['gestion de parc','data-view="parc"','sharedstoragebutton'];
  if(signatures.filter(value=>htmlPreview.includes(value)).length<2){
    throw new Error('Le fichier Dashboard.html ne semble pas être une version du dashboard H.ESSERS.');
  }

  const changes=[];
  let total=0;
  for(const item of sourceFiles){
    const sourceFile=await item.handle.getFile();
    const bytes=await sourceFile.arrayBuffer();
    total+=bytes.byteLength;
    if(total>250*1024*1024) throw new Error('La mise à jour dépasse la taille autorisée de 250 Mo.');

    let existed=false,previousBytes=null;
    try{
      const currentHandle=await dashboardGetFileAtPath(dashboardRootHandle,item.path,false);
      const currentFile=await currentHandle.getFile();
      existed=true;
      if(await dashboardBytesEqual(bytes,await currentFile.arrayBuffer())) continue;
      previousBytes=await currentFile.arrayBuffer();
    }catch(error){
      if(error?.name!=='NotFoundError') throw error;
    }
    changes.push({path:item.path,bytes,previousBytes,existed});
  }
  return {sourceName:sourceHandle.name||'Dossier sélectionné',changes,totalBytes:total};
}

async function dashboardGetFileAtPath(rootHandle,path,create=false){
  const parts=path.split('/');
  let directory=rootHandle;
  for(const part of parts.slice(0,-1)){
    directory=await directory.getDirectoryHandle(part,{create});
  }
  return await directory.getFileHandle(parts.at(-1),{create});
}

async function dashboardWriteBytesAtPath(rootHandle,path,bytes){
  const handle=await dashboardGetFileAtPath(rootHandle,path,true);
  const writable=await handle.createWritable();
  try{ await writable.write(bytes); }
  finally{ await writable.close(); }
}

function dashboardShowUpdatePlan(plan){
  const status=document.getElementById('dashboardUpdateStatus');
  const review=document.getElementById('dashboardUpdateReview');
  const list=document.getElementById('dashboardUpdateChanges');
  list.replaceChildren();
  review.hidden=false;

  if(!plan.changes.length){
    status.textContent='Cette version ne contient aucun changement par rapport au dashboard installé.';
    dashboardUpdateSelectFile.textContent='Aucun changement';
    dashboardUpdateSelectFile.disabled=true;
    return;
  }

  const shown=plan.changes.slice(0,40);
  for(const item of shown){
    const li=document.createElement('li');
    li.textContent=`${item.existed?'Modifié':'Ajouté'} · ${item.path}`;
    list.appendChild(li);
  }
  if(plan.changes.length>shown.length){
    const li=document.createElement('li');
    li.textContent=`… et ${plan.changes.length-shown.length} autre(s) fichier(s)`;
    list.appendChild(li);
  }
  status.textContent=`${plan.changes.length} fichier(s) à mettre à jour depuis « ${plan.sourceName} ». Data et les autres dossiers ne seront pas touchés.`;
  dashboardUpdateSelectFile.textContent=`Appliquer ${plan.changes.length} changement(s)`;
  dashboardUpdateSelectFile.disabled=false;
}

async function dashboardPickUpdateFolder(){
  if(!dashboardRootAuthorized){
    dashboardToast('Dossier à autoriser','Autorise d’abord le dossier du dashboard.','warn',4500);
    return;
  }
  try{
    dashboardUpdateSelectFile.disabled=true;
    dashboardUpdateSelectFile.textContent='Choix du dossier…';
    const sourceHandle=await window.showDirectoryPicker({mode:'read'});
    if(dashboardRootHandle.isSameEntry && await sourceHandle.isSameEntry(dashboardRootHandle)){
      throw new Error('Sélectionne le dossier de la nouvelle version, pas le dashboard déjà installé.');
    }
    dashboardPendingUpdate=await dashboardCompareUpdateFolder(sourceHandle);
    dashboardShowUpdatePlan(dashboardPendingUpdate);
  }catch(error){
    if(error?.name!=='AbortError') dashboardToast('Comparaison impossible',error.message||String(error),'error',6000);
    dashboardPendingUpdate=null;
    dashboardUpdateSelectFile.textContent='Choisir le dossier de la nouvelle version';
    dashboardUpdateSelectFile.disabled=false;
  }
}

async function dashboardApplyPendingUpdate(){
  const plan=dashboardPendingUpdate;
  if(!plan || !plan.changes.length) return;
  if(!confirm(`Appliquer ${plan.changes.length} changement(s) ?\n\nLes fichiers modifiés seront sauvegardés avant remplacement. Data ne sera pas touché.`)) return;

  const backupName=`MAJ_${new Date().toISOString().replace(/[:.]/g,'-')}`;
  const backupRoot=await dashboardRootHandle.getDirectoryHandle('Sauvegardes_versions',{create:true});
  const backupDir=await backupRoot.getDirectoryHandle(backupName,{create:true});
  const applied=[];
  try{
    // Sauvegarder tous les fichiers existants avant d'en remplacer un seul.
    for(const item of plan.changes){
      if(item.existed) await dashboardWriteBytesAtPath(backupDir,item.path,item.previousBytes);
    }
    for(const item of plan.changes){
      await dashboardWriteBytesAtPath(dashboardRootHandle,item.path,item.bytes);
      applied.push(item);
    }

    const now=Date.now();
    const meta={
      version:2,
      updatedAt:new Date(now).toISOString(),
      updatedAtMs:now,
      updatedBy:dashboardUser||'inconnu',
      sourceFolder:plan.sourceName,
      changedFiles:plan.changes.map(item=>item.path),
      backupFolder:backupName
    };
    await dashboardWriteUpdateMeta(meta);
    dashboardUpdateLastSeenStamp=now;
    administratorWriteHistory({
      action:'Mise à jour',section:'Administrateur',entity:'Dashboard',
      detail:`${plan.changes.length} fichier(s) appliqué(s) depuis ${plan.sourceName} · sauvegarde ${backupName}`
    });

    dashboardPendingUpdate=null;
    dashboardUpdateModal.hidden=true;
    if(document.querySelectorAll('.modal-overlay:not([hidden])').length===0) document.body.classList.remove('modal-open');
    await dashboardRefreshUpdateUi();
    dashboardVersionBanner.hidden=false;
    dashboardToast('Mise à jour terminée',`${plan.changes.length} fichier(s) installé(s). Recharge le dashboard pour utiliser la nouvelle version.`,'success',6500);
  }catch(error){
    let rollbackFailed=false;
    for(const item of applied.reverse()){
      try{
        if(item.existed) await dashboardWriteBytesAtPath(dashboardRootHandle,item.path,item.previousBytes);
        else{
          const parts=item.path.split('/');
          let directory=dashboardRootHandle;
          for(const part of parts.slice(0,-1)) directory=await directory.getDirectoryHandle(part);
          await directory.removeEntry(parts.at(-1));
        }
      }catch(rollbackError){rollbackFailed=true;}
    }
    const suffix=rollbackFailed?` La restauration automatique a échoué ; la sauvegarde est dans Sauvegardes_versions\\${backupName}.`:` Les fichiers précédents ont été restaurés.`;
    dashboardToast('Installation interrompue',`${error.message||error}${suffix}`,'error',8000);
  }
}

async function dashboardPickUpdateFile(){
  if(dashboardPendingUpdate){
    await dashboardApplyPendingUpdate();
    return;
  }
  await dashboardPickUpdateFolder();
}

async function dashboardListHtmlBackups(){
  if(!dashboardRootHandle || !dashboardRootAuthorized) return [];
  try{
    const dir=await dashboardRootHandle.getDirectoryHandle(DASHBOARD_HTML_BACKUP_FOLDER);
    const files=[];
    for await(const [name,handle] of dir.entries()){
      if(handle.kind!=='file' || !name.toLowerCase().endsWith('.html')) continue;
      const file=await handle.getFile();
      files.push({name,handle,lastModified:file.lastModified,size:file.size});
    }
    return files.sort((a,b)=>b.lastModified-a.lastModified);
  }catch(error){
    if(error?.name==='NotFoundError') return [];
    throw error;
  }
}

async function dashboardRestorePreviousHtml(){
  dashboardToast('Version multifichiers','Utilisez version.zip dans Sauvegardes_versions avec l’assistant Windows.','info',6000);
  return;
  if(!dashboardRootAuthorized){
    const allowed=await dashboardAuthorizeRoot(false);
    if(!allowed) return;
  }

  if(typeof adminSecurityIsUnlocked==='function' && !adminSecurityIsUnlocked()){
    const allowed=await adminSecurityRequestAccess();
    if(!allowed) return;
  }

  try{
    const backups=await dashboardListHtmlBackups();
    if(!backups.length){
      dashboardToast('Aucune sauvegarde','Aucune ancienne version HTML disponible.','warn');
      return;
    }

    const latest=backups[0];
    if(!confirm(`Restaurer la dernière version sauvegardée ?\n\n${latest.name}`)) return;

    // Sauvegarder d'abord la version actuelle pour permettre un retour en arrière.
    const safetyBackup=await dashboardBackupCurrentHtml();

    const bytes=await dashboardReadFileBytes(latest.handle);
    const currentName=dashboardCurrentHtmlFilename();
    const currentHandle=await dashboardRootHandle.getFileHandle(currentName,{create:true});
    const writable=await currentHandle.createWritable();
    await writable.write(bytes);
    await writable.close();

    const meta={
      version:1,
      updatedAt:new Date().toISOString(),
      updatedAtMs:Date.now(),
      updatedBy:dashboardUser||'inconnu',
      currentFile:currentName,
      sourceFile:latest.name,
      backupFile:safetyBackup,
      restored:true
    };
    await dashboardWriteUpdateMeta(meta);
    dashboardUpdateLastSeenStamp=meta.updatedAtMs;

    administratorWriteHistory({
      action:'Restauration',
      section:'Administrateur',
      entity:currentName,
      detail:`Version HTML restaurée depuis ${latest.name}`
    });

    await dashboardRefreshUpdateUi();

    dashboardToast(
      'Version restaurée',
      'Recharge la page pour utiliser la version restaurée.',
      'success',
      4000
    );
    dashboardVersionBanner.hidden=false;
  }catch(error){
    dashboardToast('Restauration impossible',String(error),'error',5000);
  }
}

function dashboardOpenUpdateModal(){
  dashboardPendingUpdate=null;
  const status=document.getElementById('dashboardUpdateStatus');
  const review=document.getElementById('dashboardUpdateReview');
  if(status){status.hidden=true;status.textContent='';}
  if(review) review.hidden=true;
  dashboardUpdateSelectFile.disabled=false;
  dashboardUpdateSelectFile.textContent='Choisir le dossier de la nouvelle version';
  dashboardUpdateModal.hidden=false;
  document.body.classList.add('modal-open');
}

function dashboardCloseUpdateModal(){
  dashboardUpdateModal.hidden=true;
  if(document.querySelectorAll('.modal-overlay:not([hidden])').length===0){
    document.body.classList.remove('modal-open');
  }
}

async function dashboardCheckForNewHtmlVersion(){
  if(!dashboardRootAuthorized) return;

  try{
    const meta=await dashboardReadUpdateMeta();
    if(!meta?.updatedAtMs) return;

    const stamp=Number(meta.updatedAtMs)||0;
    if(!dashboardUpdateLastSeenStamp){
      dashboardUpdateLastSeenStamp=stamp;
      return;
    }

    // Si une autre session a publié une version plus récente depuis le chargement de cette page.
    if(
      stamp>dashboardUpdateLastSeenStamp &&
      stamp>DASHBOARD_LOADED_AT+1500
    ){
      dashboardUpdateLastSeenStamp=stamp;
      dashboardVersionBanner.hidden=false;
    }
  }catch(error){
    console.warn('Vérification version dashboard impossible.',error);
  }
}
