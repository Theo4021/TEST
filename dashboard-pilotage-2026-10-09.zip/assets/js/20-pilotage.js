/* Pilotage 2026.10.09 — read views use the current in-memory datasets. */
(()=>{
'use strict';
const $=id=>document.getElementById(id), esc=dashboardEsc;
const norm=v=>String(v??'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]/g,'');
const has=v=>v!==null&&v!==undefined&&String(v).trim()!=='';
const same=(a,b)=>!!norm(a)&&norm(a)===norm(b);
const today=()=>{const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;};
const num=v=>fuelNumber(v)||0;
const money=v=>v.toLocaleString('fr-FR',{style:'currency',currency:'EUR'});
const btn=(text,fn)=>{const b=document.createElement('button');b.type='button';b.className='tool-btn';b.textContent=text;b.onclick=fn;return b;};
function csv(name,rows){
 const cell=v=>{let s=String(v??'');if(/^[\s]*[=+@-]/.test(s))s="'"+s;return '"'+s.replace(/"/g,'""')+'"';};
 const url=URL.createObjectURL(new Blob(['\uFEFF'+rows.map(r=>r.map(cell).join(';')).join('\r\n')],{type:'text/csv;charset=utf-8'}));
 const a=document.createElement('a');a.href=url;a.download=name+'_'+today()+'.csv';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
}
const datasets=()=>[
 {name:'Parc',rows:parkData,fields:{registration:'Immatriculation',type:'Type',parkNumber:'N° parc'}},
 {name:'Affectations',rows:affectations,fields:{name:'Chauffeur',tractor:'Tracteur',semi:'Semi',phone:'Téléphone'}},
 {name:'Chauffeurs',rows:driverProfiles,fields:{lastName:'Nom',firstName:'Prénom',phone:'Téléphone',status:'Statut'}},
 {name:'Vidanges',rows:vidangeData,fields:{registration:'Immatriculation',currentKm:'Km actuel',lastMajorKm:'Dernière grosse vidange (km)',lastGarageKm:'Dernier garage (km)'}},
 {name:'Échéances',rows:technicalDeadlines,fields:{registration:'Immatriculation',label:'Contrôle',lastControl:'Dernier contrôle',nextControl:'Prochain contrôle'}},
 {name:'Sinistres',rows:claimData,fields:{number:'Dossier',date:'Date',vehicle:'Véhicule',driver:'Chauffeur',status:'Statut'}},
 {name:'Amendes',rows:adminFines,fields:{reference:'Référence',date:'Date',vehicle:'Véhicule',driver:'Chauffeur',amount:'Montant (€)',status:'Statut'}},
 {name:'Cartes Rungis',rows:adminRungis,fields:{cardNumber:'Carte',vehicle:'Véhicule'}},
 {name:'Carburant',rows:fuelEntries,fields:{supplier:'Fournisseur',orderDate:'Commande',deliveryDate:'Livraison',dieselQty:'Gasoil (L)',gnrQty:'GNR (L)',adblueQty:'AdBlue (L)',dieselPrice:'Gasoil (€/1 000 L)',gnrPrice:'GNR (€/1 000 L)',adbluePrice:'AdBlue (€/1 000 L)'}}
];
function table(headers,rows){return '<div class="pilot-table"><table><thead><tr>'+headers.map(h=>`<th>${esc(h)}</th>`).join('')+'</tr></thead><tbody>'+(rows.length?rows.map(r=>'<tr>'+r.map(v=>`<td>${esc(has(v)?v:'—')}</td>`).join('')+'</tr>').join(''):`<tr><td colspan="${headers.length}">Aucun résultat.</td></tr>` )+'</tbody></table></div>';}
function dialog(id,title){const d=document.createElement('dialog');d.id=id;d.className='pilot-dialog';const h=document.createElement('header');const t=document.createElement('h2');t.textContent=title;h.append(t,btn('Fermer',()=>d.close()));d.append(h);document.body.append(d);return d;}

// Quality: retain the existing checks and add missing relationships and fields.
const baseIssues=dashboardDataIssues;
dashboardDataIssues=function(){
 const result=baseIssues.apply(this,arguments);const add=(section,text,level='warn',extra={})=>result.push({section,text,level,...extra});
 affectations.forEach(a=>{if(!driverProfiles.some(d=>same(driverDisplayName(d),a.name)))add('Affectations',`${a.name||'Sans nom'} : chauffeur absent des fiches.`);});
 parkData.filter(v=>v.type==='Tracteur').forEach(v=>{if(!vidangeData.some(x=>same(x.registration,v.registration)))add('Suivi technique',`${formatRegistration(v.registration)} : suivi vidange manquant.`);});
 technicalDeadlines.forEach(v=>{if(!v.nextControl)add('Suivi technique',`${formatRegistration(v.registration)} : ${v.label||v.category}, échéance manquante.`);if(v.nextControl&&v.lastControl&&v.nextControl<v.lastControl)add('Suivi technique',`${formatRegistration(v.registration)} : ${v.label||v.category}, échéance avant le dernier contrôle.`,'high');});
 fuelEntries.forEach(f=>{const prefix=`${f.supplier||'Sans fournisseur'} (${f.deliveryDate||f.orderDate||'sans date'})`;const issue=text=>add('Carburant',prefix+' : '+text,'warn',{supplier:f.supplier});
  if(!f.supplier)issue('fournisseur manquant.');if(!f.deliveryDate&&!f.orderDate)issue('date manquante.');
  if(f.deliveryDate&&f.orderDate&&f.deliveryDate<f.orderDate)issue('livraison antérieure à la commande.');
  if(!['diesel','gnr','adblue'].some(k=>num(f[k+'Qty'])>0))issue('aucune quantité positive.');
  ['diesel','gnr','adblue'].forEach((k,i)=>{const label=['Gasoil','GNR','AdBlue'][i];if(num(f[k+'Qty'])>0&&(!has(f[k+'Price'])||fuelNumber(f[k+'Price'])===null))issue(label+' : prix manquant ou invalide.');if(num(f[k+'Qty'])<0||num(f[k+'Price'])<0)issue(label+' : valeur négative.');});
 });
 claimData.filter(c=>norm(c.status)!=='clos').forEach(c=>{if(!c.number||!c.vehicle||!c.driver)add('Sinistres',`${c.vehicle||'Sans véhicule'} : dossier ${c.number||'sans numéro'}, ${[!c.number?'numéro manquant':'',!c.driver?'chauffeur manquant':'',!c.vehicle?'véhicule manquant':''].filter(Boolean).join(', ')}.`);});
 adminFines.filter(f=>norm(f.status)!=='clos').forEach(f=>{if(!f.vehicle||!f.driver||!f.reference)add('Amendes',`${f.vehicle||'Sans véhicule'} : amende ${f.reference||'sans référence'}, fiche à compléter.`);});
 adminRungis.forEach(r=>{if(!r.vehicle||!parkData.some(v=>same(v.registration,r.vehicle)))add('Cartes Rungis',`Carte ${r.cardNumber||'sans numéro'} : véhicule ${r.vehicle||'non renseigné'} absent du parc.`);});
 const seen=new Set();return result.filter(x=>{const k=x.section+'|'+x.text;if(seen.has(k))return false;seen.add(k);return true;});
};
$('qualityActionToolbar')?.append(btn('Exporter les anomalies',()=>csv('Controle_donnees',[['Priorité','Section','Anomalie'],...dashboardDataIssues().map(x=>[x.level==='high'?'Critique':'À vérifier',x.section,x.text])])));

// One shared filter predicate for the order table and its scoped totals/export.
const fuelTools=document.createElement('div');fuelTools.className='pilot-toolbar';
fuelTools.innerHTML='<label>Fournisseur<select id="pilotSupplier"><option value="">Tous</option></select></label><label>Du<input type="date" id="pilotFrom"></label><label>Au<input type="date" id="pilotTo"></label><label>Produit<select id="pilotProduct"><option value="">Tous</option><option value="diesel">Gasoil</option><option value="gnr">GNR</option><option value="adblue">AdBlue</option></select></label>';
$('fuelSearch').closest('.fuel-tools').after(fuelTools);
const fuelSummary=document.createElement('div');fuelSummary.id='pilotFuelSummary';fuelSummary.className='pilot-summary';fuelSummary.setAttribute('aria-live','polite');fuelTools.after(fuelSummary);
window.dashboardFuelMatches=f=>{const date=f.deliveryDate||f.orderDate||'';return (!$('pilotSupplier').value||f.supplier===$('pilotSupplier').value)&&(!$('pilotFrom').value||date>=$('pilotFrom').value)&&(!$('pilotTo').value||(!!date&&date<=$('pilotTo').value))&&(!$('pilotProduct').value||num(f[$('pilotProduct').value+'Qty'])>0);};
const filteredFuel=()=>fuelEntries.filter(f=>dashboardFuelMatches(f)&&fuelNorm([f.supplier,f.orderDate,f.deliveryDate,f.dieselQty,f.gnrQty,f.adblueQty,f.dieselPrice,f.gnrPrice,f.adbluePrice].join(' ')).includes(fuelNorm(fuelSearch.value))).sort((a,b)=>String(b.deliveryDate||b.orderDate||'').localeCompare(String(a.deliveryDate||a.orderDate||''))||String(a.supplier||'').localeCompare(String(b.supplier||''),'fr',{sensitivity:'base'}));
function fuelTotals(rows){let cost=0,litres=0,missing=0;rows.forEach(f=>['diesel','gnr','adblue'].forEach(k=>{const qty=num(f[k+'Qty']),price=fuelNumber(f[k+'Price']);litres+=qty;if(qty>0&&price===null)missing++;cost+=qty*(price||0)/1000;}));return {cost,litres,missing};}
function fuelRefresh(){
 const selected=$('pilotSupplier').value;const suppliers=[...new Set(fuelEntries.map(f=>f.supplier).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'fr'));
 $('pilotSupplier').innerHTML='<option value="">Tous</option>'+suppliers.map(s=>`<option value="${esc(s)}">${esc(s)}</option>`).join('');$('pilotSupplier').value=selected;
 const rows=filteredFuel(),totals=fuelTotals(rows);fuelSummary.textContent=$('pilotFrom').value&&$('pilotTo').value&&$('pilotFrom').value>$('pilotTo').value?'La date de début doit précéder la date de fin.':`${rows.length} commandes · ${totals.litres.toLocaleString('fr-FR')} L · Coût renseigné : ${money(totals.cost)}${totals.missing?' · '+totals.missing+' prix manquant(s)':''} · Date utilisée : livraison, sinon commande. Le filtre produit sélectionne les commandes qui contiennent ce produit.`;
}
window.dashboardFuelReset=()=>{['pilotSupplier','pilotFrom','pilotTo','pilotProduct'].forEach(id=>$(id).value='');};
fuelTools.append(btn('Réinitialiser',()=>{dashboardFuelReset();fuelSearch.value='';renderFuelTable();}),btn('Exporter la sélection',()=>{const d=datasets().find(d=>d.name==='Carburant');csv('Commandes_carburant',[Object.values(d.fields),...filteredFuel().map(f=>Object.keys(d.fields).map(k=>f[k]))]);}),btn('Imprimer / PDF',()=>dashboardDaily.printPage($('fuelTableWrap'),'Commandes carburant — sélection affichée')));
fuelTools.querySelectorAll('input,select').forEach(el=>el.onchange=()=>renderFuelTable());
const searchShortcut=btn('Recherche complète',()=>{globalSearchActiveIndex=-1;$('globalSearch').dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',bubbles:true}));});searchShortcut.classList.add('pilot-search-shortcut');$('globalSearch').parentElement.after(searchShortcut);
const baseFuel=renderFuelTable;renderFuelTable=function(){const result=baseFuel.apply(this,arguments);fuelRefresh();return result;};

// A separate read-only workspace: no edit controls and no writes to business data.
const consultation=dialog('pilotConsultation','Consultation du dashboard');
const note=document.createElement('p');note.textContent='Lecture seule : recherches et exports. Fermez cette fenêtre pour revenir à la gestion. Ce mode ne remplace pas les droits du dossier partagé.';
const cTools=document.createElement('div');cTools.className='pilot-toolbar';const cSelect=document.createElement('select');cSelect.setAttribute('aria-label','Liste à consulter');datasets().forEach(d=>cSelect.add(new Option(d.name,d.name)));
const cSearch=document.createElement('input');cSearch.type='search';cSearch.placeholder='Rechercher dans cette liste';cSearch.setAttribute('aria-label','Rechercher dans la consultation');const cBody=document.createElement('div');
function consultationRows(){const d=datasets().find(d=>d.name===cSelect.value);return {d,rows:d.rows.filter(r=>Object.keys(d.fields).some(k=>norm(r[k]).includes(norm(cSearch.value))))};}
function renderConsultation(){const {d,rows}=consultationRows();cBody.innerHTML=`<p>${rows.length} lignes · données actuellement chargées</p>`+table(Object.values(d.fields),rows.map(r=>Object.keys(d.fields).map(k=>r[k])));}
cSelect.onchange=()=>{cSearch.value='';renderConsultation();};cSearch.oninput=renderConsultation;
cTools.append(cSelect,cSearch,btn('Exporter',()=>{const {d,rows}=consultationRows();csv(d.name,[Object.values(d.fields),...rows.map(r=>Object.keys(d.fields).map(k=>r[k]))]);}),btn('Imprimer / PDF',()=>dashboardDaily.printPage(cBody,cSelect.value)));
consultation.append(note,cTools,cBody);

// Manager overview, with explicit units and scope.
const manager=document.createElement('section');manager.className='card pilot-manager';manager.id='pilotManager';
manager.innerHTML='<header><div><h2>Vue responsable</h2><p>Parc et actions en cours · dépenses sur le mois choisi</p></div><label>Mois<input type="month" id="pilotMonth"></label></header><div id="pilotManagerKpis" class="pilot-grid"></div><p id="pilotManagerNote"></p><div class="pilot-toolbar" id="pilotManagerActions"></div>';
$('dailyBackup').after(manager);
const legend=document.createElement('p');legend.className='pilot-legend';legend.innerHTML='<span class="daily-status" data-daily-tone="ok">À jour</span> <span class="daily-status" data-daily-tone="warn">À vérifier</span> <span class="daily-status" data-daily-tone="urgent">Urgent</span> <span class="daily-status" data-daily-tone="info">Information / inactif</span>'; $('dailyHome').append(legend);$('pilotMonth').value=today().slice(0,7);
let managerRows=[];
function refreshManager(){const month=$('pilotMonth').value;const fuel=fuelTotals(fuelEntries.filter(f=>String(f.deliveryDate||f.orderDate||'').startsWith(month)));const fines=adminFines.filter(f=>String(f.date||'').startsWith(month)).reduce((s,f)=>s+num(f.amount),0);const actions=dashboardDaily.attention();const tractors=parkData.filter(v=>v.type==='Tracteur');const assigned=tractors.filter(v=>affectations.some(a=>same(a.tractor,v.registration))).length;
 managerRows=[['Tracteurs affectés',assigned+' / '+tractors.length],['Actions urgentes',actions.filter(a=>a.tone==='urgent').length],['Sinistres ouverts',claimData.filter(c=>norm(c.status)!=='clos').length],['Anomalies à vérifier',dashboardDataIssues().length],['Carburant · coût renseigné',money(fuel.cost)],['Amendes · montants enregistrés',money(fines)]];
 $('pilotManagerKpis').innerHTML=managerRows.map(([label,value])=>`<div><small>${esc(label)}</small><strong>${esc(value)}</strong></div>`).join('');$('pilotManagerNote').textContent=`Mois : ${month||'toutes dates'}. Les coûts carburant sont calculés avec les quantités et prix saisis en €/1 000 L.${fuel.missing?' '+fuel.missing+' prix manquant(s) : coût partiel.':''} Les amendes incluent tous les statuts du mois.`;
}
$('pilotMonth').onchange=refreshManager;
$('pilotManagerActions').append(btn('Consultation seule',()=>{renderConsultation();consultation.showModal();}),btn('Exporter la synthèse',()=>{refreshManager();csv('Synthese_responsable',[['Mois','Indicateur','Valeur'],...managerRows.map(r=>[$('pilotMonth').value,...r])]);}),btn('Rechercher partout',()=>searchShortcut.click()));

// Easy access to the existing backup list, restoration and printable exports.
$('dailyBackup').append(btn('Voir les sauvegardes / restaurer',async()=>{if(!await adminSecurityRequestAccess())return;showView('administrateur','Administrateur','administrateur');$('admin-tab-backups').click();await dashboardRefreshBackupList();}));
[['exportDriversCsv','chauffeur','Chauffeurs'],['fuelTableWrap','carburant','Carburant'],['claimTable','sinistre','Sinistres']].forEach(([id,root,title])=>{const target=$(id);if(target&&title!=='Carburant'){const b=btn('Imprimer / PDF',()=>dashboardDaily.printPage($(root),title));if(target.tagName==='TBODY')target.closest('.table-wrap,table').before(b);else target.after(b);}});

// Vehicle chronology joins dated records with the recorded change history.
const originalDossier=dashboardOpenVehicleDossier;
dashboardOpenVehicleDossier=function(registration){const result=originalDossier.apply(this,arguments);setTimeout(()=>{
 const host=$('vehicleDossierBody');if(!same(dashboardCurrentVehicleDossier,registration))return;
 const panel=host.querySelector('[data-vehicle-panel="history"]'),tab=host.querySelector('[data-vehicle-tab="history"]');if(!panel||!tab)return;
 const events=[];const add=(date,kind,detail)=>events.push({date:date||'',kind,detail});
 claimData.filter(x=>same(x.vehicle,registration)).forEach(x=>add(x.date,'Sinistre',`${x.number||'Sans numéro'} · ${x.status||'Sans statut'} · ${x.driver||''}`));
 adminFines.filter(x=>same(x.vehicle,registration)).forEach(x=>add(x.date,'Amende',`${x.reference||'Sans référence'} · ${x.status||''} · ${money(num(x.amount))}`));
 technicalDeadlines.filter(x=>same(x.registration,registration)).forEach(x=>{if(x.lastControl)add(x.lastControl,'Contrôle réalisé',x.label||x.category);if(x.nextControl)add(x.nextControl,'Échéance prévue',x.label||x.category);});
 const snapshot=affectations.filter(x=>same(x.tractor,registration)||same(x.semi,registration)).map(x=>x.name).join(', ');
 tab.onclick=async()=>{panel.textContent='Chargement de l’historique…';let log=[],state='';try{if(sharedConnected){log=(await administratorReadHistory({all:true})).filter(e=>norm(e.entity).includes(norm(registration))||norm(e.detail).includes(norm(registration)));}else state='Historique des modifications partagé non connecté.';}catch{state='Historique partagé indisponible. Les dossiers chargés restent visibles.';}
 if(!same(dashboardCurrentVehicleDossier,registration))return;
 const all=[...events,...log.map(e=>({date:e.timestamp,kind:e.action,detail:[e.user,e.detail].filter(Boolean).join(' · ')}))].sort((a,b)=>String(b.date).localeCompare(String(a.date)));
 panel.innerHTML=`<p>Affectation actuelle : ${esc(snapshot||'Non affecté')}. Les anciennes affectations apparaissent si elles ont été enregistrées dans le journal.</p><p>${esc(state||'Toutes les dates disponibles dans les dossiers et le journal partagé.')}</p>`+table(['Date','Événement','Détail'],all.map(e=>[e.date?new Date(e.date).toLocaleDateString('fr-FR'):'Sans date',e.kind,e.detail]));panel.prepend(btn('Exporter l’historique',()=>csv('Historique_'+norm(registration),[['Date','Événement','Détail'],...all.map(e=>[e.date,e.kind,e.detail])])));
 };
 },40);return result;};
function refresh(){fuelRefresh();refreshManager();if(consultation.open)renderConsultation();}
document.addEventListener('dashboard-navigation',refresh);window.addEventListener('dashboard-data-refreshed',refresh);
const baseHome=refreshHomeDashboard;refreshHomeDashboard=function(){const r=baseHome.apply(this,arguments);refreshManager();return r;};
window.dashboardPilotage={filteredFuel,fuelTotals,refreshManager,datasets,csv};
refresh();dashboardRenderQuality();
})();
